const assert=require('node:assert/strict'),fs=require('node:fs');
process.env.PLAYWRIGHT_BROWSERS_PATH||='C:/Users/18062/Documents/Codex/2026-10-24/wo/work/poker/qa/browsers';
const {webkit}=require('C:/Users/18062/Documents/Codex/2026-10-24/wo/work/poker/qa/node_modules/playwright-core');
const url=process.env.POKER_URL||'http://127.0.0.1:8792/';
(async()=>{const browser=await webkit.launch({headless:true});let p,q;try{
const a=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true}),b=await browser.newContext({viewport:{width:844,height:390},isMobile:true,hasTouch:true});p=await a.newPage();q=await b.newPage();const errors=[];for(const page of [p,q])page.on('pageerror',e=>errors.push(e.message));
await p.goto(new URL('multiplayer.html?mode=create',url).href);await p.locator('#name').fill('房主小王');await p.locator('#seats').selectOption('2');await p.locator('#bots').uncheck();await p.locator('#create').click();await p.locator('#room').waitFor({state:'visible'});const code=await p.locator('#room-code').textContent();
await q.goto(new URL('multiplayer.html?room='+code,url).href);await q.locator('#name').fill('朋友小李');await q.locator('#join').click();await q.locator('#room').waitFor({state:'visible'});await p.locator('#start').click();
for(const page of [p,q]){await page.waitForURL(/friend=1/);await page.waitForFunction(()=>window.PokerRoom?.getSnapshot()&&window.PthState?.handNum===1&&document.querySelector('#s-game.active'));await page.locator('#friend-loading').waitFor({state:'detached'});await page.locator('#boot-splash').waitFor({state:'detached'});}
fs.mkdirSync('pokerth/.runtime/native-room-qa',{recursive:true});await p.screenshot({path:'pokerth/.runtime/native-room-qa/portrait.png'});await q.screenshot({path:'pokerth/.runtime/native-room-qa/landscape.png'});
assert.equal(await p.locator('#g-seats .seat').count(),2);assert.equal(await q.locator('#g-seats .seat').count(),2);
for(const page of [p,q])assert.equal(await page.evaluate(()=>PokerRoom.getSnapshot().players.find(x=>x.id!==PokerRoom.getSnapshot().heroId).hole.length),0);
await q.reload();await q.waitForFunction(()=>window.PthState?.handNum===1&&window.PokerRoom?.getSnapshot()?.phase==='playing'&&document.querySelector('#s-game.active'));
for(let i=0;i<16;i++){
 const s=await p.evaluate(()=>PokerRoom.getSnapshot());if(s.phase!=='playing')break;
 const page=s.turn.playerId===s.heroId?p:q;await page.waitForFunction(()=>PokerRoom.getSnapshot().turn?.playerId===PokerRoom.getSnapshot().heroId&&PthState.turnPid===PthState.myId);
 const check=await page.evaluate(()=>PokerRoom.getSnapshot().turn.legal.canCheck);await page.locator('#g-actions .btn-action').filter({hasText:check?'过牌':'跟注'}).click();
 await p.waitForFunction(old=>PokerRoom.getSnapshot().turn?.turnId!==old,s.turn.turnId);await q.waitForFunction(old=>PokerRoom.getSnapshot().turn?.turnId!==old,s.turn.turnId);
}
for(const page of [p,q])await page.locator('#teaching-review-dialog[open]').waitFor();assert.equal(await q.locator('#teaching-next-hand').isDisabled(),true);assert.equal(await p.locator('#teaching-next-hand').isEnabled(),true);
const s=await p.evaluate(()=>PokerRoom.getSnapshot());assert.equal(s.phase,'review');assert.equal(s.board.length,5);assert.equal(s.report.players.reduce((n,x)=>n+x.net,0),0);
await p.locator('#teaching-next-hand').click();for(const page of [p,q])await page.waitForFunction(()=>PokerRoom.getSnapshot().handNumber===2&&PthState.handNum===2&&!document.getElementById('teaching-review-dialog').open);
await q.reload();await q.waitForFunction(()=>window.PthState?.handNum===2&&window.PokerRoom?.getSnapshot()?.phase==='playing');
assert.deepEqual(errors,[]);console.log(JSON.stringify({ok:true,checks:['waiting->same native table','two private hero views','native check/call to showdown','central review host-only next','reload hand 1 and 2','portrait and landscape','zero browser errors']}));
} catch(e){for(const [page,name] of [[p,'host'],[q,'guest']])if(page){console.log(name,await page.evaluate(()=>({url:location.href,text:document.body.innerText.slice(-1600),state:window.PthState&&{handNum:PthState.handNum,myId:PthState.myId,myTurn:PthState.myTurn,seats:PthState.seats,ws:PthState.ws?.readyState,connecting:PthState._connectingNow,status:document.querySelector("#status")?.textContent,nick:document.querySelector("#nick")?.value,mode:document.querySelector("#server-mode")?.value},snap:window.PokerRoom?.getSnapshot()?.turn})).catch(()=>null));await page.screenshot({path:'pokerth/.runtime/native-failure-'+name+'.png'}).catch(()=>{});}throw e;}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1});

