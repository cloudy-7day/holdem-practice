/* Real WebKit rotation regression. Run against an isolated local-server.cjs. */
const assert=require('node:assert/strict');
const fs=require('node:fs'),os=require('node:os'),path=require('node:path');
process.env.PLAYWRIGHT_BROWSERS_PATH ||= 'C:/Users/18062/Documents/Codex/2026-10-24/wo/work/poker/qa/browsers';
const {webkit}=require(process.env.PLAYWRIGHT_CORE_PATH||'C:/Users/18062/Documents/Codex/2026-10-24/wo/work/poker/qa/node_modules/playwright-core');
const url=process.env.POKER_URL||'http://127.0.0.1:8792/multiplayer.html';
const output=process.env.POKER_QA_OUTPUT||fs.mkdtempSync(path.join(os.tmpdir(),'poker-orientation-'));
fs.mkdirSync(output,{recursive:true});
async function state(page){return page.evaluate(async()=>{const config=await(await fetch('multiplayer-config.json')).json(),code=document.querySelector('#room-code').textContent,token=localStorage.getItem(`pokerth.friend.${code}`);return(await(await fetch(`${config.apiBase.replace(/\/$/,'')}/api/rooms/${code}`,{headers:{Authorization:`Bearer ${token}`}})).json()).snapshot;});}
async function geometry(page,width,height,label,acting=false){
 await page.setViewportSize({width,height});
 await page.waitForFunction(expected=>document.documentElement.dataset.phoneLayout===expected,width>height?'landscape':'portrait');
 await page.waitForTimeout(150);
 const g=await page.evaluate(()=>{const rect=e=>e.getBoundingClientRect().toJSON();return{width:innerWidth,height:innerHeight,scroll:Math.max(document.documentElement.scrollWidth,document.body.scrollWidth),table:rect(document.querySelector('.table-wrap')),controls:rect(document.querySelector('.controls')),seats:[...document.querySelectorAll('.seat')].map(rect),buttons:[...document.querySelectorAll('.controls button')].filter(e=>!e.disabled&&e.getBoundingClientRect().height).map(e=>({id:e.id,...rect(e)}))};});
 assert(g.scroll<=width+1,`${label}: horizontal overflow ${g.scroll}`);
 if(width>height){assert(g.table.right<=g.controls.left+2,`${label}: controls should sit right of table`);assert(g.controls.bottom<=height+1,`${label}: controls fit vertically`);}
 if(acting){assert(g.buttons.length>0,`${label}: enabled actions visible`);for(const b of g.buttons){assert(b.height>=44,`${label}: ${b.id} touch height`);assert(b.left>=-1&&b.right<=width+1,`${label}: ${b.id} fits width`);if(width>height)assert(b.top>=-1&&b.bottom<=height+1,`${label}: ${b.id} fits height`);}}
 await page.screenshot({path:path.join(output,`${label}.png`),fullPage:true});
 for(let i=0;i<g.seats.length;i++)for(let j=i+1;j<g.seats.length;j++){const a=g.seats[i],b=g.seats[j];assert(Math.min(a.right,b.right)-Math.max(a.left,b.left)<=1||Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top)<=1,`${label}: seats ${i}/${j} overlap ${JSON.stringify({a,b})}`);}
 return g;
}
(async()=>{const browser=await webkit.launch({headless:true}),errors=[],results=[];try{
 const contexts=await Promise.all([browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true}),browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true})]);
 const [host,friend]=await Promise.all(contexts.map(c=>c.newPage()));for(const p of [host,friend])p.on('pageerror',e=>errors.push(e.message));
 await host.goto(url);await host.locator('#create').waitFor({state:'visible'});await host.waitForFunction(()=>!document.querySelector('#create').disabled);
 await host.locator('#name').fill('旋转房主');await host.locator('#seats').selectOption('2');await host.locator('#bots').uncheck();await host.locator('#create').click();await host.locator('#room').waitFor({state:'visible'});
 const code=await host.locator('#room-code').textContent();const invitation=new URL(url);invitation.searchParams.set('room',code);await friend.goto(invitation.href);await friend.locator('#name').fill('旋转好友');await friend.waitForFunction(()=>!document.querySelector('#join').disabled);await friend.locator('#join').click();await friend.locator('#room').waitFor({state:'visible'});await host.locator('#start').click();await host.waitForFunction(()=>document.querySelector('#phase').textContent.includes('正在对局'));
 const first=await state(host),actor=first.turn.playerId===first.heroId?host:friend;await actor.locator('#amount').waitFor({state:'visible'});const before=await state(actor),draft=String(before.turn.legal.minRaiseTo+1);await actor.locator('#amount').fill(draft);
 for(const [w,h] of [[390,844],[844,390],[390,844],[667,375],[740,320]]){results.push(await geometry(actor,w,h,`two-${w}x${h}`,true));const after=await state(actor);assert.equal(after.code,before.code);assert.equal(after.heroId,before.heroId);assert.equal(after.handNumber,before.handNumber);assert.equal(after.turn.turnId,before.turn.turnId);assert.deepEqual(after.players.find(p=>p.id===after.heroId).hole,before.players.find(p=>p.id===before.heroId).hole);assert.equal(await actor.locator('#amount').inputValue(),draft,'rotation retains amount draft');}
 const nine=await contexts[0].newPage();nine.on('pageerror',e=>errors.push(e.message));await nine.goto(url);await nine.waitForFunction(()=>!document.querySelector('#create').disabled);await nine.locator('#name').fill('九人布局');await nine.locator('#seats').selectOption('9');await nine.locator('#bots').check();await nine.locator('#create').click();await nine.locator('#room').waitFor({state:'visible'});await nine.locator('#start').click();await nine.waitForFunction(()=>document.querySelectorAll('.seat').length===9);
 for(const [w,h] of [[390,844],[320,740],[844,390],[667,375],[740,320]])results.push(await geometry(nine,w,h,`nine-${w}x${h}`));
 assert.deepEqual(errors,[]);console.log(JSON.stringify({ok:true,screenshots:output,viewports:results.length,checks:['WebKit touch rotation','portrait and landscape hints','side controls','no horizontal overflow','nine distinct seats','enabled actions fit','room/seat/hand/cards/turn/draft preserved'],errors},null,2));
 }finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
