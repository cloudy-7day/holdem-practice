// Rotation now exercises the shared native table with nine seats.
require('./test-native-room-nine-browser.cjs');
