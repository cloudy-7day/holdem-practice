// Assemble a separate Cloudflare Pages mirror; the GitHub Pages output is read-only.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {build} from './build-pages.mjs';
const poker=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const MAX_ASSET=25*1024*1024;
function noSymlinkAncestors(target){
 let current=path.resolve(target);
 while(true){if(fs.existsSync(current)&&fs.lstatSync(current).isSymbolicLink())throw new Error('Symlinks are not allowed: '+current);const parent=path.dirname(current);if(parent===current)break;current=parent;}
}
function contains(parent,child){const rel=path.relative(parent,child);return rel===''||(!rel.startsWith('..'+path.sep)&&rel!=='..'&&!path.isAbsolute(rel));}
function validateArchiveUrl(url){if(typeof url!=='string'||!/^https:\/\/raw\.githubusercontent\.com\/cloudy-7day\/holdem-practice\/[a-f0-9]{40}\/source\.zip$/.test(url))throw new Error('Source archive must use the immutable public GitHub release URL');return url;}
export function assembleCloudflarePages(input,output,{gatewayPath=path.join(poker,'multiplayer','pages-gateway.mjs'),sourceArchiveUrl}={}){
 validateArchiveUrl(sourceArchiveUrl);
 input=path.resolve(input);output=path.resolve(output);gatewayPath=path.resolve(gatewayPath);
 if(contains(input,output)||contains(output,input))throw new Error('Input and output must not overlap');
 for(const target of [input,output,gatewayPath])noSymlinkAncestors(target);
 if(fs.existsSync(output))throw new Error('Output already exists; assembly never deletes a destination');
 const files=[];
 function collect(dir,relative=''){for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
  const rel=path.join(relative,entry.name),source=path.join(dir,entry.name);
  if(entry.isSymbolicLink())throw new Error('Symlinks are not allowed: '+source);
  if(entry.isDirectory())collect(source,rel);else if(entry.isFile()&&rel!=='source.zip'){
   if(fs.statSync(source).size>MAX_ASSET)throw new Error('Asset exceeds 25 MiB: '+rel);files.push({source,rel});
  }else if(!entry.isFile())throw new Error('Unsupported asset: '+source);
 }}
 collect(input);
 if(!fs.statSync(gatewayPath).isFile())throw new Error('Gateway must be a file');
 if(fs.statSync(gatewayPath).size>MAX_ASSET)throw new Error('Gateway exceeds 25 MiB');
 const configExists=files.some(file=>file.rel==='multiplayer-config.json');
 if(files.length+2+(configExists?0:1)>=20000)throw new Error('Pages mirror must contain fewer than 20000 files');
 const site=path.join(output,'holdem-practice');fs.mkdirSync(site,{recursive:true});
 for(const {source,rel} of files){const dest=path.join(site,rel);fs.mkdirSync(path.dirname(dest),{recursive:true});fs.copyFileSync(source,dest);}
 fs.writeFileSync(path.join(site,'multiplayer-config.json'),JSON.stringify({apiBase:''})+'\n');
 fs.writeFileSync(path.join(output,'_worker.js'),fs.readFileSync(gatewayPath,'utf8').replaceAll('__SOURCE_ARCHIVE_URL__',sourceArchiveUrl));
 fs.writeFileSync(path.join(output,'_routes.json'),JSON.stringify({version:1,include:['/','/api/*','/holdem-practice/source.zip'],exclude:[]},null,2)+'\n');
 // Check the final deployed tree as well as the input, including generated assets.
 let count=0;
 function validate(dir){for(const entry of fs.readdirSync(dir,{withFileTypes:true})){const file=path.join(dir,entry.name);if(entry.isDirectory())validate(file);else{if(fs.statSync(file).size>MAX_ASSET)throw new Error('Asset exceeds 25 MiB: '+file);count++;}}}
 validate(output);if(count>=20000)throw new Error('Pages mirror must contain fewer than 20000 files');
 return output;
}
export async function buildCloudflarePages(preview=false){
 const sourceArchiveUrl=validateArchiveUrl(process.env.POKER_SOURCE_ARCHIVE_URL||(preview?'https://raw.githubusercontent.com/cloudy-7day/holdem-practice/1b7f6b258080648f56291e2b5a5c834afcdbcd6a/source.zip':undefined));
 if(preview&&!process.env.POKER_SOURCE_ARCHIVE_URL)console.warn('Preview only: source archive points to an earlier public release; do not publish this preview.');
 const input=await build('/holdem-practice/',preview);
 const runtime=path.resolve(poker,'.runtime');
 const output=path.resolve(runtime,preview?'cloudflare-pages-preview':'cloudflare-pages');
 if(path.dirname(output)!==runtime||!['cloudflare-pages','cloudflare-pages-preview'].includes(path.basename(output)))throw new Error('Unsafe output path');
 noSymlinkAncestors(output);
 fs.rmSync(output,{recursive:true,force:true});
 assembleCloudflarePages(input,output,{sourceArchiveUrl});
 console.log(JSON.stringify({output,base:'/holdem-practice/',preview}));return output;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href){
 const args=process.argv.slice(2);if(args.some(arg=>arg!=='--preview'))throw new Error('Usage: node build-cloudflare-pages.mjs [--preview]');
 await buildCloudflarePages(args.includes('--preview'));
}
