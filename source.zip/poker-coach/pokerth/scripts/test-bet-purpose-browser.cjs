const {chromium,webkit}=require(process.env.PLAYWRIGHT_CORE_PATH||'playwright');
const assert=require('node:assert/strict');
(async()=>{
 const engine=process.env.BROWSER_ENGINE==='webkit'?webkit:chromium;
 const browser=await engine.launch(engine===chromium?{headless:true,executablePath:process.env.CHROME_PATH||'C:/Program Files/Google/Chrome/Application/chrome.exe'}:{headless:true});
 try{
  const page=await browser.newPage({viewport:{width:390,height:844}}),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto(process.env.POKER_URL||'http://127.0.0.1:8792/?lang=zh');
  await page.locator('#teaching-review-dialog').waitFor({state:'attached'});
  const cases=[['pair','9h 8c','Ks 9d 2c',1,40],['draw','Ah 7h','Kh 2h 9c',1,40],['air','Jh 7c','As 9d 2c',3,40],['bluff','Jh 7c','As 9d 2c 4h Qs',1,40],['big-draw','Ah 7h','Kh 2h 9c',1,900]];
  for(const fixture of cases){
   await page.evaluate(([name,h,b,count,paid])=>{
    const cards=s=>s.split(' ').map(c=>'23456789TJQKA'.indexOf(c[0])+13*'dhsc'.indexOf(c[1]));
    const context={playerId:1,gameState:b.split(' ').length===5?'river':'flop',hole:cards(h),board:cards(b),stack:1000,streetCommitted:0,currentBet:0,posFromButton:0,numPlayers:count+1,numActive:count+1,publicPlayers:Array.from({length:count+1},(_,i)=>({id:i+1,stack:1000,streetCommitted:0,committed:60,folded:false,allin:false})),legal:{bb:20,pot:120,callAmt:0,canRaise:true,minRaiseTo:20,maxRaiseTo:1000}};
    dispatchEvent(new CustomEvent('pth-teaching',{detail:{type:'complete',report:{handNumber:name,heroId:1,board:context.board,players:[{id:1,name:'你',hole:context.hole,net:-paid,folded:true}],winnerIds:[],canContinue:false,decisions:[{playerId:1,action:'bet',paid,totalStreetBet:paid,context}]}}}));
   },fixture);
   await page.locator('.tc-decision').waitFor();
   const text=await page.locator('.tc-decision').innerText(),name=fixture[0];
   assert.doesNotMatch(text,/先想想要不要下|先把这个决定想清楚|下之前桌上有|本轮加到 40/);
   if(name!=='big-draw')assert.match(text,/40 筹码.*三分之一.*小注/);
   if(name==='pair')assert.match(text,/较差|差牌/);
   if(name==='draw'){assert.match(text,/主动下注都可考虑/);assert.doesNotMatch(text,/需要改进/);}
   if(name==='air')assert.match(text,/所有对手都弃牌/);
   if(name==='bluff')assert.match(text,/被跟必输.*25%.*不是预测/);
   if(name==='big-draw')assert.match(text,/金额需要复核/);
   for(const width of [320,390]){
    await page.setViewportSize({width,height:844});
    assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth),width);
    assert.ok(await page.locator('#teaching-review-dialog').evaluate(e=>e.scrollWidth<=e.clientWidth+1));
   }
   console.log(name+': '+await page.locator('.tc-sizing').innerText());
  }
  assert.deepEqual(errors,[]);
  console.log('Bet-purpose review, draw size qualification and mobile layouts PASS');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;});
