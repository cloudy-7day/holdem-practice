const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
process.env.PLAYWRIGHT_BROWSERS_PATH||='C:/Users/18062/Documents/Codex/2026-10-24/wo/work/poker/qa/browsers';
const {webkit}=require('C:/Users/18062/Documents/Codex/2026-10-24/wo/work/poker/qa/node_modules/playwright-core');
const base=process.env.POKER_URL||'http://127.0.0.1:8792/';
const out=path.resolve(__dirname,'../.runtime/native-room-qa');fs.mkdirSync(out,{recursive:true});
(async()=>{const browser=await webkit.launch({headless:true});const pages=[],errors=[],checks=[];try{
 for(const viewport of [{width:390,height:844},{width:844,height:390}]){const c=await browser.newContext({viewport,isMobile:true,hasTouch:true});const p=await c.newPage();p.on('pageerror',e=>errors.push(e.message));pages.push(p);}
 const [host,guest]=pages;
 await host.goto(new URL('multiplayer.html?mode=create',base).href);await host.locator('#name').fill('九人测试房主');await host.locator('#seats').selectOption('9');await host.locator('#bots').check();await host.locator('#create').click();await host.locator('#room').waitFor({state:'visible'});const code=await host.locator('#room-code').textContent();
 await guest.goto(new URL('multiplayer.html?room='+code,base).href);await guest.locator('#name').fill('九人测试朋友');await guest.locator('#join').click();await guest.locator('#room').waitFor({state:'visible'});await host.locator('#start').click();
 const ready=async p=>{await p.waitForURL(/friend=1/);await p.waitForFunction(()=>window.PokerRoom?.getSnapshot()&&window.PthState?.handNum===PokerRoom.getSnapshot().handNumber&&document.querySelector('#s-game.active'));await p.locator('#friend-loading').waitFor({state:'detached'});};
 for(const p of pages)await ready(p);
 const snap=p=>p.evaluate(()=>{const s=PokerRoom.getSnapshot();return {phase:s.phase,hand:s.handNumber,heroId:s.heroId,turn:s.turn,players:s.players.map(x=>({id:x.id,isBot:x.isBot,folded:x.folded,streetCommitted:x.streetCommitted})),events:s.nativeEvents?.map(e=>({id:e.id,type:e.type,playerId:e.playerId,action:e.action,totalStreetBet:e.totalStreetBet}))};});
 async function layout(p,name){await p.locator('#boot-splash').waitFor({state:'detached'});await p.waitForFunction(()=>{const seats=[...document.querySelectorAll('#g-seats .seat')],ids=PokerRoom.getSnapshot().players.map(x=>x.id).sort((a,b)=>a-b);return seats.length===9&&JSON.stringify(seats.map(e=>Number(e.dataset.pid)).sort((a,b)=>a-b))===JSON.stringify(ids)&&seats.every(e=>e.getBoundingClientRect().width>0&&getComputedStyle(e).visibility!=='hidden'&&getComputedStyle(e).display!=='none');});await p.waitForTimeout(600);const r=await p.evaluate(()=>{const rect=e=>{const r=e.getBoundingClientRect();return {x:r.x,y:r.y,w:r.width,h:r.height};};return {width:innerWidth,height:innerHeight,scroll:document.documentElement.scrollWidth,seats:[...document.querySelectorAll('#g-seats .seat')].map(rect),actions:rect(document.querySelector('#g-actions'))};});assert.equal(r.seats.length,9);assert.ok(r.scroll<=r.width+1,'horizontal page overflow');for(const s of r.seats)assert.ok(s.x>=-1&&s.y>=-1&&s.x+s.w<=r.width+1&&s.y+s.h<=r.height+1,JSON.stringify({name,seat:s,viewport:[r.width,r.height]}));assert.ok(r.actions.y+r.actions.h<=r.height+1,'action bar below viewport');await p.screenshot({path:path.join(out,name+'.png')});}
 await layout(host,'nine-portrait');await layout(guest,'nine-landscape');const initial=await snap(host);assert.equal(initial.players.filter(x=>x.isBot).length,7);checks.push('nine seats, two humans and seven bots, mobile bounds');
 for(const p of pages)assert.equal(await p.evaluate(()=>PokerRoom.getSnapshot().players.filter(x=>x.id!==PokerRoom.getSnapshot().heroId).reduce((n,x)=>n+x.hole.length,0)),0);
 let raised=false,rotated=false,reloaded=false,folded=false;
 for(let i=0;i<120;i++){
  const s=await snap(host);if(s.phase!=='playing')break;
  const p=s.turn?.playerId===s.heroId?host:(s.turn?.playerId===(await snap(guest)).heroId?guest:null);if(!p){await host.waitForTimeout(200);continue;}
  try{await p.waitForFunction(()=>PthState.turnPid===PthState.myId&&PokerRoom.getSnapshot().turn?.playerId===PokerRoom.getSnapshot().heroId,null,{timeout:2000});}catch{continue;}
  let t=await snap(p);
  if(!reloaded){const h=t.hand,id=t.heroId;await p.reload();await ready(p);t=await snap(p);assert.equal(t.hand,h);assert.equal(t.heroId,id);reloaded=true;checks.push('refresh resumes current hand and identity');}
  if(!raised&&t.turn.legal.canRaise&&t.turn.streetCommitted>0){
   const input=p.locator('#raise-amt');await input.waitFor();const amount=await input.inputValue();assert.ok(Number(amount)>0);
   if(!rotated){const before=await p.evaluate(()=>({hand:PthState.handNum,cards:JSON.stringify(PthState.myCards),turn:PokerRoom.getSnapshot().turn.turnId,value:document.querySelector('#raise-amt').value}));const v=p.viewportSize();await p.setViewportSize({width:v.height,height:v.width});await p.waitForTimeout(350);assert.deepEqual(await p.evaluate(()=>({hand:PthState.handNum,cards:JSON.stringify(PthState.myCards),turn:PokerRoom.getSnapshot().turn.turnId,value:document.querySelector('#raise-amt').value})),before);await layout(p,'nine-rotated');rotated=true;checks.push('rotation retains hand, cards, turn and raise draft');}
   const increment=Number(await input.inputValue()),committed=t.turn.streetCommitted;
   await p.locator('#g-actions .btn-raise').click();await p.waitForFunction(old=>PokerRoom.getSnapshot().turn?.turnId!==old,t.turn.turnId);
   const after=await snap(p),ev=after.events.filter(e=>e.type==='actionDone'&&e.playerId===t.heroId).at(-1);assert.ok(ev,'raise event');assert.equal(ev.action,'raise');assert.equal(ev.totalStreetBet,committed+increment);raised=true;checks.push('native raise increment becomes server total');continue;
  }
  const shouldFold=raised;await p.locator('#g-actions '+(shouldFold?'.btn-fold':'.btn-call')).click();await p.waitForFunction(old=>PokerRoom.getSnapshot().turn?.turnId!==old,t.turn.turnId);if(shouldFold)folded=true;
 }
 for(const p of pages)await p.locator('#teaching-review-dialog[open]').waitFor({timeout:45000});
 assert.ok(raised&&rotated&&reloaded&&folded);assert.equal((await snap(host)).phase,'review');assert.equal(await guest.locator('#teaching-next-hand').isDisabled(),true);assert.equal(await host.locator('#teaching-next-hand').isEnabled(),true);assert.equal(await host.evaluate(()=>PokerRoom.getSnapshot().report.players.reduce((n,p)=>n+p.net,0)),0);checks.push('folded humans continue watching bots to review, conserved chips, host-only next');
 await host.screenshot({path:path.join(out,'nine-review.png')});assert.deepEqual(errors,[]);console.log(JSON.stringify({ok:true,checks}));
 }catch(e){for(let i=0;i<pages.length;i++)await pages[i].screenshot({path:path.join(out,'nine-failure-'+i+'.png')}).catch(()=>{});throw e;}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});


