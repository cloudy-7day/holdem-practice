// Build the existing training client as a subdirectory-safe static Pages site.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {execFileSync} from 'node:child_process';
import config from '../teaching-config.cjs';
import {bundlePages} from './bundle-pages.mjs';
const here=path.dirname(fileURLToPath(import.meta.url)),poker=path.resolve(here,'..'),repo=path.resolve(poker,'..');
export function rewritePaths(text,base,roots){
 const names=roots.map(x=>x.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|');
 const re=new RegExp('([\x22\x27\x60(])/((?:'+names+')(?=[/\\?\x22\x27\x60)#]|$))','g');
 return text.replace(re,(_,quote,name)=>quote+base+name);
}
export function staticManifest(manifest,base){
 const out={...manifest,name:'德州扑克中文练习',short_name:'德州练习',description:'与电脑练习德州扑克，每手结束后用中文复盘。仅虚拟筹码。',start_url:base+'?lang=zh',id:base,scope:base};
 out.icons=(manifest.icons||[]).map(icon=>({...icon,src:icon.src.startsWith('/')?base+icon.src.slice(1):icon.src}));
 for(const key of ['share_target','scope_extensions','file_handlers','protocol_handlers'])delete out[key];
 return out;
}
export async function build(base='/holdem-practice/',preview=false){
 if(!/^\/[a-zA-Z0-9_-]+\/$/.test(base))throw new Error('Use a single project path, e.g. /holdem-practice/');
 const output=path.join(poker,'.runtime',preview?'pages-preview':'pages',base.slice(1,-1)),publicDir=path.join(poker,'public');
 const status=execFileSync('git',['status','--porcelain','--untracked-files=normal'],{cwd:repo,encoding:'utf8'}).trim();
 if(status&&!preview)throw new Error('Commit source changes before publishing so source.zip matches this build.');
 // Delete only this validated, generated directory, never a checkout or symlink.
 const allowed=path.resolve(poker,'.runtime',preview?'pages-preview':'pages');
 if(path.dirname(output)!==allowed||path.basename(output)!==base.slice(1,-1))throw new Error('Unsafe output path');
 if(fs.existsSync(output)&&fs.lstatSync(output).isSymbolicLink())throw new Error('Output must not be a symlink');
 fs.rmSync(output,{recursive:true,force:true});fs.mkdirSync(output,{recursive:true});
 const roots=fs.readdirSync(publicDir).concat(['LICENSE','SOURCE.md']);
 const textTypes=new Set(['.html','.js','.mjs','.css','.json','.svg']);
 let count=0;
 function copy(dir,dest){fs.mkdirSync(dest,{recursive:true});for(const entry of fs.readdirSync(dir,{withFileTypes:true})){
  const from=path.join(dir,entry.name),to=path.join(dest,entry.name);
  if(entry.isDirectory())copy(from,to);else if(entry.isFile()){
   if(textTypes.has(path.extname(entry.name)))fs.writeFileSync(to,rewritePaths(fs.readFileSync(from,'utf8'),base,roots));else fs.copyFileSync(from,to);count++;
  }
 }}
 copy(publicDir,output);
 const revision=execFileSync('git',['rev-parse','HEAD'],{cwd:repo,encoding:'utf8'}).trim();
 const staticConfig={...config,featureOff:[...config.featureOff,'err_report']};
 let bootstrap=fs.readFileSync(path.join(here,'static-host.template.js'),'utf8').replace('__BASE_JSON__',JSON.stringify(base)).replace('__CONFIG_JSON__',JSON.stringify(staticConfig)).replace('__REVISION_JSON__',JSON.stringify(revision));
 fs.writeFileSync(path.join(output,'static-host.js'),bootstrap);
 let html=fs.readFileSync(path.join(output,'pokerth-client.html'),'utf8');
 html=html.replace('<head>','<head>\n<script src="'+base+'static-host.js"></script>');
 html=html.replace('</body>','<span id="tc-public-source"><a href="'+base+'source.zip" download>下载完整源代码</a> · <a href="'+base+'SOURCE.md">来源与许可</a></span><style>#tc-public-source{position:fixed;bottom:5px;left:10px;z-index:20;font:12px system-ui;color:#cbbd82}#tc-public-source a{color:inherit}body.tc-active #tc-public-source{display:none}</style>\n</body>');
 // The bundle owns mobile.mjs; leave the early boot settings/CSS in place.
 const early=path.join(output,'teaching-boot.js');
 fs.writeFileSync(early,fs.readFileSync(early,'utf8').replace(/import\([^;]*mobile\.mjs['"]\);?/,''));
 const bundled=await bundlePages(output,base,html);html=bundled.html;
 html=html.replace(/var CRIT = \[[\s\S]*?  var done =/, 'var CRIT = '+JSON.stringify([base+'pokerth.css',bundled.entryPath])+';\n  var done =');
 fs.writeFileSync(path.join(output,'pokerth-client.html'),html);fs.writeFileSync(path.join(output,'index.html'),html);
 fs.writeFileSync(path.join(output,'manifest.json'),JSON.stringify(staticManifest(JSON.parse(fs.readFileSync(path.join(publicDir,'manifest.json'),'utf8')),base),null,2));
 fs.copyFileSync(path.join(poker,'LICENSE'),path.join(output,'LICENSE'));
 fs.writeFileSync(path.join(output,'SOURCE.md'),'# 中文教学网页版：源码与许可\n\n本网站是 PokerTH 的非官方教学改编，仅使用虚拟筹码。\n\n[下载本次发布对应的完整源码](./source.zip) · [AGPL-3.0-or-later 许可证](./LICENSE)\n\n构建提交：`'+revision+'`。源代码包括本地启动器、静态网站构建脚本、修改后的游戏引擎和复盘模块。单人练习与复盘在浏览器中计算；好友桌由源码内的 Cloudflare 房间服务同步，无 AI API 密钥。\n\n'+fs.readFileSync(path.join(poker,'SOURCE.md'),'utf8'));
 fs.writeFileSync(path.join(output,'README.md'),'# 德州扑克中文练习\n\n[直接试玩](https://holdem-practice-cloudy-7day.pages.dev'+base+'?lang=zh)\n\n九人电脑牌桌、好友房间联机、中文逐次决策复盘、手动下一手、手机适配。无需注册，只用虚拟筹码。\n\n[完整对应源码](./source.zip) · [来源与许可](./SOURCE.md)\n');
 fs.writeFileSync(path.join(output,'.nojekyll'),'');
 if(!preview)execFileSync('git',['archive','--format=zip','--prefix=poker-coach/','--output='+path.join(output,'source.zip'),'HEAD'],{cwd:repo});
 console.log(JSON.stringify({output,base,revision,files:count}));return output;
}
if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href)await build(process.argv[2],process.argv.includes('--preview'));
