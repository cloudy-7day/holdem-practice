const {chromium}=require(process.env.PLAYWRIGHT_CORE_PATH || 'playwright');
const assert=require('node:assert/strict');
(async()=>{const browser=await chromium.launch({executablePath:process.env.CHROME_PATH || (process.platform==='win32'?'C:/Program Files/Google/Chrome/Application/chrome.exe':undefined),headless:true});try{
 const page=await browser.newPage({viewport:{width:1000,height:900}}),errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(process.env.POKER_URL || 'http://127.0.0.1:8787/?lang=zh');await page.locator('#teaching-review-dialog').waitFor({state:'attached'});
 for(const mode of ['call','size','wrong-bet']){
  await page.evaluate(mode=>{
   const cs=s=>s.split(' ').map(c=>'23456789TJQKA'.indexOf(c[0])+13*'dhsc'.indexOf(c[1]));
   const context=mode==='call'?{playerId:1,gameState:'preflop',hole:cs('Ah Ac'),board:[],stack:2000,streetCommitted:20,currentBet:1194,posFromButton:2,numPlayers:2,numActive:2,publicPlayers:[{id:1,name:'你',stack:2000},{id:2,name:'小林',stack:2000}],publicHistory:[{playerId:2,street:'preflop',action:'raise',isAggressive:true,paid:1194,totalStreetBet:1194,potBefore:306}],legal:{bb:20,pot:1500,callAmt:1174,canRaise:true,minRaiseTo:2368,maxRaiseTo:2020}}:{playerId:1,gameState:mode==='size'?'turn':'river',hole:cs(mode==='size'?'Kh 9c':'8h 3c'),board:cs(mode==='size'?'9d Qs 2h Kd':'As Kd Qc Jh 9s'),stack:2000,streetCommitted:0,currentBet:0,posFromButton:0,numPlayers:2,numActive:2,legal:{bb:20,pot:200,callAmt:0,canRaise:true,minRaiseTo:20,maxRaiseTo:2000}};
   const paid=mode==='call'?1174:20,action=mode==='call'?'call':'bet';const report={handNumber:mode==='call'?1:2,heroId:1,board:context.board,players:[{id:1,name:'学习玩家',hole:context.hole,net:-paid,folded:true},{id:2,name:'小林',hole:cs('7s 7c'),net:paid,folded:false}],winnerIds:[2],canContinue:false,decisions:[{playerId:1,action,paid,totalStreetBet:context.streetCommitted+paid,context}]};
   dispatchEvent(new CustomEvent('pth-teaching',{detail:{type:'complete',report}}));
  },mode);
  await page.locator('.tc-decision').waitFor();
  const text=await page.locator('.tc-decision').innerText();
  if(mode==='call'){assert.match(text,/额外投入 1174 筹码/);assert.match(text,/小林.*1194 筹码/);assert.match(text,/还剩 826 筹码/);assert.equal(await page.locator('.tc-sizing').count(),0);}
  if(mode==='size'){assert.match(text,/100–150/);assert.match(text,/一半.*四分之三/);assert.match(text,/J.*10.*顺子/);assert.match(text,/Q.*J.*10/);assert.ok(await page.locator('.tc-size-basis').isVisible());}
  if(mode==='wrong-bet'){assert.match(text,/建议过牌/);assert.equal(await page.locator('.tc-size-basis').count(),0);}
  for(const width of [320,390]){await page.setViewportSize({width,height:844});await page.locator('.tc-decision').scrollIntoViewIfNeeded();assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth),width);assert.ok(await page.locator('#teaching-review-dialog').evaluate(el=>el.scrollWidth<=el.clientWidth+1));}
  console.log(mode+': '+text);
 }
 assert.deepEqual(errors,[]);console.log('Call amount, concrete range reasoning, action-first and mobile 320/390 PASS');
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
