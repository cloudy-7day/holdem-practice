import fs from 'node:fs/promises';
import path from 'node:path';
import { build } from 'esbuild';

/** Keep the original document order and global side effects, but fetch one ESM graph. */
export async function bundlePages(output, base, html) {
  const root = path.resolve(output);
  if (!/^\/[a-zA-Z0-9_-]+\/$/.test(base)) throw new Error('Invalid Pages base');
  const modules = [];
  const tags = /<script\b([^>]*)>\s*<\/script\s*>/gi;
  html = html.replace(tags, (tag, attrs) => {
    if (!/\btype\s*=\s*(["'])module\1/i.test(attrs)) return tag;
    const src = attrs.match(/\bsrc\s*=\s*(["'])(.*?)\1/i)?.[2];
    if (!src) return tag;
    if (/^(?:https?:)?\/\//i.test(src)) throw new Error('Remote module cannot be bundled: ' + src);
    modules.push(src.startsWith('/') ? src : base + src.replace(/^\.\//, ''));
    return '';
  });
  if (!modules.length) throw new Error('No module scripts found');
  const mobile = base + 'modules/teaching/mobile.mjs';
  if (!modules.includes(mobile)) modules.push(mobile);

  const result = await build({
    stdin: {
      contents: [...new Set(modules)].map(src => `import ${JSON.stringify(src)};`).join('\n'),
      resolveDir: root,
      sourcefile: 'pages-entry.mjs',
      loader: 'js',
    },
    absWorkingDir: root,
    outdir: path.join(root, 'bundles'),
    entryNames: 'app-[hash]',
    chunkNames: 'chunk-[hash]',
    bundle: true,
    splitting: true,
    format: 'esm',
    platform: 'browser',
    target: 'safari15.4',
    treeShaking: false,
    minify: true,
    metafile: true,
    // This is already a complete browser tree; do not search parent folders
    // for tsconfig/package resolution in restricted Windows workspaces.
    tsconfigRaw: {},
    plugins: [{
      name: 'pages-original-module-urls',
      setup(plugin) {
        plugin.onResolve({ filter: /^\.\.?\// }, args => {
          const resolved = path.resolve(args.resolveDir, args.path);
          if (!resolved.startsWith(root + path.sep)) throw new Error('Module escapes Pages output: ' + args.path);
          return { path: resolved };
        });
        plugin.onResolve({ filter: /^\// }, args => {
          const relative = args.path.startsWith(base) ? args.path.slice(base.length) : args.path.slice(1);
          const resolved = path.resolve(root, relative);
          if (!resolved.startsWith(root + path.sep)) throw new Error('Module escapes Pages output: ' + args.path);
          return { path: resolved };
        });
        plugin.onLoad({ filter: /\.(?:mjs|js)$/ }, async args => {
          const relative = path.relative(root, args.path).split(path.sep).join('/');
          const originalUrl = `new URL(${JSON.stringify(base + relative)}, location.href).href`;
          let contents = await fs.readFile(args.path, 'utf8');
          // Workers remain separately served modules, relative to the original source.
          contents = contents.replace(/\bimport\.meta\.url\b/g, originalUrl);
          // These imports are data catalogues, not stateful modules. Avoid esbuild's
          // glob import expansion, and retain their original directory at runtime.
          if (relative === 'modules/i18n.mjs') {
            contents = contents.replace('import(_langUrl(code, n))', `import(new URL(_langUrl(code, n), ${originalUrl}).href)`);
          } else if (relative === 'modules/guide/i18n.mjs') {
            contents = contents.replace("import('./lang/' + l + '.mjs')", `import(new URL('./lang/' + l + '.mjs', ${originalUrl}).href)`);
          } else if (relative === 'modules/guide/knowledge.mjs') {
            contents = contents.replace("import('../help/content/' + l + '.mjs')", `import(new URL('../help/content/' + l + '.mjs', ${originalUrl}).href)`);
          }
          return { contents, loader: 'js', resolveDir: path.dirname(args.path) };
        });
      },
    }],
  });
  const emitted = Object.entries(result.metafile.outputs);
  const entry = emitted.find(([, info]) => info.entryPoint === 'pages-entry.mjs');
  if (!entry) throw new Error('Bundled entry missing');
  const urlFor = file => base + path.relative(root, path.resolve(root, file)).split(path.sep).join('/');
  const entryPath = urlFor(entry[0]);
  const bundles = emitted.filter(([file]) => file.endsWith('.js')).map(([file]) => urlFor(file));
  html = html.replace(/<\/body\s*>/i, `<script type="module" src="${entryPath}"></script>\n</body>`);
  return { html, entryPath, bundles };
}
