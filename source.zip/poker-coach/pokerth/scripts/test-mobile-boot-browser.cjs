const {webkit,devices}=require(process.env.PLAYWRIGHT_CORE_PATH||'playwright');
const assert=require('node:assert/strict');
const url=process.env.POKER_URL||'http://127.0.0.1:8791/holdem-practice/?lang=zh';
(async()=>{const browser=await webkit.launch({headless:true});try{
 for(const mode of ['normal','slow','retry']){
  const page=await browser.newPage({...devices['iPhone 13'],userAgent:'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Mobile/15E148 MicroMessenger/8.0.50'});
  const errors=[],requests=[];let allow=mode!=='retry';page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>requests.push(r.url()));
  if(mode!=='normal')await page.route(/\/bundles\/app-[^/]+\.js/,async route=>{if(!allow)return route.abort();if(mode==='slow')await new Promise(resolve=>setTimeout(resolve,18000));try{await route.continue();}catch{}});
  await page.goto(url,{waitUntil:mode==='slow'?'commit':'domcontentloaded',timeout:60000});
  if(mode==='slow'){
   await page.waitForTimeout(14000);
   assert.equal(await page.locator('#bs-card').evaluate(el=>el.classList.contains('err')),false,'still downloading is not a failure');
   assert.match(await page.locator('#bs-msg').innerText(),/准备|加载|复盘/);
  }
  if(mode==='retry'){
   await page.locator('#bs-card.err').waitFor({timeout:15000});
   assert.match(await page.locator('#bs-error-msg').innerText(),/游戏还没加载完成/);
   allow=true;await page.locator('#bs-retry').click();
  }
  await page.waitForFunction(()=>window.App&&window.PokerOffline&&window.__pthLangReady!==false,{},{timeout:45000});
  await page.locator('#boot-splash').waitFor({state:'detached',timeout:15000});
  if(mode==='normal'){
   await page.locator('.login-card[onclick*="offline"]').click();await page.locator('#nick').fill('手机验证');await page.evaluate(()=>App.connect());
   await page.locator('button[onclick="App.createGame()"]').click();await page.waitForFunction(()=>window.PthState?.ws?._server?.table?.h);
   await page.evaluate(()=>{const s=PthState.ws._server,pace=s.pace;s.pace=(fn,ms)=>pace(fn,Math.min(ms||0,40));});
   await page.waitForFunction(()=>PokerTeaching.getState()?.type==='turn',{},{timeout:30000});await page.locator('#g-actions .btn-fold').click();
   await page.waitForFunction(()=>PokerTeaching.getState()?.type==='complete',{},{timeout:30000});await page.locator('.tc-main-advice').waitFor();
   assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth),390);
   assert.match(await page.locator('.tc-main-advice').innerText(),/建议/);
   assert.equal(await page.evaluate(()=>PokerTeaching.getState().report.players.length),9);
  }
  if(mode!=='retry')assert.deepEqual(errors,[]);
  console.log(JSON.stringify({mode,requests:requests.length,errors,passed:true}));await page.close();
 }
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
