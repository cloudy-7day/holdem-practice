import assert from 'node:assert/strict';
const base=process.env.POKER_API_URL||'http://127.0.0.1:8793';
async function req(path,body,token,status=200){const response=await fetch(base+'/api/rooms'+path,{method:body===undefined?'GET':'POST',headers:{Origin:'https://cloudy-7day.github.io',...(body===undefined?{}:{'Content-Type':'application/json'}),...(token?{Authorization:'Bearer '+token}:{})},...(body===undefined?{}:{body:JSON.stringify(body)})});assert.equal(response.status,status,await response.clone().text());return response.json();}
const a=await req('',{name:'联调甲',config:{maxPlayers:2,fillBots:false,turnSeconds:10}},null,201),code=a.snapshot.code;
const b=await req(`/${code}/join`,{name:'联调乙'},null,201),members=[a,b];
await req(`/${code}/command`,{type:'start'},b.token,403);
let state=(await req(`/${code}/command`,{type:'start'},a.token)).snapshot;
assert.equal(state.phase,'playing');
for(let count=0;count<80&&state.phase==='playing';count++){
 const member=members.find(m=>m.snapshot.heroId===state.turn.playerId);
 const s=(await req(`/${code}`,undefined,member.token)).snapshot;
 for(const p of s.players)assert.equal(p.hole.length,p.id===s.heroId?2:0);
 assert.ok(!('deck'in s));assert.equal(s.report,null);
 const command={type:'action',turnId:s.turn.turnId,action:s.turn.legal.canCheck?'check':'call'};
 state=(await req(`/${code}/command`,command,member.token)).snapshot;
 await req(`/${code}/command`,command,member.token,409);
}
assert.equal(state.phase,'review');assert.equal(state.board.length,5);
assert.equal(state.report.players.reduce((n,p)=>n+p.net,0),0);
for(const member of members){const s=(await req(`/${code}`,undefined,member.token)).snapshot;assert.equal(s.report.heroId,member.snapshot.heroId);assert.ok(s.report.decisions.some(d=>d.playerId===s.heroId));for(const d of s.report.decisions)assert.equal(!!d.context.hole,d.playerId===s.heroId);}
await req(`/${code}/command`,{type:'next'},b.token,403);
state=(await req(`/${code}/command`,{type:'next'},a.token)).snapshot;assert.equal(state.handNumber,2);
// Durable alarms must advance an unattended human deadline, not only active polling.
if(process.env.POKER_TEST_ALARM==='1'){
 const oldTurn=state.turn.turnId;
 await new Promise(resolve=>setTimeout(resolve,11500));
 state=(await req(`/${code}`,undefined,a.token)).snapshot;
 assert.notEqual(state.turn?.turnId,oldTurn);
}
console.log(JSON.stringify({backend:base,players:2,privacy:true,showdown:true,personalReviews:true,staleActionRejected:true,manualNext:true,alarm:process.env.POKER_TEST_ALARM==='1'}));
