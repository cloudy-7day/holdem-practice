const {chromium}=require(process.env.PLAYWRIGHT_CORE_PATH || 'playwright');
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');
const out=path.resolve(__dirname,'../.runtime/qa');fs.mkdirSync(out,{recursive:true});
(async()=>{const browser=await chromium.launch({executablePath:process.env.CHROME_PATH || 'C:/Program Files/Google/Chrome/Application/chrome.exe',headless:true});const errors=[],results=[];
try{for(const [width,height] of [[320,568],[390,844],[430,932],[844,390]]){
 const context=await browser.newContext({viewport:{width,height},isMobile:true,hasTouch:true,deviceScaleFactor:1});const p=await context.newPage();p.on('pageerror',e=>errors.push(e.message));
 await p.goto(process.env.POKER_URL || 'http://127.0.0.1:8787/?lang=zh');await p.waitForFunction(()=>window.App&&window.PokerOffline);
 assert.equal(await p.evaluate(()=>innerWidth),width,'viewport uses actual device width');
 await p.locator('.login-card[onclick*="offline"]').tap();await p.locator('#nick').fill('手机玩家');await p.evaluate(()=>App.connect());
 await p.locator('button[onclick="App.createGame()"]').waitFor({state:'visible'});
 assert.ok(await p.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),'setup has no horizontal overflow');
 await p.locator('button[onclick="App.createGame()"]').tap();await p.waitForFunction(()=>window.PthState?.ws?._server?.table?.h);
 await p.evaluate(()=>{const s=PthState.ws._server,pace=s.pace;s.pace=(fn,ms)=>pace(fn,Math.min(ms||0,35));});
 await p.waitForFunction(()=>PokerTeaching.getState()?.type==='turn',{}, {timeout:30000});await p.waitForFunction(()=>!document.querySelector('.fly-card'),{}, {timeout:10000});await p.waitForTimeout(200);
 const geometry=await p.evaluate(()=>{const rect=q=>document.querySelector(q).getBoundingClientRect().toJSON();return{width:innerWidth,scroll:document.documentElement.scrollWidth,hero:rect('.seat.me'),board:rect('#g-comm'),actions:rect('.my-zone'),buttons:[...document.querySelectorAll('#g-actions button')].filter(e=>e.getBoundingClientRect().height).map(e=>({text:e.textContent,r:e.getBoundingClientRect().toJSON()})),font:parseFloat(getComputedStyle(document.querySelector('.raise-amt-field')).fontSize)}});
 assert.ok(geometry.scroll<=width);assert.ok(geometry.board.bottom<=geometry.hero.top+1,'public and private cards do not overlap');assert.ok(geometry.font>=16);
 for(const btn of geometry.buttons){assert.ok(btn.r.height>=44,btn.text+' touch height');assert.ok(btn.r.left>=-1&&btn.r.right<=width+1&&btn.r.bottom<=height+1,btn.text+' inside screen');}
 await p.screenshot({path:path.join(out,`phone-${width}.png`)});
 await p.locator('.tc-experience-flyout>summary').tap();const settings=p.locator('#tc-table-experience');await settings.waitFor({state:'visible'});
 const sr=await settings.boundingBox();assert.ok(sr.x>=0&&sr.x+sr.width<=width+1);assert.ok(sr.y+sr.height<=height+1);
 await p.locator('.tc-settings-close').tap();assert.equal(await settings.isVisible(),false);
 if(width===390){await p.setViewportSize({width:844,height:390});await p.waitForTimeout(400);await p.setViewportSize({width,height});await p.waitForTimeout(400);}
 await p.locator('#g-actions .btn-fold').tap();await p.waitForFunction(()=>PokerTeaching.getState()?.type==='complete',{}, {timeout:45000});
 const dialog=p.locator('#teaching-review-dialog');await dialog.locator('.tc-main-advice').waitFor({state:'visible',timeout:30000});
 const review=await dialog.evaluate(e=>({r:e.getBoundingClientRect().toJSON(),scroll:e.scrollWidth,width:e.clientWidth}));assert.ok(review.r.left>=0&&review.r.right<=width+1&&review.r.bottom<=height+1);assert.ok(review.scroll<=review.width+1);
 assert.equal(await dialog.locator('.tc-net').count(),9);
 await p.screenshot({path:path.join(out,`phone-review-${width}.png`)});
 await p.locator('.tc-close').tap();await p.locator('#teaching-open-review').tap();assert.equal(await dialog.evaluate(e=>e.open),true);
 await p.locator('#teaching-next-hand').tap();await p.waitForFunction(()=>PokerTeaching.getState()?.type==='turn',{}, {timeout:30000});
 results.push({viewport:[width,height],buttons:geometry.buttons.length,reviewFits:true,touchNextHand:true});await context.close();
}
assert.deepEqual(errors,[]);console.log(JSON.stringify({results,errors},null,2));
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
