#!/usr/bin/env node
// Sampling audit of the production table's dealing, not a proof of randomness.
// Run: node pokerth/scripts/audit-deal-randomness.mjs [hands per mode]
import assert from 'node:assert/strict';
import { webcrypto } from 'node:crypto';
import { OfflineTable } from '../public/modules/offline/engine.mjs';

const hands = Number(process.argv[2] || 10000);
assert(Number.isSafeInteger(hands) && hands > 0, 'hands must be a positive integer');
const modes = [
  ['singleplayer (Math.random)', Math.random],
  ['multiplayer (crypto)', () => webcrypto.getRandomValues(new Uint32Array(1))[0] / 4294967296],
];
for (const [name, rng] of modes) {
  const players = Array.from({length: 9}, (_, id) => ({id, stack: 1000, in: true}));
  const table = new OfflineTable({players, rng, endRaiseMode: 3});
  const frequencies = players.map(() => Array(52).fill(0));
  const distinct = players.map(() => new Set());
  let pairs = 0;
  for (let i = 0; i < hands; i++) {
    // Reset stacks because this audit samples successive deals without betting.
    players.forEach(p => { p.stack = 1000; });
    table.nextHand();
    const hole = players.flatMap(p => table.h.hole[p.id]);
    const all = hole.concat(table.h.deck);
    assert.equal(all.length, 52);
    assert.equal(new Set(all).size, 52, `duplicate card on hand ${i + 1}`);
    assert(all.every(card => Number.isInteger(card) && card >= 0 && card < 52));
    for (const p of players) {
      const cards = table.h.hole[p.id];
      frequencies[p.id][cards[0]]++;
      distinct[p.id].add(cards.slice().sort((a, b) => a - b).join(','));
    }
    const hero = table.h.hole[0];
    if (hero[0] % 13 === hero[1] % 13) pairs++;
  }
  console.log(JSON.stringify({mode:name, hands, duplicateHands:0, heroPairs:pairs,
    heroPairPercent: +(100 * pairs / hands).toFixed(2), theoreticalPairPercent: +(100 / 17).toFixed(2),
    players:players.map(p => ({id:p.id, distinctHoleHands:distinct[p.id].size,
      firstCardMin:Math.min(...frequencies[p.id]), firstCardMax:Math.max(...frequencies[p.id])}))}, null, 2));
}
