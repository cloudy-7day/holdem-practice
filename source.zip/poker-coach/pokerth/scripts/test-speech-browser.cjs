const {chromium}=require(process.env.PLAYWRIGHT_CORE_PATH || 'playwright');
const assert=require('node:assert/strict');
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROME_PATH || (process.platform==='win32'?'C:/Program Files/Google/Chrome/Application/chrome.exe':undefined),headless:true});
 try{
  const page=await browser.newPage({viewport:{width:550,height:900}}),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto(process.env.POKER_URL || 'http://127.0.0.1:8787/?lang=zh');
  await page.waitForFunction(()=>window.App&&window.PokerOffline);
  await page.locator('.login-card[onclick*="offline"]').click();
  await page.locator('#nick').fill('气泡回归');await page.evaluate(()=>App.connect());
  await page.locator('button[onclick="App.createGame()"]').click();
  await page.waitForFunction(()=>window.PthState?.ws?._server?.table?.h);
  await page.evaluate(()=>{const server=PthState.ws._server,pace=server.pace;server.pace=(fn,ms)=>pace(fn,Math.min(ms||0,40));});
  await page.waitForFunction(()=>PokerTeaching.getState()?.type==='turn',{},{timeout:30000});
  // Hold the human turn. Reproduce the renderer replacing inline geometry while
  // a single action bubble remains visible; no second action event is emitted.
  for(const size of [{width:550,height:900},{width:390,height:844},{width:320,height:700},{width:900,height:450},{width:1200,height:900}]){
   await page.setViewportSize(size);
   await page.evaluate(()=>new Promise(resolve=>requestAnimationFrame(()=>requestAnimationFrame(resolve))));
   const result=await page.evaluate(async()=>{
    const seats=[...document.querySelectorAll('#g-seats .seat:not(.me)')];
    const speaker=seats[3],pid=Number(speaker.dataset.pid);
    dispatchEvent(new CustomEvent('pth-teaching',{detail:{type:'action',playerId:pid,playerName:'定位检查',action:'check',speech:'这句话只属于当前玩家。'}}));
    const bubble=document.querySelector('.tc-speech'),origin=bubble.getBoundingClientRect();
    const styles=seats.map(s=>s.getAttribute('style'));
    const samples=[];
    for(let repeat=0;repeat<3;repeat++){
     seats.forEach((s,i)=>{s.setAttribute('style',styles[i].replace(/--tc-seat-[xy]:[^;]*;?/g,''));s.innerHTML=s.innerHTML;});
     // Sample immediately after mutation observers, and across rendering frames.
     await new Promise(resolve=>setTimeout(resolve,0));
     for(let frame=0;frame<3;frame++){
      const rect=bubble.getBoundingClientRect();samples.push({x:rect.x,y:rect.y});
      await new Promise(resolve=>requestAnimationFrame(resolve));
     }
    }
    return {origin:{x:origin.x,y:origin.y},samples,count:document.querySelectorAll('.tc-speech').length,pid:bubble.dataset.pid,speaker:pid};
   });
   assert.equal(result.count,1,'one action has one bubble');assert.equal(Number(result.pid),result.speaker);
   for(const sample of result.samples){assert.ok(Math.abs(sample.x-result.origin.x)<2&&Math.abs(sample.y-result.origin.y)<2,`${size.width}px: bubble jumped from ${JSON.stringify(result.origin)} to ${JSON.stringify(sample)}`);}
  }
  assert.deepEqual(errors,[]);console.log('Speech stays at its speaker during seat redraw: 320/390/550/900 landscape/1200 PASS');
 }finally{await browser.close();}
})().catch(error=>{console.error(error);process.exitCode=1;});
