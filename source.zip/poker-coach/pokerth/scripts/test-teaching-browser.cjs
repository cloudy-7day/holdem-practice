const {chromium}=require(process.env.PLAYWRIGHT_CORE_PATH || 'playwright');
const fs=require('node:fs');const path=require('node:path');const artifacts=path.resolve(__dirname,'../.runtime/qa');fs.mkdirSync(artifacts,{recursive:true});const assert=require('node:assert/strict');
(async()=>{
 const b=await chromium.launch({executablePath:process.env.CHROME_PATH || (process.platform==='win32'?'C:/Program Files/Google/Chrome/Application/chrome.exe':undefined),headless:true});
 try{
 const p=await b.newPage({viewport:{width:1440,height:1000}});const errors=[],bad=[];
 p.on('pageerror',e=>errors.push(e.message));p.on('response',r=>{if(r.status()>=400)bad.push([r.status(),r.url()]);});
 await p.goto(process.env.POKER_URL || 'http://127.0.0.1:8787/?lang=zh');await p.waitForFunction(()=>window.App&&window.PokerOffline);
 await p.locator('.login-card[onclick*="offline"]').click();await p.locator('#nick').fill('学习玩家');await p.evaluate(()=>App.connect());
 await p.locator('button[onclick="App.createGame()"]').waitFor({state:'visible'});
 await p.locator('button[onclick="App.createGame()"]').click();
 await p.waitForFunction(()=>window.PthState?.ws?._server?.table?.h);
 // Accelerate only the server's future wall-clock delays for integration testing.
 await p.evaluate(()=>{const s=PthState.ws._server,pace=s.pace;s.pace=(fn,ms)=>pace(fn,Math.min(ms||0,35));});
 await p.waitForFunction(()=>PokerTeaching.getState()?.type==='turn',{},{timeout:30000});
 await p.waitForTimeout(250);
 await p.screenshot({path:path.join(artifacts,'hero-turn.png'),fullPage:true});
 const tableWidth=await p.locator('#s-game').evaluate(e=>e.getBoundingClientRect().width);assert.equal(Math.round(tableWidth),1440,'playing table uses full width');
 await p.locator('#g-actions .btn-fold').click();
 await p.waitForFunction(()=>PokerTeaching.getState()?.type==='complete',{},{timeout:45000});
 const report=await p.evaluate(()=>PokerTeaching.getState().report);
 assert.equal(report.players.length,9);assert.ok(report.players.every(p=>p.hole.length===2));assert.equal(report.players.find(p=>p.id===1).folded,true);
 assert.equal(report.players.reduce((s,p)=>s+p.net,0),0);assert.ok(report.winnerIds.length);
 const dialog=p.locator('#teaching-review-dialog');await dialog.locator('.tc-main-advice').waitFor({state:'visible',timeout:30000});
 await p.screenshot({path:path.join(artifacts,'review.png'),fullPage:true});
 const reviewText=await dialog.innerText();assert.match(reviewText,/你的每次决策/);assert.match(reviewText,/净输赢/);assert.match(reviewText,/这手为什么这样结算/);assert.doesNotMatch(reviewText,/下列仅为可能底牌|进入翻牌后，先看/);
 assert.equal(await dialog.locator('.tc-net').count(),report.players.length);assert.equal(await dialog.locator('.tc-main-advice .tc-decision').count(),report.decisions.filter(d=>d.playerId===1).length);
 assert.equal(await dialog.locator('.tc-main-advice .tc-suggestion').count(),report.decisions.filter(d=>d.playerId===1).length,'every decision displays its recommendation, including correct calls/checks');
 const lastStreet=report.decisions.at(-1)?.context.gameState;const expected=report.players.filter(p=>p.id===1||!p.folded||report.winnerIds.includes(p.id)||(lastStreet!=='preflop'&&report.decisions.some(d=>d.playerId===p.id&&d.context.gameState===lastStreet))).length;
 assert.equal(await dialog.locator(':scope > .tc-players .tc-player').count(),expected);
 const hand=await p.evaluate(()=>PthState.ws._server.table.handNum);
 await p.waitForTimeout(13500);assert.equal(await p.evaluate(()=>PthState.ws._server.table.handNum),hand,'native winner timer must not advance');
 await p.keyboard.press('Escape');assert.equal(await dialog.evaluate(e=>e.open),false);
 assert.equal(await p.evaluate(()=>PthState.ws._server.table.handNum),hand,'closing review does not advance');
 await p.locator('#teaching-open-review').click();assert.equal(await dialog.evaluate(e=>e.open),true);
 await p.locator('#teaching-next-hand').click();await p.waitForFunction(n=>PthState.ws._server.table.handNum===n+1,hand);
 await p.waitForFunction(()=>PokerTeaching.getState()?.type==='turn',{},{timeout:30000});
 // Play the next hand with calls/checks through the real client action path.
 for(let i=0;i<90;i++){
  if(await p.evaluate(()=>PokerTeaching.getState()?.type==='complete'))break;
  await p.evaluate(()=>{const s=PthState.ws._server;if(s._visibleTurn===1&&s.table.h._pendingId===1){const call=Math.min(s.table.players.find(p=>p.id===1).stack,s.table.h.currentBet-s.table.h.streetCommit[1]);App.doAction(call?3:2,call);}});
  await p.waitForTimeout(160);
 }
 const second=await p.evaluate(()=>PokerTeaching.getState());assert.equal(second.type,'complete');assert.ok(second.report.decisions.filter(d=>d.playerId===1).length>=1);
 await dialog.locator('.tc-main-advice').waitFor({state:'visible',timeout:30000});
 await p.setViewportSize({width:390,height:844});await p.waitForTimeout(300);await p.screenshot({path:path.join(artifacts,'mobile-review.png'),fullPage:true});
 const overflow=await p.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth,panel:document.getElementById('teaching-panel').getBoundingClientRect().toJSON()}));
 console.log(JSON.stringify({errors,bad,first:{board:report.board.length,actions:report.decisions.length,hero:report.decisions.filter(d=>d.playerId===1).length},second:{board:second.report.board.length,actions:second.report.decisions.length},overflow},null,2));
 fs.writeFileSync(path.join(artifacts,'e2e-report.json'),JSON.stringify({errors,bad,report,second,overflow},null,2));
 assert.deepEqual(errors,[]);
 }finally{await b.close();}
})();

