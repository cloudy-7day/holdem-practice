// Friends now use the native PokerTH table; keep the old test entry point.
require('./test-native-room-browser.cjs');
