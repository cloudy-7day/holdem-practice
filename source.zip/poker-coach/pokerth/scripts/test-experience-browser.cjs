const {chromium}=require(process.env.PLAYWRIGHT_CORE_PATH || 'playwright');
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path');const artifacts=path.resolve(__dirname,'../.runtime/qa');fs.mkdirSync(artifacts,{recursive:true});
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.CHROME_PATH || (process.platform==='win32'?'C:/Program Files/Google/Chrome/Application/chrome.exe':undefined),headless:true});
 try{
  const p=await browser.newPage({viewport:{width:1440,height:1000}});const errors=[],bad=[];
  p.on('pageerror',e=>errors.push(e.message));p.on('response',r=>{if(r.status()>=400)bad.push(r.url());});
  await p.goto(process.env.POKER_URL || 'http://127.0.0.1:8787/?lang=zh');await p.waitForFunction(()=>window.SOUNDS?.setSoundProfile&&window.App&&window.PokerOffline);
  await p.evaluate(()=>{window.__audioStarts=[];const create=AudioContext.prototype.createBufferSource;AudioContext.prototype.createBufferSource=function(){const s=create.call(this),start=s.start;s.start=function(...args){__audioStarts.push({duration:s.buffer?.duration,samples:s.buffer?.length,at:performance.now(),args});return start.apply(this,args);};return s;};});
  await p.locator('.login-card[onclick*="offline"]').click();await p.locator('#nick').fill('视听测试');await p.evaluate(()=>App.connect());
  const setup=p.locator('#tc-setup-experience');await setup.waitFor({state:'visible'});
  await p.waitForTimeout(600);await setup.locator('[data-sample="deal"]').click();await p.waitForTimeout(150);
  const decoded=await p.evaluate(()=>__audioStarts.filter(x=>x.samples>1000));assert.ok(decoded.length,'preview must use decoded real sample');
  await setup.locator('input[type=range]').evaluate(e=>{e.value='30';e.dispatchEvent(new Event('input',{bubbles:true}));});
  assert.equal(await p.evaluate(()=>SOUNDS.getSoundVolume()),.3);
  await setup.locator('select[id$="-motion"]').selectOption('0');assert.ok(await p.locator('html').evaluate(e=>e.classList.contains('tc-motion-off')));
  await setup.locator('.tc-sound-toggle').click();assert.equal(await p.evaluate(()=>SOUNDS.isSoundEnabled()),false);
  await p.reload();await p.waitForFunction(()=>window.SOUNDS?.getSoundVolume);
  assert.equal(await p.evaluate(()=>SOUNDS.isSoundEnabled()),false);assert.equal(await p.evaluate(()=>SOUNDS.getSoundVolume()),.3);
  // Reopen training; chosen preferences survive navigation and reload.
  if(await p.locator('.login-card[onclick*="offline"]').isVisible())await p.locator('.login-card[onclick*="offline"]').click();
  await p.locator('#nick').fill('视听测试');await p.evaluate(()=>App.connect());await setup.waitFor({state:'visible'});
  await setup.locator('select[id$="-profile"]').selectOption('original');assert.equal(await p.evaluate(()=>SOUNDS.getSoundProfile()),'original');
  await setup.locator('select[id$="-profile"]').selectOption('table');await setup.locator('select[id$="-motion"]').selectOption('1');
  await setup.locator('[data-sample="raise"]').click();assert.equal(await p.evaluate(()=>SOUNDS.isSoundEnabled()),true);
  await p.screenshot({path:path.join(artifacts,'settings.png'),fullPage:true});
  await p.locator('button[onclick="App.createGame()"]').click();await p.waitForFunction(()=>PthState.ws?._server?.table?.h);
  await p.waitForTimeout(3000);await p.screenshot({path:path.join(artifacts,'table-audio.png'),fullPage:true});
  const active=await p.locator('.seat.tc-turn').count();assert.equal(active,1);
  const style=await p.locator('.seat.tc-turn').evaluate(e=>({hasPlate:!!e.querySelector('.seat-plate'),outline:getComputedStyle(e.querySelector('.seat-plate')||e).outlineStyle}));
  await p.locator('.tc-experience-flyout > summary').click();
  const tableSettings=p.locator('#tc-table-experience');await tableSettings.locator('select[id$="-motion"]').selectOption('0');
  assert.ok(await p.locator('html').evaluate(e=>e.classList.contains('tc-motion-off')));
  await p.setViewportSize({width:390,height:844});await p.waitForTimeout(300);await p.screenshot({path:path.join(artifacts,'mobile-audio.png'),fullPage:true});
  const widths=await p.evaluate(()=>({view:innerWidth,doc:document.documentElement.scrollWidth}));assert.equal(widths.view,widths.doc);
  assert.deepEqual(errors,[]);assert.deepEqual(bad,[]);
  const result={decodedPreview:decoded,active,style,widths,errors,bad};fs.writeFileSync(path.join(artifacts,'audio-ui-results.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result,null,2));
 }finally{await browser.close();}
})();
