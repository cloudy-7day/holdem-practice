const assert=require('node:assert/strict'),fs=require('node:fs');
process.env.PLAYWRIGHT_BROWSERS_PATH||='C:/Users/18062/Documents/Codex/2026-10-24/wo/work/poker/qa/browsers';
const {webkit}=require('C:/Users/18062/Documents/Codex/2026-10-24/wo/work/poker/qa/node_modules/playwright-core');
(async()=>{const browser=await webkit.launch({headless:true});try{
 for(const scenario of ['ok','post-error','read-error','post-timeout']){
  const context=await browser.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true}),page=await context.newPage();let postCount=0,release;
  const pending=new Promise(resolve=>release=resolve),errors=[];page.on('pageerror',e=>errors.push(e.message));
  await page.addInitScript(()=>{const real=setTimeout;window.setTimeout=(fn,ms,...args)=>real(fn,ms===30000?1200:ms,...args);});
  await page.route('https://check.test/**',async route=>{
   const url=new URL(route.request().url());
   if(url.pathname.endsWith('connection-check.html'))return route.fulfill({contentType:'text/html',body:fs.readFileSync('pokerth/public/connection-check.html','utf8')});
   if(url.pathname.endsWith('multiplayer-config.json'))return route.fulfill({json:{apiBase:''}});
   if(url.pathname==='/api/rooms/config')return scenario==='read-error'?route.fulfill({status:503,contentType:'text/html',body:'unavailable'}):route.fulfill({json:{enabled:true}});
   if(url.pathname==='/api/rooms'){postCount++;assert.deepEqual(JSON.parse(route.request().postData()),{});if(scenario==='post-timeout'){await pending;return route.abort().catch(()=>{});}return scenario==='post-error'?route.abort('failed'):route.fulfill({status:400,json:{error:'昵称需要 1 至 24 个字'}});}
   return route.abort();
  });
  await page.goto('https://check.test/holdem-practice/connection-check.html');await page.waitForFunction(()=>!document.getElementById('run').disabled);
  const report=await page.locator('#report').inputValue();assert.equal(postCount,1);assert.deepEqual(errors,[]);
  assert.match(report,/网页配置：通过/);
  if(scenario==='ok')assert.match(report,/本次读写检测通过/);
  if(scenario==='post-error')assert.match(report,/提交房间请求：连接失败/);
  if(scenario==='post-timeout')assert.match(report,/提交房间请求：等待 30 秒/);
  if(scenario==='read-error')assert.match(report,/读取房间服务：HTTP 503/);
  assert.ok(await page.locator('#copy').isEnabled());release();await context.close();console.log('PASS',scenario);
 }
}finally{await browser.close();}})().catch(e=>{console.error(e);process.exitCode=1;});
