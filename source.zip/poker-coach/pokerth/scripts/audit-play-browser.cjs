// Six real client hands with a deliberately mixed teaching exercise policy.
const {chromium}=require(process.env.PLAYWRIGHT_CORE_PATH||'playwright');
const fs=require('node:fs');const assert=require('node:assert/strict');
const path=require('node:path');const root=path.resolve(__dirname,'../..');const artifacts=path.join(root,'pokerth/.runtime/qa');fs.mkdirSync(artifacts,{recursive:true});const label=process.argv[2]||'after';
const {execFileSync}=require('node:child_process');
const originals=label==='before'?Object.fromEntries(['offline/bots.mjs','teaching/analysis.mjs','teaching/equity.mjs'].map(f=>[f,execFileSync('git',['show','0040b4d:pokerth/public/modules/'+f],{cwd:root,encoding:'utf8'})])):{};
(async()=>{const browser=await chromium.launch({executablePath:process.env.CHROME_PATH||(process.platform==='win32'?'C:/Program Files/Google/Chrome/Application/chrome.exe':undefined),headless:true});const reports=[],errors=[];try{for(let i=0;i<6;i++){
const p=await browser.newPage({viewport:{width:1440,height:1000}});p.on('pageerror',e=>errors.push(e.message));for(const [f,body] of Object.entries(originals))await p.route('**/modules/'+f,route=>route.fulfill({status:200,contentType:'text/javascript',body}));await p.goto(process.env.POKER_URL||'http://127.0.0.1:8787/?lang=zh');await p.waitForFunction(()=>window.App&&window.PokerOffline);await p.locator('.login-card[onclick*="offline"]').click();await p.locator('#nick').fill('试玩复核');await p.evaluate(()=>App.connect());await p.waitForFunction(()=>PthState.ws?._server);await p.evaluate(seed=>{PthState.ws._server.rng=()=>{seed|=0;seed=seed+0x6D2B79F5|0;let t=Math.imul(seed^seed>>>15,1|seed);t^=t+Math.imul(t^t>>>7,61|t);return ((t^t>>>14)>>>0)/4294967296;};},3100+i);await p.locator('button[onclick="App.createGame()"]').click();await p.waitForFunction(()=>window.PthState?.ws?._server?.table?.h);await p.evaluate(()=>{const s=PthState.ws._server,pace=s.pace;s.pace=(fn,ms)=>pace(fn,Math.min(ms||0,30));});
let done=false;
for(let step=0;step<550;step++){
 const state=await p.evaluate(i=>{const s=PthState.ws._server,q=PokerTeaching.getState();if(q?.type==='complete')return 'done';if(s._visibleTurn!==1||s.table.h._pendingId!==1)return 'wait';const c=s.teaching.contexts[1],l=c.legal,hi=Math.max(...c.hole.map(x=>x%13)),pair=c.hole[0]%13===c.hole[1]%13,match=c.hole.some(x=>c.board.some(y=>x%13===y%13));let action=2,amount=0;
 if(c.gameState==='preflop'&&i%3===2&&l.canRaise&&(pair||hi>=10)&&c.currentBet<=l.bb){action=5;amount=Math.max(l.minRaiseTo,Math.round(l.bb*2.5))-c.streetCommitted;}
 else if(l.callAmt){const willing=i%3===0?Math.min(c.stack,l.pot*.6):i%3===1?Math.min(c.stack,l.bb*5):match||pair?Math.min(c.stack,l.pot*.5):l.bb*2;action=l.callAmt<=willing?3:1;amount=l.callAmt;}
 App.doAction(action,amount);return 'acted';},i);
 if(state==='done'){done=true;break;}await p.waitForTimeout(65);
}
assert.ok(done,'hand finishes');await p.locator('#teaching-review-dialog .tc-main-advice').waitFor({timeout:30000});const report=await p.evaluate(()=>PokerTeaching.getState().report);const analysis=await p.evaluate(async report=>(await import('/modules/teaching/review-client.mjs')).analyzeHandAsync(report),report);reports.push({report,analysis});fs.writeFileSync(path.join(artifacts,`play-audit-${label}.json`),JSON.stringify(reports,null,2));
const raises=report.decisions.filter(d=>['raise','bet','allin'].includes(d.action));console.log(JSON.stringify({sample:i+1,board:report.board,hero:report.players.find(p=>p.id===1).hole,actions:report.decisions.length,raises:raises.map(d=>({name:d.playerName,street:d.context.gameState,pot:d.context.legal.pot,paid:d.paid,to:d.totalStreetBet})),reviews:analysis.heroReviews.map(r=>({action:r.action,title:r.title,verdict:r.verdict,reason:r.reason}))}));if(i===5)await p.screenshot({path:path.join(artifacts,`play-audit-${label}.png`)});await p.close();}
assert.deepEqual(errors,[]);console.log('SIX REAL CLIENT HANDS PASS '+label);
}finally{await browser.close();}})();
