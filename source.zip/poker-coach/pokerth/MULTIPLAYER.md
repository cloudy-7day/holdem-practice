# 好友联机

入口：<https://cloudy-7day.github.io/holdem-practice/multiplayer.html>

创建一桌后，把邀请链接或六位房间码发给朋友。各人可以使用不同 Wi-Fi 或手机流量，无需开着你的电脑。2–9 个座位，可以只坐真人，也可以在开始时用电脑补齐空位。所有人入座后由房主开始；开局后不再接纳新座位，原玩家刷新仍可重连。

这是教学桌：只有虚拟筹码，对局中只有自己能看到自己的底牌，**每手结束后所有底牌都会公开**，包括已弃牌的底牌。每人看到的决策建议来自自己当时的牌面和下注，不会拿后来公开的底牌反推当时的决定。

- 每次行动 60 秒；超时能过就过，否则弃牌。手机切后台后，计时仍继续。
- 房主决定何时发下一手。房主超过 90 秒没有连接后，权限交给仍在线的人。
- 刷新同一浏览器可回到原座位。不要清理网站存储；微信和 Safari 的存储不互通，换浏览器不是原座位。
- 房间最多存在 24 小时；结束后可以新建。当前同时最多保留 100 间房；等待期间累计入座次数有上限，避免无限增长。
- 联机金额框是“本轮加到多少”，旁边说明已投入与总额；单人旧版的金额框规则保持不变。
- 复盘本地计算，不调用大模型，不消耗 AI API 额度。房间同步会使用 Cloudflare 的请求、计算及存储额度；本次部署没有购买或升级付费套餐。达到平台免费限额时服务可能暂时不可用。

## 架构

GitHub Pages 提供静态网页，Cloudflare Worker 提供 API，每个 Durable Object 负责一桌。Room 核心复用原有 OfflineTable 发牌、下注、主池/边池结算；只接受带座位凭证与当前行动编号的合法操作。底牌、未发出的牌、认证凭证仅在服务端持久化，客户端只收自己的即时底牌。手后教学规则才允许公开全部底牌。

手机约每秒取一次自己的状态，提交操作后立即得到新状态。服务端闹钟推进电脑和超时行动；即使所有手机暂时切后台，也不会把超时当成尚未操作。Durable Objects 保存当前桌面、牌堆和行动上下文，服务重新加载后可恢复。房间和凭证不是账户系统，不支持跨浏览器登录或大厅随机匹配。

本地同 Wi-Fi 也可用：运行原来的 `启动手机同WiFi试玩.cmd`，朋友访问同一电脑的 `http://局域网IP:8788/multiplayer.html`。本地服务使用同一个 Room 核心，存档位于 `pokerth/.runtime/multiplayer/rooms.json`；不要分享该文件，它含底牌和座位凭证。本地模式的自动行动由在线客户端轮询触发，无人在线时暂停推进，返回后处理到期行动。

## 开发和发布

```sh
npm ci
npm test
npm run check
npm run rooms:dev
```

Cloudflare 本地模拟器默认端口 8793。Node 网页服务端口由 `POKER_PORT` 控制，默认 8787；`POKER_HOST=0.0.0.0` 用于局域网。`/multiplayer-config.json` 在 Node 服务器上始终返回空 apiBase，表示使用本机 API；公开静态构建使用文件里配置的 HTTPS Cloudflare API。

首次在自己的账户部署需运行 `wrangler login --scopes account:read user:read workers:write workers_scripts:write`，然后 `npm run rooms:deploy`。SQLite Durable Objects 由 wrangler.jsonc 的迁移创建。把实际部署 URL 写入 `pokerth/public/multiplayer-config.json`，将网页域名写入 ALLOWED_ORIGINS。不要向 Git 提交 OAuth 凭证、.dev.vars 或 .runtime。

`pokerth/scripts/test-multiplayer-api.mjs` 验证真实 API 对局，可用 POKER_API_URL 指定服务。`pokerth/scripts/test-multiplayer-browser.cjs` 验证两个独立浏览器会话和窄屏；环境变量与其他浏览器测试相同。静态构建仍使用 `npm run build:pages`，提交源码后生成对应 source.zip。

## 参考

- [Poker Now](https://www.pokernow.com/) 的建桌与邀请链接流程。
- [Colyseus](https://docs.colyseus.io/) 的服务端掌握牌局、房间隔离与状态同步思路。
- [Cloudflare Durable Objects](https://developers.cloudflare.com/durable-objects/) 的单房间持久化协调。

实现复用了已有 AGPL PokerTH 引擎；参考其他产品的交互方式，没有复制其私有源码。
