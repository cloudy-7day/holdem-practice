# 好友联机

入口：<https://cloudy-7day.github.io/holdem-practice/multiplayer.html>

创建一桌后，把邀请链接或六位房间码发给朋友。各人可以使用不同 Wi-Fi 或手机流量，无需开着你的电脑。2–9 个座位，可以只坐真人，也可以在开始时用电脑补齐空位。所有人入座后由房主开始；开局后不再接纳新座位，原玩家刷新仍可重连。

## 创建房间没有反应时

创建／加入期间，按钮旁显示当前进度。配置、API 及响应正文都受 12 秒期限约束；超时、网络不通、服务器错误会在当前手机视口显示中文原因和手动重试按钮。创建／加入请求不会自动重发，因为服务端可能已经处理了第一次请求。浏览器无法更新地址栏时，成功返回的房间号仍会显示。脚本未能加载时，15 秒后提示刷新，不再只留下灰色按钮。

目前网页与 API 分别使用 GitHub Pages 和 Cloudflare 默认域名。网络对这些域名的可达性是独立问题：错误反馈改善并不会使原本不可达的域名自动变得可达。若只有开启 VPN 才稳定，需要在实际手机网络验证其他入口；不能保证更换任意域名就能解决全部线路问题。

已有域名可接入 Cloudflare 后给 Worker 绑定专用子域名，再更新 `public/multiplayer-config.json` 的 `apiBase`；若网页也更换域名，需同时更新允许的来源并部署网页，不能仅改邀请链接。操作依据：[Cloudflare Worker 自定义域名](https://developers.cloudflare.com/workers/configuration/routing/custom-domains/)。域名注册与现有服务器托管是两件事，使用现有 Worker 无需额外购买一台服务器。

这是教学桌：只有虚拟筹码，对局中只有自己能看到自己的底牌，**每手结束后所有底牌都会公开**，包括已弃牌的底牌。每人看到的决策建议来自自己当时的牌面和下注，不会拿后来公开的底牌反推当时的决定。

- 每次行动 60 秒；超时能过就过，否则弃牌。手机切后台后，计时仍继续。
- 房主决定何时发下一手。房主超过 90 秒没有连接后，权限交给仍在线的人。
- 刷新同一浏览器可回到原座位。不要清理网站存储；微信和 Safari 的存储不互通，换浏览器不是原座位。
- 房间最多存在 24 小时；结束后可以新建。当前同时最多保留 100 间房；等待期间累计入座次数有上限，避免无限增长。
- 联机与单人训练共用原来的 PokerTH 牌桌、发牌动画、音效和操作栏。金额框填写“本次再投入多少”：已投入10，再填50，本轮总投入就是60。
- 复盘本地计算，不调用大模型，不消耗 AI API 额度。房间同步会使用 Cloudflare 的请求、计算及存储额度；本次部署没有购买或升级付费套餐。达到平台免费限额时服务可能暂时不可用。

## 架构

GitHub Pages 提供静态网页，Cloudflare Worker 提供 API，每个 Durable Object 负责一桌。Room 核心复用原有 OfflineTable 发牌、下注、主池/边池结算；只接受带座位凭证与当前行动编号的合法操作。底牌、未发出的牌、认证凭证仅在服务端持久化，客户端只收自己的即时底牌。手后教学规则才允许公开全部底牌。

房间页只负责创建、加入和等朋友；开局自动进入原版 PokerTH 牌桌。客户端传输适配器把服务端公开事件转换成原版协议，复用同一套渲染和复盘组件。当前手的完整公开事件按序持久化，刷新可恢复当前桌面；旧存档没有事件日志时直接恢复公开状态，不补造下注记录。

手机约每秒取一次自己的状态，提交操作后立即得到新状态。服务端闹钟推进电脑和超时行动；即使所有手机暂时切后台，也不会把超时当成尚未操作。Durable Objects 保存当前桌面、牌堆和行动上下文，服务重新加载后可恢复。房间和凭证不是账户系统，不支持跨浏览器登录或大厅随机匹配。

本地同 Wi-Fi 也可用：运行原来的 `启动手机同WiFi试玩.cmd`，朋友访问同一电脑的 `http://局域网IP:8788/multiplayer.html`。本地服务使用同一个 Room 核心，存档位于 `pokerth/.runtime/multiplayer/rooms.json`；不要分享该文件，它含底牌和座位凭证。本地模式的自动行动由在线客户端轮询触发，无人在线时暂停推进，返回后处理到期行动。

## 开发和发布

```sh
npm ci
npm test
npm run check
npm run rooms:dev
```

Cloudflare 本地模拟器默认端口 8793。Node 网页服务端口由 `POKER_PORT` 控制，默认 8787；`POKER_HOST=0.0.0.0` 用于局域网。`/multiplayer-config.json` 在 Node 服务器上始终返回空 apiBase，表示使用本机 API；公开静态构建使用文件里配置的 HTTPS Cloudflare API。

首次在自己的账户部署需运行 `wrangler login --scopes account:read user:read workers:write workers_scripts:write`，然后 `npm run rooms:deploy`。SQLite Durable Objects 由 wrangler.jsonc 的迁移创建。把实际部署 URL 写入 `pokerth/public/multiplayer-config.json`，将网页域名写入 ALLOWED_ORIGINS。不要向 Git 提交 OAuth 凭证、.dev.vars 或 .runtime。

`pokerth/scripts/test-multiplayer-api.mjs` 验证真实 API 对局，可用 POKER_API_URL 指定服务。`pokerth/scripts/test-multiplayer-browser.cjs` 验证两个独立浏览器会话和窄屏；环境变量与其他浏览器测试相同。静态构建仍使用 `npm run build:pages`，提交源码后生成对应 source.zip。

## 免费备用入口（Cloudflare Pages）

地址：<https://holdem-practice-cloudy-7day.pages.dev/?lang=zh>。若网页能打开但建房超时，打开 [连接检测](https://holdem-practice-cloudy-7day.pages.dev/holdem-practice/connection-check.html)。该页先读网页配置，再分别测试房间 GET 和无昵称的 POST 请求；预期 POST 被服务拒绝，不会生成房间。每项最多等 30 秒并记录完整响应耗时，结果仅展示在本机，复制后可用于排查。检测成功不代表真实建房及手机线路永久稳定。

首次创建真正的 Pages 项目使用 `wrangler pages project create holdem-practice-cloudy-7day --production-branch main --cwd pokerth/cloudflare-pages --force`。Wrangler 4.152 可能自动把新 Pages 项目转成 Workers；此处明确需要 pages.dev 域名。已有 Pages 项目直接使用下述部署命令，不要另建 Worker。

备用站把网页和 `/api/rooms` 放在同一个域名。Pages 的 `_worker.js` 通过 `ROOM_API` 服务绑定连接现有 `holdem-friend-rooms` Worker，手机无需直接请求 `workers.dev`。不是另建一套牌局服务器：房间仍由原有 Durable Objects 管理，原来的 GitHub 入口也保留。不同入口的网站存储相互独立，刷新重连请使用创建或加入时的同一入口。

部署使用 `pokerth/cloudflare-pages/wrangler.jsonc`，需额外的 `pages:write` 授权。先提交源码、执行 `npm run build:pages` 并发布到公共仓库，再把该公共提交对应的 `https://raw.githubusercontent.com/cloudy-7day/holdem-practice/<40位提交>/source.zip` 设置为环境变量 `POKER_SOURCE_ARCHIVE_URL`，执行 `npm run build:cloudflare-pages` 和 `npm run deploy:cloudflare-pages`。完整源码包超过 Pages 单文件限制，所以备用站的源码下载跳转到不可变的公共 Git 提交；游戏运行不依赖该下载地址。

本地验证：`npm run build:cloudflare-pages -- --preview`，然后 `npm run test:pages-mirror`。两个独立移动浏览器通过生成后的入口创建、加入、打完一手、查看复盘、进入下一手和刷新恢复，并检查游戏过程没有跨域请求。生产构建不接受指向移动分支的源码包地址。

Pages 默认域名不需要购买，但不能保证所有手机网络均可直连。Pages Functions 和原有 Workers/存储均受平台免费额度约束；没有为此购买服务器、域名或升级套餐。依据：[服务绑定](https://developers.cloudflare.com/pages/functions/bindings/)、[计费与免费额度](https://developers.cloudflare.com/pages/functions/pricing/)、[Pages 限制](https://developers.cloudflare.com/pages/platform/limits/)。

## 参考资料

- [Poker Now](https://www.pokernow.com/) 的建桌与邀请链接流程。
- [Colyseus](https://docs.colyseus.io/) 的服务端掌握牌局、房间隔离与状态同步思路。
- [Cloudflare Durable Objects](https://developers.cloudflare.com/durable-objects/) 的单房间持久化协调。

实现复用了已有 AGPL PokerTH 引擎；参考其他产品的交互方式，没有复制其私有源码。

## 手机握持方向

横屏更适合看全桌和下注：牌桌在左侧，操作区在右侧；竖屏更适合单手操作及阅读复盘。页面自动识别当前方向并提示，无需手动切换、刷新或锁定横屏。旋转只调整布局，保留房间、座位、牌局和金额草稿；输入法弹出时不会误判成旋转。短横屏会收紧其他玩家的座位卡片，但下注按钮保持至少44像素高。
