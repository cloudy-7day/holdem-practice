$ErrorActionPreference = 'Stop'
$gameDir = $PSScriptRoot
$gameUrl = 'http://127.0.0.1:8787/?lang=zh'
$ready = $false
try { $ready = (Invoke-RestMethod 'http://127.0.0.1:8787/health' -TimeoutSec 2).app -eq 'pokerth-chinese-teaching' } catch {}
if (-not $ready) {
  $nodeCmd = Get-Command node -ErrorAction SilentlyContinue
  $nodeExe = if ($nodeCmd) { $nodeCmd.Source } elseif (Test-Path -LiteralPath 'D:\node.exe') { 'D:\node.exe' } else { $null }
  if (-not $nodeExe) { throw 'Node.js is required. Install Node.js 20 or newer, then run this launcher again.' }
  $runtimeDir = Join-Path $gameDir '.runtime'
  New-Item -ItemType Directory -Force -Path $runtimeDir | Out-Null
  $serverFile = Join-Path $gameDir 'local-server.cjs'
  $serverProcess = Start-Process -FilePath $nodeExe -ArgumentList ('"' + $serverFile + '"') -WorkingDirectory $gameDir -WindowStyle Hidden -RedirectStandardOutput (Join-Path $runtimeDir 'server.log') -RedirectStandardError (Join-Path $runtimeDir 'server-error.log') -PassThru
  for ($attempt=0; $attempt -lt 30; $attempt++) {
    Start-Sleep -Milliseconds 200
    try { $ready = (Invoke-RestMethod 'http://127.0.0.1:8787/health' -TimeoutSec 1).app -eq 'pokerth-chinese-teaching' } catch {}
    if ($ready) { break }
    if ($serverProcess.HasExited) { break }
  }
  if (-not $ready) { throw 'Unable to start PokerTH. Check pokerth/.runtime/server-error.log; port 8787 may be in use.' }
}
Start-Process $gameUrl
