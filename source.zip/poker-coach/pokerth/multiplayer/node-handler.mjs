import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRoomService} from './http-service.mjs';

export function createNodeRoomHandler(){
 const dir=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../.runtime/multiplayer');
 const stateFile=path.join(dir,'rooms.json');let saved=[];
 try{saved=JSON.parse(fs.readFileSync(stateFile,'utf8'));}catch{}
 let queue=Promise.resolve();
 // One service uses all hostnames of this local listener; cross-site Origins are rejected per request.
 const service=createRoomService({saved,onChange:state=>{
  fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(stateFile+'.tmp',JSON.stringify(state));fs.renameSync(stateFile+'.tmp',stateFile);
 }});
 return (req,res)=>{
  const run=async()=>{
   const origin='http://'+req.headers.host;
   if(req.headers.origin&&req.headers.origin!==origin){res.writeHead(403,{'Content-Type':'application/json'});res.end(JSON.stringify({error:'请从当前游戏网页进入房间。'}));return;}
   let size=0;const chunks=[];const bodyLimit=req.method==='POST'&&/^\/api\/rooms\/[A-Z2-9]{6}\/voice$/.test(new URL(req.url,origin).pathname)?96*1024:8192;
   for await(const chunk of req){size+=chunk.length;if(size>bodyLimit){res.writeHead(413,{'Content-Type':'application/json'});res.end(JSON.stringify({error:'提交内容过长。'}));return;}chunks.push(chunk);}
   const headers=new Headers();for(const [key,value]of Object.entries(req.headers))if(value!==undefined&&key!=='origin')headers.set(key,Array.isArray(value)?value.join(','):value);
   const request=new Request(origin+req.url,{method:req.method,headers,...(['GET','HEAD'].includes(req.method)?{}:{body:Buffer.concat(chunks)})});
   const response=await service.fetch(request,req.socket.remoteAddress||'local');
   res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));
  };
  queue=queue.then(run).catch(()=>{if(!res.headersSent)res.writeHead(500,{'Content-Type':'application/json'});res.end(JSON.stringify({error:'房间暂时不可用，请重试。'}));});
 };
}
