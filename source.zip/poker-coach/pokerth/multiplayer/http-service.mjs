import {Room} from './room.mjs';

export const ROOM_TTL=24*60*60*1000;
export function httpError(status,message){return Object.assign(new Error(message),{status});}
export function randomToken(){return Array.from(crypto.getRandomValues(new Uint8Array(24)),v=>v.toString(16).padStart(2,'0')).join('');}
export function randomCode(){const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789';return Array.from(crypto.getRandomValues(new Uint8Array(6)),v=>alphabet[v&31]).join('');}
export function reply(data,status=200){return new Response(data===null?null:JSON.stringify(data),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});}
export function errorReply(error){const status=Number(error.status)||500;if(status>=500)console.error('Room service failure:',error.name,error.message);return reply({error:status>=500?'房间服务暂时不可用，请稍后重试。':error.message},status);}
export function bearer(request){const match=/^Bearer ([a-f0-9]{48})$/.exec(request.headers.get('Authorization')||'');if(!match)throw httpError(401,'请先输入昵称加入房间。');return match[1];}
export async function readJSON(request){
 if(!/^application\/json(?:;|$)/i.test(request.headers.get('Content-Type')||''))throw httpError(415,'请使用 JSON 提交。');
 if(Number(request.headers.get('Content-Length'))>8192)throw httpError(413,'提交内容过长。');
 let text='',size=0;const reader=request.body?.getReader();if(!reader)throw httpError(400,'提交内容为空。');
 const decoder=new TextDecoder();
 try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>8192){await reader.cancel();throw httpError(413,'提交内容过长。');}text+=decoder.decode(value,{stream:true});}text+=decoder.decode();}
 finally{reader.releaseLock();}
 let body;try{body=JSON.parse(text);}catch{throw httpError(400,'提交内容不是有效的 JSON。');}
 if(!body||typeof body!=='object'||Array.isArray(body))throw httpError(400,'提交内容格式不正确。');return body;
}
export function route(request){
 const path=new URL(request.url).pathname.replace(/\/$/,'');
 if(path==='/api/rooms/config'&&request.method==='GET')return {kind:'config'};
 if(path==='/api/rooms'&&request.method==='POST')return {kind:'create'};
 const m=/^\/api\/rooms\/([A-Z2-9]{6})(?:\/(join|command))?$/.exec(path);
 if(!m||request.method!==(m[2]?'POST':'GET'))throw httpError(404,'找不到这个房间接口。');
 return {kind:m[2]||'snapshot',code:m[1]};
}
export function cors(request,origins){
 const origin=request.headers.get('Origin');
 if(origin&&!origins.includes(origin))throw httpError(403,'请从游戏网页进入房间。');
 return incoming=>{const response=new Response(incoming.body,{status:incoming.status,headers:incoming.headers});if(origin)response.headers.set('Access-Control-Allow-Origin',origin);response.headers.set('Vary','Origin');response.headers.set('Access-Control-Allow-Methods','GET, POST, OPTIONS');response.headers.set('Access-Control-Allow-Headers','Authorization, Content-Type');response.headers.set('Access-Control-Max-Age','86400');return response;};
}
export async function executeRoomRequest(room,request,kind){
 if(kind==='join'){const body=await readJSON(request),token=randomToken();room.join({name:body.name,token});return reply({token,snapshot:room.snapshot(token)},201);}
 const token=bearer(request);
 if(kind==='command'){const body=await readJSON(request);room.command(token,body);if(body.type==='leave')return reply({left:true});}
 return reply({snapshot:room.snapshot(token)});
}

// Node/LAN adapter. Cloudflare uses the same protocol with one persistent object per room.
export function createRoomService({allowedOrigins=[],maxRooms=100,now=Date.now,ttl=ROOM_TTL,saved=[],onChange=()=>{}}={}){
 const rooms=new Map(),rates=new Map();
 for(const savedRoom of saved){try{if(savedRoom.expiresAt>now())rooms.set(savedRoom.code,{room:Room.restore(savedRoom.state,{now}),expiresAt:savedRoom.expiresAt});}catch{/* Corrupt rooms never prevent the solo server from starting. */}}
 const exportAll=()=>[...rooms].map(([code,value])=>({code,expiresAt:value.expiresAt,state:value.room.exportState()}));
 function cleanup(){for(const [code,item]of rooms)if(item.expiresAt<=now())rooms.delete(code);for(const [key,v]of rates)if(v.until<=now())rates.delete(key);}
 function limit(key,max){let entry=rates.get(key);if(!entry||entry.until<=now()){if(rates.size>=2000)throw httpError(429,'请求较多，请稍后再试。');entry={count:0,until:now()+60000};rates.set(key,entry);}if(++entry.count>max)throw httpError(429,'操作太频繁，请稍等一分钟。');}
 return {exportAll,async fetch(request,clientKey='local'){
  let decorate=x=>x;
  try{
   decorate=cors(request,allowedOrigins);
   if(request.method==='OPTIONS')return decorate(reply(null,204));
   const r=route(request);if(r.kind==='config')return decorate(reply({enabled:true,expiresHours:24}));
   cleanup();
   if(r.kind==='create'){
    limit('create:'+clientKey,10);const body=await readJSON(request);
    if(rooms.size>=maxRooms)throw httpError(429,'目前房间较多，请稍后再建房。');
    let code;do{code=randomCode();}while(rooms.has(code));const token=randomToken();
    const room=new Room({code,name:body.name,token,config:body.config,now});rooms.set(code,{room,expiresAt:now()+ttl});
    await onChange(exportAll());return decorate(reply({token,snapshot:room.snapshot(token)},201));
   }
   // Validate the bearer before room lookup to avoid unauthenticated room probing.
   if(r.kind!=='join')bearer(request);
   limit(clientKey+':'+r.kind,r.kind==='join'?30:240);
   const item=rooms.get(r.code);if(!item)throw httpError(404,'房间不存在或已过期，请核对房间号。');
   try{return decorate(await executeRoomRequest(item.room,request,r.kind));}
   finally{await onChange(exportAll());}
  }catch(error){return decorate(errorReply(error));}
 }};
}
