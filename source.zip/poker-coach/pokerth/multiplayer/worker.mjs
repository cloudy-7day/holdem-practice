import {Room} from './room.mjs';
import {readVoiceUpload} from './voice.mjs';
import {ROOM_TTL,randomCode,randomToken,reply,errorReply,httpError,readJSON,route,cors,executeRoomRequest,bearer} from './http-service.mjs';

// SQLite-backed Durable Object KV: chunk JSON below the per-value size limit.
export async function readState(storage){
 const meta=await storage.get('meta');if(!meta)return null;
 const keys=Array.from({length:meta.parts},(_,i)=>'part:'+i),values=await storage.get(keys);
 return {expiresAt:meta.expiresAt,state:JSON.parse(keys.map(key=>values.get(key)).join(''))};
}
export async function writeState(storage,state,expiresAt){
 const json=JSON.stringify(state),data={},parts=Math.ceil(json.length/24000);
 for(let i=0;i<parts;i++)data['part:'+i]=json.slice(i*24000,(i+1)*24000);
 data.meta={parts,expiresAt};await storage.put(data);
}

export class PokerRoom {
 constructor(ctx){this.ctx=ctx;this.room=null;this.expiresAt=0;this.queue=Promise.resolve();ctx.blockConcurrencyWhile(async()=>{
  const saved=await readState(ctx.storage);if(saved){this.expiresAt=saved.expiresAt;if(saved.expiresAt>Date.now())this.room=Room.restore(saved.state);else await ctx.storage.deleteAll();}
 });}
 fetch(request){
  const queuedAt=performance.now();
  const response=this.queue.then(async()=>{
   const startedAt=performance.now(),result=await this.handle(request);
   // Public durations only: diagnose transport latency separately from room work.
   const timed=new Response(result.body,result);
   timed.headers.append('Server-Timing',`room_queue;dur=${Math.max(0,startedAt-queuedAt).toFixed(1)}, room_work;dur=${Math.max(0,performance.now()-startedAt).toFixed(1)}`);
   return timed;
  });this.queue=response.catch(()=>{});return response;
 }
 async handle(request){
  let result,kind;const revision=this.room?.revision;
  try{
   const url=new URL(request.url);
   if(url.pathname==='/internal/create'){
    if(this.room&&this.expiresAt>Date.now())throw httpError(409,'房间号冲突，请重新建房。');
    const body=await request.json();this.room=new Room(body);this.expiresAt=Date.now()+ROOM_TTL;
    result=reply({token:body.token,snapshot:this.room.snapshot(body.token)},201);
   }else{
    if(!this.room||this.expiresAt<=Date.now())throw httpError(404,'房间不存在或已过期，请重新建房。');
    const r=route(request);kind=r.kind;result=await executeRoomRequest(this.room,request,r.kind,this.ctx.storage);
   }
  }catch(error){result=errorReply(error);}
  // Also preserve an automatic timeout action when a late command was rejected.
  // Snapshot reads refresh presence in memory, but must not serialize a full
  // durable write per seat per second ahead of player actions. Checkpoint
  // presence every 30s; mutations (including tick/host changes during a GET)
  // are still persisted before acknowledging the request.
  if(this.room&&((!['snapshot','voice-read'].includes(kind))||this.room.revision!==revision||Date.now()-(this.lastSavedAt||0)>=30000)){await this.save();}
  return result;
 }
 async save(){
  await writeState(this.ctx.storage,this.room.exportState(),this.expiresAt);
  const turn=this.room.turn,p=turn&&this.room.players.find(p=>p.id===turn.playerId);
  const due=turn?(p?.isBot?turn.botAt:turn.deadline):this.expiresAt;
  await this.ctx.storage.setAlarm(Math.max(Date.now()+20,Math.min(this.expiresAt,due)));
  this.lastSavedAt=Date.now();
 }
 alarm(){const result=this.queue.then(async()=>{
  if(!this.room||Date.now()>=this.expiresAt){this.room=null;await this.ctx.storage.deleteAll();return;}
  this.room.tick();await this.save();
 });this.queue=result.catch(()=>{});return result;}
}

// Room codes and create/join limits live in one small directory, not a public lobby.
export class RoomDirectory {
 constructor(ctx,env){this.ctx=ctx;this.env=env;this.rooms={};this.rates={};this.queue=Promise.resolve();ctx.blockConcurrencyWhile(async()=>{this.rooms=await ctx.storage.get('rooms')||{};this.rates=await ctx.storage.get('rates')||{};});}
 fetch(request){const p=this.queue.then(()=>this.handle(request));this.queue=p.catch(()=>{});return p;}
 async handle(request){
  try{
   const now=Date.now(),data=await request.json();
   for(const [code,expires]of Object.entries(this.rooms))if(expires<=now)delete this.rooms[code];
   for(const [key,rate]of Object.entries(this.rates))if(rate.until<=now)delete this.rates[key];
   if(data.kind==='create'||data.kind==='join'){
    const key=data.ip+':'+data.kind;
    if(!this.rates[key]){if(Object.keys(this.rates).length>=2000)throw httpError(429,'请求较多，请稍后再试。');this.rates[key]={count:0,until:now+60000};}
    if(++this.rates[key].count>(data.kind==='create'?10:30))throw httpError(429,'操作太频繁，请稍等一分钟。');
   }
   if(data.kind==='create'){
    if(Object.keys(this.rooms).length>=100)throw httpError(429,'目前房间较多，请稍后再建房。');
    let code;do{code=randomCode();}while(this.rooms[code]);
    this.rooms[code]=now+ROOM_TTL;
    await this.ctx.storage.put({rooms:this.rooms,rates:this.rates});
    return reply({code});
   }
   await this.ctx.storage.put({rooms:this.rooms,rates:this.rates});
   if(!this.rooms[data.code])throw httpError(404,'房间不存在或已过期，请核对房间号。');
   return reply({code:data.code});
  }catch(error){return errorReply(error);}
 }
}

export default {async fetch(request,env){
 let decorate=x=>x;
 try{
  decorate=cors(request,(env.ALLOWED_ORIGINS||'https://cloudy-7day.github.io').split(',').map(s=>s.trim()));
  if(request.method==='OPTIONS')return decorate(reply(null,204));
  const r=route(request);if(r.kind==='config')return decorate(reply({enabled:true,expiresHours:24}));
  let body;
  if(r.kind==='create'){
   body=await readJSON(request);
   // Validate first, so malformed requests cannot consume all room slots.
   new Room({code:'VALIDA',name:body.name,token:'validation',config:body.config});
  }else if(r.kind!=='join')bearer(request);
  if(r.kind==='voice-upload'){const clip=await readVoiceUpload(request);request=new Request(request,{body:clip.bytes});}
  // GET/action already require an unguessable seat token. Directory checks only
  // create/join, avoiding a global write bottleneck on every phone's snapshot.
  let code=r.code;
  if(r.kind==='create'||r.kind==='join'){
   const directory=env.DIRECTORY.get(env.DIRECTORY.idFromName('rooms-v1'));
   const response=await directory.fetch(new Request('https://directory/internal',{method:'POST',body:JSON.stringify({kind:r.kind,code,ip:request.headers.get('CF-Connecting-IP')||'local'})}));
   const data=await response.json();if(!response.ok)return decorate(reply(data,response.status));code=data.code;
  }
  const room=env.ROOMS.get(env.ROOMS.idFromName(code));
  // The subrequest duration includes the DO output gate and internal routing;
  // an in-object clock alone may stay unchanged for cached storage operations.
  const timedFetch=async value=>{const started=performance.now(),response=await room.fetch(value),result=new Response(response.body,response);result.headers.append('Server-Timing',`room_roundtrip;dur=${Math.max(0,performance.now()-started).toFixed(1)}`);return result;};
  if(r.kind==='create')return decorate(await timedFetch(new Request('https://room/internal/create',{method:'POST',body:JSON.stringify({code,name:body.name,config:body.config,token:randomToken()})})));
  return decorate(await timedFetch(request));
 }catch(error){return decorate(errorReply(error));}
}};
