import { OfflineTable } from '../public/modules/offline/engine.mjs';
import { decide, pickArchetype } from '../public/modules/offline/bots.mjs';
import { TeachingSession } from '../public/modules/teaching/session.mjs';

const copy = value => JSON.parse(JSON.stringify(value));
const random = () => globalThis.crypto.getRandomValues(new Uint32Array(1))[0] / 4294967296;
export class RoomError extends Error {
  constructor(status, message) { super(message); this.name='RoomError'; this.status=status; }
}
function fail(message,status=400) { throw new RoomError(status,message); }
function nickname(name) {
  if(typeof name!=='string'||!name.trim()||name.trim().length>24)fail('昵称需要 1 至 24 个字');
  return name.trim();
}
function configuration(input={}) {
  if(!input||typeof input!=='object'||Array.isArray(input))fail('房间设置格式无效');
  const config={maxPlayers:9,startMoney:2000,smallBlind:10,fillBots:true,turnSeconds:60};
  for(const key of Object.keys(config))if(input[key]!==undefined)config[key]=input[key];
  for(const [key,min,max] of [['maxPlayers',2,9],['startMoney',40,1000000],['smallBlind',1,100000],['turnSeconds',10,120]])
    if(!Number.isSafeInteger(config[key])||config[key]<min||config[key]>max)fail('房间设置超出范围');
  if(config.smallBlind*2>config.startMoney||typeof config.fillBots!=='boolean')fail('盲注或机器人设置无效');
  return config;
}

/** Authoritative portable state. Only exportState contains secrets; never send it to clients. */
export class Room {
  constructor({code,name,token,config,now=Date.now,rng=random}) {
    this.code=code;this.config=configuration(config);this.now=now;this.rng=rng;
    this.revision=0;this.phase='waiting';this.hostId=1;this.players=[];this.members=[];
    this.turn=null;this.turnSequence=0;this.events=[];this.eventSequence=0;this.table=null;
    this.session=new TeachingSession();this.botConfigs={};this.report=null;
    this.join({name,token});
  }
  _member(token) {
    if(typeof token!=='string'||!token)fail('需要有效的重连凭证',401);
    const member=this.members.find(m=>m.token===token);
    if(!member)fail('重连凭证无效',401);
    return member;
  }
  join({name,token}) {
    if(typeof token!=='string'||!token)fail('需要有效的重连凭证',401);
    const existing=this.members.find(m=>m.token===token);
    if(existing){if(existing.left)fail('你已离开房间',403);return existing.id;}
    if(this.phase!=='waiting')fail('牌局已开始，请使用原来的重连凭证',409);
    if(this.members.length>=100)fail('房间历史加入人数已达上限，请重建房间',409);
    if(this.players.length>=this.config.maxPlayers)fail('房间已满',409);
    const id=Math.max(0,...this.players.map(p=>p.id),...this.members.map(m=>m.id))+1;
    this.players.push({id,name:nickname(name),isBot:false,in:true,stack:this.config.startMoney});
    if(this.hostId==null)this.hostId=id;
    this.members.push({id,token,lastSeen:this.now(),left:false});this.revision++;
    return id;
  }
  _makeTable() {
    this.table=new OfflineTable({players:this.players,smallBlind:this.config.smallBlind,endRaiseMode:3,now:this.now,rng:this.rng,onEvent:ev=>this._event(ev)});
  }
  _heartbeat(member) {
    member.lastSeen=this.now();
    const host=this.members.find(m=>m.id===this.hostId&&!m.left);
    if(!host||this.now()-host.lastSeen>90000) {
      const next=this.members.find(m=>!m.left&&this.now()-m.lastSeen<=90000);
      if(next&&next.id!==this.hostId){this.hostId=next.id;this.revision++;}
    }
  }
  _event(ev) {
    if(ev.type==='handStart') {
      this.phase='playing';this.report=null;this.events=[];
      for(const bot of Object.values(this.botConfigs))Object.assign(bot,{_barrels:0,_barrelStreet:null,_hadDraw:false});
      this.session.start(ev,this.table,this.players);
    } else if(ev.type==='turn') {
      this.session.turn(ev,this.table);
      this.turn={playerId:ev.playerId,turnId:`${this.code}:${++this.turnSequence}`,deadline:this.now()+this.config.turnSeconds*1000,
        botAt:this.now()+700,legal:copy(ev.legal),currentBet:this.table.h.currentBet,streetCommitted:this.table.h.streetCommit[ev.playerId]||0};
    } else if(ev.type==='actionDone') {
      this.session.action(ev);
      this.events.push({id:++this.eventSequence,playerId:ev.playerId,text:this.session.last.speech});
      if(this.events.length>100)this.events.shift();
      this.turn=null;
    } else if(ev.type==='handComplete'||ev.type==='gameOver') {
      this.turn=null;
      for(const m of this.members)if(m.left){const p=this.players.find(p=>p.id===m.id);if(p)p.in=false;}
      this.phase=ev.type==='gameOver'||this.players.filter(p=>p.in).length<=1?'finished':'review';
      if(this.session.hand)this.report=this.session.report(this.table,this.phase==='finished');
    }
  }
  _validate(action,amountTo) {
    const l=this.turn.legal,h=this.table.h;
    if(action==='fold')return;
    if(action==='check'){if(!l.canCheck)fail('当前需要跟注，不能过牌');return;}
    if(action==='call'){if(!l.canCall)fail('当前不能跟注');return;}
    if(!['bet','raise','allin'].includes(action))fail('未知操作');
    const target=action==='allin'?(amountTo??l.maxRaiseTo):amountTo;
    if(!Number.isSafeInteger(target)||target<=this.turn.streetCommitted||target>l.maxRaiseTo)fail('下注金额无效');
    if(action==='allin'&&target!==l.maxRaiseTo)fail('全下金额无效');
    if(action==='allin'&&target<=h.currentBet){if(!l.canCall)fail('当前不能全下');return;}
    if(!l.canRaise||target<=h.currentBet||(target<l.minRaiseTo&&target!==l.maxRaiseTo))fail('加注金额不合法');
  }
  _act(action,amountTo) {
    this._validate(action,amountTo);
    const t=this.turn;
    // An all-in call must use the call branch: engine's raise branch clamps it upward.
    if(action==='allin'&&t.legal.maxRaiseTo<=this.table.h.currentBet)action='call';
    this.table.act(t.playerId,action,action==='allin'?t.legal.maxRaiseTo:amountTo);
    this.revision++;
  }
  command(token,command) {
    const member=this._member(token);
    if(member.left)fail('你已离开房间',403);
    this._heartbeat(member);
    if(!command||typeof command!=='object')fail('操作格式无效');
    if(command.playerId!==undefined&&command.playerId!==member.id)fail('不能替其他玩家操作',403);
    const {type}=command;
    if(type==='start'||type==='next') {
      if(member.id!==this.hostId)fail('只有房主可以开始下一手',403);
      if(type==='start') {
        if(this.phase!=='waiting')fail('牌局已经开始',409);
        if(this.config.fillBots)while(this.players.length<this.config.maxPlayers) {
          const id=Math.max(...this.players.map(p=>p.id),...this.members.map(m=>m.id))+1;
          const style=pickArchetype(this.rng),skill='normal';
          this.players.push({id,name:`陪练 ${id}`,isBot:true,in:true,stack:this.config.startMoney,skill,...style});
          this.botConfigs[id]={skill,...style,_barrelOn:style.arch!=='station',_barrels:0,_barrelStreet:null,_hadDraw:false};
        }
        if(this.players.length<2)fail('至少需要两位玩家',409);
        this._makeTable();this.table.start();
      } else {
        if(this.phase!=='review')fail('当前不能开始下一手',409);
        this.table.nextHand();
      }
      this.revision++;return;
    }
    if(type==='action') {
      if(this.phase!=='playing'||!this.turn||command.turnId!==this.turn.turnId)fail('操作已过期，请刷新牌桌',409);
      if(this.turn.playerId!==member.id)fail('还没轮到你操作',403);
      if(this.now()>=this.turn.deadline){this.tick();fail('操作已超时',409);}
      this._act(command.action,command.amountTo);return;
    }
    if(type==='leave') {
      member.left=true;
      if(this.phase==='waiting')this.players=this.players.filter(p=>p.id!==member.id);
      else if(this.phase==='playing')this.table.removePlayer(member.id);
      else this.players.find(p=>p.id===member.id).in=false;
      if(this.hostId===member.id)this.hostId=this.members.find(m=>!m.left)?.id??null;
      this.revision++;return;
    }
    fail('未知房间操作');
  }
  tick() {
    if(this.phase!=='playing'||!this.turn)return false;
    const p=this.players.find(p=>p.id===this.turn.playerId);
    if(p.isBot&&this.now()>=this.turn.botAt) {
      const bot=this.botConfigs[p.id]||(this.botConfigs[p.id]={skill:'easy'});
      let d;
      bot.rng=this.rng;
      try { d=decide(this.session.contexts[p.id],bot); }
      finally { delete bot.rng; }
      // Bot policy can propose clamped sizing. Normalize only server-owned bot output.
      if(['bet','raise','allin'].includes(d.action)) {
        const l=this.turn.legal;
        if(!l.canRaise){d.action=l.canCall?'call':'check';delete d.amountTo;}
        else d.amountTo=Math.min(l.maxRaiseTo,Math.max(l.minRaiseTo,Math.round(d.amountTo??l.maxRaiseTo)));
      }
      this._act(d.action,d.amountTo);return true;
    }
    if(this.now()>=this.turn.deadline){this._act(this.turn.legal.canCheck?'check':'fold');return true;}
    return false;
  }
  snapshot(token) {
    const member=this._member(token);
    if(member.left)fail('你已离开房间',403);
    this._heartbeat(member);
    this.tick();
    const h=this.table?.h,done=this.phase==='review'||this.phase==='finished';
    const turn=this.turn?{playerId:this.turn.playerId,turnId:this.turn.turnId,deadline:this.turn.deadline,currentBet:this.turn.currentBet,streetCommitted:this.turn.streetCommitted,
      ...(this.turn.playerId===member.id?{legal:copy(this.turn.legal)}:{})}:null;
    let report=null;
    if(done&&this.report){
      report=copy(this.report);report.heroId=member.id;
      report.canContinue=this.phase==='review'&&!!this.players.find(p=>p.id===member.id&&p.in);
      for(const decision of report.decisions)if(decision.playerId!==member.id)delete decision.context.hole;
    }
    return {code:this.code,revision:this.revision,phase:this.phase,hostId:this.hostId,heroId:member.id,config:copy(this.config),
      players:this.players.map(p=>({id:p.id,name:p.name,isBot:p.isBot,connected:p.isBot||!!this.members.find(m=>m.id===p.id&&!m.left&&this.now()-m.lastSeen<90000),stack:p.stack,in:p.in,
        folded:!!h?.folded[p.id],allin:!!h?.allin[p.id],streetCommitted:h?.streetCommit[p.id]||0,hole:(done||p.id===member.id)?(h?.hole[p.id]?.slice()||[]):[]})),
      board:h?.board.slice()||[],handNumber:this.table?.handNum||0,dealerId:h?this.players[this.table.button]?.id:null,sbId:h?.sbP.id??null,bbId:h?.bbP.id??null,
      pot:h?this.table._pot():0,turn,events:copy(this.events),report};
  }
  exportState() {
    let table=null;
    if(this.table){
      const {players,onEvent,now,rng,h,...fields}=this.table;
      table={...fields,h:h?{...h,sbP:h.sbP.id,bbP:h.bbP.id,_order:h._order.map(p=>p.id),noReraise:[...h.noReraise],needsToAct:[...h.needsToAct]}:null};
    }
    return copy({version:1,code:this.code,config:this.config,revision:this.revision,phase:this.phase,hostId:this.hostId,players:this.players,members:this.members,
      turn:this.turn,turnSequence:this.turnSequence,events:this.events,eventSequence:this.eventSequence,botConfigs:this.botConfigs,report:this.report,
      session:{hand:this.session.hand,contexts:this.session.contexts,ready:this.session.ready,last:this.session.last},table});
  }
  static restore(saved,{now=Date.now,rng=random}={}) {
    if(saved?.version!==1)fail('房间存档版本不支持');
    const data=copy(saved),room=Object.create(Room.prototype);
    const {session,table,version,...fields}=data;
    Object.assign(room,fields,{now,rng});
    room.session=new TeachingSession();Object.assign(room.session,session);
    if(table){room._makeTable();Object.assign(room.table,table);if(table.h){const h=room.table.h;
      h.sbP=room.players.find(p=>p.id===h.sbP);h.bbP=room.players.find(p=>p.id===h.bbP);
      h._order=h._order.map(id=>room.players.find(p=>p.id===id));h.noReraise=new Set(h.noReraise);h.needsToAct=new Set(h.needsToAct);
    }}else room.table=null;
    return room;
  }
}
