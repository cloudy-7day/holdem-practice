// Pages serves the game and forwards only the room API over a service binding.
const archive = '__SOURCE_ARCHIVE_URL__';
function error(message, status) {
 return Response.json({error: message}, {status, headers: {'Cache-Control': 'no-store'}});
}
export async function handlePagesRequest(request, env, {sourceArchiveUrl = archive} = {}) {
 const url = new URL(request.url);
 if (url.pathname === '/') {
  url.pathname = '/holdem-practice/';
  return Response.redirect(url.href, 302);
 }
 if (url.pathname === '/holdem-practice/source.zip') {
  if (!/^https:\/\/raw\.githubusercontent\.com\/cloudy-7day\/holdem-practice\/[a-f0-9]{40}\/source\.zip$/.test(sourceArchiveUrl)) return error('源码下载地址尚未配置。', 503);
  return Response.redirect(sourceArchiveUrl, 302);
 }
 if (url.pathname.startsWith('/api/')) {
  if (!/^\/api\/rooms(?:\/config|\/[A-Z2-9]{6}(?:\/(?:join|command))?)?$/.test(url.pathname)) return error('接口不存在。', 404);
  const origin = request.headers.get('Origin');
  if ((origin && origin !== url.origin) || request.headers.get('Sec-Fetch-Site') === 'cross-site') return error('请从游戏页面访问房间。', 403);
  if (!env.ROOM_API?.fetch) return error('房间服务暂时不可用，请稍后重试。', 503);
  // Validate the browser's origin before removing it for the internal binding.
  // Seat authentication and the original client IP remain intact.
  const headers = new Headers(request.headers);
  for (const name of ['Origin', 'Referer', 'Cookie']) headers.delete(name);
  try {
   const response = await env.ROOM_API.fetch(new Request(request, {headers}));
   const result = new Response(response.body, response);
   result.headers.set('Cache-Control', 'no-store');
   return result;
  } catch {
   return error('房间服务连接失败，请稍后重试。', 503);
  }
 }
 return env.ASSETS?.fetch ? env.ASSETS.fetch(request) : error('页面不存在。', 404);
}
export default {fetch: (request, env) => handlePagesRequest(request, env)};
