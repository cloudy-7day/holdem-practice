export const MAX_VOICE_BYTES=96*1024;
const uploadQueues=new WeakMap();
const fail=(status,message)=>{throw Object.assign(new Error(message),{status});};
export async function readVoiceUpload(request){
 const mime=(request.headers.get('Content-Type')||'').split(';')[0].trim().toLowerCase();
 if(!['audio/mp4','audio/webm','audio/ogg','audio/wav'].includes(mime))fail(415,'当前语音格式不支持');
 const durationMs=Number(request.headers.get('X-Voice-Duration-Ms'));
 if(!Number.isInteger(durationMs)||durationMs<100||durationMs>8000)fail(400,'语音最多 8 秒');
 if(Number(request.headers.get('Content-Length'))>MAX_VOICE_BYTES)fail(413,'语音太大，请缩短后重试');
 const reader=request.body?.getReader();if(!reader)fail(400,'没有收到语音');
 const chunks=[];let size=0;
 try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>MAX_VOICE_BYTES){await reader.cancel();fail(413,'语音太大，请缩短后重试');}chunks.push(value);}}finally{reader.releaseLock();}
 const bytes=new Uint8Array(size);let offset=0;for(const chunk of chunks){bytes.set(chunk,offset);offset+=chunk.length;}
 const text=(from,to)=>String.fromCharCode(...bytes.slice(from,to));
 const valid=size>=12&&(mime==='audio/mp4'?text(4,8)==='ftyp':mime==='audio/webm'?bytes[0]===0x1a&&bytes[1]===0x45&&bytes[2]===0xdf&&bytes[3]===0xa3:mime==='audio/ogg'?text(0,4)==='OggS':text(0,4)==='RIFF'&&text(8,12)==='WAVE');
 if(!valid)fail(415,'没有收到有效的语音文件');
 return {bytes,mime,durationMs};
}
export async function handleVoice(room,request,kind,id,store,token){
 room.socialMember(token);
 if(kind==='voice-read'){
  if(!room.socialMessages.some(m=>m.kind==='voice'&&m.id===id))fail(404,'这条语音已过期');
  const clip=await store.get('voice:'+id);if(!clip)fail(404,'这条语音已过期');
  return new Response(clip.bytes,{headers:{'Content-Type':clip.mime,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
 }
 const clip=await readVoiceUpload(request);
 // Buffer outside the commit lock; serialize only ID allocation and storage.
 const commit=(uploadQueues.get(room)||Promise.resolve()).then(async()=>{
 room.socialMember(token);
 const before=await store.get('voice:index')||[];
 // Store first, so a failed upload cannot leave a visible but unplayable message.
 const futureId=`${room.code}-${++room.socialSequence}`;
 await store.put('voice:'+futureId,{bytes:clip.bytes,mime:clip.mime});
 let message;try{message=room.addSocial(token,{kind:'voice',durationMs:clip.durationMs},{reservedId:futureId});}catch(e){await store.delete('voice:'+futureId);throw e;}
 const retained=before.concat(message.id).filter(old=>room.socialMessages.some(m=>m.id===old)).slice(-6);
 await store.put('voice:index',retained);
 for(const old of before)if(!retained.includes(old))await store.delete('voice:'+old);
 return Response.json({message,snapshot:room.snapshot(token)},{status:201,headers:{'Cache-Control':'no-store'}});
 });
 uploadQueues.set(room,commit.catch(()=>{}));return commit;
}
