import test from 'node:test';
import assert from 'node:assert/strict';
import {rewritePaths,staticManifest} from '../scripts/build-pages.mjs';
test('Pages rewrite scopes assets but preserves external URLs and relative module imports',()=>{
 const input=`<img src="/img/avatar.png"><script src='/teaching-boot.js'></script> import './worker.mjs'; const url='/modules/teaching/ui.mjs'; const ext='https://example.com/img/a.png'; x.split('/'); url(/fonts/a.woff2);`;
 const result=rewritePaths(input,'/holdem-practice/',['img','modules','fonts','teaching-boot.js']);
 assert.match(result,/src="\/holdem-practice\/img\/avatar.png/);assert.match(result,/url\(\/holdem-practice\/fonts/);assert.match(result,/import '\.\/worker.mjs'/);assert.match(result,/https:\/\/example.com\/img/);assert.match(result,/split\('\/'\)/);
});
test('static manifest is scoped to project path and excludes server-only handlers',()=>{
 const result=staticManifest({start_url:'/',id:'/',scope:'/',icons:[{src:'/icon.png'}],share_target:{action:'/share-target'},scope_extensions:[{origin:'https://pokerth.net'}],file_handlers:[],protocol_handlers:[]},'/holdem-practice/');
 assert.equal(result.start_url,'/holdem-practice/?lang=zh');assert.equal(result.scope,'/holdem-practice/');assert.equal(result.icons[0].src,'/holdem-practice/icon.png');assert.equal(result.share_target,undefined);assert.equal(result.scope_extensions,undefined);
});
