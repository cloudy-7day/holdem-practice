import test from 'node:test';
import assert from 'node:assert/strict';
import {decide,ARCHETYPES} from '../public/modules/offline/bots.mjs';
function random(seed){return ()=>{seed=(Math.imul(1664525,seed)+1013904223)>>>0;return seed/4294967296;};}
function ctx(hole,n=9,pos=3){const committed=pos===1?10:pos===2?20:0;return {gameState:'preflop',hole,board:[],stack:2000,numPlayers:n,numActive:n,posFromButton:pos,mRatio:66,legal:{street:'preflop',bb:20,pot:30,callAmt:20-committed,canCheck:pos===2,canRaise:true,minRaiseTo:40,maxRaiseTo:2000+committed}};}
function bot(arch,seed=31){const a=ARCHETYPES[arch];return {...a,arch,aggr:(a.aggrLo+a.aggrHi)/2,skill:'normal',rng:random(seed)};}
test('AA enters deep unopened eight- and nine-handed pots regardless of seed',()=>{
 for(const n of [8,9])for(let seed=1;seed<=50;seed++)assert.notEqual(decide(ctx([12,25],n),bot('tag',seed)).action,'fold');
});
test('seeded ranges retain tight and loose archetypes and widen late without forcing entry',t=>{
 const rng=random(9021),holes=Array.from({length:2000},()=>{const a=Math.floor(rng()*52);let b;do{b=Math.floor(rng()*52);}while(a===b);return [a,b];});
 const rates={};
 for(const arch of ['rock','tag','lag','station','maniac'])for(const pos of [3,0]){
   const config=bot(arch);rates[`${arch}:${pos}`]=holes.filter(h=>decide(ctx(h,9,pos),config).action!=='fold').length/holes.length;
 }
 t.diagnostic(JSON.stringify(rates));
 assert.ok(rates['rock:3']>=0.08&&rates['rock:3']<=0.20);
 assert.ok(rates['tag:3']>=0.10&&rates['tag:3']<=0.23);
 assert.ok(rates['tag:0']>rates['tag:3']&&rates['tag:0']<0.4);
 assert.ok(rates['lag:3']>rates['tag:3']);
 assert.ok(rates['station:3']>rates['lag:3']);
 assert.ok(rates['maniac:3']>rates['station:3']&&rates['maniac:3']<0.85);
});
test('BB facing a minraise uses a raised-pot decision despite calling only one blind',()=>{
 const hand=ctx([0,18],9,2);hand.legal={...hand.legal,pot:70,callAmt:20,canCheck:false,minRaiseTo:60};
 assert.equal(decide(hand,bot('rock')).action,'fold');
});
