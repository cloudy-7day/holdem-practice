import test from 'node:test';
import assert from 'node:assert/strict';
import {FakeServer} from '../public/modules/offline/server.mjs';

function setup(n=3,money=3000){
  let now=0,seq=0;const queue=[],packets=[],frames=[],messages=[];
  const server=new FakeServer({rng:()=>0.42,config:{maxPlayers:n,startMoney:money},deliver:f=>frames.push({at:now,f}),publish:p=>packets.push({at:now,p}),pace:(fn,ms=0)=>queue.push({fn,at:now+ms,seq:seq++})});
  const send=server._send.bind(server);server._send=(name,spec)=>{messages.push({name,at:now});send(name,spec);};
  const step=()=>{queue.sort((a,b)=>a.at-b.at||a.seq-b.seq);const task=queue.shift();if(!task)return false;now=task.at;task.fn();return true;};
  server._onStartRequest();server._onStartAck();
  return {server,packets,frames,messages,step,get now(){return now;},queue};
}
function finish(s,action='call'){
  for(let i=0;i<1000;i++){
    if(s.packets.at(-1)?.p.type==='complete')return s.packets.at(-1).p.report;
    if(s.server.table?.h?._pendingId===1&&s.server._visibleTurn===1){
      s.server._onMyAction({4:[action==='fold'?1:3],5:[0]});
    }else assert.ok(s.step(),'scheduler stalled before completion');
  }
  assert.fail('hand never completed');
}
test('real OfflineTable logs snapshots, bots finish after hero folds, manual next is single use',()=>{
  const s=setup();const report=finish(s,'fold');
  assert.equal(report.players.length,3);assert.ok(report.players.every(p=>p.hole.length===2));
  assert.ok(report.players.find(p=>p.id===1).folded);
  assert.ok(report.decisions.some(d=>d.playerId!==1));
  assert.equal(report.players.reduce((v,p)=>v+p.net,0),0);
  assert.ok(report.decisions.every(d=>d.context.hole.length===2));
  for(const d of report.decisions){
    assert.ok(d.context.publicPlayers.every(p=>!('hole' in p)&&!('cards' in p)));
    assert.ok(d.context.publicHistory.every(a=>!('hole' in a)&&!('context' in a)));
    assert.ok(d.context.publicHistory.length<report.decisions.length);
    assert.equal(d.context.heroTotalCommitted,d.context.publicPlayers.find(p=>p.id===d.playerId).committed);
  }
  assert.ok(report.players.every(p=>Number.isFinite(p.voluntaryPaid)&&Number.isFinite(p.committed)));
  const serialized=JSON.stringify(report.decisions);
  while(s.step()){} // no automatic next hand, even after every timer drains
  assert.equal(s.server.table.handNum,1);
  assert.equal(s.server.resumeNextHand(),true);assert.equal(s.server.resumeNextHand(),false);
  s.step();assert.equal(s.server.table.handNum,2);
  assert.equal(JSON.stringify(report.decisions),serialized);
});
test('live packets hide bots and pause before committed bot actions',()=>{
  const s=setup();finish(s);
  let lastAction=-Infinity;
  for(const {p,at} of s.packets){
    if(p.type==='action'){assert.ok(at-lastAction>=650);lastAction=at;}
    if(p.type==='thinking'){assert.equal(p.context,undefined);assert.equal(p.hole,undefined);assert.ok(at-lastAction>=650);}
    if(p.type==='turn')assert.equal(p.context.playerId,1);
  }
});
test('human waits indefinitely and reset invalidates stale timers',()=>{
  const s=setup();
  for(let i=0;i<100&&s.server._visibleTurn!==1;i++)assert.ok(s.step());
  while(s.step()){}
  assert.equal(s.server.table.h._pendingId,1);assert.equal(s.server._humanTimer,null);
  s.server._onMyAction({4:[1],5:[0]});
  s.server._closeAndReset();const count=s.packets.length;
  while(s.step()){}
  assert.equal(s.packets.length,count);assert.equal(s.server.resumeNextHand(),false);
});
test('all-in runout is displayed before complete, terminal report prevents next hand',()=>{
  const s=setup(2,20);const report=finish(s);
  assert.equal(report.board.length,5);assert.equal(report.canContinue,false);
  assert.equal(s.server.resumeNextHand(),false);
  const completed=s.packets.find(p=>p.p.type==='complete');
  assert.ok(completed.at>=300+3*s.server._roStep());
  const river=s.messages.find(m=>m.name==='DealRiver');
  const show=s.messages.find(m=>m.name==='EndOfHandShow');
  assert.ok(river&&show);assert.ok(river.at<show.at&&show.at<completed.at);
});
test('dealmeaces chat command cannot alter deck',()=>{
  const s=setup();while(!s.server.table.h)assert.ok(s.step());const before=JSON.stringify(s.server.table.h.hole);
  s.server._onChat({3:[new TextEncoder().encode('/dealmeaces')]});
  assert.equal(s.server._eggAces,false);assert.equal(JSON.stringify(s.server.table.h.hole),before);
});
test('human raise input adds new chips to existing street commitment',()=>{
  const s=setup(2);
  for(let i=0;i<100&&s.server._visibleTurn!==1;i++)assert.ok(s.step());
  const h=s.server.table.h, committed=h.streetCommit[1];
  assert.ok(committed>0,'heads-up hero has posted a blind');
  s.server._onMyAction({4:[5],5:[100]});
  const action=s.packets.filter(x=>x.p.type==='action'&&x.p.playerId===1).at(-1).p;
  assert.equal(action.paid,100);assert.equal(action.totalStreetBet,committed+100);
});


test('folded and all-in heroes use faster pace, fresh hand restores normal pace',()=>{
  const s=setup();
  while(!s.server.table.h)assert.ok(s.step());
  const h=s.server.table.h;
  assert.equal(s.server._actionGap(),650);
  // A zero stack alone must not switch presentation mode (engine settlement).
  s.server.table.players.find(p=>p.id===1).stack=0;
  assert.equal(s.server._actionGap(),650);
  h.folded[1]=true;assert.equal(s.server._actionGap(),300);
  h.folded[1]=false;h.allin[1]=true;assert.equal(s.server._actionGap(),300);
  h.allin[1]=false;assert.equal(s.server._actionGap(),650);
});

test('bot decisions keep normal and spectator intervals within their intended ranges',()=>{
  for(const fold of [false,true]){
    const s=setup();finish(s,fold?'fold':'call');
    let pending, previousAction, watching=false, checked=0, fastChecked=0;
    for(const {p,at} of s.packets){
      if(p.type==='thinking')pending={at,watching};
      if(p.type==='action'){
        if(p.playerId===1 && p.action==='fold')watching=true;
        if(p.playerId!==1 && pending){
          const min=pending.watching?400:950,max=pending.watching?900:1850;
          assert.ok(at-pending.at>=min && at-pending.at<=max);
          if(previousAction!==undefined){
            const minTotal=pending.watching?700:1600;
            const maxTotal=pending.watching?1200:2500;
            assert.ok(at-previousAction>=minTotal && at-previousAction<=maxTotal);
          }
          checked++;if(pending.watching)fastChecked++;pending=undefined;
        }
        previousAction=at;
      }
    }
    assert.ok(checked>0);
    if(fold)assert.ok(fastChecked>0,'fold must exercise spectator bot timing');
  }
});
