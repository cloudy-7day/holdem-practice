import test from 'node:test';
import assert from 'node:assert/strict';
import {decide, ARCHETYPES} from '../public/modules/offline/bots.mjs';
function random(seed){return()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/2**32;};}
function bot(seed){return {...ARCHETYPES.tag,arch:'tag',aggr:.65,skill:'normal',rng:random(seed)};}
function ctx(overrides={}){return {hole:[12,25],board:[0,16,33],stack:2000,numActive:2,numPlayers:6,mRatio:66,legal:{street:'flop',bb:20,pot:300,callAmt:100,canCheck:false,canRaise:true,minRaiseTo:200,maxRaiseTo:2000},...overrides};}
test('postflop short stack does not invoke preflop shove-or-fold',()=>{
 const c=ctx({stack:220,mRatio:7.33,legal:{...ctx().legal,maxRaiseTo:220}});
 const actions=Array.from({length:100},(_,i)=>decide(c,bot(i+1)));
 assert.ok(actions.some(a=>a.action==='call'),'one pair must retain a calling line');
 assert.ok(actions.some(a=>a.action==='raise'),'short-stack value raises remain available');
});
test('8 BB push-fold uses actual blinds and preserves strong-hand jams',()=>{
 const c=ctx({board:[],stack:160,mRatio:160/30,stackBB:8,legal:{...ctx().legal,street:'preflop',pot:30,callAmt:20,minRaiseTo:40,maxRaiseTo:160}});
 assert.deepEqual(decide(c,bot(1)),{action:'raise',amountTo:160});
 const deep={...c,stack:220,mRatio:220/30,stackBB:11,legal:{...c.legal,maxRaiseTo:220}};
 assert.ok(decide(deep,bot(1)).amountTo!==220,'11 BB does not trigger 8 BB push-fold');
});
test('BB facing a minraise sizes a genuine reraise',()=>{
 const c=ctx({board:[],stack:2000,legal:{...ctx().legal,street:'preflop',pot:70,callAmt:20,minRaiseTo:60,maxRaiseTo:2020}});
 const raises=Array.from({length:20},(_,i)=>decide(c,bot(i+1))).filter(a=>a.action==='raise');
 assert.ok(raises.length>0);for(const a of raises)assert.equal(a.amountTo,121);
});
test('postflop raise sizing uses call plus pot fraction and treats minimum as floor',()=>{
 // Quads can raise for value even against a strong opponent range.
 const c=ctx({hole:[12,25],board:[38,51,0,16,33],legal:{...ctx().legal,street:'river',pot:700,callAmt:200,minRaiseTo:600,maxRaiseTo:2100}});
 const d=decide(c,bot(1));assert.equal(d.action,'raise');
 assert.equal(d.amountTo,836); // current bet 300 + .595 * (700 + 200)
});
test('ordinary broadways do not continue against a deep 4-bet just on random-hand equity',()=>{
 const c=ctx({hole:[12,22],board:[],legal:{...ctx().legal,street:'preflop',pot:1000,callAmt:400,minRaiseTo:800,maxRaiseTo:2000}});
 for(let seed=1;seed<=20;seed++)assert.equal(decide(c,bot(seed)).action,'fold');
});

test('multiway aggressor checks weak air instead of automatic continuation bets',()=>{
 const actions=[];
 for(let seed=1;seed<=100;seed++)actions.push(decide(ctx({hole:[0,18],board:[12,24,35],numActive:8,playerId:1,aggressorId:1,legal:{...ctx().legal,pot:400,callAmt:0,canCheck:true,minRaiseTo:20}}),{...bot(seed),aggr:.9}));
 const bets=actions.filter(d=>d.action==='raise').length;
 assert.ok(bets<25,`weak-air multiway bets: ${bets}/100`);
});
