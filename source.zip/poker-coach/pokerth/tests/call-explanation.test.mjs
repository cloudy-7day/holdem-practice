import test from 'node:test';
import assert from 'node:assert/strict';
import {analyzeHand} from '../public/modules/teaching/analysis.mjs';
const cs=s=>s.split(' ').map(c=>'23456789TJQKA'.indexOf(c[0])+13*'dhsc'.indexOf(c[1]));
function context(overrides={}){return {playerId:1,gameState:'preflop',hole:cs('Ah Ac'),board:[],stack:2000,streetCommitted:20,currentBet:1194,posFromButton:2,numPlayers:2,numActive:2,publicPlayers:[{id:1,name:'你',stack:2000},{id:2,name:'小林',stack:2000}],publicHistory:[{playerId:2,street:'preflop',action:'raise',isAggressive:true,paid:1194,totalStreetBet:1194,potBefore:306}],legal:{bb:20,pot:1500,callAmt:1174,canRaise:true,minRaiseTo:2368,maxRaiseTo:2020},...overrides};}
const review=(c,action='call')=>analyzeHand({heroId:1,decisions:[{playerId:1,action,paid:c.legal.callAmt,totalStreetBet:c.streetCommitted+c.legal.callAmt,context:c}]}).heroReviews[0];
test('1174 is explicitly an additional chip payment with source and remaining stack',()=>{
 const r=review(context());assert.equal(r.recommendedAction,'call');
 assert.match(r.title,/再投入 1174 筹码/);
 assert.match(r.callExplanation,/小林.*1194 筹码/);assert.match(r.callExplanation,/本轮已经投入 20 筹码/);assert.match(r.callExplanation,/额外投入 1174 筹码/);assert.match(r.callExplanation,/桌上.*1500 筹码/);assert.match(r.callExplanation,/还剩 826 筹码/);assert.match(r.callExplanation,/一半/);
 assert.match(r.briefReason,/一对A/);assert.doesNotMatch(r.briefReason,/还有机会配好，先跟着就行/);assert.doesNotMatch(r.reason,/价格较低/);
});
test('short all-in explains the unfilled difference without claiming to match the opponent',()=>{
 const c=context({stack:500,legal:{bb:20,pot:1500,callAmt:500,canRaise:false,maxRaiseTo:520}});const r=review(c,'allin');
 assert.match(r.callExplanation,/还差 1174 筹码/);assert.match(r.callExplanation,/只有 500 筹码/);assert.match(r.callExplanation,/全下/);assert.match(r.callExplanation,/本轮合计 520 筹码/);assert.doesNotMatch(r.callExplanation,/补齐|还剩 -/);
});
test('call amounts use the action snapshot, never the eventual result',()=>{
 const c=context(),d={playerId:1,action:'call',paid:1174,totalStreetBet:1194,context:c};
 const first=analyzeHand({heroId:1,decisions:[d]}).heroReviews[0];
 const second=analyzeHand({heroId:1,decisions:[d],players:[{id:1,stack:0,net:-2000},{id:2,name:'另一个名字',hole:cs('Ks Kc')}],winnerIds:[2]}).heroReviews[0];
 assert.equal(first.callExplanation,second.callExplanation);
});
test('no public bettor identity is invented when history does not match current street',()=>{
 const c=context({gameState:'turn',board:cs('As 9d 3h 5s')});const r=review(c);assert.doesNotMatch(r.callExplanation,/小林/);assert.match(r.callExplanation,/对方/);
});
