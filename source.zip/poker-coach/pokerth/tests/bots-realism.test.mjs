import test from 'node:test';
import assert from 'node:assert/strict';
import { decide, ARCHETYPES } from '../public/modules/offline/bots.mjs';
function random(seed){return ()=>{seed=(Math.imul(1664525,seed)+1013904223)>>>0;return seed/4294967296;};}
function context(hole,pos=3){const committed=pos===1?10:pos===2?20:0;return {gameState:'preflop',hole,board:[],stack:2000,numPlayers:6,numActive:6,posFromButton:pos,mRatio:66,currentBet:20,minRaise:20,streetCommitted:committed,legal:{street:'preflop',bb:20,pot:30,callAmt:20-committed,canCheck:pos===2,canRaise:true,minRaiseTo:40,maxRaiseTo:2000+committed}};}
const bot=(rng,arch='tag')=>({...ARCHETYPES[arch],aggr:(ARCHETYPES[arch].aggrLo+ARCHETYPES[arch].aggrHi)/2,skill:'normal',rng});
test('deep-stack TAG never folds AA first to act in unopened six-handed pot',()=>{
 for(let seed=1;seed<=20;seed++)assert.notEqual(decide(context([12,25]),bot(random(seed))).action,'fold',`AA folded seed ${seed}`);
});
test('seeded unopened-seat sample does not fold virtually every hand',t=>{
 const rng=random(71401), holes=Array.from({length:200},()=>{const a=Math.floor(rng()*52);let b;do{b=Math.floor(rng()*52);}while(a===b);return[a,b];});
 const rates=[];
 for(const pos of [3,4,5,0,1,2]){
  let folds=0;const config=bot(random(803+pos));
  for(const hole of holes)if(decide(context(hole,pos),config).action==='fold')folds++;
  rates.push({pos,folds,total:holes.length,rate:folds/holes.length});
 }
 t.diagnostic(JSON.stringify(rates));
 for(const {pos,rate} of rates)assert.ok(rate<=0.90,`seat ${pos} folds ${(rate*100).toFixed(1)}% of initial decisions`);
});
