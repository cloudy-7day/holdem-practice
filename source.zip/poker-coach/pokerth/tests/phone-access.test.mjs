import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const serverPath = new URL('../local-server.cjs', import.meta.url);
async function withServer(host, run) {
  const child = spawn(process.execPath, [fileURLToPath(serverPath)], {
    env: { ...process.env, POKER_HOST: host, POKER_PORT: '0' }, stdio: ['ignore', 'pipe', 'pipe'],
  });
  let output = '';
  try {
    const port = await new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('Server startup timed out')), 5000);
      child.once('exit', code => { clearTimeout(timer); reject(new Error(`Server exited: ${code}`)); });
      child.stdout.on('data', data => {
        output += data;
        const match = output.match(/:(\d+)\/\?lang/);
        if (match) { clearTimeout(timer); resolve(Number(match[1])); }
      });
    });
    await run(port);
  } finally { child.kill(); }
}

for (const host of ['', '127.0.0.1', '0.0.0.0']) {
  test(`explicit bind host ${host} is reflected in health and serves game`, async () => {
    await withServer(host, async port => {
      const base = `http://127.0.0.1:${port}`;
      const health = await (await fetch(`${base}/health`)).json();
      assert.equal(health.host, host || '127.0.0.1');
      assert.equal(health.port, port);
      assert.equal((await fetch(`${base}/?lang=zh`)).status, 200);
      assert.equal((await (await fetch(`${base}/app-config`)).json()).modes.offline, true);
    });
  });
}

test('reject unsupported bind hosts before listening', async () => {
  const child = spawn(process.execPath, [fileURLToPath(serverPath)], {
    env: { ...process.env, POKER_HOST: 'example.com', POKER_PORT: '0' }, stdio: 'pipe',
  });
  const timer = setTimeout(() => child.kill(), 5000);
  let stderr = '';
  child.stderr.on('data', chunk => { stderr += chunk; });
  const code = await new Promise(resolve => child.once('exit', resolve));
  clearTimeout(timer);
  assert.equal(code, 1);
  assert.match(stderr, /POKER_HOST/);
});
