import test from 'node:test';
import assert from 'node:assert/strict';
import {evaluateSpot} from '../public/modules/teaching/equity.mjs';
import {analyzeHand} from '../public/modules/teaching/analysis.mjs';
const cards=s=>s.split(' ').map(c=>'23456789TJQKA'.indexOf(c[0])+13*'dhsc'.indexOf(c[1]));
const context=(extra={})=>({playerId:1,hole:cards('As Ah'),board:cards('Ad 7c 2h'),stack:1000,heroTotalCommitted:100,publicPlayers:[{id:1,committed:100},{id:2,committed:50,allin:true},{id:3,committed:200}],legal:{pot:350,callAmt:100},...extra});
test('complete contribution layers give top set a valid price and profitable call',()=>{
 const r=evaluateSpot(context(),{samples:200});assert.equal(r.threshold,100/450);assert.ok(r.callEV>300);assert.ok(r.equity>.9);
});
test('complete short-stack side pot does not make top set fold in review',()=>{
 const c={...context(),gameState:'flop',numPlayers:3,currentBet:100,streetCommitted:0};
 const r=analyzeHand({heroId:1,decisions:[{playerId:1,action:'call',paid:100,totalStreetBet:100,context:c}]}).heroReviews[0];
 assert.equal(r.recommendedAction,'call');assert.notEqual(r.severity,'warning');
});
test('shared board splits main pot and larger side pot by their own eligible counts',()=>{
 const r=evaluateSpot(context({hole:cards('2d 3d'),board:cards('Th Jh Qh Kh Ah')}),{samples:100});
 // Main 150 / 3, side 300 / 2: hero receives 200 from the projected 450.
 assert.equal(r.equity,200/450);assert.equal(r.callEV,100);
});
test('folded chips remain in layers without giving a folded player a share',()=>{
 const r=evaluateSpot(context({hole:cards('2d 3d'),board:cards('Th Jh Qh Kh Ah'),publicPlayers:[{id:1,committed:100},{id:2,committed:50,allin:true},{id:3,committed:200},{id:4,committed:50,folded:true}],legal:{pot:400,callAmt:100}}),{samples:100});
 assert.ok(Math.abs(r.callEV-(200/3+150-100))<1e-9);
});
test('normal single pot retains equal showdown share',()=>{
 const r=evaluateSpot(context({hole:cards('2d 3d'),board:cards('Th Jh Qh Kh Ah'),publicPlayers:[{id:1,committed:100},{id:2,committed:200}],legal:{pot:300,callAmt:100}}),{samples:100});assert.equal(r.equity,.5);assert.equal(r.threshold,.25);assert.equal(r.callEV,100);
});
test('ordinary multiway pending call keeps current pot price without inventing layers',()=>{
 const r=evaluateSpot(context({publicPlayers:[{id:1,committed:100},{id:2,committed:200},{id:3,committed:100}],legal:{pot:400,callAmt:100}}),{samples:100});
 assert.equal(r.threshold,.2);assert.equal(r.equityModel,'showdown');assert.notEqual(r.callEV,null);
});
test('complete short all-in layers identify weighted rather than whole-field equity',()=>{
 assert.equal(evaluateSpot(context(),{samples:100}).equityModel,'layered');
});
test('unmatched live player prevents fabricated uncontested side layer',()=>{
 const r=evaluateSpot(context({publicPlayers:[{id:1,committed:100},{id:2,committed:50,allin:true},{id:3,committed:100}],legal:{pot:250,callAmt:100}}),{samples:100});assert.equal(r.threshold,null);assert.equal(r.callEV,null);
});
test('layered estimation is independent of hidden hands and future outcomes',()=>{
 const c=context(),r=evaluateSpot(c,{samples:100});assert.deepEqual(r,evaluateSpot({...c,opponentHole:cards('Ac Kc'),futureBoard:cards('Kd Qd'),result:'loss'},{samples:100}));
});
test('losing to the short stack does not also forfeit the larger side pot',()=>{
 const c=context(),layered=evaluateSpot(c,{samples:1200}),wholeField=evaluateSpot({...c,heroTotalCommitted:undefined},{samples:1200});
 assert.ok(layered.equity>wholeField.equity+.005);
});
