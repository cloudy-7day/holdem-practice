import test from 'node:test';
import assert from 'node:assert/strict';
import { analyzeHand } from '../public/modules/teaching/analysis.mjs';
const decision=(action='fold', overrides={})=>({playerId:1,action,paid:0,totalStreetBet:0,context:{gameState:'preflop',hole:[12,25],board:[],stack:1000,currentBet:20,minRaise:20,streetCommitted:0,posFromButton:3,numPlayers:6,legal:{bb:20,pot:30,callAmt:20,canRaise:true,minRaiseTo:40,maxRaiseTo:1000},...overrides}});
const report=d=>({heroId:1,bb:20,decisions:[d],players:[]});
test('AA fold is specifically warned about',()=>assert.equal(analyzeHand(report(decision())).heroReviews[0].severity,'warning'));
test('hero advice is invariant to results and revealed opponent cards',()=>{
 const a=report(decision('call')); const b={...a,board:[1,2,3,4,5],winnerIds:[2],players:[{id:2,hole:[0,13],net:999}]};
 assert.deepEqual(analyzeHand(a).heroReviews,analyzeHand(b).heroReviews);
});
test('call uses snapshot pot odds and exact action',()=>{
 const r=analyzeHand(report(decision('call',{gameState:'turn',hole:[0,14],board:[3,6,9,11],legal:{pot:100,callAmt:50,canRaise:true,minRaiseTo:100,maxRaiseTo:1000}}))).heroReviews[0];
 assert.equal(r.action,'call'); assert.ok(Math.abs(r.threshold-1/3)<0.001); assert.match(r.evidence.join(' '),/转牌/);
});
test('short all-in call does not propose unavailable raise',()=>{
 const r=analyzeHand(report(decision('allin',{stack:10,currentBet:100,legal:{pot:200,callAmt:10,canRaise:false,minRaiseTo:200,maxRaiseTo:10}}))).heroReviews[0];
 assert.match(r.reason,/跟注/); assert.doesNotMatch(r.suggestion,/加注到/);
});
test('ordinary early opening hand gets no blanket warning',()=>{
 const r=analyzeHand(report(decision('raise',{hole:[8,21]}))).heroReviews[0]; assert.notEqual(r.severity,'warning');
});
test('weak costly early call is flagged',()=>{
 const r=analyzeHand(report(decision('call',{hole:[0,18],currentBet:100,legal:{bb:20,pot:150,callAmt:100,canRaise:true,minRaiseTo:180,maxRaiseTo:1000}}))).heroReviews[0]; assert.equal(r.severity,'warning');
});
test('raise suggestions respect minimum and available stack',()=>{
 const r=analyzeHand(report(decision('fold',{currentBet:150,minRaise:100,legal:{bb:20,pot:300,callAmt:150,canRaise:true,minRaiseTo:250,maxRaiseTo:600}}))).heroReviews[0];
 assert.ok(r.recommendedTo>=250&&r.recommendedTo<=600);assert.match(r.title,/本次再投/);
});
test('future river and losing outcome never change flop advice',()=>{
 const a=report(decision('call',{gameState:'flop',hole:[12,25],board:[0,14,28]}));
 const b={...a,board:[0,14,28,39,40],winnerIds:[2],players:[{id:1,net:-1000},{id:2,hole:[1,2],net:1000}]};
 assert.deepEqual(analyzeHand(a).heroReviews,analyzeHand(b).heroReviews);
 assert.doesNotMatch(analyzeHand(b).heroReviews[0].reason,/K♣/);
});
test('checking river four of a kind discusses potential value',()=>{
 const r=analyzeHand(report(decision('check',{gameState:'river',hole:[12,25],board:[38,51,0,4,8],currentBet:0,legal:{pot:200,callAmt:0,canCheck:true,canRaise:true,minRaiseTo:20,maxRaiseTo:1000}}))).heroReviews[0];
 assert.match(r.reason,/价值/);
});
test('unpaired river costly call gets concrete warning',()=>{
 const r=analyzeHand(report(decision('call',{gameState:'river',hole:[0,14],board:[3,19,35,11,25],legal:{pot:100,callAmt:100,canRaise:true,minRaiseTo:200,maxRaiseTo:1000}}))).heroReviews[0];
 assert.equal(r.severity,'warning'); assert.match(r.reason,/没有后续公共牌/);
});
test('overlarge playable opening raise is not praised automatically',()=>{
 const d=decision('raise',{hole:[8,21]});d.paid=1000;d.totalStreetBet=1000;
 assert.notEqual(analyzeHand(report(d)).heroReviews[0].severity,'good');
});
test('folding free check is flagged',()=>{
 const r=analyzeHand(report(decision('fold',{hole:[0,18],legal:{pot:30,callAmt:0,canCheck:true,canRaise:true,minRaiseTo:40,maxRaiseTo:1000}}))).heroReviews[0];
 assert.equal(r.severity,'warning');assert.match(r.reason,/免费/);
});
test('river shared board strong hand is not automatically value bet',()=>{
 const r=analyzeHand(report(decision('raise',{gameState:'river',hole:[0,14],board:[8,9,10,11,12],legal:{pot:100,callAmt:0,canCheck:true,canRaise:true,minRaiseTo:20,maxRaiseTo:1000}}))).heroReviews[0];
 assert.match(r.reason,/公共牌本身/);
});
test('heads-up blind labels follow engine seat order',()=>{
 const sb=analyzeHand(report(decision('call',{numPlayers:2,posFromButton:0}))).heroReviews[0];
 const bb=analyzeHand(report(decision('check',{numPlayers:2,posFromButton:1}))).heroReviews[0];
 assert.match(sb.evidence.join(' '),/按钮位兼小盲/);assert.match(bb.evidence.join(' '),/大盲位/);
 assert.doesNotMatch(sb.evidence.join(' '),/索引/);
});
test('short allin never presents full pot as required equity threshold',()=>{
 const r=analyzeHand(report(decision('allin',{stack:10,currentBet:100,legal:{pot:200,callAmt:10,canRaise:false,minRaiseTo:200,maxRaiseTo:10}}))).heroReviews[0];
 assert.doesNotMatch(r.reason,/门槛为|至少约/);assert.match(r.reason,/边池/);
});

test('Ah7c turn gutshot faces 24.5 percent price: fold, not flush draw',()=>{
 const r=analyzeHand(report(decision('call',{gameState:'turn',hole:[25,44],board:[23,48,13,8],numActive:3,legal:{pot:1012,callAmt:329,canRaise:true,minRaiseTo:658,maxRaiseTo:1000}}))).heroReviews[0];
 assert.equal(r.recommendedAction,'fold'); assert.match(r.suggestion,/K|国王/); assert.ok(Math.abs(r.threshold-329/1341)<0.001); assert.ok(r.draws.some(d=>d.outs===4&&Math.abs(d.nextCardProbability-4/46)<0.001)); assert.match(r.reason,/不是同花听牌/); assert.equal(r.verdict,'需要改进'); assert.ok(r.ranges.length); assert.ok(r.sources.length);
});
test('Ah7c flop check preserves chips with only backdoor hearts',()=>{
 const r=analyzeHand(report(decision('check',{gameState:'flop',hole:[25,44],board:[23,48,13],numActive:3,legal:{pot:100,callAmt:0,canCheck:true,canRaise:true,minRaiseTo:20,maxRaiseTo:1000}}))).heroReviews[0];
 assert.equal(r.recommendedAction,'check'); assert.equal(r.verdict,'合理'); assert.match(r.reason,/后门/); assert.match(r.suggestion,/转牌/);
});

test('hero quads can value bet with legal size; shared board cannot',()=>{
 const r=analyzeHand(report(decision('check',{gameState:'river',hole:[12,25],board:[38,51,0,4,8],numActive:2,currentBet:0,legal:{pot:200,callAmt:0,canCheck:true,canRaise:true,minRaiseTo:20,maxRaiseTo:1000}}))).heroReviews[0];
 assert.equal(r.recommendedAction,'raise');assert.ok(r.recommendedTo>=20&&r.recommendedTo<=1000);assert.match(r.reason,/较差/);
});

test('button A7 offsuit can open rather than fold on multiway raw equity',()=>{
 const r=analyzeHand(report(decision('raise',{hole:[25,44],posFromButton:0,numPlayers:9,currentBet:20,legal:{bb:20,pot:30,callAmt:20,canRaise:true,minRaiseTo:40,maxRaiseTo:1000}}))).heroReviews[0];
 assert.equal(r.recommendedAction,'raise');assert.equal(r.verdict,'合理');
});
test('early 99 opening does not require premium-only opening range',()=>{
 const r=analyzeHand(report(decision('raise',{hole:[7,20]}))).heroReviews[0];
 assert.equal(r.recommendedAction,'raise');
});

test('own flop set bets for concrete worse made hands',()=>{
 const r=analyzeHand(report(decision('check',{gameState:'flop',hole:[0,13],board:[26,19,34],numActive:2,currentBet:0,legal:{pot:200,callAmt:0,canCheck:true,canRaise:true,minRaiseTo:20,maxRaiseTo:1000}}))).heroReviews[0];
 assert.equal(r.recommendedAction,'raise');assert.match(r.reason,/跟注|付费/);assert.ok(r.recommendedTo>=20);assert.ok(r.reason.length<350);
});
test('river ace high can call an extremely cheap price against wide range',()=>{
 const r=analyzeHand(report(decision('call',{gameState:'river',hole:[25,50],board:[36,7,43,14,26],numActive:2,currentBet:1,legal:{pot:1000,callAmt:1,canRaise:false}}))).heroReviews[0];
 assert.equal(r.recommendedAction,'call');
});
test('88 facing enormous preflop raise is not automatic strong hand call',()=>{
 const r=analyzeHand(report(decision('call',{hole:[6,19],currentBet:900,legal:{bb:20,pot:930,callAmt:900,canRaise:false}}))).heroReviews[0];
 assert.equal(r.recommendedAction,'fold');
});

test('private quads do not fold solely because sidepot threshold is unknown',()=>{
 const r=analyzeHand(report(decision('allin',{gameState:'river',hole:[12,25],board:[38,51,0,4,8],numActive:2,stack:10,currentBet:100,legal:{pot:200,callAmt:10,canRaise:false}}))).heroReviews[0];
 assert.equal(r.threshold,null);assert.equal(r.recommendedAction,'call');assert.match(r.reason,/边池/);
});

const card = x => '23456789TJQKA'.indexOf(x[0]) + 'dhsc'.indexOf(x[1])*13;
const spot = (hand,board,street='flop',cost=30,pot=100) => decision('call',{gameState:street,hole:hand.map(card),board:board.map(card),numPlayers:2,numActive:2,currentBet:cost,legal:{bb:20,pot,callAmt:cost,canRaise:true,minRaiseTo:cost*2||20,maxRaiseTo:1000}});
test('dry top pair explains price, beaten hands and future safe-card calls',()=>{
 const r=analyzeHand(report(spot(['As','Kh'],['Ad','7c','2h']))).heroReviews[0];
 assert.equal(r.recommendedAction,'call');assert.match(r.reason,/23\.1%/);assert.match(r.reason,/Q♦ A♥/);assert.match(r.reason,/暗三条|三条/);assert.doesNotMatch(r.suggestion,/无关小牌.*优先弃牌/);
});
test('wet top pair names flush and straight threats rather than generic pressure',()=>{
 const r=analyzeHand(report(spot(['As','Kh'],['Ah','Jh','Th']))).heroReviews[0];
 assert.match(r.reason,/红桃.*同花|同花.*红桃/);assert.match(r.reason,/顺子/);
});
test('river bluff catcher explains numeric price and actual value threats',()=>{
 const r=analyzeHand(report(spot(['As','Kh'],['Ad','Jc','8h','4d','2c'],'river',100,200))).heroReviews[0];
 assert.match(r.reason,/33\.3%/);assert.match(r.reason,/抓诈唬/);assert.match(r.reason,/两对|三条/);assert.doesNotMatch(r.reason,/后续压力/);
});
test('button Q9 suited fold to costly raise does not describe offsuit early position',()=>{
 const r=analyzeHand(report(decision('fold',{hole:['Qs','9s'].map(card),posFromButton:0,currentBet:202,legal:{bb:20,pot:300,callAmt:202,canRaise:true,minRaiseTo:384,maxRaiseTo:1000}}))).heroReviews[0];
 assert.equal(r.recommendedAction,'fold');assert.doesNotMatch(r.reason,/尤其前位|弱不同花/);assert.match(r.reason,/同花|Q/);
});
test('flop open ender explains eight nominal outs separately from showdown equity',()=>{
 const r=analyzeHand(report(spot(['7c','8s'],['4c','9c','6d'],'flop',61,90))).heroReviews[0];
 assert.match(r.reason,/8张/);assert.match(r.reason,/补牌.*不是.*胜率|命中率.*不是.*胜率/);assert.match(r.reason,/40\.4%/);
});
test('river free check never promises future improvement',()=>{
 const r=analyzeHand(report(spot(['7c','8s'],['4c','9c','6d','3c','Kh'],'river',0,100))).heroReviews[0];
 assert.doesNotMatch(r.reason,/保留现有摊牌价值和改善机会/);
});
test('all-in call on turn has no later betting realization penalty',()=>{
 const context={gameState:'turn',hole:[7,24],board:[12,44,13,31],stack:100,currentBet:100,numPlayers:2,legal:{pot:100,callAmt:100,canRaise:false}};
 const r=analyzeHand(report({playerId:1,action:'allin',paid:100,totalStreetBet:100,context})).heroReviews[0];
 assert.ok(r.equity>r.threshold&&r.equity-r.threshold<.035);assert.equal(r.recommendedAction,'call');
});
test('dry top pair good kicker can value bet without condemning a check',()=>{
 const d=spot(['As','Kh'],['Ad','7c','2h'],'flop',0,100);d.action='check';
 const r=analyzeHand(report(d)).heroReviews[0];assert.equal(r.recommendedAction,'raise');assert.notEqual(r.severity,'warning');assert.match(r.reason,/Q♦ A♥/);
});
test('dry overpair can value bet',()=>{
 const d=spot(['As','Ah'],['Kd','7c','2h'],'flop',0,100);d.action='bet';
 const r=analyzeHand(report(d)).heroReviews[0];assert.equal(r.recommendedAction,'raise');assert.equal(r.severity,'good');
});
test('nut quads facing bet can raise for worse full houses',()=>{
 const d=spot(['As','Ah'],['Ad','Ac','2h','7c','Kd'],'river',100,200);
 const r=analyzeHand(report(d)).heroReviews[0];assert.equal(r.recommendedAction,'raise');assert.match(r.reason,/价值/);
});
test('stack-sized value raise is accepted; a deep nut-hand shove still needs size justification',()=>{
 const context={gameState:'river',hole:['As','Ah'].map(card),board:['Ad','Ac','2h','7c','Kd'].map(card),stack:50,streetCommitted:0,currentBet:0,numPlayers:2,legal:{pot:200,callAmt:0,canRaise:true,minRaiseTo:20,maxRaiseTo:50}};
 const r=analyzeHand(report({playerId:1,action:'allin',paid:50,totalStreetBet:50,context})).heroReviews[0];
 assert.equal(r.recommendedTo,50);assert.equal(r.severity,'good');
 const big={...context,stack:1000,legal:{...context.legal,maxRaiseTo:1000}};
 const b=analyzeHand(report({playerId:1,action:'allin',paid:1000,totalStreetBet:1000,context:big})).heroReviews[0];
 assert.ok(b.recommendedTo<1000);assert.equal(b.severity,'note');assert.match(b.verdict,/尺寸需复核/);
});

test('top pair value-bet advice does not endorse a five-pot bet',()=>{
 const d=spot(['As','Kh'],['Ad','7c','2h'],'flop',0,100);d.action='bet';d.paid=500;d.totalStreetBet=500;
 const r=analyzeHand(report(d)).heroReviews[0];assert.equal(r.recommendedAction,'raise');assert.equal(r.verdict,'尺寸偏大');assert.match(r.reason,/5.0 倍/);
 const modest={...d,paid:40,totalStreetBet:40};assert.equal(analyzeHand(report(modest)).heroReviews[0].severity,'good');
});
test('very large nut-hand raise is qualified rather than automatically praised',()=>{
 const d=spot(['As','Ah'],['Ad','Ac','2h','7c','Kd'],'river',100,200);d.action='raise';d.paid=900;d.totalStreetBet=900;
 const r=analyzeHand(report(d)).heroReviews[0];assert.equal(r.recommendedAction,'raise');assert.equal(r.verdict,'大额加注，尺寸需复核');
});


test('compact decision reviews retain every action in order with specific reasons',()=>{
 const a=decision('raise');
 const b=spot(['As','Kh'],['Ad','7c','2h']);
 const rs=analyzeHand({heroId:1,decisions:[a,b],players:[]}).heroReviews;
 assert.deepEqual(rs.map(r=>r.action),['raise','call']);
 assert.ok(rs.every(r=>r.briefReason.length<=200&&r.briefReason.length>20));
 assert.match(rs[1].briefReason,/一对|顶对/);
 assert.match(rs[1].briefReason,/再跟30/);
 assert.doesNotMatch(rs[0].nextAdvice,/进入翻牌后|顶对好踢脚/);
});

test('oversized bet compact reason identifies the size problem and concrete alternative',()=>{
 const d=spot(['As','Kh'],['Ad','7c','2h'],'flop',0,100);
 d.action='bet';d.paid=500;d.totalStreetBet=500;
 const r=analyzeHand(report(d)).heroReviews[0];
 assert.match(r.briefReason,/尺寸|小注/);assert.match(r.nextAdvice,/下注 \d+/);
});

test('opponent strategy summarizes missed draw aggression with uncertainty',()=>{
 const flop=spot(['Ah','Kh'],['2h','7h','9c'],'flop',0,100);
 const river=spot(['Ah','Kh'],['2h','7h','9c','3s','Jd'],'river',0,200);
 for(const d of [flop,river]){d.playerId=2;d.action='bet';d.paid=50;}
 const r=analyzeHand({heroId:1,players:[{id:2,hole:['Ah','Kh'].map(card)}],decisions:[flop,river]}).playerReviews[0];
 assert.match(r.summary,/想等的牌没来.*可能/);assert.match(r.summary,/不能确定/);
 assert.doesNotMatch(r.summary,/翻牌：.*河牌：/);
});

test('unknown opponent cards never produce a confident value or bluff claim',()=>{
 const d=spot(['As','Kh'],['Ad','7c','2h']);d.playerId=2;d.action='bet';
 const r=analyzeHand({players:[{id:2}],decisions:[d]}).playerReviews[0];
 assert.match(r.summary,/没看到他的底牌/);assert.match(r.summary,/不能确定/);
});

test('K3 small blind review says why to fold in everyday language without hiding the price',()=>{
 const d=decision('call',{hole:['Ks','3d'].map(card),stack:2000,currentBet:122,streetCommitted:10,posFromButton:1,numPlayers:9,legal:{bb:20,pot:212,callAmt:112,canRaise:true,minRaiseTo:224,maxRaiseTo:2010}});
 const r=analyzeHand(report(d)).heroReviews[0];
 assert.equal(r.recommendedAction,'fold');assert.match(r.briefReason,/K♠ 3♦.*不同花/);assert.match(r.briefReason,/同样拿K、另一张牌比你大/);assert.match(r.briefReason,/再跟112.*弃牌/);assert.doesNotMatch(r.briefReason,/门槛|份额|权益|踢脚|%/);assert.equal(r.threshold,112/324);
});

test('shared royal straight explains splitting instead of winning from worse hands',()=>{
 const d=spot(['2s','3h'],['As','Kd','Qc','Jh','Ts'],'river',10,300);
 const r=analyzeHand(report(d)).heroReviews[0];
 assert.equal(r.recommendedAction,'call');assert.match(r.briefReason,/别人也能用/);assert.match(r.briefReason,/平分/);assert.doesNotMatch(r.briefReason,/赢一些更差|你凑出/);assert.ok(r.briefReason.length<=200);
});

test('river check copy leaves room for a later opponent bet',()=>{
 const d=spot(['8s','8h'],['As','Kd','Qc','Jh','2s'],'river',0,300);d.action='check';
 const r=analyzeHand(report(d)).heroReviews[0];
 assert.equal(r.recommendedAction,'check');assert.match(r.briefReason,/后面有人下注.*重新考虑/);assert.doesNotMatch(r.briefReason,/等最后比大小/);
});
