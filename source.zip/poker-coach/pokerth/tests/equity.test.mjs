import test from 'node:test';
import assert from 'node:assert/strict';
import {evaluateSpot} from '../public/modules/teaching/equity.mjs';
const card=s=>'23456789TJQKA'.indexOf(s[0])+13*'dhsc'.indexOf(s[1]);
const cards=s=>s.split(' ').map(card);
const ctx=(hole,board,extra={})=>({playerId:1,hole:cards(hole),board:cards(board),stack:1000,numActive:2,legal:{pot:1012,callAmt:329},...extra});
test('shared royal board splits exactly across opponents',()=>{const r=evaluateSpot(ctx('2d 3d','Th Jh Qh Kh Ah',{numActive:4}),{samples:100});assert.equal(r.equity,.25);});
test('gutshot has exactly four kings and no phantom flush',()=>{const r=evaluateSpot(ctx('Ah 7c','Qh Jc 2h Td'),{samples:100});assert.equal(r.draws.length,1);assert.equal(r.draws[0].outs,4);assert.equal(r.draws[0].nextCardProbability,4/46);assert.ok(r.draws[0].cards.every(c=>c[0]==='K'));assert.equal(r.threshold,329/1341);});
test('real flush draw has nine outs',()=>{const r=evaluateSpot(ctx('Ah 7h','Qh Jc 2h'),{samples:100});assert.equal(r.draws.find(d=>d.name==='同花听牌').outs,9);});
test('results and hidden future information cannot change evaluation',()=>{const c=ctx('Ah 7c','Qh Jc 2h Td');assert.deepEqual(evaluateSpot(c,{samples:100}),evaluateSpot({...c,opponentHole:cards('Kh Kd'),result:'win',futureBoard:cards('Kd')},{samples:100}));});
test('eligible pot caps opponent sidepot and counts folded contributions',()=>{const r=evaluateSpot(ctx('Ah 7c','Qh Jc 2h Td',{stack:20,heroTotalCommitted:100,legal:{pot:1300,callAmt:400},publicPlayers:[{id:1,committed:100},{id:2,committed:1000},{id:3,committed:200,folded:true}]}),{samples:100});assert.equal(r.callCost,20);assert.equal(r.potEligible,340);assert.equal(r.threshold,20/360);});
test('deterministic conditional ranges provide examples and sensitivity',()=>{const c=ctx('Ah 7c','Qh Jc 2h Td',{publicPlayers:[{id:1,committed:0},{id:2,name:'Villain',committed:329}],publicHistory:[{playerId:2,action:'raise',street:'turn',paid:329}]});const r=evaluateSpot(c,{samples:300});assert.deepEqual(r,evaluateSpot(c,{samples:300}));assert.ok(r.equityLow<=r.equity&&r.equity<=r.equityHigh);assert.ok(r.equityHigh>r.equityLow);assert.match(r.ranges[0].description,/1次/);assert.equal(r.ranges[0].examples.length,4);});
test('eight opponent default workload remains practical',()=>{const start=performance.now();const r=evaluateSpot(ctx('Ah 7c','Qh Jc 2h Td',{numActive:9}));assert.equal(r.sampleCount,1200);assert.ok(performance.now()-start<8000);});
test('shorter opposing all-in suppresses unmodelled layered EV',()=>{const r=evaluateSpot(ctx('Ah 7c','Qh Jc 2h Td',{heroTotalCommitted:100,publicPlayers:[{id:1,committed:100},{id:2,committed:20,allin:true},{id:3,committed:429}]}),{samples:100});assert.equal(r.threshold,null);assert.equal(r.callEV,null);assert.match(r.assumptions.join(' '),/边池/);});
test('legacy short call cannot use entire unverified pot',()=>{const r=evaluateSpot(ctx('Ah 7c','Qh Jc 2h Td',{stack:10,currentBet:100,streetCommitted:0,legal:{pot:200,callAmt:10}}),{samples:100});assert.equal(r.threshold,null);assert.equal(r.callEV,null);});
test('range examples distinguish rank classes and show readable suits',()=>{const r=evaluateSpot(ctx('Ah 7c','Qh Jc 2h Td',{publicPlayers:[{id:1},{id:2}],publicHistory:[{playerId:2,action:'raise',street:'turn',paid:329,potBefore:683,isAggressive:true}]}),{samples:100});const ex=r.ranges[0].examples;assert.equal(new Set(ex.map(e=>e.split('（')[0])).size,4);assert.ok(ex.every(e=>/红桃|方块|黑桃|梅花/.test(e)));assert.ok(ex.some(e=>/听牌/.test(e)));});
test('explicit all-in call is not aggression',()=>{const r=evaluateSpot(ctx('Ah 7c','Qh Jc 2h Td',{publicPlayers:[{id:1},{id:2}],publicHistory:[{playerId:2,action:'allin',street:'turn',paid:10,isAggressive:false}]}),{samples:100});assert.match(r.ranges[0].description,/1次跟注/);assert.doesNotMatch(r.ranges[0].description,/下注\/加注/);});
test('wide preflop examples span strong medium and suited developing hands',()=>{const r=evaluateSpot({playerId:1,hole:cards('Ah 7c'),board:[],stack:1000,numActive:2,legal:{pot:30,callAmt:20}},{samples:100});assert.match(r.ranges[0].description,/仅为可能底牌的示例/);assert.doesNotMatch(r.ranges[0].description,/非零权重/);const ex=r.ranges[0].examples;assert.equal(new Set(ex.map(e=>e.split('（')[0])).size,4);assert.ok(ex.some(e=>/^(T9|98|87|76|65|54|43|32)s/.test(e)));});

test('real K4 river spot weights turn betting on the turn board, preserving missed draws',()=>{
 const board=cards('Qs 9d 2d 8h Kh');
 const history=[{playerId:8,action:'raise',street:'preflop',board:[],paid:163,potBefore:132,isAggressive:true},{playerId:8,action:'check',street:'flop',board:board.slice(0,3),paid:0},{playerId:8,action:'bet',street:'turn',board:board.slice(0,4),paid:301,potBefore:458,isAggressive:true},{playerId:8,action:'bet',street:'river',board,paid:811,potBefore:1060,isAggressive:true}];
 const c=ctx('Ks 4s','Qs 9d 2d 8h Kh',{legal:{pot:1871,callAmt:811},publicPlayers:[{id:1},{id:8}],publicHistory:history});
 const actual=evaluateSpot(c,{samples:4000});
 const hindsight=evaluateSpot({...c,publicHistory:history.map(a=>a.street==='turn'?{...a,street:'river',board}:a)},{samples:4000});
 assert.ok(actual.equity>hindsight.equity+.03,JSON.stringify({actual:actual.equity,hindsight:hindsight.equity}));
 assert.deepEqual(actual,evaluateSpot({...c,opponentHole:cards('Jd Td'),futureBoard:cards('Ad')},{samples:4000}));
});
