import test from 'node:test';
import assert from 'node:assert/strict';
import {OfflineTable} from '../public/modules/offline/engine.mjs';
import {TeachingSession} from '../public/modules/teaching/session.mjs';
function fixture(commits, holes, board, folded={}) {
  const players=commits.map((n,i)=>({id:i+1,name:`P${i+1}`,stack:1000,in:true}));
  const table=new OfflineTable({players,smallBlind:10,rng:()=>0.4});table.start();
  const session=new TeachingSession();
  players.forEach(p=>p.stack=1000);
  table.h.committed=Object.fromEntries(players.map(p=>[p.id,0]));
  session.start({handNum:1,bb:20,seats:players.map(p=>({id:p.id,stack:1000})),holeByPlayer:holes},table,players);
  Object.assign(table.h,{board,hole:holes,folded,committed:Object.fromEntries(players.map(p=>[p.id,commits[p.id-1]]))});
  players.forEach(p=>p.stack=1000-commits[p.id-1]);
  return {table,session,report:()=>session.report(table)};
}
test('actual board tie splits odd chip by left-of-button position',()=>{
  const f=fixture([5,5,5],{1:[0,1],2:[13,14],3:[26,27]},[8,9,10,11,12],{3:true});
  f.table._showdown();const r=f.report(),p=r.settlement.pots[0];
  assert.deepEqual(p.winnerIds,[1,2]);assert.deepEqual(p.awards,[{playerId:2,amount:8},{playerId:1,amount:7}]);
  assert.match(r.settlement.summary,/平分/);assert.match(p.explanation,/零头/);
  assert.deepEqual(r.players.map(p=>p.net),[2,3,-5]);
  assert.ok(r.settlement.winningHands.every(h=>h.bestFive.length===5));
  assert.match(r.settlement.explanation,/零、一或两张底牌/);
});
test('different main and side pot winners are not described as an overall tie',()=>{
  const f=fixture([100,200,200],{1:[12,25],2:[11,24],3:[10,23]},[0,14,28,42,7]);
  f.table._showdown();const r=f.report();
  assert.deepEqual(r.settlement.pots.map(p=>[p.amount,p.winnerIds,p.eligibleIds]),[[300,[1],[1,2,3]],[200,[2],[2,3]]]);
  assert.match(r.settlement.summary,/不同玩家/);assert.doesNotMatch(r.settlement.summary,/平分/);
  assert.deepEqual(r.players.map(p=>p.net),[200,0,-200]);
});
test('uncalled excess is a refund, not a second winner',()=>{
  const f=fixture([200,100],{1:[11,24],2:[12,25]},[0,14,28,42,7]);
  f.table._showdown();const r=f.report(),refund=r.settlement.pots[1];
  assert.deepEqual(r.winnerIds,[2]);assert.deepEqual(refund.winnerIds,[]);assert.equal(refund.refundTo,1);
  assert.deepEqual(refund.awards,[{playerId:1,amount:100}]);assert.match(refund.explanation,/不算赢得底池/);
  assert.equal(r.players.reduce((n,p)=>n+p.net,0),0);
});
test('fold win explains collection without exposing a made-up winning hand',()=>{
  const f=fixture([20,10],{1:[0,1],2:[12,25]},[],{2:true});
  assert.equal(f.report().settlement,undefined);
  f.table._endHand();const r=f.report();assert.equal(r.settlement.kind,'uncontested');
  assert.deepEqual(r.settlement.winningHands,[]);assert.match(r.settlement.pots[0].explanation,/无需摊牌/);
  assert.deepEqual(r.players.map(p=>p.net),[10,-10]);assert.equal(r.settlement.pots[0].amount,20);assert.equal(r.settlement.pots[1].refundTo,1);assert.equal(r.settlement.pots[1].amount,10);
});
const fromCards=text=>text.split(' ').map(c=>'23456789TJQKA'.indexOf(c[0])+13*'dhsc'.indexOf(c[1]));
test('screenshot wheel A2345 wins against three aces and explains ace as one',()=>{
  const f=fixture([100,100,100],{1:fromCards('5s 5h'),2:fromCards('Ad As'),3:fromCards('5d 3d')},fromCards('4s Ac Th 2h Js'));
  f.table._showdown();const r=f.report();assert.deepEqual(r.winnerIds,[3]);
  const h=r.settlement.winningHands.find(h=>h.playerId===3);
  assert.deepEqual(h.score,[4,3]);assert.equal(h.straightRanks,'A–2–3–4–5');
  assert.deepEqual(h.bestFive,fromCards('Ac 2h 3d 4s 5d'));assert.match(h.straightExplanation,/A 在这里作 1/);
  assert.equal(r.settlement.winningHands.find(h=>h.playerId===2).handName,'三条');
});
test('ace high straight is displayed ten through ace without ace-low explanation',()=>{
  const f=fixture([100,100],{1:fromCards('Ad Ks'),2:fromCards('9d 9s')},fromCards('Qh Jc Ts 4h 2c'));
  f.table._showdown();const h=f.report().settlement.winningHands.find(h=>h.playerId===1);
  assert.equal(h.straightRanks,'10–J–Q–K–A');assert.doesNotMatch(h.straightExplanation,/作 1/);
});
test('QKA23 does not wrap around into a straight',()=>{
  const f=fixture([100,100],{1:fromCards('Ad Ks'),2:fromCards('9d 9s')},fromCards('Qh 2c 3s 7h 8c'));
  f.table._showdown();const h=f.report().settlement.winningHands.find(h=>h.playerId===1);
  assert.equal(h.handName,'高牌');assert.equal(h.straightRanks,undefined);
});
