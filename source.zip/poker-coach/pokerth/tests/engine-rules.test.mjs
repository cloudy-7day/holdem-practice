import test from 'node:test';
import assert from 'node:assert/strict';
import {OfflineTable,ACT} from '../public/modules/offline/engine.mjs';
import {TeachingSession} from '../public/modules/teaching/session.mjs';
function street(stacks){
 const events=[];
 const table=new OfflineTable({players:stacks.map((stack,i)=>({id:i+1,stack,name:`P${i+1}`})),smallBlind:10,rng:()=>0.4,onEvent:e=>events.push(e)});
 table.start();
 const order=table.players;
 for(const p of order){p.stack=stacks[p.id-1];p.in=true;}
 Object.assign(table.h,{street:'flop',board:[0,14,28],committed:{},streetCommit:{},folded:{},allin:{},inHand:{},currentBet:0,minRaise:20,actedAt:{},reopenBy:{},noReraise:new Set()});
 for(const p of order){table.h.committed[p.id]=0;table.h.streetCommit[p.id]=0;table.h.inHand[p.id]=true;}
 table._beginStreet('flop',order,0);
 return {table,events,turn:()=>events.filter(e=>e.type==='turn').at(-1)};
}
test('cumulative short all-ins reopen prior bettor after a full increment',()=>{
 const {table:t,turn}=street([1000,150,200,1000]);
 t.act(1,ACT.BET,100);t.act(2,ACT.ALLIN,150);
 assert.ok(t.h.noReraise.has(1));
 t.act(3,ACT.ALLIN,200);t.act(4,ACT.CALL);
 assert.equal(turn().playerId,1);assert.equal(turn().legal.canRaise,true);
 assert.equal(turn().legal.minRaiseTo,300);
 t.act(1,ACT.RAISE,300);t.act(4,ACT.CALL);
 // Match every remaining decision through the actual engine to settlement.
 for(let i=0;t.h._pendingId!=null&&i<30;i++)t.act(t.h._pendingId,ACT.CALL);
 assert.equal(t.players.reduce((sum,p)=>sum+p.stack,0),2350);
});
test('checking before a short opening all-in retains raise rights',()=>{
 const {table:t,turn}=street([1000,10,1000]);
 t.act(1,ACT.CHECK);t.act(2,ACT.ALLIN,10);t.act(3,ACT.CALL);
 assert.equal(turn().playerId,1);assert.equal(turn().legal.canRaise,true);
 t.act(1,ACT.RAISE,30);assert.equal(t.h.currentBet,30);
});
test('one incomplete raise does not reopen a previous bet',()=>{
 const {table:t,turn}=street([1000,150,1000]);
 t.act(1,ACT.BET,100);t.act(2,ACT.ALLIN,150);t.act(3,ACT.CALL);
 assert.equal(turn().playerId,1);assert.equal(turn().legal.canRaise,false);
 t.act(1,ACT.RAISE,250);
 assert.notEqual(t.h.street,'flop'); // call completes street, illegal raise was demoted
assert.equal(t.players[0].stack,850);
});
test('cannot raise when every opponent is already all-in',()=>{
 const {table:t,turn}=street([100,1000]);
 t.act(1,ACT.ALLIN,100);
 assert.equal(turn().playerId,2);assert.equal(turn().legal.canRaise,false);
 t.act(2,ACT.RAISE,500);
 assert.equal(t.h.committed[2],100);
 assert.equal(t.players.reduce((sum,p)=>sum+p.stack,0),1100);
});
test('uncalled excess is refunded without naming its owner a contested-pot winner',()=>{
 const {table:t}=street([1000,1000]);
 const session=new TeachingSession();
 session.start({handNum:1,bb:20,seats:t.players.map(p=>({id:p.id,stack:p.stack})),holeByPlayer:{1:[11,24],2:[12,25]}},t,t.players);
 t.h.hole={1:[11,24],2:[12,25]};
 t.h.board=[0,14,28,42,7];
 t.h.committed={1:200,2:100};t.h.streetCommit={1:200,2:100};
 t.players[0].stack=800;t.players[1].stack=900;
 t._showdown();
 const report=session.report(t);
 assert.deepEqual(report.winnerIds,[2]);
 assert.equal(t.players[0].stack,900);assert.equal(t.players[1].stack,1100);
 assert.equal(t.players.reduce((sum,p)=>sum+p.stack,0),2000);
});
