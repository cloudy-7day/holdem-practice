/* PokerTH 中文教学分支 — AGPL-3.0-or-later. Local static server, no dependencies. */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const root = path.join(__dirname, 'public');
const port = Number(process.env.POKER_PORT || 8787);
const host = process.env.POKER_HOST || '127.0.0.1';
if (!['127.0.0.1', '0.0.0.0'].includes(host)) throw new Error('POKER_HOST must be 127.0.0.1 or 0.0.0.0');
const config = require('./teaching-config.cjs');
const roomHandler = import('./multiplayer/node-handler.mjs').then(m=>m.createNodeRoomHandler());
const mime = {'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.webp':'image/webp','.gif':'image/gif','.ico':'image/x-icon','.woff2':'font/woff2','.woff':'font/woff','.ttf':'font/ttf','.mp3':'audio/mpeg','.ogg':'audio/ogg','.wav':'audio/wav','.proto':'text/plain; charset=utf-8','.md':'text/plain; charset=utf-8'};
function json(res, value, code=200) {res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(value));}
const server = http.createServer((req,res)=>{
  let pathname;
  try {pathname=decodeURIComponent(new URL(req.url,'http://localhost').pathname);} catch {res.writeHead(400);return res.end();}
  if(pathname==='/health') return json(res,{app:'pokerth-chinese-teaching',port:server.address().port,host});
  if(pathname==='/api/rooms'||pathname.startsWith('/api/rooms/')) {roomHandler.then(handle=>handle(req,res)).catch(()=>json(res,{error:'联机服务启动失败，请检查本地日志。'},503));return;}
  if(pathname==='/multiplayer-config.json') return json(res,{apiBase:''});
  if(pathname==='/app-config') return json(res,config);
  if(pathname==='/__ver') return json(res,{version:'teaching-1',ver:'teaching-1'});
  if(pathname==='/__visit'||pathname==='/__error'||pathname==='/clienterr') {res.writeHead(204);return res.end();}
  if(['/cards/decks.json','/seats/seats.json','/table/tables.json'].includes(pathname)) return json(res,[]);
  if(!['GET','HEAD'].includes(req.method)) return json(res,{error:'Local training only'},405);
  // No proxy, accounts, telemetry persistence, or Internet game endpoints.
  if(pathname.startsWith('/api/')) return json(res,{enabled:false,items:[],players:[],events:[],count:0});
  let file;
  if(pathname==='/LICENSE') file=path.join(__dirname,'LICENSE');
  else if(pathname==='/SOURCE.md') file=path.join(__dirname,'SOURCE.md');
  else {
    if(pathname==='/'||pathname==='/index.html') pathname='/pokerth-client.html';
    file=path.resolve(root,'.'+pathname);
    if(!file.startsWith(root+path.sep)||pathname.includes('\0')) {res.writeHead(403);return res.end();}
  }
  fs.stat(file,(err,stat)=>{
    if(err||!stat.isFile()) {res.writeHead(404);return res.end('Not found');}
    res.writeHead(200,{'Content-Type':mime[path.extname(file)]||'application/octet-stream','Content-Length':stat.size,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
    if(req.method==='HEAD')return res.end();
    fs.createReadStream(file).on('error',()=>res.destroy()).pipe(res);
  });
});
server.listen(port,host,()=>console.log(`PokerTH 中文教学桌 http://${host}:${server.address().port}/?lang=zh`));
server.on('error',e=>{console.error(e.message);process.exitCode=1;});
module.exports=server;
