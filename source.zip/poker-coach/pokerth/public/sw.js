/**
 * PokerTH Service Worker — v4
 * ⚠ Bump CACHE_VERSION on every static deploy to force clients to update.
 *    Format: 'pokerth-v{MAJOR}.{MINOR}.{N}' where {N} is a monotonic deploy
 *    counter that doubles as the release patch number. A release tag equals
 *    this string without the 'pokerth-' prefix (cache pokerth-v0.2.378 ↔ v0.2.91).
 *
 * Strategy (v4):
 *   • install   — precache the critical app shell (HTML, JS, CSS, modules,
 *                 manifest, key PWA icons)
 *   • activate  — drop stale caches, enable navigation preload, notify pages
 *                 (clients.claim is intentionally omitted — see activate note)
 *   • fetch     — split by request type for the best of both worlds:
 *                   – navigations (the HTML document) → NETWORK-FIRST, so a
 *                     fresh deploy is picked up immediately; falls back to the
 *                     cached shell when offline. Uses navigationPreload to
 *                     start the network request in parallel with SW boot.
 *                   – static assets (js, css, mjs, svg, png, fonts, proto…) →
 *                     STALE-WHILE-REVALIDATE: served instantly from cache and
 *                     refreshed in the background. Repeat loads are near
 *                     instant and work fully offline; the CACHE_VERSION bump on
 *                     each deploy still guarantees clients get the new files.
 *                 Cross-origin requests and WS upgrades are left untouched.
 *                 (Fonts are now self-hosted and handled by SWR above.)
 */
const CACHE_VERSION = 'pokerth-v2.1.10-web.332';
// Build id the page puts on the card back URL (deck.mjs _deckBack →
// flipside.<ext>?v=<BUILD_VERSION>): CACHE_VERSION without its prefix.
const BUILD_ID = CACHE_VERSION.replace(/^pokerth-v/, '');
// Share Target payload park (see handleShareTarget). Kept OUT of CACHE_VERSION
// so an update sweep never eats a share that arrived seconds earlier.
const SHARE_CACHE = 'pokerth-share';

// Where navigations fall back to when the network is unavailable.
const NAV_FALLBACK = '/pokerth-client.html';
// How long a navigation waits for the origin before falling back to the
// cached shell. Keeps the tab from hanging on a blank page when the origin
// is slow (e.g. during server backups); the network fetch keeps running in
// the background so the cached shell still gets refreshed.
const NAV_TIMEOUT_MS = 3500;

// Critical app shell precached on install. Keep this list tight — anything
// large or rarely used (e.g. the protobuf bundle, individual flags) is fetched
// on demand and then served from cache thanks to the SWR handler below.
const ASSETS = [
  '/',
  '/pokerth-client.html',
  '/pokerth.js',
  '/chat-emotes.js',
  '/pokerth.css',
  // Self-hosted fonts (Cinzel + Inconsolata) — offline + privacy
  '/fonts/fonts.css',
  '/fonts/cinzel-latin-400-normal.woff2',
  '/fonts/cinzel-latin-600-normal.woff2',
  '/fonts/cinzel-latin-700-normal.woff2',
  '/fonts/cinzel-latin-ext-400-normal.woff2',
  '/fonts/cinzel-latin-ext-600-normal.woff2',
  '/fonts/cinzel-latin-ext-700-normal.woff2',
  '/fonts/inconsolata-latin-300-normal.woff2',
  '/fonts/inconsolata-latin-400-normal.woff2',
  '/fonts/inconsolata-latin-500-normal.woff2',
  '/fonts/inconsolata-latin-ext-300-normal.woff2',
  '/fonts/inconsolata-latin-ext-400-normal.woff2',
  '/fonts/inconsolata-latin-ext-500-normal.woff2',
  '/fonts/inter-latin-wght-normal.woff2',
  '/fonts/inter-latin-ext-wght-normal.woff2',
  '/manifest.json',
  '/modules/errreport.mjs',
  '/modules/feature-off.mjs',
  '/modules/i18n.mjs',
  '/modules/lang-meta.mjs',
  '/modules/handlog.mjs',
  '/modules/pdb-autosave.mjs',
  '/modules/arena-witness.mjs',
  '/modules/backup-autosave.mjs',
  '/modules/journal.mjs',
  '/modules/seo/about-guides.mjs',
  '/modules/notes/index.mjs',
  '/modules/notes/store.mjs',
  '/vendor/sql-wasm.js',
  '/vendor/sql-wasm.wasm',
  '/modules/theme.mjs',
  '/modules/ui/chatlog-tint.mjs',
  // Modules loaded by pokerth-client.html (or imported by one) — a module
  // missing here breaks its whole graph offline after a CACHE_VERSION bump.
  // Guarded by scripts/test-precache.mjs.
  '/modules/ui/debuglog.mjs',
  '/modules/ui/accessibility.mjs',
  '/modules/ui/livescroll.mjs',
  '/modules/chat/abbrev.mjs',
  '/modules/ui/pm.mjs',
  '/modules/game/presence.mjs',
  '/modules/net/watchdog.mjs',
  '/modules/pm/store.mjs',
  '/modules/ui/assist-pane.mjs',
  '/modules/ui/seat-menu.mjs',
  '/modules/ui/back-guard.mjs',
  '/modules/ui/z-order.mjs',
  // Offline (vs bots) mode modules
  '/vendor/phe.mjs',
  '/modules/game/state.mjs',
  '/modules/ui/fmt.mjs',
  '/modules/ui/media.mjs',
  '/modules/ui/announcer.mjs',
  '/modules/game/turn-timer.mjs',
  '/modules/game/stats.mjs',
  '/modules/net/petitions.mjs',
  '/modules/ui/chat.mjs',
  '/modules/ui/botsuggest.mjs',
  '/modules/create-presets.mjs',
  '/modules/ui/player-popup.mjs',
  '/modules/ui/avatar-studio.mjs',
  '/modules/ui/avatar-vector.mjs',
  '/modules/ui/avatar-photo.mjs',
  '/modules/ui/avatar-capture.mjs',
  '/modules/ui/avatar-parts/helpers.mjs',
  '/modules/ui/avatar-parts/faces.mjs',
  '/modules/ui/avatar-parts/colors.mjs',
  '/modules/ui/avatar-parts/hair.mjs',
  '/modules/ui/avatar-parts/outfits.mjs',
  '/modules/ui/avatar-parts/face-parts.mjs',
  '/modules/ui/avatar-parts/extras.mjs',
  '/modules/ui/avatar-parts/expressions.mjs',
  '/modules/ui/avatar-parts/legacy.mjs',
  '/modules/ui/avatar-parts/index.mjs',
  '/modules/ui/avatar-parts/presets.mjs',
  '/modules/ui/lobby.mjs',
  '/modules/ui/wait-alert.mjs',
  '/modules/ui/lobby-keynav.mjs',
  '/modules/ui/lobby-typechat.mjs',
  '/modules/ui/forumnews.mjs',
  '/modules/ui/forum-events.mjs',
  '/modules/ui/lobby-clock.mjs',
  '/modules/ui/header-title-fit.mjs',
  '/modules/ui/login-flourish.mjs',
  '/modules/mascot/index.mjs',
  '/modules/mascot/engine.mjs',
  '/modules/mascot/plan.mjs',
  '/modules/mascot/panel.mjs',
  '/modules/mascot/acts-extra.mjs',
  '/modules/mascot/acts-props.mjs',
  '/modules/mascot/acts-social.mjs',
  '/modules/mascot/acts-dance.mjs',
  '/modules/mascot/groove.mjs',
  '/modules/games/index.mjs',
  '/modules/games/shell.mjs',
  '/modules/games/ace-runner.mjs',
  '/modules/games/poker-hand.mjs',
  '/modules/games/common.mjs',
  '/modules/games/menu.mjs',
  '/modules/games/art.mjs',
  '/modules/games/ui.mjs',
  '/modules/games/deal.mjs',
  '/modules/games/videopoker.mjs',
  '/modules/games/whowins.mjs',
  '/modules/games/hilo.mjs',
  '/modules/games/bluff.mjs',
  '/modules/games/pokerdrop.mjs',
  '/modules/games/pokerdrop-rules.mjs',
  '/modules/games/house.mjs',
  '/modules/games/solitaire.mjs',
  '/modules/games/solitaire-rules.mjs',
  '/modules/mascot/guide.mjs',
  // Aide de l'As (modules/guide) — petit, précaché pour marcher hors ligne (D11).
  // Catalogues de textes : guide/lang/<code>.mjs (chargés à la demande).
  '/modules/guide/index.mjs',
  '/modules/guide/core.mjs',
  '/modules/guide/state.mjs',
  '/modules/guide/i18n.mjs',
  '/modules/guide/highlight.mjs',
  '/modules/guide/ranking-pick.mjs',
  '/modules/guide/cup.mjs',
  '/modules/guide/beacons.mjs',
  '/modules/guide/hotspots.mjs', '/modules/guide/knowledge.mjs',
  '/modules/guide/contexts/index.mjs',
  '/modules/guide/contexts/lobby-guest.mjs',
  '/modules/guide/contexts/lobby-watch.mjs',
  '/modules/guide/contexts/lobby-cup.mjs',
  '/modules/guide/contexts/lobby-flag.mjs',
  '/modules/guide/contexts/lobby-open.mjs',
  '/modules/guide/contexts/lobby-lan.mjs',
  '/modules/guide/contexts/lobby-ranking-create.mjs',
  '/modules/guide/contexts/lobby-ranking.mjs',
  '/modules/guide/contexts/login.mjs',
  '/modules/guide/contexts/create.mjs',
  '/modules/guide/contexts/windows.mjs',
  '/modules/guide/contexts/login-profile.mjs',
  '/modules/guide/contexts/login-lan.mjs',
  '/modules/guide/contexts/wait-normal.mjs',
  '/modules/guide/contexts/ranked-result.mjs',
  '/modules/guide/contexts/wait-ranking.mjs',
  '/modules/guide/contexts/welcome.mjs',
  '/modules/guide/lang/af.mjs',
  '/modules/guide/lang/am.mjs',
  '/modules/guide/lang/ar.mjs',
  '/modules/guide/lang/az.mjs',
  '/modules/guide/lang/be.mjs',
  '/modules/guide/lang/bg.mjs',
  '/modules/guide/lang/bn.mjs',
  '/modules/guide/lang/bs.mjs',
  '/modules/guide/lang/ca.mjs',
  '/modules/guide/lang/cs.mjs',
  '/modules/guide/lang/cy.mjs',
  '/modules/guide/lang/da.mjs',
  '/modules/guide/lang/de.mjs',
  '/modules/guide/lang/el.mjs',
  '/modules/guide/lang/en.mjs',
  '/modules/guide/lang/eo.mjs',
  '/modules/guide/lang/es-419.mjs',
  '/modules/guide/lang/es.mjs',
  '/modules/guide/lang/et.mjs',
  '/modules/guide/lang/eu.mjs',
  '/modules/guide/lang/fa.mjs',
  '/modules/guide/lang/fi.mjs',
  '/modules/guide/lang/fil.mjs',
  '/modules/guide/lang/fr.mjs',
  '/modules/guide/lang/ga.mjs',
  '/modules/guide/lang/gd.mjs',
  '/modules/guide/lang/gl.mjs',
  '/modules/guide/lang/gu.mjs',
  '/modules/guide/lang/ha.mjs',
  '/modules/guide/lang/he.mjs',
  '/modules/guide/lang/hi.mjs',
  '/modules/guide/lang/hr.mjs',
  '/modules/guide/lang/hu.mjs',
  '/modules/guide/lang/hy.mjs',
  '/modules/guide/lang/id.mjs',
  '/modules/guide/lang/is.mjs',
  '/modules/guide/lang/it.mjs',
  '/modules/guide/lang/ja.mjs',
  '/modules/guide/lang/ka.mjs',
  '/modules/guide/lang/kk.mjs',
  '/modules/guide/lang/km.mjs',
  '/modules/guide/lang/kn.mjs',
  '/modules/guide/lang/ko.mjs',
  '/modules/guide/lang/ky.mjs',
  '/modules/guide/lang/lt.mjs',
  '/modules/guide/lang/lv.mjs',
  '/modules/guide/lang/mk.mjs',
  '/modules/guide/lang/ml.mjs',
  '/modules/guide/lang/mn.mjs',
  '/modules/guide/lang/mr.mjs',
  '/modules/guide/lang/ms.mjs',
  '/modules/guide/lang/my.mjs',
  '/modules/guide/lang/nb.mjs',
  '/modules/guide/lang/ne.mjs',
  '/modules/guide/lang/nl.mjs',
  '/modules/guide/lang/pa.mjs',
  '/modules/guide/lang/pl.mjs',
  '/modules/guide/lang/pt-br.mjs',
  '/modules/guide/lang/pt-pt.mjs',
  '/modules/guide/lang/ro.mjs',
  '/modules/guide/lang/ru.mjs',
  '/modules/guide/lang/si.mjs',
  '/modules/guide/lang/sk.mjs',
  '/modules/guide/lang/sl.mjs',
  '/modules/guide/lang/sq.mjs',
  '/modules/guide/lang/sr.mjs',
  '/modules/guide/lang/sv.mjs',
  '/modules/guide/lang/sw.mjs',
  '/modules/guide/lang/ta.mjs',
  '/modules/guide/lang/te.mjs',
  '/modules/guide/lang/tg.mjs',
  '/modules/guide/lang/th.mjs',
  '/modules/guide/lang/tk.mjs',
  '/modules/guide/lang/tr.mjs',
  '/modules/guide/lang/uk.mjs',
  '/modules/guide/lang/ur.mjs',
  '/modules/guide/lang/uz.mjs',
  '/modules/guide/lang/vi.mjs',
  '/modules/guide/lang/yo.mjs',
  '/modules/guide/lang/zh-hk.mjs',
  '/modules/guide/lang/zh-tw.mjs',
  '/modules/guide/lang/zh.mjs',
  '/modules/guide/lang/zu.mjs',
  '/modules/ui/invite.mjs',
  '/modules/ui/lan-directory.mjs',
  '/modules/net/invite-link.mjs',
  '/modules/ui/mini-board.mjs',
  '/modules/ui/sound-import.mjs',
  '/vendor/qrcode.mjs',
  '/modules/ui/poll.mjs',
  '/modules/ui/live-stats.mjs',
  '/modules/ui/hold-tip.mjs',
  '/modules/game/showdown.mjs',
  '/modules/game/showlist.mjs',
  '/modules/net/session.mjs',
  '/modules/ui/game-info.mjs',
  '/modules/ui/odds-panel.mjs',
  '/modules/ui/table-cards.mjs',
  '/modules/ui/action-bar.mjs',
  '/modules/ui/bet-keypad.mjs',
  '/modules/net/msg-avatars.mjs',
  '/modules/net/msg-social.mjs',
  '/modules/net/msg-lobby.mjs',
  '/modules/net/msg-game-join.mjs',
  '/modules/game/msg-hand.mjs',
  '/modules/game/seat-render.mjs',
  '/modules/game/cards.mjs',
  '/modules/net/proto.mjs',
  '/modules/net/crypto.mjs',
  '/modules/net/messages.mjs',
  '/modules/ui/shortcuts.mjs',
  '/modules/ui/reactions.mjs',
  '/modules/ui/anim.mjs',
  '/modules/game/seats.mjs',
  '/modules/game/layout.mjs',
  '/modules/game/puck-dodge.mjs',
  '/modules/game/seat-top-clamp.mjs',
  '/modules/ui/deck.mjs',
  '/modules/net/avatar-cache.mjs',
  '/modules/ui/misc.mjs',
  '/modules/ui/adv-search.mjs',
  '/modules/ui/keynav.mjs',
  '/modules/ui/gamepad.mjs',
  '/modules/ui/spatial-nav.mjs',
  '/modules/ui/ctl-nav.mjs',
  '/modules/ui/ctl-menu.mjs',
  '/modules/ui/ctl-keyboard.mjs',
  '/modules/ui/remote.mjs',
  '/modules/help/content/en.mjs',
  '/modules/help/content/eo.mjs',
  '/modules/help/content/fr.mjs',
  '/modules/help/content/ga.mjs',
  '/modules/help/content/de.mjs',
  '/modules/help/content/es.mjs',
  '/modules/help/content/es-419.mjs',
  '/modules/help/content/it.mjs',
  '/modules/help/content/nl.mjs',
  '/modules/help/content/pl.mjs',
  '/modules/help/content/ru.mjs',
  '/modules/help/content/pt-br.mjs',
  '/modules/help/content/zh.mjs',
  '/modules/help/content/zh-tw.mjs',
  '/modules/help/content/zh-hk.mjs',
  '/modules/help/content/zu.mjs',
  '/modules/help/content/ja.mjs',
  '/modules/help/content/ko.mjs',
  '/modules/help/content/ky.mjs',
  '/modules/help/content/tr.mjs',
  '/modules/help/content/pt-pt.mjs',
  '/modules/help/content/cs.mjs',
  '/modules/help/content/cy.mjs',
  '/modules/help/content/da.mjs',
  '/modules/help/content/fi.mjs',
  '/modules/help/content/nb.mjs',
  '/modules/help/content/ne.mjs',
  '/modules/help/content/sv.mjs',
  '/modules/help/content/ro.mjs',
  '/modules/help/content/sk.mjs',
  '/modules/help/content/bg.mjs',
  '/modules/help/content/el.mjs',
  '/modules/help/content/hr.mjs',
  '/modules/help/content/hu.mjs',
  '/modules/help/content/hy.mjs',
  '/modules/help/content/lt.mjs',
  '/modules/help/content/et.mjs',
  '/modules/help/content/eu.mjs',
  '/modules/help/content/lv.mjs',
  '/modules/help/content/sl.mjs',
  '/modules/help/content/bs.mjs',
  '/modules/help/content/mk.mjs',
  '/modules/help/content/ms.mjs',
  '/modules/help/content/my.mjs',
  '/modules/help/content/ka.mjs',
  '/modules/help/content/kk.mjs',
  '/modules/help/content/si.mjs',
  '/modules/help/content/sq.mjs',
  '/modules/help/content/pa.mjs',
  '/modules/help/content/am.mjs',
  '/modules/help/content/km.mjs',
  '/modules/help/content/te.mjs',
  '/modules/help/content/tg.mjs',
  '/modules/help/content/ml.mjs',
  '/modules/help/content/mn.mjs',
  '/modules/help/content/mr.mjs',
  '/modules/help/content/kn.mjs',
  '/modules/help/content/gu.mjs',
  '/modules/help/content/ha.mjs',
  '/modules/help/content/is.mjs',
  '/modules/help/content/sr.mjs',
  '/modules/help/content/uk.mjs',
  '/modules/help/content/af.mjs',
  '/modules/help/content/ca.mjs',
  '/modules/help/content/gd.mjs',
  '/modules/help/content/gl.mjs',
  '/modules/help/content/hi.mjs',
  '/modules/help/content/ta.mjs',
  '/modules/help/content/vi.mjs',
  '/modules/help/content/yo.mjs',
  '/modules/help/content/id.mjs',
  '/modules/help/content/th.mjs',
  '/modules/help/content/tk.mjs',
  '/modules/help/content/fil.mjs',
  '/modules/help/content/bn.mjs',
  '/modules/help/content/sw.mjs',
  '/modules/help/content/ar.mjs',
  '/modules/help/content/az.mjs',
  '/modules/help/content/be.mjs',
  '/modules/help/content/fa.mjs',
  '/modules/help/content/he.mjs',
  '/modules/help/content/ur.mjs',
  '/modules/help/content/uz.mjs',
  '/modules/offline/engine.mjs',
  '/modules/offline/bots.mjs',
  '/modules/offline/proto.mjs',
  '/modules/offline/server.mjs',
  '/modules/offline/index.mjs',
  '/modules/offline/rand.mjs',
  // Achievements, imported by offline/server.mjs: without them the lazy
  // import of the offline mode fails with no network ("Offline init failed").
  '/modules/achievements/index.mjs',
  '/modules/achievements/defs.mjs',
  '/modules/achievements/tracker.mjs',
  '/modules/achievements/store.mjs',
  '/modules/lang/en.mjs',
  '/modules/lang/eo.mjs',
  '/modules/lang/fr.mjs',
  '/modules/lang/ga.mjs',
  '/modules/lang/de.mjs',
  '/modules/lang/es.mjs',
  '/modules/lang/es-419.mjs',
  '/modules/lang/it.mjs',
  '/modules/lang/pt-br.mjs',
  '/modules/lang/pt-pt.mjs',
  '/modules/lang/nl.mjs',
  '/modules/lang/pl.mjs',
  '/modules/lang/ru.mjs',
  // Remaining UI languages — i18n.mjs imports all of them statically,
  // so they must be cached for the app to boot offline.
  '/modules/lang/af.mjs',
  '/modules/lang/bg.mjs',
  '/modules/lang/ca.mjs',
  '/modules/lang/cs.mjs',
  '/modules/lang/cy.mjs',
  '/modules/lang/da.mjs',
  '/modules/lang/el.mjs',
  '/modules/lang/fi.mjs',
  '/modules/lang/gd.mjs',
  '/modules/lang/gl.mjs',
  '/modules/lang/hi.mjs',
  '/modules/lang/ar.mjs',
  '/modules/lang/az.mjs',
  '/modules/lang/be.mjs',
  '/modules/lang/fa.mjs',
  '/modules/lang/he.mjs',
  '/modules/lang/ur.mjs',
  '/modules/lang/uz.mjs',
  '/modules/lang/hr.mjs',
  '/modules/lang/hu.mjs',
  '/modules/lang/hy.mjs',
  '/modules/lang/ja.mjs',
  '/modules/lang/ko.mjs',
  '/modules/lang/ky.mjs',
  '/modules/lang/lt.mjs',
  '/modules/lang/et.mjs',
  '/modules/lang/eu.mjs',
  '/modules/lang/lv.mjs',
  '/modules/lang/sl.mjs',
  '/modules/lang/bs.mjs',
  '/modules/lang/mk.mjs',
  '/modules/lang/ms.mjs',
  '/modules/lang/my.mjs',
  '/modules/lang/ka.mjs',
  '/modules/lang/kk.mjs',
  '/modules/lang/si.mjs',
  '/modules/lang/sq.mjs',
  '/modules/lang/pa.mjs',
  '/modules/lang/am.mjs',
  '/modules/lang/km.mjs',
  '/modules/lang/te.mjs',
  '/modules/lang/tg.mjs',
  '/modules/lang/ml.mjs',
  '/modules/lang/mn.mjs',
  '/modules/lang/mr.mjs',
  '/modules/lang/kn.mjs',
  '/modules/lang/gu.mjs',
  '/modules/lang/ha.mjs',
  '/modules/lang/is.mjs',
  '/modules/lang/nb.mjs',
  '/modules/lang/ne.mjs',
  '/modules/lang/ro.mjs',
  '/modules/lang/sk.mjs',
  '/modules/lang/sr.mjs',
  '/modules/lang/sv.mjs',
  '/modules/lang/ta.mjs',
  '/modules/lang/tr.mjs',
  '/modules/lang/uk.mjs',
  '/modules/lang/vi.mjs',
  '/modules/lang/yo.mjs',
  '/modules/lang/zh.mjs',
  '/modules/lang/zh-tw.mjs',
  '/modules/lang/zh-hk.mjs',
  '/modules/lang/zu.mjs',
  '/modules/lang/id.mjs',
  '/modules/lang/th.mjs',
  '/modules/lang/tk.mjs',
  '/modules/lang/fil.mjs',
  '/modules/lang/bn.mjs',
  '/modules/lang/sw.mjs',
  '/modules/sounds.mjs',
  '/modules/music.mjs',
  // Sons de jeu PokerTH (MP3, AGPL-3.0)
  '/sounds/pokerth/fold.mp3',
  '/sounds/pokerth/check.mp3',
  '/sounds/pokerth/call.mp3',
  '/sounds/pokerth/bet.mp3',
  '/sounds/pokerth/raise.mp3',
  '/sounds/pokerth/allin.mp3',
  '/sounds/pokerth/dealtwocards.mp3',
  '/sounds/pokerth/yourturn.mp3',
  '/sounds/pokerth/blinds_raises_level1.mp3',
  '/sounds/pokerth/blinds_raises_level2.mp3',
  '/sounds/pokerth/blinds_raises_level3.mp3',
  // Default deck (theme.mjs 'pokerth-new', PokerTH Royal Classic, ~50 KB)
  // and default table style ('' → table/pokerth-official-fs: felt, pucks,
  // action buttons, ~1 MB), so a table has its cards and felt with no
  // network right after an update. The back is listed twice: the inline
  // boot poses it plain, deck.mjs with ?v=<build> (a distinct cache key).
  ...Array.from({ length: 52 }, function (_, n) { return '/cards/pokerth-new/' + n + '.svg'; }),
  '/cards/pokerth-new/flipside.svg',
  '/cards/pokerth-new/flipside.svg?v=' + BUILD_ID,
  '/table/pokerth-official-fs/felt.png',
  '/table/pokerth-official-fs/dealerPuck.svg',
  '/table/pokerth-official-fs/smallblindPuck.svg',
  '/table/pokerth-official-fs/bigblindPuck.svg',
  '/table/pokerth-official-fs/actionFold.svg',
  '/table/pokerth-official-fs/actionCall.svg',
  '/table/pokerth-official-fs/actionRaise.svg',
  '/table/pokerth-official-fs/actionAllIn.svg',
  '/favicon.ico',
  '/favicon.svg',
  '/favicon-32.png',
  '/favicon-192.png',
  '/favicon-512.png',
  '/logo-chip.png',
  '/bbc-icon.png',
  '/wec-icon.png',
  '/img/pokerth-login-bg.webp',
  // PWA install icons referenced by manifest.json
  '/icon-192.png',
  '/icon-512.png',
  '/icon-maskable-192.png',
  '/icon-maskable-512.png',
  '/ChangeLog',
  '/CHANGELOG.md',
  '/modules/ui/changelog-md.mjs'
];

// Precache one asset with a couple of retries so a single flaky request
// doesn't leave a hole. addAll() is all-or-nothing (one failure rejects the
// whole batch) and its rejection used to be swallowed, so a hiccup during
// install could leave the cache empty without any signal. Per-asset with
// allSettled below means a miss is isolated, retried, and logged.
function precacheOne(cache, url, tries) {
  tries = tries || 3;
  return (async function () {
    for (var i = 0; i < tries; i++) {
      try {
        var res = await fetch(new Request(url, { cache: 'reload' }));
        if (res && res.status === 200) { await cache.put(url, res.clone()); return true; }
      } catch (e) { /* retry */ }
      await new Promise(function (r) { setTimeout(r, 400 * (i + 1)); });
    }
    console.warn('[SW] precache miss:', url);
    return false;
  })();
}

// ── Install : precache the app shell (per-asset, resilient) ──
self.addEventListener('install', function(e) {
  e.waitUntil(
    caches.open(CACHE_VERSION).then(function (c) {
      // Bounded concurrency: firing all ~130 fetches at once hammered the
      // origin on every update — worst when the update banner lands during
      // the nightly server backup. A small worker pool (6) keeps installs
      // gentle without noticeably slowing them; precacheOne never rejects,
      // so each worker chain runs to the end of the queue.
      var queue = ASSETS.slice();
      var miss = 0;
      function worker() {
        var u = queue.shift();
        if (u === undefined) return Promise.resolve();
        return precacheOne(c, u).then(function (ok) {
          if (ok === false) miss++;
          return worker();
        });
      }
      var pool = [];
      for (var i = 0; i < 6 && i < ASSETS.length; i++) pool.push(worker());
      return Promise.all(pool).then(function () {
        if (miss) console.warn('[SW] precache incomplete:', miss, 'of', ASSETS.length, 'asset(s) missing');
        else console.log('[SW] precache complete:', ASSETS.length, 'assets');
      });
    })
  );
  // NOTE: skipWaiting() is deliberately NOT called here. A freshly installed SW
  // must WAIT until the user applies the update via the /__ver banner (which
  // posts SKIP_WAITING below, then reloads). Auto-activating would let the new
  // SW take over a live page and fire controllerchange, which can drop an
  // in-flight WebSocket to the proxy (close 1005) → the PokerTH server reads it
  // as a connect-then-drop and blocks the IP for a few minutes (the bug seen
  // when reconnecting after a reload with a cleared cache). Waiting also keeps
  // registration.waiting populated so the banner button has a worker to message.
});

// ── Activate : drop old caches, enable nav preload ──
self.addEventListener('activate', function(e) {
  e.waitUntil(
    caches.keys().then(function(keys) {
      return Promise.all(
        keys
          .filter(function(k) { return k !== CACHE_VERSION && k !== SHARE_CACHE; })
          .map(function(k) {
            console.log('[SW] Dropping old cache:', k);
            return caches.delete(k);
          })
      );
    }).then(function() {
      // Let the browser fetch the navigation request in parallel with SW
      // startup so network-first navigations stay fast.
      if (self.registration.navigationPreload) {
        return self.registration.navigationPreload.enable();
      }
    }).then(function() {
      // NOTE: clients.claim() is deliberately NOT called. Taking control of an
      // already-loaded page fires controllerchange, which can drop an in-flight
      // WebSocket to the proxy (close 1005) and make the PokerTH server treat it
      // as a connect-then-drop → temporary IP block. This is the root cause of
      // the buggy reconnect after a reload (reliably reproduced once the cache
      // is cleared, since the SW then re-installs from scratch). Updates are
      // user-driven (the /__ver banner → SKIP_WAITING → reload), so the SW only
      // ever controls a freshly-navigated page, never a live one.
      // Tell pages a new version is live so they can offer a reload prompt.
      return self.clients.matchAll({ type: 'window' }).then(function(clients) {
        clients.forEach(function(client) {
          client.postMessage({ type: 'SW_UPDATED', version: CACHE_VERSION });
        });
      });
    })
  );
});

// ── Message : SKIP_WAITING (from the page) ──
self.addEventListener('message', function(e) {
  if (e.data && e.data.type === 'SKIP_WAITING') {
    self.skipWaiting();
  }
});

// Network-first, used for navigations (the HTML document). Prefers the preload
// response when available, refreshes the cached shell, and falls back to cache
// (then a tiny offline notice) when the network is down.
// The cached app shell only stands in for the app itself: a first visit to
// /live, /privacy, /faq, /studio… used to get the full client at that URL when
// the network was slow or down.
function isAppRoute(req) {
  try { return /^\/(?:index\.html|pokerth-client\.html)?$/.test(new URL(req.url).pathname); } catch (e) { return false; }
}
function handleNavigation(e) {
  var appRoute = isAppRoute(e.request);
  return (async function() {
    try {
      var preload = await e.preloadResponse;
      var netP = preload ? Promise.resolve(preload) : fetch(e.request);
      // Don't hang on a blank page while the origin is slow: after
      // NAV_TIMEOUT_MS serve the cached shell and let the fetch finish in the
      // background (it still refreshes the cache for the next load).
      var response = await Promise.race([
        netP,
        new Promise(function (res) { setTimeout(function () { res(null); }, NAV_TIMEOUT_MS); })
      ]);
      if (response === null) {
        netP.then(function (r) {
          if (r && r.status === 200) {
            var cl = r.clone();
            caches.open(CACHE_VERSION).then(function (c) { c.put(e.request, cl); });
          }
        }).catch(function () {});
        var shellNow = await caches.match(e.request) || (appRoute ? await caches.match(NAV_FALLBACK) : null);
        if (shellNow) return shellNow;
        response = await netP; // nothing cached yet (first visit) — wait it out
      }
      if (response && response.status === 200) {
        var clone = response.clone();
        caches.open(CACHE_VERSION).then(function(c) { c.put(e.request, clone); });
      }
      return response;
    } catch (err) {
      var cached = await caches.match(e.request);
      if (cached) return cached;
      var shell = appRoute ? await caches.match(NAV_FALLBACK) : null;
      if (shell) return shell;
      return new Response('Offline — reload when you are back online', {
        status: 503,
        headers: { 'Content-Type': 'text/plain; charset=utf-8' }
      });
    }
  })();
}

// Stale-while-revalidate, used for static assets. Serve from cache at once and
// refresh in the background; if nothing is cached, go to network and store it.
function handleAsset(e) {
  return caches.open(CACHE_VERSION).then(function(cache) {
    return cache.match(e.request).then(function(cached) {
      var network = fetch(e.request).then(function(response) {
        if (response && response.status === 200) {
          cache.put(e.request, response.clone());
        }
        return response;
      }).catch(function() { return null; });
      // Cache hit → instant response, network refresh happens in the background.
      // Cache miss → wait for the network (and a real Response on failure).
      return cached || network.then(function(r) {
        return r || new Response('Offline', {
          status: 503,
          headers: { 'Content-Type': 'text/plain; charset=utf-8' }
        });
      });
    });
  });
}

// True network-first for app CODE (.js/.mjs/.css): the network is always
// tried FIRST (`cache:'reload'` bypasses the HTTP disk cache too), and only
// a network failure (offline, origin down) falls back to the SW cache — so
// two code files requested moments apart (e.g. pokerth.js + pokerth.css on
// the same page load) can never end up served from two different deploys.
// Was stale-while-revalidate until 2.1.8-web.155 (narmod, 2026-09-12): that
// served the CACHED copy instantly and only refreshed it in the background
// for the *next* request, so pokerth.css and pokerth.js — revalidated by
// independent, differently-timed requests — could each pick up a deploy at
// a different moment and briefly disagree (new JS markup rendered against
// old CSS, or vice versa). Slightly slower on a cold/slow connection since
// every request now waits on the network before falling back; still fully
// offline-capable, and the /__ver banner is unaffected (CACHE_VERSION bump
// still drives the full re-precache on activate).
function handleCode(e) {
  return caches.open(CACHE_VERSION).then(function (cache) {
    return fetch(e.request, { cache: 'reload' }).then(function (response) {
      if (response && response.status === 200) {
        cache.put(e.request, response.clone());
        return response;
      }
      // A 5xx is an edge/origin hiccup (Cloudflare 52x bursts between the
      // edge and the origin last a few seconds), not a verdict on the file:
      // answering with it fails the <script type=module> just like a cut
      // connection would. Serve this version's precached copy when there is
      // one — same build as long as this worker is current — and pass the
      // error through otherwise. A 404 is passed through untouched (real
      // "not here"). If this worker is OLDER than the server (update not
      // applied yet), that copy can mismatch its fresh neighbours: the page
      // detects the resulting link error and reloads once (pokerth-client.html,
      // "Module skew", web.260).
      if (response && response.status >= 500) {
        return cache.match(e.request).then(function (cached) {
          return cached || response;
        });
      }
      return response;
    }).catch(function () {
      return cache.match(e.request).then(function (cached) {
        return cached || new Response('Offline', {
          status: 503,
          headers: { 'Content-Type': 'text/plain; charset=utf-8' }
        });
      });
    });
  });
}

// ── Notification actions ──
// The turn notification carries Fold / Check-Call buttons (see action-bar.mjs).
// Only a service worker can own those buttons, so the click lands here: we
// focus the game window and hand the chosen action over to the page, which
// re-validates that it is still the player's turn before sending anything.
// A click on the notification body (no action) only focuses the window.
self.addEventListener('notificationclick', function(e) {
  var act = e.action || '';
  e.notification.close();
  e.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function(list) {
      var client = (list && list[0]) || null;
      if (!client) return self.clients.openWindow('/');
      // The notification names the tab that posted it (data.tab): every window
      // gets the action and only that tab plays it. Without a tab (a page from
      // before web.331) the first window gets it, as before.
      var tab = e.notification.data && e.notification.data.tab;
      if (act && tab) list.forEach(function (c) { try { c.postMessage({ type: 'NOTIF_ACTION', action: act, tab: tab }); } catch (_e) {} });
      else if (act) client.postMessage({ type: 'NOTIF_ACTION', action: act });
      return client.focus ? client.focus() : null;
    })
  );
});

// ── Web Share Target (POST, multipart) ──
// The manifest points share_target at /share-target, but nothing on the server
// answers that route: the service worker IS the endpoint. The OS posts the
// shared text/URL and files here; we park the payload in a dedicated cache and
// redirect to the app, which drains it on boot (window._pthDrainShare).
function handleShareTarget(e) {
  return (async function() {
    var idx = { ts: Date.now(), title: '', text: '', url: '', files: [] };
    try {
      var form = await e.request.formData();
      idx.title = String(form.get('title') || '');
      idx.text  = String(form.get('text')  || '');
      idx.url   = String(form.get('url')   || '');
      var cache = await caches.open(SHARE_CACHE);
      var files = form.getAll('files') || [];
      for (var i = 0; i < files.length && i < 4; i++) {
        var f = files[i];
        if (!f || typeof f.name !== 'string') continue;
        var path = '/__share/' + i;
        await cache.put(new Request(path), new Response(f, {
          headers: { 'Content-Type': f.type || 'application/octet-stream' }
        }));
        idx.files.push({ path: path, name: f.name, type: f.type || '' });
      }
      await cache.put(new Request('/__share/index.json'), new Response(JSON.stringify(idx), {
        headers: { 'Content-Type': 'application/json' }
      }));
    } catch (err) {}
    // 303: turns the POST into a GET navigation, so a reload never re-posts.
    return Response.redirect('/?share=1', 303);
  })();
}

// ── Fetch : route by request type ──
self.addEventListener('fetch', function(e) {
  if (e.request.method === 'POST' &&
      new URL(e.request.url).pathname === '/share-target') {
    e.respondWith(handleShareTarget(e));
    return;
  }
  if (e.request.method !== 'GET') return;
  var url = new URL(e.request.url);
  // Don't intercept WebSocket upgrades or cross-origin requests (fonts etc.)
  if (url.origin !== self.location.origin) return;
  // The admin dashboard + its API are authenticated and no-store: never let the
  // SW cache or serve them (otherwise the package list, status, logs… show stale
  // after a change). Network only — admin is an online-only tool.
  if (/^\/admin(?:\/|$)/.test(url.pathname)) return;
  // Same for /arena: sent to the linked Arena (or a 404): a cached app shell
  // must never stand in for it.
  if (/^\/arena(?:\.html|\/|$)/.test(url.pathname)) return;
  // Live state endpoints served by the proxy: never cached, never served from
  // Cache Storage. `cache:'no-store'` on the page and `Cache-Control: no-store`
  // on the response are both ignored once the SW answers from a cache entry, so
  // the only way to keep them fresh is to leave them alone here. /__ver in
  // particular drives the update banner: served stale, it made the page compare
  // the previous deploy's marker against the fresh one and prompt for an update
  // that was already applied.
  if (/^\/(?:__ver|__time|__visit|__music|__poll-vote|prefs|prefs-web|stats|api)(?:\/|$)/.test(url.pathname)) return;
  // Media is served by the browser straight from the network: an <audio> element
  // streams with byte-range requests, and the SWR handler below only stores
  // status 200, so a 206 was never cacheable anyway. Every buffer chunk paid a
  // SW round-trip plus a full background revalidation, and a cache.match() hit
  // (which ignores Range) could answer a partial request with the whole file —
  // both stutter playback, badly so on iOS Safari. Nothing offline is lost.
  if (e.request.headers.get('range')) return;
  if (/^\/music\//.test(url.pathname) && !/\.json$/.test(url.pathname)) return;

  if (e.request.mode === 'navigate') {
    e.respondWith(handleNavigation(e));
  } else if (/\.(?:js|mjs|css)$/.test(url.pathname) || /^\/(?:table\/tables|cards\/decks|seats\/seats|music\/tracks)\.json$/.test(url.pathname) || url.pathname === '/app-config') {
    // Code, the runtime gallery manifests, AND the live /app-config are
    // network-first: a freshly imported package or a changed admin default must
    // be visible on the next load, never served stale from the SW cache.
    e.respondWith(handleCode(e));
  } else {
    e.respondWith(handleAsset(e));
  }
});

