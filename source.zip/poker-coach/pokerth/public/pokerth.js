// [Phase 2] audio (AudioContext, playTone, notify*, toggleSound) moved to public/modules/sounds.mjs

// ══ i18n ══
// [Phase 2] i18n moved to public/modules/i18n.mjs (LANG, _lang, t)
var _ipBlockInterval = null;
function _stopIpBlockCountdown() {
  if (_ipBlockInterval) { clearInterval(_ipBlockInterval); _ipBlockInterval = null; }
}
function _startIpBlockCountdown() {
  _stopIpBlockCountdown(); // ne jamais empiler deux minuteurs
  // Met à jour le statut toutes les secondes avec le temps restant
  _ipBlockInterval = setInterval(function() {
    // Le mode entraînement n'a pas de réseau → aucun blocage IP ne s'y applique.
    if (window._offlineMode) { _stopIpBlockCountdown(); return; }
    var rem = Math.max(0, Math.ceil((window._ipBlockUntil - Date.now()) / 1000));
    var mins = Math.floor(rem / 60), secs = rem % 60;
    var txt = t('ipBlockedPrefix') + (mins > 0 ? mins + 'min ' : '') + secs + 's';
    // Mettre à jour seulement si on est sur l'écran de connexion
    var cs = document.getElementById('cstatus');
    if (cs) cs.textContent = rem > 0 ? txt : t('canReconnect');
    if (rem <= 0) {
      _stopIpBlockCountdown();
      window._ipBlockUntil = 0;
      var cs2 = document.getElementById('cstatus');
      if (cs2) { cs2.textContent = t('canReconnect'); cs2.className = 'status ok'; }
    }
  }, 1000);
}

// The pill lives in the scaled table, on one line: a long notice
// (« Connection problems — The server is not responding… ») ran off a phone
// screen on both sides. When it does not fit, its message wraps, at the
// widest the screen allows (measured in the table's own scale); otherwise it
// stays on one line, as before. Also on resize / rotation.
function _fitConnPill() {
  var p = document.getElementById('g-conn-pill'), pm = document.getElementById('g-conn-pill-msg'), ps = document.getElementById('g-conn-pill-sub');
  if (!p || !pm || p.style.display === 'none') return;
  try {
    p.style.maxWidth = '';
    pm.style.whiteSpace = ''; pm.style.textAlign = ''; pm.style.flex = ''; pm.style.minWidth = '';
    if (ps) ps.style.whiteSpace = '';
    var r = p.getBoundingClientRect(), k = p.offsetWidth ? r.width / p.offsetWidth : 1;
    var room = (window.innerWidth || document.documentElement.clientWidth) - 24;
    if (!(k > 0) || r.width <= room) return;
    // the pill takes the widest the screen allows (in the table's own scale);
    // the message shares the first line with the dot and the ✕ and wraps, the
    // « seat kept » line below wraps too
    p.style.maxWidth = Math.floor(room / k) + 'px';
    pm.style.whiteSpace = 'normal'; pm.style.textAlign = 'center'; pm.style.flex = '1 1 0'; pm.style.minWidth = '0';
    if (ps) ps.style.whiteSpace = 'normal';
  } catch (e) {}
}
window.addEventListener('resize', function () { _fitConnPill(); });
function _showBanner(msg) {
  // À table (écran jeu actif) : pastille rouge centrée sur les cartes communes
  // (#g-conn-pill, dans le scaler → taille asservie au modèle générique de la
  // table). Hors table (connexion / lobby / attente) : bandeau plein écran
  // historique. Option avancée conn_pill (défaut ON) pour revenir au bandeau.
  // Appelée en boucle pendant les comptes à rebours → le choix pastille/bandeau
  // se réévalue à chaque tick (suit les changements d'écran en cours de reco).
  var sg = document.getElementById('s-game');
  var usePill = !!(sg && sg.classList.contains('active'));
  try { usePill = usePill && _advGet('conn_pill', true); } catch (e) {}
  // While the link is DOWN nothing can leave the machine: the action bar is
  // greyed out and inert (CSS: body.conn-lost) instead of looking live - a
  // player could tap Fold and believe it was sent. It follows the SOCKET, not
  // the notice: as soon as the retry socket is open (this function is called
  // again from its onopen, "re-authenticating") the bar is live again - after a
  // rebind on my own turn the server says nothing more, it waits for me, and
  // every second of a greyed bar would be taken from my thinking time.
  try {
    var _stB = window.PthState || {};
    document.body.classList.toggle('conn-lost', !(_stB.ws && _stB.ws.readyState === 1));
  } catch (e) {}
  var p = document.getElementById('g-conn-pill');
  var pm = document.getElementById('g-conn-pill-msg');
  if (pm) pm.textContent = msg;
  if (p) p.style.display = usePill ? 'flex' : 'none';
  var b = document.getElementById('reconnect-banner');
  var m = document.getElementById('reconnect-msg');
  if (m) m.textContent = msg;
  if (b) b.classList.toggle('visible', !usePill);
  // Parité QML 2.1.6 (reconnectPopup) : tant que le rejoin est armé, dire au
  // joueur que son siège reste réservé (la grâce proxy tient l'upstream ~2 min).
  // Réévalué à chaque tick, comme le choix pastille/bandeau.
  // FIX web.20 : _showBanner est HORS de l'IIFE App — `S` n'existe pas ici,
  // seul le pont window.PthState l'est (ReferenceError qui cassait toute la
  // reconnexion, rapport narmod 09/08). Garde défensive en prime.
  var _st = window.PthState || {};
  var _keep = !!_st._pendingRejoin;
  var ps = document.getElementById('g-conn-pill-sub');
  if (ps) { ps.textContent = _keep ? t('reconnSeatKept') : ''; ps.style.display = (_keep && usePill) ? 'block' : 'none'; }
  var bs = document.getElementById('reconnect-sub');
  if (bs) { bs.textContent = _keep ? t('reconnSeatKept') : ''; bs.style.display = (_keep && !usePill) ? 'inline' : 'none'; }
  if (usePill) _fitConnPill();          // once its lines are all set
}
function _hideBanner() {
  try { document.body.classList.remove('conn-lost'); } catch (e) {}
  var b = document.getElementById('reconnect-banner');
  if (b) b.classList.remove('visible');
  var p = document.getElementById('g-conn-pill');
  if (p) p.style.display = 'none';
}

// ═══════════════════════════════════════════════════════════
// ANIMATIONS DE JEU
// ═══════════════════════════════════════════════════════════
// ═══════════════════════════════════════════════════════════
// NOUVELLES ANIMATIONS
// ═══════════════════════════════════════════════════════════

// [Phase 2] Animations d'ambiance (launchConfetti, animateTableEnter,
// setUrgentMode, animatePlayerEliminated, état _prevDealerPid) déplacées dans
// public/modules/ui/anim.mjs (toujours globales via window.*).
// ── Indicateur de ping sur mon avatar (parité ShowPingStateInAvatar, bible
// §15) — OPT-IN. Mesure le RTT vers l'origine (fetch no-store de /__ver,
// l'endpoint mtime du proxy) toutes les 15 s, uniquement en jeu, onglet
// visible et partie réseau : le tick est un no-op quasi gratuit sinon
// (économie batterie iOS). Vert < 120 ms · jaune < 300 ms · rouge au-delà ·
// gris si la mesure échoue.
function _pingColor(ms) { return ms < 120 ? '#50c878' : ms < 300 ? '#FFC107' : '#e05050'; }
function _pingDotHide() { var d = document.getElementById('g-ping-dot'); if (d) d.style.display = 'none'; }
function _pingTick() {
  try {
    if (!_advGet('ping_avatar', true) || document.hidden || window._offlineMode) { _pingDotHide(); return; }
    var sg = document.getElementById('s-game');
    if (!sg || !sg.classList.contains('active')) { _pingDotHide(); return; }
    var t0 = performance.now();
    fetch('/__ver?ping=' + Date.now(), { cache: 'no-store' }).then(function () {
      var ms = Math.round(performance.now() - t0);
      var d = document.getElementById('g-ping-dot');
      if (!d) return;
      d.style.display = '';
      d.style.background = _pingColor(ms);
      d.title = ms + ' ms';
    }).catch(function () {
      var d = document.getElementById('g-ping-dot');
      if (d) { d.style.display = ''; d.style.background = '#8b93a7'; d.title = '\u2014'; }
    });
  } catch (e) {}
}
window._pingTick = _pingTick;
setInterval(_pingTick, 15000);
setTimeout(_pingTick, 3000);

// [Phase 2] Animations de jeu (updatePotSize, animateDealerMove, animateAllIn,
// fadeOutAllActions, animateShowdownCards, burstStars, animatePot,
// setMyTurnActive) déplacées dans public/modules/ui/anim.mjs (toujours
// globales via window.*).
// Réglages persistés en localStorage (pth_*). Les bascules « présentation »
// sont appliquées via des classes sur <body> (CSS) pour rester additif et sûr.
// Les lignes grisées « bientôt » dépendent d'un travail backend/moteur à venir.
// Sièges « perdants » au showdown (pids) → cartes estompées (fadeOutLosingCards).
// Rempli dans EndOfHandShow (si pth_fade_losers != '0'), vidé à HandStart.
window.directWS = false; // [9g-A2] jamais déclaré → propriété window explicite
window._pthLiveTransport = 'inherit'; // /live transport override, from /app-config
window._sdLosers = new Set();
window._sdWinners = new Set();   // sièges gagnants du showdown (PlayerWinnerOverlay QML)
// Option "révéler mes cartes au tap" (pth_own_click) : quand activée, mes cartes
// sont face cachée tant que window._ownReveal est faux ; un tap sur la player-bar bascule.
// Remis à faux à chaque nouvelle main (confidentialité), forcé à vrai au showdown.
window._ownReveal = false;
// Anti-Call accidentel (pth_guard_call) : suit le montant "à suivre" vu à ma
// dernière décision sur la street courante (reset par street). Si une grosse
// relance fait bondir ce montant, le bouton Call exige une confirmation (2e tap).
window._lastCallSeen = -1;
window._callConfirmArmed = false;
window._callConfirmTimer = null;
window._lastBoardCount = -1; // nb de cartes du board au dernier rendu (détecte la street)
window._oddsSeq = 0; // jeton du moniteur d'odds : abandonne tout calcul périmé
function _advStripEmoji(s) {
  s = String(s == null ? '' : s);
  try { s = s.replace(/\p{Extended_Pictographic}/gu, ''); } catch (e) {}
  s = s.replace(/[\uFE0F\u200D\u20E3]/g, '').replace(/[ \t]{2,}/g, ' ').trim();
  return s;
}
function _advGet(key, defOn) {
  // Interrupteur d'arrêt admin (/app-config.featureOff) : il prime sur la
  // préférence du joueur, qui reste écrite en localStorage et reprend effet si
  // l'admin réouvre la fonctionnalité — on force la lecture, on n'efface rien.
  try { if (window._pthFeatureOff && window._pthFeatureOff[key]) return false; } catch (e) {}
  try {
    var v = localStorage.getItem('pth_' + key);
    if (v === null) return !!defOn;
    return v === '1';
  } catch (e) { return !!defOn; }
}
// ── Termes de poker (Fold/Check/Call/Bet/Raise/All-In) ───────────────────────
//    Option « ne pas traduire les termes de poker » (poker_en, cochée par
//    défaut = parité officielle PokerTH : DontTranslateInternationalPokerStrings).
//    Cochée  → terme anglais canonique. Décochée → traduction de la langue
//    active (transKey, comportement historique inchangé). base ∈
//    fold|check|call|bet|raise|allin.
var _POKER_EN_TERMS = { fold: 'Fold', check: 'Check', call: 'Call', bet: 'Bet', raise: 'Raise', allin: 'All-In' };
function pkTerm(base, transKey) {
  try {
    if (_advGet('poker_en', true)) return _POKER_EN_TERMS[base] || t(transKey || base);
    return t(transKey || base);
  } catch (e) { return t(transKey || base); }
}
window.pkTerm = pkTerm;
// ── Joueurs ignorés (préférence locale, par nom). Le chat du joueur est masqué
//    et son avatar anonymisé (sauf si « ne pas masquer les avatars ignorés »
//    est activée). Voir _ignHide (sièges), addChat/addGameChat (filtre) et
//    window._toggleIgnore (carte joueur). ──
var _ignoredSet = (function(){ try { return new Set(JSON.parse(localStorage.getItem('pth_ignored') || '[]')); } catch (e) { return new Set(); } })();
function _isIgnored(name){ return !!name && _ignoredSet.has(String(name)); }
// Liste centrale des ignorés (Options avancées > Partie Internet — parité
// QML Ignorierte Spieler) : rendu + bouton « Retirer » par joueur.
function renderIgnoredList(){
  var box = document.getElementById('adv-ignored-list');
  if (!box) return;
  var esc = function(v){ return String(v == null ? '' : v).replace(/[&<>"]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); };
  var tt = function(k, fb){ try { if (typeof window.t === 'function') { var v = window.t(k); if (v && v !== k) return v; } } catch (e) {} return fb; };
  var names = Array.from(_ignoredSet).sort(function(a, b){ return String(a).localeCompare(String(b)); });
  if (!names.length) { box.innerHTML = '<div class="adv-ign-empty">' + esc(tt('advIgnoredEmpty', '(no ignored players)')) + '</div>'; return; }
  box.innerHTML = names.map(function(n){
    return '<div class="adv-ign-row"><span class="adv-ign-name">' + esc(n) + '</span>'
         + '<button type="button" class="adv-ign-rm" data-name="' + esc(n) + '">' + esc(tt('advIgnoredRemove', 'Remove')) + '</button></div>';
  }).join('');
}
window.renderIgnoredList = renderIgnoredList;
document.addEventListener('click', function(e){
  var b = (e.target && e.target.closest) ? e.target.closest('.adv-ign-rm') : null;
  if (!b) return;
  _setIgnoredName(b.getAttribute('data-name'), false);
  renderIgnoredList();
  try { if (typeof window._renderSeats === 'function') window._renderSeats(); } catch (err) {}
});
function _setIgnoredName(name, on){
  name = String(name || ''); if (!name) return;
  if (on) _ignoredSet.add(name); else _ignoredSet.delete(name);
  try { localStorage.setItem('pth_ignored', JSON.stringify(Array.from(_ignoredSet))); } catch (e) {}
  if (on) {
    ['chat', 'g-chat-msgs'].forEach(function(id){
      var box = document.getElementById(id);
      if (!box) return;
      box.querySelectorAll('.msg').forEach(function(m){
        var w = m.querySelector('.who');
        if (w && w.textContent === name && !m.classList.contains('mine')) m.remove();
      });
    });
  }
}
function applyAdvOpts() {
  try {
    var b = document.body;
    b.classList.toggle('adv-no-cardanim', !_advGet('anim_cards', true));
    b.classList.toggle('adv-no-blinds', !_advGet('show_blinds', true));
    b.classList.toggle('adv-no-potbtns', !_advGet('pot_btns', true)); // quick-bets 1/3·1/2·Pot (parite ShowPotPercentButtons)
    b.classList.toggle('adv-no-communitycontent', !_advGet('community_content', true)); // contenus communaute (parite showCommunityContent)
    b.classList.toggle('adv-no-blindsbadge', !_advGet('blinds_badge', true)); // pastille blinds du bandeau (extension web)
    b.classList.toggle('adv-no-forumnews', !_advGet('forum_news', true)); // bouton Forum du lobby (extension web)
    try { if (typeof window._lobbyClockRefresh === 'function') window._lobbyClockRefresh(); } catch (e) {} // horloge serveur du lobby (option lobby_clock)
    b.classList.toggle('adv-no-community', !_advGet('show_community', true));
    b.classList.toggle('adv-no-flag', !_advGet('show_flag', true));
    // Titre « PokerTH » de l'écran de connexion : caché par défaut (defOn
    // = false). La classe n'est posée que si l'option est activée (narmod
    // 19/07). Le CSS masque .cl-app-title sauf sous body.adv-show-title.
    /* adv-show-title : desormais pilote par l'admin via /app-config.showLoginTitle (reglage d'instance applique a tous) — plus d'option par utilisateur. */
    try { if (typeof window._syncStatsTab === 'function') window._syncStatsTab(); } catch (e) {}
    try { if (typeof window._hudRefresh === 'function' && _advGet('hud_on', false)) window._hudRefresh(); else if (typeof window._hudRender === 'function') window._hudRender(); } catch (e) {}
    try {
      var _ex = document.querySelectorAll('.adv-export-btn');
      var _on = _advGet('stats_track', true);
      for (var _k = 0; _k < _ex.length; _k++) _ex[_k].disabled = !_on;
    } catch (e) {}
    b.classList.add('adv-hide-pbar'); // mode PokerTH permanent — option « barre joueur masquée » retirée (narmod 2026-07-17), le CSS reste keyé sur la classe
    b.classList.toggle('adv-no-tablezoom', !_advGet('table_zoom', true)); // interrupteur zoom (parite QML tableZoomEnabled)
    try { if (typeof window._applyBrowserZoomOpt === 'function') window._applyBrowserZoomOpt(); } catch (e) {}   // zoom navigateur (option browser_zoom)
    try { if (typeof window.applyAccessibilityPreferences === 'function') window.applyAccessibilityPreferences(); } catch (e) {}
    b.classList.toggle('adv-no-lobbychat', !_advGet('lobby_chat', true)); // chat du lobby (parite QML UseLobbyChat)
    b.classList.toggle('adv-no-chatts', !_advGet('chat_ts', true)); // heure [HH:MM:SS] devant les messages de chat (demande forum, extension web)
    b.classList.remove('adv-no-winopen'); // bouton dore tant que sa fenetre est ouverte : toujours actif — option retiree (narmod 2026-07-30), le CSS reste keye sur la classe
    try { if (typeof window._syncWinBtns === 'function') window._syncWinBtns(); } catch (e) {}
    b.classList.toggle('adv-no-handsbtn', !_advGet('hands_btn', true)); // icone combinaisons de poker sur le tapis (extension web)
    b.classList.toggle('adv-no-avcreate', !_advGet('avatar_create', true)); // onglet « Créer » de la fenêtre avatar (avatar-studio)
    try { if (typeof window.applyTableZoom === 'function') window.applyTableZoom(); } catch (e) {}
    try { var _slm = localStorage.getItem('pth_seat_layout'); _slm = (_slm === 'pokerth-official' || _slm === 'pokerth-ellipse' || _slm === 'custom') ? _slm : 'auto'; document.documentElement.setAttribute('data-seat-layout', _slm); } catch (e) {}
    try { if (typeof window._refreshOwnCards === 'function') window._refreshOwnCards(); } catch (e) {}
    try { if (typeof window._renderOdds === 'function') window._renderOdds(); } catch (e) {}
    try { if (typeof window._renderSeats === 'function') window._renderSeats(); } catch (e) {}
    // Glossaire d'abréviations de chat (option chat_abbrev) : re-marque /
    // dé-marque les messages selon l'état de l'option (module chat/abbrev.mjs).
    try { if (typeof window._chatAbbrevRefresh === 'function') window._chatAbbrevRefresh(); } catch (e) {}
    // Scènes de l'As (modules/mascot, sans option depuis web.265) : réarme le minuteur d'inactivité.
    try { if (typeof window._mascotApply === 'function') window._mascotApply(); } catch (e) {}
    // Aide de l'As (option guide_on, modules/guide) : allume / éteint l'assistant.
    try { if (typeof window._guideApply === 'function') window._guideApply(); } catch (e) {}
    // Gamepad (modules/ui/gamepad.mjs): glyph layout, pad on/off.
    try { if (typeof window.padApply === 'function') window.padApply(); } catch (e) {}
  } catch (e) {}
}
window.applyAdvOpts = applyAdvOpts;
function setAdvOpt(key, on) {
  try { localStorage.setItem('pth_' + key, on ? '1' : '0'); } catch (e) {}
  applyAdvOpts();
  try { _cfgSyncMark(key); } catch (e) {}   // sync compte (no-op si désactivée)
}
window.setAdvOpt = setAdvOpt;
// Options avancees : infobulles natives (title). Off => on retire les title
// (ranges dans data-ttl) ; On => on les restaure. Applique au chargement et a
// chaque bascule. Les title ajoutes dynamiquement apres coupure gardent leur
// title jusqu'a la prochaine application (limite mineure, non bloquante).
function applyTooltips() {
  try {
    var on = _advGet('tooltips', true);
    if (on) {
      var r = document.querySelectorAll('[data-ttl]');
      for (var i = 0; i < r.length; i++) { r[i].setAttribute('title', r[i].getAttribute('data-ttl')); r[i].removeAttribute('data-ttl'); }
    } else {
      var t = document.querySelectorAll('[title]');
      for (var j = 0; j < t.length; j++) { t[j].setAttribute('data-ttl', t[j].getAttribute('title')); t[j].removeAttribute('title'); }
    }
  } catch (e) {}
}
window.applyTooltips = applyTooltips;
function setTooltips(on) {
  try { localStorage.setItem('pth_tooltips', on ? '1' : '0'); } catch (e) {}
  applyTooltips();
}
window.setTooltips = setTooltips;
// Options avancees : communaute par defaut du classement (pth/bbc/wec). Reutilise
// la preference existante pth_rank_src (derniere source ouverte = defaut). Si le
// classement est ouvert, applique tout de suite.
function setDefaultCommunity(v) {
  v = (v === 'bbc' || v === 'wec') ? v : 'pth';
  try { localStorage.setItem('pth_rank_src', v); } catch (e) {}
  try {
    var m = document.getElementById('ranking-modal');
    if (m && m.style.display !== 'none' && typeof window.rankingSelect === 'function') window.rankingSelect(v);
  } catch (e) {}
}
window.setDefaultCommunity = setDefaultCommunity;
// Intervalle du journal (parite QML LogInterval) : 'action' (chaque action)
// ou 'hand' (une entree par etape de main seulement). Persiste ; lu en direct
// par logAction via _getLogInterval.
// Index officiel (configfile.cpp defaut "1", log.cpp) :
//   0 = after every action · 1 = after every hand · 2 = after every game.
// Les anciennes valeurs texte ('action'/'hand') restent lues pour ne pas
// perdre le reglage des joueurs deja installes.
function _getLogIntervalIdx() {
  try {
    var v = localStorage.getItem('pth_log_interval');
    if (v === 'action') return 0;
    if (v === 'hand') return 1;
    var n = parseInt(v, 10);
    return (n === 0 || n === 1 || n === 2) ? n : 1;
  } catch (e) { return 1; }
}
window._getLogIntervalIdx = _getLogIntervalIdx;
// Compatibilite : le journal texte ne distingue que « chaque action » du reste,
// exactement comme guilog.cpp (LogInterval == 0).
function _getLogInterval() {
  return (_getLogIntervalIdx() === 0) ? 'action' : 'hand';
}
window._getLogInterval = _getLogInterval;
window.setLogInterval = function (v) {
  var idx;
  if (v === 'action') idx = 0;
  else if (v === 'hand') idx = 1;
  else { idx = parseInt(v, 10); if (!(idx === 0 || idx === 1 || idx === 2)) idx = 1; }
  try { localStorage.setItem('pth_log_interval', String(idx)); } catch (e) {}
  // Le fichier .pdb suit le meme reglage (parite log.cpp) : on previent le
  // module d'ecriture automatique pour qu'il reprenne au bon rythme.
  try { if (typeof window._pdbAutoSave === 'function') window._pdbAutoSave('flush'); } catch (e) {}
};
// Croix de fermeture des fenetres flottantes : coupe l'option et masque.
window.closeOddsWin = function () {
  // Héritage : l'ancienne fenêtre flottante d'odds est devenue l'onglet
  // « Chances » du panneau info unifié — on ferme simplement le panneau.
  try { var p = document.getElementById('g-log-panel'); if (p && p.style.display !== 'none') toggleLog(); } catch (e) {}
};
window.closeAssistWin = function () {
  try { if (typeof window.setAssist === 'function') window.setAssist(false); } catch (e) {}
  var cb = document.getElementById('adv-assist'); if (cb) cb.checked = false;
};
// Options avancees : fenetre flottante via le SYSTEME GENERIQUE
// (_enableFloating — meme patron que chat, log, journaux). Largeur >= 600 px
// (seuil canonique QML : « compact » = largeur < 600) : deplacable par la barre
// de titre, redimensionnable (poignees
// .win-rsz), contenu zoome avec la taille (base 620x640), position/taille
// memorisees sous pth_win_adv. Sur mobile : modal centre flex, aucun resize.
// Remplace l'ancien systeme dedie (_advAttachDrag/_advApplyZoom/
// _advSetupResize, cles pth_adv_pos/pth_adv_size — migrees ci-dessous).
function _advSetupFloat() {
  var card = document.querySelector('#adv-modal .adv-card');
  if (!card) return;
  var wide = false;
  try { wide = window.matchMedia('(min-width:600px)').matches; } catch (e) {}
  if (!wide) { try { _disableFloating(card); } catch (e) {} return; }
  // Migration one-shot des anciennes cles vers la cle unique du systeme.
  try {
    if (!localStorage.getItem('pth_win_adv')) {
      var op = JSON.parse(localStorage.getItem('pth_adv_pos') || 'null');
      var os = JSON.parse(localStorage.getItem('pth_adv_size') || 'null');
      if ((op && typeof op.left === 'number') || (os && os.w)) {
        var d = { left: (op && op.left) || 16, top: (op && op.top) || 56 };
        if (os && os.w) { d.width = os.w; d.height = os.h || 640; }
        localStorage.setItem('pth_win_adv', JSON.stringify(d));
      }
    }
    localStorage.removeItem('pth_adv_pos'); localStorage.removeItem('pth_adv_size');
  } catch (e) {}
  // Plafond proportionne a l'ecran : la fenetre reste redimensionnable mais bornee
  // (marges qui s'adaptent — petit ecran => plus petite, grand ecran => plafonne).
  var maxW = Math.min(1010, Math.round(window.innerWidth * 0.92));
  var maxH = Math.min(680, Math.round(window.innerHeight * 0.90));
  // Nouvel utilisateur (aucune geometrie memorisee sous pth_win_adv) : on ouvre a
  // la taille MAXIMALE possible — le plafond ci-dessus, borne par le viewport —
  // et centree. Des que l'utilisateur deplace ou redimensionne, sa geometrie est
  // memorisee et prime aux ouvertures suivantes. Desktop + tablette seulement :
  // sous 600 px on n'est pas en fenetre flottante (sortie plus haut).
  var openW = Math.max(380, Math.min(maxW, window.innerWidth - 16));
  var openH = Math.max(360, Math.min(maxH, window.innerHeight - 16));
  _enableFloating(card, {
    key: 'pth_win_adv',
    handle: card.querySelector('.km-title'),
    resizable: true,
    maxW: maxW, maxH: maxH,   // plafond proportionne (fenetre bornee)
    zoom: true,
    defW: 620, defH: 640,          // base du zoom (inchangee vs _advApplyZoom)
    openW: openW, openH: openH,    // 1re ouverture : taille maxi possible
    minW: 380, minH: 360,   // 524→380 : sous 600 px la sidebar devient barre d'icônes (container query), une fenêtre étroite « portrait » est légitime
    defLeft: Math.max(8, Math.round((window.innerWidth - openW) / 2)),
    defTop: Math.max(8, Math.round((window.innerHeight - openH) / 2)),
  });
}
function openAdvancedOptions() {
  var m = document.getElementById('adv-modal');
  if (!m) return;
  var sync = function (id, key, defOn) {
    var el = document.getElementById(id);
    if (el) el.checked = _advGet(key, defOn);
  };
  sync('adv-anim', 'anim_cards', true);
  sync('adv-dealanim', 'deal_anim', true);   // animation de distribution (web) — désactivable, rapport forum
  sync('adv-blinds', 'show_blinds', true);
  sync('adv-potbtns', 'pot_btns', true);
  sync('adv-communitycontent', 'community_content', true);
  sync('adv-splash', 'splash', true);          // parité QML : DisableSplashScreenOnStartup=0
  sync('adv-community', 'show_community', true);
  sync('adv-communitysuggest', 'community_suggest', false); // defaut QML : showCommunitySuggest = false
  sync('adv-focusbet', 'focus_bet', false);
  sync('adv-noemoji', 'chat_noemoji', false);
  sync('adv-chatabbrev', 'chat_abbrev', true);   // glossaire d'abréviations (gg, nh…), actif par défaut
  sync('adv-chatts', 'chat_ts', true);   // heure dans le chat, active par defaut (comportement historique)
  sync('adv-fadelosers', 'fade_losers', true);
  sync('adv-flag', 'show_flag', true);
  sync('adv-ownclick', 'own_click', false);
  sync('adv-guardcall', 'guard_call', false);  // défaut web : anti-call accidentel désactivé
  sync('adv-guardraise', 'guard_raise', true);  // garde-fou montant hors bornes (parité QML 2.1.5)
  // Globe de traduction : défaut = comportement QML 2.1.5 (ligne survolée /
  // tapée seulement) ; coché = bouton permanent sur toutes les lignes.
  sync('adv-chattralways', 'chat_tr_always', false);
  sync('adv-avcreate', 'avatar_create', true);   // onglet « Créer » de la fenêtre avatar (studio matriciel, extension web)
  try { document.body.classList.toggle('chat-tr-always', _advGet('chat_tr_always', false)); } catch (e) {}
  sync('adv-assist', 'assist', true);
  sync('adv-showodds', 'show_odds', true);
  sync('adv-handsbtn', 'hands_btn', true);
  sync('adv-haptic', 'haptic', true);
  sync('adv-displaybb', 'display_bb', false);
  sync('adv-nohideignored', 'no_hide_ignored', false);
  sync('adv-fkeysalt', 'fkeys_alt', false);
  sync('adv-keynav', 'keynav', true);   // Esc = annuler / Enter = valider (defaut on)
  sync('adv-padon', 'pad_on', true);          // gamepad (modules/ui/gamepad.mjs, web) — on by default
  sync('adv-padrumble', 'pad_rumble', true);  // gamepad vibrates on my turn
  sync('adv-padnin', 'pad_nintendo', false);  // Nintendo layout: A/B swapped
  sync('adv-padkb', 'pad_kb', true);          // controller on-screen keyboard for text fields
  try { var _rmt = document.getElementById('adv-remoteon'); if (_rmt && window.RemoteNav) _rmt.checked = window.RemoteNav.enabled(); } catch (e) {}   // TV remote: on by itself on a TV (modules/ui/remote.mjs)
  sync('adv-tablezoom', 'table_zoom', true);
  sync('adv-browserzoom', 'browser_zoom', false);   // zoom navigateur : bloqué par défaut sur tactile
  sync('adv-backguard', 'back_guard', true);        // bouton Retour Android = Escape (parité QML §6)
  sync('adv-guide', 'guide_on', false);             // Aide de l'As (modules/guide) — OFF tant que le joueur n'a pas dit oui
  sync('adv-acescenes', 'ace_scenes', true);       // facéties de l'As (scènes, danses, réactions, bravo) — modules/mascot/index.mjs
  sync('adv-acedance', 'ace_dance', true);    // l'As danse sur le lecteur de musique (modules/mascot/acts-dance.mjs)
  sync('adv-lobbychat', 'lobby_chat', true);
  sync('adv-polls', 'polls', true);   // sondages produit : visible par defaut, decochable ici
  sync('adv-connpill', 'conn_pill', true);   // pastille de connexion sur le feutre (web)
  sync('adv-pausehands', 'pause_hands', false);
  sync('adv-createdialog', 'create_dialog', true);
  sync('adv-cfgsync', 'cfg_sync', true);
  sync('adv-pokeren', 'poker_en', true);
  try { renderIgnoredList(); } catch (e) {}
  sync('adv-logon', 'log_on', true);
  sync('adv-statstrack', 'stats_track', true);
  sync('adv-hudon', 'hud_on', false);
  sync('adv-pdbauto', 'pdb_auto', true);   // ecriture auto du .pdb dans un dossier local (web) — ON par defaut
  try { if (typeof window._pdbAutoUi === 'function') window._pdbAutoUi(); } catch (e) {}
  sync('adv-bakauto', 'bak_auto', true);   // ecriture auto de la sauvegarde web dans un dossier local (web) — ON par defaut
  try { if (typeof window._bakAutoUi === 'function') window._bakAutoUi(); } catch (e) {}
  try { var _li = document.getElementById('adv-loginterval'); if (_li) _li.value = String(_getLogIntervalIdx()); } catch (e) {}
  sync('adv-zoomfollow', 'zoom_follow', true); // défaut QML : suivi actif quand le zoom l'est
  sync('adv-snd-actions', 'snd_actions', true);
  sync('adv-snd-lobby', 'snd_lobby', true);
  sync('adv-snd-net', 'snd_net', true);
  sync('adv-snd-blinds', 'snd_blinds', true);
  sync('adv-reducefx', 'reduce_fx', false);
  sync('adv-statusbar', 'status_bar', true);
  sync('adv-blindsbadge', 'blinds_badge', true);
  sync('adv-lobbyclock', 'lobby_clock', true);   // horloge serveur dans la barre du lobby (pokerth.net, web)
  sync('adv-forumnews', 'forum_news', true);   // bouton Forum + badge non-lus dans l'en-tete du lobby (web)
  sync('adv-winnerpopup', 'winner_popup', true);
  sync('adv-removegone', 'remove_gone', false);
  sync('adv-confirmsocial', 'confirm_social', true);   // confirmation avant inviter/ignorer (parité QML 2.1.4)
  sync('adv-chatclearlogin', 'chat_clear_login', true); // vider le chat lobby au login (parité QML 2.1.5)
  sync('adv-lobbytypechat', 'lobby_type_chat', true);   // lobby : la frappe hors champ va dans le chat (web)
  try { var _dm = document.getElementById('adv-darkmode'); if (_dm && window.getTheme) _dm.value = window.getTheme() || 'auto'; } catch (e) {}
  sync('adv-pingavatar', 'ping_avatar', true); // défaut QML : ShowPingStateInAvatar=1
  sync('adv-autoleave', 'auto_leave', false);
  sync('adv-nickretry', 'nick_retry', true);   // réessai auto quand le pseudo est encore occupé
  sync('adv-errreport', 'err_report', true);
  sync('adv-tdwitness', 'td_witness', true);   // témoin de tournoi (modules/arena-witness.mjs, web)
  sync('adv-invitelink', 'invite_link', true); // bouton \u00ab Inviter des amis \u00bb du salon d'attente (web)   // remontée des erreurs JS à l'admin du serveur (web) — ON par défaut, décochable
  // Barre d'état de jeu (pot-strip : H#/G#, pot+bets, phase) masquable
  try {
    var _ps = document.getElementById('pot-strip');
    if (_ps) _ps.style.display = _advGet('status_bar', true) ? '' : 'none';
  } catch (e) {}
  // Mode « effets réduits » (parité QmlReduceEffects) : classe sur <html>,
  // le CSS coupe ombres / glow / backdrop-filter.
  try { document.documentElement.classList.toggle('reduce-fx', _advGet('reduce_fx', false)); } catch (e) {}
  try { var _sv = document.getElementById('adv-sndvol'); if (_sv && window.getSoundVolume) _sv.value = Math.round(window.getSoundVolume() * 10); } catch (e) {}
  try {
    var _as = localStorage.getItem('pth_assist_style');
    _as = (_as === 'bar') ? 'bar' : 'segs';
    document.documentElement.setAttribute('data-assist-style', _as);
    var _ase = document.getElementById('adv-assiststyle'); if (_ase) _ase.value = _as;
  } catch (e) {}
  try { var _sl = document.getElementById('adv-seatlayout'); if (_sl) { var _slv = localStorage.getItem('pth_seat_layout'); _sl.value = (_slv === 'pokerth-official' || _slv === 'pokerth-ellipse' || _slv === 'custom') ? _slv : 'auto'; } } catch (e) {}
  try { var _ctr = document.getElementById('adv-chattranslate'); if (_ctr) { _ctr.checked = !(window._pthFeatureOff && window._pthFeatureOff.chat_translate) && (localStorage.getItem('pth_chat_translate') !== '0'); if (!window._chatTrSupported) { var _ctl = _ctr.closest('label'); if (_ctl) _ctl.style.opacity = '0.55'; } } } catch (e) {}
  try { window._rebindAction = null; _renderKeyButtons(); } catch (e) {}
  sync('adv-tooltips', 'tooltips', true);
  try { var _nr = document.getElementById('adv-noreact'); if (_nr) _nr.checked = (localStorage.getItem('pth_react_muted') === '1'); } catch (e) {}
  try { var _dc = document.getElementById('adv-defcommunity'); if (_dc) _dc.value = (localStorage.getItem('pth_rank_src') || 'pth'); } catch (e) {}
  try { _advSyncPrefs(); } catch (e) {}
  try { _advSyncContext(); } catch (e) {}
  // Réouverture sur la DERNIÈRE catégorie visitée (demande narmod 2026-07-18) —
  // avant : retour systématique sur « Interface utilisateur ». Restauré APRÈS
  // _advSyncContext pour connaître les catégories grisées ; repli 'ui' si la
  // catégorie mémorisée est sans objet dans le contexte courant (lobby/partie).
  try {
    var _advCat = '';
    try { _advCat = localStorage.getItem('pth_adv_cat') || ''; } catch (e2) {}
    var _advBtn = _advCat ? m.querySelector('.adv-cat[data-cat="' + _advCat + '"]') : null;
    if (!_advBtn || _advBtn.hasAttribute('disabled')) _advCat = 'ui';
    advSelectCat(_advCat);
    var _advTab = '';
    try { _advTab = localStorage.getItem('pth_adv_uitab') || ''; } catch (e2) {}
    advUiTab(_advTab === 'network' ? 'network' : 'general');
  } catch (e) { try { advSelectCat('ui'); advUiTab('general'); } catch (e2) {} }
  m.style.display = '';
  try { _advSetupFloat(); } catch (e) {}
}
window.openAdvancedOptions = openAdvancedOptions;
function closeAdvancedOptions() {
  var m = document.getElementById('adv-modal');
  if (m) m.style.display = 'none';
  window._rebindAction = null;
}
window.closeAdvancedOptions = closeAdvancedOptions;
// Re-clic sur l'entree du menu = fermer (parite des autres boutons a fenetre).
window.toggleAdvancedOptions = function () {
  var m = document.getElementById('adv-modal');
  if (m && m.style.display && m.style.display !== 'none') { closeAdvancedOptions(); return; }
  openAdvancedOptions();
};
// Options avancées : navigation par catégories (parité du dialogue officiel
// PokerTH QML). Sidebar icône+texte en tablette/desktop ; barre d'icônes seules
// en haut sur téléphone (géré en CSS). Les catégories hors « Interface » relient
// l'UI existante (thème, son, avatar, journal, connexion…), elles ne dupliquent
// rien. advSelectCat() bascule l'onglet actif ; les catégories grisées sont
// inertes.
function advSelectCat(cat) {
  var modal = document.getElementById('adv-modal');
  if (!modal) return;
  // Une recherche en cours masque les panneaux : cliquer une categorie (ou
  // rouvrir la fenetre, qui passe par ici) la remet a zero.
  try { if (window._advSearchReset) window._advSearchReset(); } catch (e) {}
  var btn = modal.querySelector('.adv-cat[data-cat="' + cat + '"]');
  if (btn && btn.hasAttribute('disabled')) return;   // catégorie sans objet : on ignore
  var cats = modal.querySelectorAll('.adv-cat');
  for (var i = 0; i < cats.length; i++) {
    var on = cats[i].getAttribute('data-cat') === cat;
    cats[i].classList.toggle('is-active', on);
    cats[i].setAttribute('aria-selected', on ? 'true' : 'false');
  }
  var panels = modal.querySelectorAll('.adv-panel');
  for (var j = 0; j < panels.length; j++) {
    panels[j].classList.toggle('is-active', panels[j].getAttribute('data-cat') === cat);
  }
  try { var pn = modal.querySelector('.adv-panels'); if (pn) pn.scrollTop = 0; } catch (e) {}
  try { if (cat === 'style' && window.renderThemeInto) window.renderThemeInto(document.getElementById('adv-theme-host')); } catch (e) {}
  // Liste des sons personnalisables : module charge a la demande (personne ne
  // paie son telechargement tant que l'onglet Son n'est pas ouvert).
  try {
    if (cat === 'sound') {
      var _sh = document.getElementById('adv-snd-custom-host');
      if (_sh) import('/modules/ui/sound-import.mjs')
        .then(function (m) { try { m.mount(_sh); } catch (e) {} })
        .catch(function () {});
    }
  } catch (e) {}
  try { localStorage.setItem('pth_adv_cat', cat); } catch (e) {}  // réouverture au même endroit
}
window.advSelectCat = advSelectCat;

// Options avancees : sous-onglets « General » / « Network » du panneau Interface
// (parite de la fenetre officielle : onglets General / Reseau).
function advUiTab(name) {
  var modal = document.getElementById('adv-modal');
  if (!modal) return;
  var tabs = modal.querySelectorAll('.adv-subtab');
  for (var i = 0; i < tabs.length; i++) {
    var on = tabs[i].getAttribute('data-uitab') === name;
    tabs[i].classList.toggle('is-active', on);
    tabs[i].setAttribute('aria-selected', on ? 'true' : 'false');
  }
  var ps = modal.querySelectorAll('.adv-uipanel');
  for (var j = 0; j < ps.length; j++) {
    ps[j].classList.toggle('is-active', ps[j].getAttribute('data-uitab') === name);
  }
  try { localStorage.setItem('pth_adv_uitab', name); } catch (e) {}  // réouverture au même endroit
}
window.advUiTab = advUiTab;

// Grise les catégories sans objet dans le contexte courant (lobby vs partie) et
// renseigne le serveur courant dans l'onglet « Jeu Internet ».
// ── Préférences de table par mode (passe G — parité QML LocalGameSettings /
// NetworkGameSettings / InternetGameSettings). Trois emplacements localStorage :
// pth_prefs_local / pth_prefs_lan / pth_prefs_internet. Édités champ par champ
// dans les Options avancées (persistance immédiate) ; la pastille 💾 du
// formulaire de création écrit l'instantané complet dans l'emplacement du mode
// courant et ⭐ Perso le recharge (App._createPrefsKey). ──
var _ADV_PREFS_KEYS = { local: 'pth_prefs_local', lan: 'pth_prefs_lan', net: 'pth_prefs_internet' };
// Valeurs affichées tant que le joueur n'a rien réglé. Elles DOIVENT coïncider
// avec le baseline du formulaire de création (App._getCreateDefaults) : ce
// panneau et ce formulaire décrivent la même chose, et deux jeux de défauts
// différents pour une même notion ne peuvent produire qu'une contradiction.
//
// C'est ce qui avait été signalé sur le forum : le panneau annonçait 5 s en
// Internet (et une hausse toutes les 7 mains) là où le formulaire s'ouvrait à
// 20 s / 8 mains. Le joueur lisait ses « préférences », voyait autre chose à la
// création, et concluait — à raison — qu'elles étaient ignorées, alors qu'il
// n'avait en réalité jamais rien enregistré.
//
// Une préférence ne pèse donc que lorsqu'elle a été VOULUE : tant qu'aucun
// champ n'est touché, panneau et formulaire disent la même chose, celle du
// client officiel (configfile.cpp : 3000 en réseau, 5000 en local, SB 10,
// hausse toutes les 8 mains, 20 s, délai 7 s, vitesse 4).
// Les valeurs stockées, elles, ne bougent pas — un joueur qui avait déjà réglé
// ses préférences les retrouve intactes.
function _advPrefsBaseline(mode) {
  var b = { players: 10, stack: 3000, blind: 10, raiseEvery: 8, timeout: 20, delayHands: 7 };
  if (mode === 'local') { b.stack = 5000; b.guiSpeed = 4; }
  if (mode === 'net') { b.name = ''; b.gameType = '1'; b.allowSpectators = true; }
  return b;
}
function _advPrefsRead(mode) {
  var d = null;
  try { d = JSON.parse(localStorage.getItem(_ADV_PREFS_KEYS[mode]) || 'null'); } catch (e) {}
  // Héritage pré-passe G : l'ancien instantané unique sert de repli en lecture.
  if (!d) { try { d = JSON.parse(localStorage.getItem('pth_create_prefs') || 'null'); } catch (e) {} }
  var b = _advPrefsBaseline(mode);
  if (d && typeof d === 'object') { for (var k in b) { if (d[k] != null) b[k] = d[k]; } }
  return b;
}
function advPrefSet(mode, field, el) {
  var key = _ADV_PREFS_KEYS[mode];
  if (!key || !el) return;
  var v;
  if (el.type === 'checkbox') v = !!el.checked;
  else if (el.type === 'number') {
    try { if (window.App && App.clampNum) App.clampNum(el); } catch (e) {}
    v = parseInt(el.value, 10);
    if (isNaN(v)) return;
  } else v = el.value;
  var d = null;
  try { d = JSON.parse(localStorage.getItem(key) || 'null'); } catch (e) {}
  // Premier réglage du mode : on fige l'état affiché (repli inclus) pour que
  // l'objet stocké soit cohérent avec ce que l'utilisateur voit.
  if (!d || typeof d !== 'object') d = _advPrefsRead(mode);
  d[field] = v;
  try { localStorage.setItem(key, JSON.stringify(d)); } catch (e) {}
  try { _cfgSyncMark(field); } catch (e) {}   // sync compte (no-op si désactivée)
}
window.advPrefSet = advPrefSet;
function _advSyncPrefs() {
  var fields = {
    local: ['players', 'stack', 'blind', 'raiseEvery', 'timeout', 'delayHands', 'guiSpeed'],
    lan:   ['players', 'stack', 'blind', 'raiseEvery', 'timeout', 'delayHands'],
    net:   ['name', 'gameType', 'allowSpectators', 'players', 'stack', 'blind', 'raiseEvery', 'timeout', 'delayHands']
  };
  var ids = { players: 'players', stack: 'stack', blind: 'blind', raiseEvery: 'raise', timeout: 'timeout', delayHands: 'delay', guiSpeed: 'speed', name: 'name', gameType: 'gtype', allowSpectators: 'spect' };
  for (var m in fields) {
    var d = _advPrefsRead(m);
    for (var i = 0; i < fields[m].length; i++) {
      var f = fields[m][i];
      var el = document.getElementById('advp-' + m + '-' + ids[f]);
      if (!el) continue;
      if (el.type === 'checkbox') el.checked = !!d[f];
      else el.value = (d[f] != null) ? d[f] : '';
    }
  }
}

function _advSyncContext() {
  var modal = document.getElementById('adv-modal');
  if (!modal) return;
  var inGame = false;
  try { inGame = document.body.classList.contains('in-game'); } catch (e) {}
  var setEnabled = function (cat, enabled) {
    var b = modal.querySelector('.adv-cat[data-cat="' + cat + '"]');
    if (b) {
      if (enabled) { b.removeAttribute('disabled'); b.removeAttribute('aria-disabled'); }
      else { b.setAttribute('disabled', ''); b.setAttribute('aria-disabled', 'true'); }
    }
    var p = modal.querySelector('.adv-panel[data-cat="' + cat + '"]');
    if (p) p.classList.toggle('adv-panel-off', !enabled);
  };
  var onConnect = false;            // page de login (pré-connexion : pas encore de profil ni serveur)
  try { var _sc = document.getElementById('s-connect'); onConnect = !!(_sc && _sc.classList.contains('active')); } catch (e) {}
  var connected = !onConnect;       // lobby ou partie = contexte de jeu connecté
  setEnabled('local', true);        // réglages persistants (pause entre les mains)
  // Journal et Partie Internet contiennent désormais des RÉGLAGES persistants
  // (journal on/off + intervalle ; liste des joueurs ignorés) → catégories
  // toujours accessibles. Seuls leurs liens contextuels (« Ouvrir le journal »,
  // serveur/déconnexion) sont masqués hors contexte.
  setEnabled('log', true);
  setEnabled('network', true);      // Jeu en réseau (LAN) : préférences de table éditables (l'hébergement reste « bientôt »)
  setEnabled('internet', true);
  setEnabled('avatar', connected);  // profil / avatar indisponible avant connexion
  try {
    var _lcLink = modal.querySelector('.adv-panel[data-cat="local"] .adv-link');
    if (_lcLink) _lcLink.style.display = inGame ? '' : 'none';
    var _lgLink = modal.querySelector('.adv-panel[data-cat="log"] .adv-link');
    if (_lgLink) _lgLink.style.display = inGame ? '' : 'none';
    var _inLink = modal.querySelector('.adv-panel[data-cat="internet"] .adv-link');
    if (_inLink) _inLink.style.display = connected ? '' : 'none';
  } catch (e) {}
  try {
    var host = (window._pthNetServer && window._pthNetServer.host) ? window._pthNetServer.host : null;
    var el = modal.querySelector('#adv-srv-host');
    if (el) el.textContent = _advSrvDisplay(host);
  } catch (e) {}
}

// Adresse du serveur affichee dans Options avancees > Jeu internet.
// Le client web ne parle jamais au serveur PokerTH en direct : il passe par le
// pont proxy, et l'hote configure cote proxy est souvent une adresse d'infra
// (10.x, 192.168.x, localhost, *.local...). Cette adresse n'apprend rien au
// joueur et n'a pas a etre exposee : on affiche alors « Pont proxy ». Un nom
// public reel (pokerth.net, un domaine de club) reste affiche tel quel.
function _advSrvIsPrivate(h) {
  if (!h) return false;
  var s = String(h).trim().toLowerCase().replace(/^\[|\]$/g, '');
  if (s === 'localhost' || s === '::1' || /\.(local|lan|home|internal|localdomain)$/.test(s)) return true;
  var m = s.match(/^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/);
  if (m) {
    var a = +m[1], b = +m[2];
    if (a === 10 || a === 127 || a === 0) return true;                 // prive / loopback / non specifie
    if (a === 192 && b === 168) return true;                            // prive
    if (a === 172 && b >= 16 && b <= 31) return true;                   // prive
    if (a === 169 && b === 254) return true;                            // lien-local
    if (a === 100 && b >= 64 && b <= 127) return true;                  // CGNAT (RFC 6598)
    return false;
  }
  if (/^f[cd][0-9a-f]{2}:/.test(s) || /^fe80:/.test(s)) return true;    // IPv6 ULA / lien-local
  return false;
}
function _advSrvDisplay(host) {
  var key = null;
  if (!host) key = 'advSrvUnknown';
  else if (_advSrvIsPrivate(host)) key = 'advSrvBridge';
  if (!key) return host;
  var fb = (key === 'advSrvBridge') ? 'Proxy bridge' : '\u2014';
  try {
    if (typeof window.t === 'function') { var v = window.t(key); if (v && v !== key) return v; }
  } catch (e) {}
  return fb;
}
window._advSrvDisplay = _advSrvDisplay;   // pont pour les tests deterministes

// « Paramètres par défaut » : réinitialise options + raccourcis (avec confirmation).
function resetAdvDefaults() {
  var msg = (typeof window.t === 'function' && window.t('advResetConfirm') !== 'advResetConfirm')
    ? window.t('advResetConfirm')
    : 'Restore everything to factory defaults (options, styles, shortcuts, stats)? Nickname, avatar and account are kept. The app will reload.';
  if (!window.confirm(msg)) return;
  // ── Réinitialisation USINE (demande narmod 2026-07-18) ──
  // On efface TOUTES les préférences locales (préfixe pth_) : options,
  // styles/thèmes/tapis/decks/sièges, raccourcis, positions et tailles de
  // fenêtres, filtres, stats, journal, ignorés, config.xml importée… — comme
  // pour un NOUVEL utilisateur. Sont préservés UNIQUEMENT l'identité et la
  // connexion : pseudo(s), avatar, compte, serveur, session/reprise en cours.
  // Puis rechargement complet : tout se réinitialise proprement au boot
  // (styles injectés au chargement, modules, mémoires en RAM).
  var KEEP = {
    pth_auth_login: 1, pth_pass: 1, pth_sid: 1, pth_vid: 1, pth_resume: 1,
    pth_host: 1, pth_port: 1, pth_proxy: 1, pth_server_mode: 1, pth_login_mode: 1,
    pth_nick: 1, pth_lan_nick: 1, pth_lan_host: 1, pth_lan_port: 1, pth_lan_tls: 1, pth_unauth_nick: 1, pth_offline_nick: 1,
    pth_avatar: 1, pth_avatar_img: 1, pth_avatar_up: 1
  };
  try {
    var doomed = [];
    for (var i = 0; i < localStorage.length; i++) {
      var k = localStorage.key(i);
      if (k && k.indexOf('pth_') === 0 && !KEEP[k]) doomed.push(k);
    }
    for (var j = 0; j < doomed.length; j++) { try { localStorage.removeItem(doomed[j]); } catch (e2) {} }
  } catch (e) {}
  try { location.reload(); } catch (e) {}
}
window.resetAdvDefaults = resetAdvDefaults;

// ── Import / Export « config.xml » PokerTH (interop clients Qt-Widgets & QML) ──
// Format (configfile.cpp, writeBuffer) :
//   <?xml version="1.0" encoding='utf-8'?>
//   <PokerTH><Configuration><Clé value="…"/><Liste type="list"><Sous value="…"/>…
// Politique : on n'écrit que les clés MAPPÉES + celles préservées d'un import
// précédent (round-trip, clé localStorage pth_qml_config_xml). Un fichier
// partiel est valide côté officiel : ConfigFile comble les absentes avec ses
// défauts et son writeBuffer() fusionne sans perdre les clés inconnues.
// Exclues (spécifiques machine) : AppDataDir, LogDir, UserDataDir, CacheDir,
// MyAvatar. Non mappée volontairement : Language (index Qt interne ≠ codes
// ISO du web) — préservée telle quelle par le round-trip.
var PTH_CFG_XML_KEY = 'pth_qml_config_xml';
var PTH_CFG_MACHINE_KEYS = { AppDataDir: 1, LogDir: 1, UserDataDir: 1, CacheDir: 1, MyAvatar: 1 };

function _cfgXmlEsc(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function _cfgReadPrefs(storageKey) {
  var d = null;
  try { d = JSON.parse(localStorage.getItem(storageKey) || 'null'); } catch (e) {}
  if (!d) { try { d = JSON.parse(localStorage.getItem('pth_last_create') || 'null'); } catch (e) {} }
  return (d && typeof d === 'object') ? d : {};
}
function _cfgLs(key) { try { return localStorage.getItem(key); } catch (e) { return null; } }
// Traduit un objet de préférences de table web (players/stack/blind/raiseMode/
// raiseEvery/manualOrder/manualBlinds/endRaiseMode/endRaiseValue) vers les clés
// officielles, avec le préfixe '' (locale) ou 'Net' (réseau/Internet).
function _cfgBlindsKeys(p, net, out, lists) {
  var P = net ? 'Net' : '';
  if (p.players != null) out[P + 'NumberOfPlayers'] = parseInt(p.players, 10) || 10;
  if (p.stack   != null) out[P + 'StartCash']       = parseInt(p.stack, 10) || 3000;
  if (p.blind   != null) out[P + 'FirstSmallBlind'] = parseInt(p.blind, 10) || 10;
  if (p.raiseMode != null) {
    var byMin = String(p.raiseMode) === '2';
    out[P + 'RaiseBlindsAtHands']   = byMin ? 0 : 1;
    out[P + 'RaiseBlindsAtMinutes'] = byMin ? 1 : 0;
    if (p.raiseEvery != null) out[P + (byMin ? 'RaiseSmallBlindEveryMinutes' : 'RaiseSmallBlindEveryHands')] = parseInt(p.raiseEvery, 10) || 8;
  }
  if (p.manualOrder != null) {
    out[P + 'AlwaysDoubleBlinds'] = p.manualOrder ? 0 : 1;
    out[P + 'ManualBlindsOrder']  = p.manualOrder ? 1 : 0;
  }
  if (p.manualBlinds != null && String(p.manualBlinds) !== '') {
    var vals = String(p.manualBlinds).split(',').map(function (s) { return parseInt(s, 10); })
      .filter(function (n) { return Number.isInteger(n) && n > 0; });
    if (vals.length) lists[P + 'ManualBlindsList'] = { sub: P ? 'NetBlind' : 'Blind', values: vals };
  }
  if (p.endRaiseMode != null) {
    var m = parseInt(p.endRaiseMode, 10) || 1;
    out[P + 'AfterMBAlwaysDoubleBlinds'] = m === 1 ? 1 : 0;
    out[P + 'AfterMBAlwaysRaiseAbout']   = m === 2 ? 1 : 0;
    out[P + 'AfterMBStayAtLastBlind']    = m === 3 ? 1 : 0;
    if (m === 2 && p.endRaiseValue != null) out[P + 'AfterMBAlwaysRaiseValue'] = parseInt(p.endRaiseValue, 10) || 0;
  }
}
// Construit { scalars: {clé: valeur}, lists: {clé: {sub, values[]}} } depuis
// l'état web courant — la table de vérité du mapping web → officiel.
// ── Notes de joueur ↔ clients officiels (liste config « PlayerTooltips ») ────
// Format d'une ligne, partagé par le client Qt-Widgets (myavatarlabel.cpp) et
// le client QML depuis upstream b77ad47 :
//     Nom(!#$%)Note(!#$%)Étoiles(!#$%)
// Trois champs, séparateur compris à la fin. Pas de couleur (le web en a une
// en plus, cf. modules/notes) et pas de date : côté officiel le fichier est
// local, il n'y a rien à réconcilier. C'est pourquoi cette liste sert
// d'ÉCHANGE (export/import de config.xml) et non de stockage : la fusion
// multi-appareils du web a besoin du t par entrée, que ce format ne porte pas.
var PTH_TIP_SEP = '(!#$%)';
// Lignes à écrire dans le config.xml exporté, une par joueur annoté.
function _cfgTipLines() {
  var out = [];
  try {
    var st = window._nvStore;
    if (!st || typeof st.names !== 'function') return out;   // module notes absent
    st.names().forEach(function (nm) {
      var e = st.get(nm);
      if (!e) return;
      // Un pseudo qui contient le séparateur casserait la ligne à la relecture,
      // ici comme chez l'officiel : on le laisse de côté plutôt que d'exporter
      // une entrée qui reviendrait en morceaux.
      if (String(nm).indexOf(PTH_TIP_SEP) >= 0) return;
      // Le séparateur est retiré du texte (même geste que setPlayerNote côté
      // QML) et les retours à la ligne deviennent des espaces : la valeur
      // voyage dans un attribut XML, où un saut de ligne est normalisé en
      // espace à la lecture — autant que les deux clients lisent la même chose.
      var note = String(e.note || '').split(PTH_TIP_SEP).join(' ').replace(/[\r\n\t]+/g, ' ');
      var stars = e.stars || 0;
      // Une entrée qui n'a QUE la couleur web n'a rien à dire à l'officiel :
      // la ligne serait vide et il la supprimerait de toute façon.
      if (!note && !stars) return;
      out.push(nm + PTH_TIP_SEP + note + PTH_TIP_SEP + stars + PTH_TIP_SEP);
    });
  } catch (e) {}
  return out;
}
// Lecture : fusionne les lignes d'un config.xml IMPORTÉ dans les notes web.
// Importer un fichier est un geste explicite, donc la note et les étoiles du
// fichier gagnent ; la COULEUR locale n'est pas touchée (le format ne la porte
// pas, l'écraser reviendrait à l'effacer). Retourne le nombre d'entrées lues.
function _cfgApplyTipLines(list) {
  var st = window._nvStore;
  if (!list || !list.values || !list.values.length || !st || typeof st.set !== 'function') return 0;
  var n = 0;
  list.values.forEach(function (line) {
    var f = String(line == null ? '' : line).split(PTH_TIP_SEP);
    if (f.length < 3) return;                  // ligne d'un autre format : ignorée
    var nm = String(f[0]).trim();
    if (!nm) return;
    var stars = parseInt(f[2], 10);
    if (!isFinite(stars)) stars = 0;
    // set() borne les étoiles et la longueur, et supprime l'entrée si tout est
    // vide — y compris quand la couleur locale l'était déjà.
    try { st.set(nm, { note: f[1], stars: stars }); n++; } catch (e) {}
  });
  return n;
}
function _cfgCollectWebSettings(withNotes) {
  var out = {}, lists = {};
  // The player's own choice, not _advGet: an option the admin has switched off
  // must not be written to the account as "off" and outlive the switch.
  var B = function (advKey, def) { var v = _cfgLs('pth_' + advKey); return (v === null ? !!def : v === '1') ? 1 : 0; };
  // Identité & connexion
  var nick = _cfgLs('pth_nick') || _cfgLs('pth_offline_nick') || _cfgLs('pth_lan_nick');
  if (nick) out.MyName = nick;
  var host = _cfgLs('pth_host'); if (host) out.InternetServerAddress = host;
  var port = parseInt(_cfgLs('pth_port') || '', 10); if (port) out.InternetServerPort = port;
  // Interface (défauts = ceux du web, mêmes que resetAdvDefaults)
  out.ShowFadeOutCardsAnimation = B('fade_losers', true);
  out.ShowFlipCardsAnimation    = B('anim_cards', true);
  out.AlternateFKeysUserActionMode = B('fkeys_alt', false);
  out.ShowBlindButtons          = B('show_blinds', true);
  out.ShowPotPercentButtons     = B('pot_btns', true);
  out.AntiPeekMode              = B('own_click', false);
  out.AccidentallyCallBlocker   = B('guard_call', false);
  out.EnableBetInputFocusSwitch = B('focus_bet', false);
  out.ShowCountryFlagInAvatar   = B('show_flag', true);
  out.ShowPingStateInAvatar     = B('ping_avatar', true);
  out.DontHideAvatarsOfIgnored  = B('no_hide_ignored', false);
  out.UseLobbyChat              = B('lobby_chat', true);
  out.DisableEmojiReactions     = B('react_muted', false);
  out.QmlReduceEffects          = B('reduce_fx', false);
  out.NetAutoLeaveGameAfterFinish = B('auto_leave', false);
  out.PauseBetweenHands         = B('pause_hands', false);
  out.DontTranslateInternationalPokerStringsFromStyle = B('poker_en', true);  // case « ne pas traduire » (parité)
  out.DisableSplashScreenOnStartup = B('splash', true) ? 0 : 1;  // clé officielle inversée (1 = pas de splash)
  // Sons (catégories officielles)
  out.PlayGameActions             = B('snd_actions', true);
  out.PlayLobbyChatNotification   = B('snd_lobby', true);
  out.PlayNetworkGameNotification = B('snd_net', true);
  out.PlayBlindRaiseNotification  = B('snd_blinds', true);
  out.PlaySoundEffects = (out.PlayGameActions || out.PlayLobbyChatNotification || out.PlayNetworkGameNotification || out.PlayBlindRaiseNotification) ? 1 : 0;
  // Styles (noms transportés tels quels — pas forcément identiques entre clients)
  var tbl = _cfgLs('pth_table');    if (tbl) out.QmlGameTableStyle = tbl;
  var dck = _cfgLs('pth_deck');     if (dck) out.QmlCardDeckStyle  = dck;
  var cbk = _cfgLs('pth_cardback'); if (cbk) out.QmlCardBackStyle  = cbk;
  // Préférences de table : locale + réseau/Internet
  var pl = _cfgReadPrefs('pth_prefs_local');
  _cfgBlindsKeys(pl, false, out, lists);
  if (pl.guiSpeed != null) out.GameSpeed = parseInt(pl.guiSpeed, 10) || 4;
  var pn = _cfgReadPrefs('pth_prefs_internet');
  _cfgBlindsKeys(pn, true, out, lists);
  if (pn.guiSpeed   != null) out.NetGameSpeed          = parseInt(pn.guiSpeed, 10) || 4;
  if (pn.timeout    != null) out.NetTimeOutPlayerAction = parseInt(pn.timeout, 10) || 20;
  if (pn.delayHands != null) out.NetDelayBetweenHands   = parseInt(pn.delayHands, 10) || 7;
  if (pn.name)               out.InternetGameName       = String(pn.name).slice(0, 60);
  if (pn.gameType   != null) out.InternetGameType       = parseInt(pn.gameType, 10) || 1;
  if (pn.allowSpectators != null) out.InternetGameAllowSpectators = pn.allowSpectators ? 1 : 0;
  if (pn.usePassword != null) out.UseInternetGamePassword = pn.usePassword ? 1 : 0;
  if (pn.usePassword && pn.password) out.InternetGamePassword = String(pn.password);
  // Notes de joueur : SEULEMENT dans le fichier qu'on télécharge. Le config.xml
  // poussé au compte n'en veut pas — les notes y voyagent déjà sous pth_notes,
  // avec leurs dates et leurs couleurs, et 300 notes de 500 caractères
  // gonfleraient la charge de synchro pour rien.
  if (withNotes) {
    var tips = _cfgTipLines();
    if (tips.length) lists.PlayerTooltips = { sub: 'PlayerTooltips', values: tips };
  }
  return { scalars: out, lists: lists };
}
// Parse un config.xml (DOMParser) → { scalars, lists, order[] } ; jette si invalide.
function _cfgParseXml(text) {
  var doc = new DOMParser().parseFromString(text, 'text/xml');
  if (doc.getElementsByTagName('parsererror').length) throw new Error('invalid XML');
  var root = doc.documentElement;
  if (!root || root.tagName !== 'PokerTH') throw new Error('not a PokerTH config');
  var conf = root.getElementsByTagName('Configuration')[0];
  if (!conf) throw new Error('missing <Configuration>');
  var scalars = {}, lists = {}, order = [];
  for (var el = conf.firstElementChild; el; el = el.nextElementSibling) {
    var name = el.tagName;
    order.push(name);
    if (el.getAttribute('type') === 'list') {
      var values = [], sub = null;
      for (var c = el.firstElementChild; c; c = c.nextElementSibling) {
        if (sub === null) sub = c.tagName;
        values.push(c.getAttribute('value') || '');
      }
      lists[name] = { sub: sub || el.getAttribute('value') || 'Entry', values: values };
    } else {
      scalars[name] = el.getAttribute('value') || '';
    }
  }
  return { scalars: scalars, lists: lists, order: order };
}
// Export : round-trip (XML importé précédemment) fusionné avec l'état web
// courant (le web gagne sur les clés mappées), sérialisé au format officiel.
function _cfgBuildXml(withNotes) {
  var web = _cfgCollectWebSettings(withNotes);
  var base = { scalars: {}, lists: {}, order: [] };
  var stored = _cfgLs(PTH_CFG_XML_KEY);
  if (stored) { try { base = _cfgParseXml(stored); } catch (e) { base = { scalars: {}, lists: {}, order: [] }; } }
  Object.keys(web.scalars).forEach(function (k) { base.scalars[k] = web.scalars[k]; });
  Object.keys(web.lists).forEach(function (k) { base.lists[k] = web.lists[k]; });
  if (base.scalars.ConfigRevision == null) base.scalars.ConfigRevision = 108;  // configfile.cpp actuel
  // Ordre : celui du fichier importé d'abord (diff lisible côté Qt), puis les nouvelles clés.
  var seen = {}, names = [];
  base.order.forEach(function (k) { if (!seen[k] && (k in base.scalars || k in base.lists)) { seen[k] = 1; names.push(k); } });
  Object.keys(base.scalars).concat(Object.keys(base.lists)).forEach(function (k) { if (!seen[k]) { seen[k] = 1; names.push(k); } });
  var xml = "<?xml version=\"1.0\" encoding='utf-8'?>\n<PokerTH>\n <Configuration>\n";
  names.forEach(function (k) {
    if (k in base.lists) {
      var L = base.lists[k];
      xml += '  <' + k + ' type="list" value="' + _cfgXmlEsc(L.sub) + '">\n';
      L.values.forEach(function (v) { xml += '   <' + L.sub + ' value="' + _cfgXmlEsc(v) + '"/>\n'; });
      xml += '  </' + k + '>\n';
    } else {
      xml += '  <' + k + ' value="' + _cfgXmlEsc(base.scalars[k]) + '"/>\n';
    }
  });
  xml += ' </Configuration>\n</PokerTH>\n';
  return xml;
}
function exportPokerthConfig() {
  var xml;
  // true : le fichier téléchargé emporte les notes de joueur, pour qu'un
  // client officiel les retrouve (liste PlayerTooltips).
  try { xml = _cfgBuildXml(true); } catch (e) {
    if (typeof showToast === 'function') showToast('Export failed: ' + e.message, { tone: 'error' });
    return;
  }
  try {
    var blob = new Blob([xml], { type: 'application/xml' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'config.xml';                     // nom attendu dans ~/.pokerth/
    document.body.appendChild(a); a.click();
    setTimeout(function () { try { URL.revokeObjectURL(a.href); a.remove(); } catch (e) {} }, 2000);
  } catch (e) {
    if (typeof showToast === 'function') showToast('Export failed: ' + e.message, { tone: 'error' });
    return;
  }
  if (typeof showToast === 'function') showToast(t('cfgXmlExported') || 'config.xml exported');
}
window.exportPokerthConfig = exportPokerthConfig;
// ── Sauvegarde COMPLÈTE du client web ────────────────────────────────────────
// Contrairement à config.xml (qui ne porte que les réglages partagés avec les
// clients officiels), ce fichier emporte TOUT l'état local : options web, thèmes,
// decks, sièges custom, image d'avatar, succès, stats… Aucune limite de 20 000
// caractères ici, donc l'avatar et les dos de cartes personnalisés sont inclus
// (eux ne peuvent pas passer par la synchro compte).
// JAMAIS exportés : identifiants et session (mot de passe, jetons) + comptabilité
// interne de la synchro, qui ne doit pas voyager d'un appareil à l'autre.
var _BACKUP_SKIP = {
  pth_auth_login: 1, pth_pass: 1, pth_sid: 1, pth_vid: 1, pth_resume: 1,
  pth_cfg_sync_dirty: 1, pth_cfg_sync_ts: 1, pth_cfg_sync_weblast: 1, pth_cfg_sync_webts: 1,
  pth_feature_off: 1   // the server's kill-switch list, not a player setting
};
// Construit l'enregistrement de sauvegarde sans le télécharger : partagé entre
// l'export manuel ci-dessous et l'écriture automatique (backup-autosave.mjs).
function _webBackupRecord() {
  var keys = {}, n = 0;
  try {
    for (var i = 0; i < localStorage.length; i++) {
      var k = localStorage.key(i);
      if (!k || k.indexOf('pth_') !== 0 || _BACKUP_SKIP[k]) continue;
      var v = localStorage.getItem(k);
      if (v != null) { keys[k] = v; n++; }
    }
  } catch (e) {}
  var rec = {
    format: 'pokerth-web-client', kind: 'full-backup', version: 1,
    app: window.BUILD_VERSION || '', exportedAt: new Date().toISOString(), keys: keys
  };
  // config.xml officiel conservé tel quel : la sauvegarde reste un sur-ensemble.
  try { var x = localStorage.getItem(PTH_CFG_XML_KEY); if (x) rec.xml = x; } catch (e) {}
  return { rec: rec, n: n };
}
window._webBackupRecord = _webBackupRecord;
function exportWebBackup() {
  var b = _webBackupRecord(), rec = b.rec, n = b.n;
  try {
    var blob = new Blob([JSON.stringify(rec)], { type: 'application/json' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'pokerth-web-backup.json';
    document.body.appendChild(a); a.click();
    setTimeout(function () { try { URL.revokeObjectURL(a.href); a.remove(); } catch (e) {} }, 2000);
  } catch (e) {
    if (typeof showToast === 'function') showToast('Export failed: ' + e.message, { tone: 'error' });
    return;
  }
  if (typeof showToast === 'function') showToast((t('backupExported') || 'Backup exported') + ' (' + n + ')');
}
window.exportWebBackup = exportWebBackup;
// Applique un enregistrement de sauvegarde déjà parsé à l'état local. Retourne
// le nombre de clés écrites, ou -1 si l'enregistrement est invalide. Partagé
// entre l'import manuel ci-dessous et la restauration automatique
// (backup-autosave.mjs).
function _applyWebBackupRec(rec) {
  if (!rec || rec.format !== 'pokerth-web-client' || !rec.keys || typeof rec.keys !== 'object') return -1;
  var n = 0;
  // Succès : FUSION cumulative — importer une vieille sauvegarde ne doit
  // jamais faire reculer la progression déjà acquise sur cet appareil.
  try { _achMergeIn(rec.keys); } catch (e) {}
  try {
    Object.keys(rec.keys).forEach(function (k) {
      if (!/^pth_[A-Za-z0-9_]{1,60}$/.test(k) || _BACKUP_SKIP[k]) return;
      if (_ACH_SYNC_KEYS.indexOf(k) >= 0) return;            // déjà fusionné
      var v = rec.keys[k];
      if (typeof v !== 'string') return;
      try { localStorage.setItem(k, v); n++; } catch (e) {}
    });
  } catch (e) { return -1; }
  // config.xml embarqué : même chemin que l'import config.xml classique.
  try {
    if (typeof rec.xml === 'string' && rec.xml.indexOf('<PokerTH') >= 0) {
      localStorage.setItem(PTH_CFG_XML_KEY, rec.xml.slice(0, 400000));
      _cfgApplyImported(_cfgParseXml(rec.xml));
    }
  } catch (e) {}
  try { localStorage.setItem('pth_cfg_sync_dirty', '1'); _cfgSyncPushSoon(1500); } catch (e) {}
  return n;
}
window._applyWebBackupRec = _applyWebBackupRec;
// Traitement d'UN fichier de sauvegarde, quelle que soit sa provenance : le
// selecteur ci-dessous, un « ouvrir avec » du gestionnaire de fichiers
// (file_handlers) ou un partage entrant (share_target).
function _importWebBackupFile(f) {
  if (!f) return;
  var fail = function () {
    if (typeof showToast === 'function') showToast(t('backupImportErr') || 'Import failed', { tone: 'error' });
  };
  if (f.size > 8 * 1024 * 1024) return fail();
  var r = new FileReader();
  r.onload = function () {
    var rec = null;
    try { rec = JSON.parse(String(r.result || '')); } catch (e) {}
    var n = _applyWebBackupRec(rec);
    if (n < 0) return fail();
    var msg = (t('backupImported') || 'Backup imported') + ' (' + n + ')';
    if (typeof showToast === 'function') showToast(msg);
    setTimeout(function () {
      var q = t('cfgXmlReload') || 'Reload now to apply everything?';
      if (window.confirm(msg + '\n\n' + q)) { try { location.reload(); } catch (e) {} }
    }, 300);
  };
  r.onerror = fail;
  r.readAsText(f);
}
window._importWebBackupFile = _importWebBackupFile;
function importWebBackupPick() {
  var inp = document.getElementById('adv-backup-file');
  if (!inp) return;
  inp.value = '';
  inp.onchange = function () { _importWebBackupFile(inp.files && inp.files[0]); };
  inp.click();
}
window.importWebBackupPick = importWebBackupPick;
// ── Stockage persistant ──────────────────────────────────────────────────────
// Demande au navigateur de marquer l'origine comme persistante : l'éviction
// automatique (nettoyage d'espace disque, purge d'inactivité) ne peut alors
// plus vider localStorage/IndexedDB sans action explicite du joueur. Sans
// effet là où l'API n'existe pas ; un refus est silencieux et sans conséquence.
// Firefox excepté (web.31) : il AFFICHE une demande d'autorisation, qui
// surgissait ici au chargement sans explication et était souvent refusée pour
// de bon. Là, l'As explique d'abord et la demande part au clic du joueur
// (modules/backup-autosave.mjs, « Protéger mes réglages »).
try {
  if (navigator.storage && typeof navigator.storage.persist === 'function'
      && !/Firefox\//.test(navigator.userAgent || '')) {
    navigator.storage.persist().catch(function () {});
  }
} catch (e) {}
// Import : applique les clés mappées à l'état web, conserve le XML complet
// pour le round-trip, puis propose de recharger (comme le redémarrage demandé
// par l'officiel après un reset).
function _cfgApplyImported(cfg) {
  var S = cfg.scalars, L = cfg.lists;
  var num = function (k) { var v = parseInt(S[k], 10); return isNaN(v) ? null : v; };
  var setB = function (advKey, cfgKey) { if (S[cfgKey] != null) setAdvOpt(advKey, num(cfgKey) !== 0); };
  if (S.MyName) {
    try { localStorage.setItem('pth_nick', S.MyName); } catch (e) {}
  }
  if (S.InternetServerAddress) { try { localStorage.setItem('pth_host', S.InternetServerAddress); } catch (e) {} }
  if (num('InternetServerPort')) { try { localStorage.setItem('pth_port', String(num('InternetServerPort'))); } catch (e) {} }
  setB('fade_losers', 'ShowFadeOutCardsAnimation');
  setB('anim_cards', 'ShowFlipCardsAnimation');
  setB('fkeys_alt', 'AlternateFKeysUserActionMode');
  setB('show_blinds', 'ShowBlindButtons');
  setB('own_click', 'AntiPeekMode');
  setB('guard_call', 'AccidentallyCallBlocker');
  setB('focus_bet', 'EnableBetInputFocusSwitch');
  setB('show_flag', 'ShowCountryFlagInAvatar');
  setB('pot_btns', 'ShowPotPercentButtons');
  setB('ping_avatar', 'ShowPingStateInAvatar');
  setB('no_hide_ignored', 'DontHideAvatarsOfIgnored');
  setB('lobby_chat', 'UseLobbyChat');
  setB('react_muted', 'DisableEmojiReactions');
  setB('reduce_fx', 'QmlReduceEffects');
  setB('auto_leave', 'NetAutoLeaveGameAfterFinish');
  setB('pause_hands', 'PauseBetweenHands');
  setB('poker_en', 'DontTranslateInternationalPokerStringsFromStyle');
  if (S.DisableSplashScreenOnStartup != null) setAdvOpt('splash', num('DisableSplashScreenOnStartup') === 0);  // inversée
  setB('snd_actions', 'PlayGameActions');
  setB('snd_lobby', 'PlayLobbyChatNotification');
  setB('snd_net', 'PlayNetworkGameNotification');
  setB('snd_blinds', 'PlayBlindRaiseNotification');
  // Styles : appliqués seulement si le nom existe côté web (sinon ignorés
  // silencieusement — les catalogues diffèrent entre clients).
  ['QmlGameTableStyle:pth_table', 'QmlCardDeckStyle:pth_deck', 'QmlCardBackStyle:pth_cardback'].forEach(function (pair) {
    var ck = pair.split(':')[0], lk = pair.split(':')[1];
    if (S[ck]) { try { localStorage.setItem(lk, S[ck]); } catch (e) {} }
  });
  // Préférences de table : fusion champ à champ dans les prefs web.
  var mergePrefs = function (storageKey, net) {
    var P = net ? 'Net' : '';
    var d = {};
    try { d = JSON.parse(localStorage.getItem(storageKey) || 'null') || {}; } catch (e) { d = {}; }
    var n = function (k) { var v = parseInt(S[P + k], 10); return isNaN(v) ? null : v; };
    if (n('NumberOfPlayers') != null) d.players = n('NumberOfPlayers');
    if (n('StartCash')       != null) d.stack   = n('StartCash');
    if (n('FirstSmallBlind') != null) d.blind   = n('FirstSmallBlind');
    if (S[P + 'RaiseBlindsAtMinutes'] != null || S[P + 'RaiseBlindsAtHands'] != null) {
      var byMin = n('RaiseBlindsAtMinutes') === 1;
      d.raiseMode = byMin ? '2' : '1';
      var ev = byMin ? n('RaiseSmallBlindEveryMinutes') : n('RaiseSmallBlindEveryHands');
      if (ev != null) d.raiseEvery = ev;
    }
    if (S[P + 'ManualBlindsOrder'] != null) d.manualOrder = n('ManualBlindsOrder') === 1;
    var ml = L[P + 'ManualBlindsList'];
    if (ml) d.manualBlinds = ml.values.map(function (v) { return parseInt(v, 10); })
      .filter(function (x) { return Number.isInteger(x) && x > 0; }).sort(function (a, b) { return a - b; }).join(',');
    if (S[P + 'AfterMBAlwaysRaiseAbout'] === '1')      d.endRaiseMode = '2';
    else if (S[P + 'AfterMBStayAtLastBlind'] === '1')  d.endRaiseMode = '3';
    else if (S[P + 'AfterMBAlwaysDoubleBlinds'] != null) d.endRaiseMode = '1';
    if (n('AfterMBAlwaysRaiseValue') != null) d.endRaiseValue = n('AfterMBAlwaysRaiseValue');
    if (net) {
      // n() already prepends P ('Net' here): passing the full official name
      // read doubly-prefixed keys (NetNetGameSpeed & co) that never exist — an
      // imported or synced config.xml silently skipped the internet speed,
      // timeout and between-hands delay while everything around them merged.
      if (n('GameSpeed')           != null) d.guiSpeed   = n('GameSpeed');
      if (n('TimeOutPlayerAction') != null) d.timeout    = n('TimeOutPlayerAction');
      if (n('DelayBetweenHands')   != null) d.delayHands = n('DelayBetweenHands');
      if (S.InternetGameName)                  d.name       = String(S.InternetGameName).slice(0, 60);
      if (S.InternetGameType != null)          d.gameType   = String(parseInt(S.InternetGameType, 10) || 1);
      if (S.InternetGameAllowSpectators != null) d.allowSpectators = S.InternetGameAllowSpectators !== '0';
      if (S.UseInternetGamePassword != null)   d.usePassword = S.UseInternetGamePassword === '1';
      if (S.InternetGamePassword)              d.password    = String(S.InternetGamePassword);
    } else {
      if (n('GameSpeed') != null) d.guiSpeed = n('GameSpeed');
    }
    try { localStorage.setItem(storageKey, JSON.stringify(d)); } catch (e) {}
  };
  mergePrefs('pth_prefs_local', false);
  mergePrefs('pth_prefs_internet', true);
}
function _importPokerthConfigFile(f) {
  if (!f) return;
  if (f.size > 512 * 1024) { if (typeof showToast === 'function') showToast(t('cfgXmlImportErr') || 'Import failed', { tone: 'error' }); return; }
  var r = new FileReader();
  r.onload = function () {
    try {
      var text = String(r.result || '');
      var cfg = _cfgParseXml(text);
      // Round-trip : garder le fichier ENTIER, machine-keys comprises (elles
      // seront réécrites telles quelles ; l'officiel corrige AppDataDir seul).
      try { localStorage.setItem(PTH_CFG_XML_KEY, text.slice(0, 400000)); } catch (e) {}
      Object.keys(PTH_CFG_MACHINE_KEYS).forEach(function (k) { delete cfg.scalars[k]; });
      _cfgApplyImported(cfg);
      // Notes de joueur : uniquement sur import de FICHIER, jamais sur la
      // descente de synchro (_cfgSyncApplyDescent passe par _cfgApplyImported
      // aussi). Un config.xml de bureau plus ancien, rejoué à chaque
      // connexion, écraserait sinon des notes prises depuis sur le téléphone.
      try { _cfgApplyTipLines(cfg.lists && cfg.lists.PlayerTooltips); } catch (e) {}
      var msg = t('cfgXmlImported') || 'config.xml imported';
      if (typeof showToast === 'function') showToast(msg);
      // Comme le « redémarre PokerTH » de l'officiel : proposer un rechargement
      // pour appliquer thèmes/decks et resynchroniser toute l'UI.
      setTimeout(function () {
        var q = t('cfgXmlReload') || 'Reload now to apply everything?';
        if (window.confirm(msg + '\n\n' + q)) { try { location.reload(); } catch (e) {} }
      }, 150);
    } catch (e) {
      if (typeof showToast === 'function') showToast((t('cfgXmlImportErr') || 'Import failed') + ' — ' + e.message, { tone: 'error' });
    }
  };
  r.readAsText(f);
}
window._importPokerthConfigFile = _importPokerthConfigFile;
function importPokerthConfigPick() {
  var inp = document.getElementById('adv-cfgxml-file');
  if (!inp) return;
  inp.value = '';
  inp.onchange = function () { _importPokerthConfigFile(inp.files && inp.files[0]); };
  inp.click();
}
window.importPokerthConfigPick = importPokerthConfigPick;

// ── Fichiers et liens entrants (file_handlers · share_target · protocole) ────
// Trois portes, un seul aiguillage. Le type est deduit de l'extension : .zip =
// pack de style (tapis / jeu de cartes / sieges), .json = sauvegarde web,
// .xml = config.xml du client officiel. Tout le reste est ignore silencieusement.
function _pthHandleIncomingFile(file) {
  if (!file) return Promise.resolve(false);
  var name = String(file.name || '').toLowerCase();
  var fail = function (e) {
    if (typeof showToast === 'function')
      showToast((t('importError') || 'Import failed') + (e && e.message ? ' \u2014 ' + e.message : ''), { tone: 'error' });
    return false;
  };
  try {
    if (/\.zip$/.test(name)) {
      if (typeof window._pthImportPackZip !== 'function') return Promise.resolve(fail());
      return window._pthImportPackZip(file).then(function (rec) {
        if (typeof showToast === 'function') showToast((rec && rec.name) || file.name);
        return true;
      }).catch(fail);
    }
    if (/\.json$/.test(name)) { _importWebBackupFile(file); return Promise.resolve(true); }
    if (/\.xml$/.test(name))  { _importPokerthConfigFile(file); return Promise.resolve(true); }
  } catch (e) { return Promise.resolve(fail(e)); }
  return Promise.resolve(false);
}
window._pthHandleIncomingFile = _pthHandleIncomingFile;

// Un lien d'invitation partage depuis une autre application (messagerie, mail)
// arrive comme du TEXTE : on y repeche l'URL et on relance l'application dessus,
// ce qui reutilise tel quel le chemin d'invitation deja en place (#join=…).
// Jamais pendant une main : recharger couperait la partie en cours.
function _pthApplySharedLink(text) {
  var m = String(text || '').match(/(https?:\/\/[^\s]+|web\+pokerth:\/\/[^\s]+)/);
  if (!m) return false;
  var raw = m[1], dest = '';
  try {
    if (raw.indexOf('web+pokerth:') === 0) dest = '/?proto=' + encodeURIComponent(raw);
    else {
      var u = new URL(raw);
      if (!/[#?](?:.*&)?(?:join|table|host)=/.test(u.hash + u.search)) return false;
      dest = u.pathname + u.search + u.hash;   // toujours notre propre origine
    }
  } catch (e) { return false; }
  var S = window.PthState;
  if (S && (S.gId || S.amInGame)) {
    if (typeof showToast === 'function') showToast(raw);
    return false;
  }
  try { location.replace(dest); } catch (e) {}
  return true;
}

// Vide la boite aux lettres remplie par le service worker (voir sw.js,
// handleShareTarget). Appele au demarrage et a chaque relance entrante.
function _pthDrainShare() {
  if (!window.caches) return;
  var C = null;
  caches.open('pokerth-share').then(function (c) {
    C = c;
    return c.match('/__share/index.json');
  }).then(function (r) {
    if (!r) return null;
    return r.json();
  }).then(function (idx) {
    if (!idx) return null;
    var txt = [idx.url, idx.text, idx.title].filter(Boolean).join(' ');
    var seq = Promise.resolve();
    (idx.files || []).forEach(function (f) {
      seq = seq.then(function () {
        return C.match(f.path).then(function (rf) {
          if (!rf) return;
          return rf.blob().then(function (b) {
            return _pthHandleIncomingFile(new File([b], f.name, { type: f.type || b.type || '' }));
          });
        });
      });
    });
    return seq.then(function () {
      return Promise.all(['/__share/index.json', '/__share/0', '/__share/1',
                          '/__share/2', '/__share/3'].map(function (k) { return C.delete(k); }));
    }).then(function () {
      // Le lien en dernier : il peut recharger la page, les fichiers sont deja
      // ranges et la boite videe, donc rien ne sera rejoue au retour.
      if (txt) _pthApplySharedLink(txt);
    });
  }).catch(function () {});
}
window._pthDrainShare = _pthDrainShare;

// « Ouvrir avec » depuis le gestionnaire de fichiers (manifest file_handlers) et
// relances entrantes de l'application deja ouverte (launch_handler focus-existing :
// pas de rechargement, donc le drain doit repasser ici).
try {
  if ('launchQueue' in window && window.launchQueue &&
      typeof LaunchParams !== 'undefined' && 'files' in LaunchParams.prototype) {
    window.launchQueue.setConsumer(function (params) {
      try { _pthDrainShare(); } catch (e) {}
      if (!params || !params.files || !params.files.length) return;
      var seq = Promise.resolve();
      params.files.slice(0, 4).forEach(function (h) {
        seq = seq.then(function () { return h.getFile(); })
                 .then(_pthHandleIncomingFile)
                 .catch(function () {});
      });
    });
  }
} catch (e) {}
try { _pthDrainShare(); } catch (e) {}

// ── Phase 2 : synchronisation du config.xml liée au COMPTE (opt-in) ─────────
// Réservée aux logins AUTHENTIFIÉS (compte pokerth enregistré) : le proxy
// n'émet un jeton de session (trame texte SYNCTOK:) qu'après l'InitAck d'un
// login SCRAM vérifié par le serveur. Invités / LAN non authentifiés : jamais
// de jeton, donc jamais de sync. Le blob synchronisé = exactement le même
// config.xml que l'export manuel (round-trip compris).
// Réconciliation : pth_cfg_sync_ts = updatedAt serveur du dernier état commun ;
// serveur plus récent → on applique ; local modifié (drapeau dirty posé par
// les hooks setAdvOpt/advPrefSet/saveCreatePrefs) → on pousse (debounce 5 s,
// et au pagehide en best-effort keepalive).
// ── Indicateur « disquette » de synchronisation (tous les headers) ──────────
// Visible uniquement pendant un echange reel avec le proxy ; comme toutes les
// requetes de synchro exigent un jeton, il ne peut pas s'allumer hors compte.
var _syncBusy = 0, _syncHideTimer = null, _syncPending = false;
var _SYNC_ICON = '<svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">'
  + '<path d="M17 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V7l-4-4zm-5 16a3 3 0 1 1 0-6 3 3 0 0 1 0 6zm3-10H7V5h8v4z"/></svg>';
function _syncBadgeMount() {
  try {
    // Un .hdr-ovf-wrap par header (connexion, lobby, creation, jeu, confidentialite).
    var wraps = document.querySelectorAll('.hdr-ovf-wrap');
    for (var i = 0; i < wraps.length; i++) {
      var w = wraps[i], hdr = w.parentNode;
      if (!hdr) continue;
      // Place : a GAUCHE de l'enveloppe des messages prives quand ce header en
      // porte une (demande narmod 26/08) ; les autres headers n'en ont pas, la
      // disquette y reste donc a gauche du menu « Plus » comme avant.
      var anchor = hdr.querySelector('[id^="pm-btn-"]') || w;
      var el = hdr.querySelector(':scope > .hdr-sync');
      if (!el) {
        el = document.createElement('span');
        el.className = 'hdr-sync';
        el.setAttribute('role', 'status');
        el.innerHTML = _SYNC_ICON;
        if (_syncBusy > 0) el.classList.add('on');
      }
      try { el.title = t('syncBusy') || 'Syncing\u2026'; } catch (e) { el.title = 'Syncing\u2026'; }
      // Deja au bon endroit : ne pas toucher au DOM. Re-inserer le noeud
      // relancerait l'animation de pulsation a chaque montage, et _syncBadgeMount
      // est appele a chaque debut d'echange.
      if (el.parentNode !== hdr || el.nextElementSibling !== anchor)
        hdr.insertBefore(el, anchor);
    }
  } catch (e) {}
}
window._syncBadgeMount = _syncBadgeMount;
function _syncBadgeApply() {
  // Visible tant qu'il reste quelque chose a envoyer (attente) OU qu'un echange
  // est en vol : l'icone couvre donc toute la fenetre de temporisation (~5 s).
  var on = _syncBusy > 0 || _syncPending;
  try {
    var els = document.querySelectorAll('.hdr-sync');
    for (var i = 0; i < els.length; i++) els[i].classList.toggle('on', on);
  } catch (e) {}
}
function _syncBusyBegin() { _syncBusy++; clearTimeout(_syncHideTimer); _syncBadgeMount(); _syncBadgeApply(); }
function _syncPendingSet(on) {
  _syncPending = !!on;
  clearTimeout(_syncHideTimer);
  if (_syncPending) { _syncBadgeMount(); _syncBadgeApply(); }
  else _syncHideTimer = setTimeout(_syncBadgeApply, 1200);
}
function _syncBusyEnd() {
  _syncBusy = Math.max(0, _syncBusy - 1);
  clearTimeout(_syncHideTimer);
  if (_syncBusy > 0) { _syncBadgeApply(); return; }
  // Plus rien en vol : le cycle de push est termine, donc plus rien en attente.
  _syncPending = false;
  // Maintien avant extinction pour qu'un echange rapide reste lisible.
  _syncHideTimer = setTimeout(_syncBadgeApply, 1200);
}
try {
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', _syncBadgeMount);
  else _syncBadgeMount();
} catch (e) {}
var _cfgSyncToken = null;
var _cfgSyncPushTimer = null;
function _cfgSyncEnabled() { return _advGet('cfg_sync', true); }
// ── Blob « web-only » : réglages SANS clé dans le config.xml officiel, poussés
// en JSON séparé (/prefs-web) pour couvrir 100 % des options sans jamais
// polluer le XML interopérable. Whitelist explicite (jamais de clés machine
// type pth_cfg_sync_ts, jetons, caches).
var _CFG_WEB_SYNC_KEYS = [
  // Toggles web-only (via setAdvOpt → pth_<clé>)
  'pth_show_community', 'pth_chat_noemoji', 'pth_chat_ts', 'pth_chat_clear_login', 'pth_lobby_type_chat', 'pth_chat_tr_always', 'pth_guard_raise', 'pth_community_suggest',
  'pth_assist', 'pth_show_odds', 'pth_hands_btn', 'pth_voice', 'pth_announce', 'pth_avatar_create',
  'pth_haptic', 'pth_display_bb', 'pth_table_zoom', 'pth_zoom_follow',
  'pth_community_content', 'pth_sound_vol',
  'pth_log_on', 'pth_create_dialog', 'pth_status_bar', 'pth_blinds_badge', 'pth_deal_anim',
  'pth_forum_news', 'pth_lobby_clock',
  'pth_winner_popup', 'pth_remove_gone', 'pth_tooltips', 'pth_big_own_cards',
  'pth_chat_translate', 'pth_chat_abbrev', 'pth_pin_actionbar', 'pth_confirm_social',
  'pth_help_btn',
  'pth_guide_on',   // Aide de l'As (modules/guide) : allumée / éteinte
  'pth_ace_scenes',   // facéties de l'As : scènes, danses, réactions (modules/mascot)
  'pth_ace_dance',   // l'As danse sur le lecteur de musique (modules/mascot)
  // Valeurs (thème web, sièges, clavier, langue, divers)
  'pth_theme', 'pth_buttons', 'pth_pucks', 'pth_seat', 'pth_seat_layout',
  'pth_seat_custom', 'pth_keys', 'pth_lang', 'pth_offline_skill',
  'pth_log_interval', 'pth_avatar', 'pth_ignored', 'pth_prefs_lan',
  // Web-only sans equivalent config.xml : elles appelaient _cfgSyncMark() mais
  // n'etaient collectees par aucun canal (donc jamais synchronisees).
  'pth_conn_pill', 'pth_stats_track', 'pth_pdb_auto', 'pth_bak_auto',
  'pth_interface_size', 'pth_high_contrast', 'pth_browser_zoom'
];
// Notes de joueur + étiquettes (modules/notes). PAS dans la liste ci-dessus :
// elles se FUSIONNENT au lieu de s'écraser. Un écrasement ferait perdre la
// note prise sur le téléphone dès que le bureau repousse la sienne — chaque
// appareil annote des joueurs différents. Même traitement que les succès.
// Les LIBELLÉS renommés des couleurs suivent la même règle, couleur par
// couleur (la logique vit dans modules/notes/store.mjs::mergeIn).
var _NOTES_SYNC_KEYS = ['pth_notes'];
// Fusion pseudo par pseudo (et couleur par couleur pour les libellés), la
// date la plus récente gagnant — pont window._nvStore.
// Renvoie true si le local en sait plus que le distant -> il faut repousser.
function _notesMergeIn(o) {
  var raw = o ? o.pth_notes : null;
  if (typeof raw !== 'string' || raw.length > 20000) return false;
  var theirs = null;
  try { theirs = JSON.parse(raw); } catch (e) { return false; }
  if (!theirs || typeof theirs !== 'object') return false;
  var store = window._nvStore;
  if (!store || typeof store.mergeIn !== 'function') return false;
  store.mergeIn(theirs);
  // Si l'état local ne coïncide plus avec ce qu'ils ont envoyé, c'est qu'on a
  // des notes qu'ils n'ont pas : on repousse.
  try { return JSON.stringify(store.raw()) !== JSON.stringify(theirs); } catch (e) { return false; }
}
// Succès (mode entraînement) : mêmes transport et compte que les réglages, mais
// réconciliation par FUSION et non par écrasement — la progression est cumulative,
// donc deux appareils ne peuvent pas se contredire : union des succès débloqués
// (on garde le déblocage le plus ancien) et maximum des compteurs.
var _ACH_SYNC_KEYS = ['pth_ach_unlocked', 'pth_ach_hands', 'pth_ach_gamesWon',
                     'pth_ach_beatenSkills', 'pth_ach_wonStyles'];
// Etat « lu » des actualites du forum (comptes authentifies uniquement, comme
// tout le canal /prefs-web) : meme reconciliation par FUSION que les succes —
// lu quelque part = lu partout (union des ids, maximum du repere
// « tout marquer comme lu »). Jamais synchronise pour les invites : le canal
// entier n'existe qu'avec un jeton emis sur InitAck authentifie.
var _FORUM_SYNC_KEYS = ['pth_forum_read_base', 'pth_forum_read_ids'];
var _FORUM_IDS_MAX = 120;   // borne partagee avec modules/ui/forumnews.mjs
function _forumMergeIn(o) {
  var needPush = false, changed = false;
  try {
    // repere « tout lu » : max des deux
    var rawB = o ? (o.pth_forum_read_base != null ? o.pth_forum_read_base : null) : null;
    if (typeof rawB === 'string' && rawB.length <= 32) {
      var theirsB = parseInt(rawB, 10) || 0;
      var mineB = parseInt(_cfgLs('pth_forum_read_base'), 10) || 0;
      var maxB = Math.max(theirsB, mineB);
      if (maxB > theirsB) needPush = true;
      if (maxB !== mineB) { try { localStorage.setItem('pth_forum_read_base', String(maxB)); changed = true; } catch (e) {}
      }
    }
    // ids lus individuellement : union bornee (les plus recents gardes)
    var rawI = o ? (o.pth_forum_read_ids != null ? o.pth_forum_read_ids : null) : null;
    if (typeof rawI === 'string' && rawI.length <= 20000) {
      var theirs = null, mine = null;
      try { theirs = JSON.parse(rawI); } catch (e) { theirs = null; }
      try { mine = JSON.parse(_cfgLs('pth_forum_read_ids') || '[]'); } catch (e) { mine = null; }
      if (Array.isArray(theirs)) {
        if (!Array.isArray(mine)) mine = [];
        var seen = {}, merged = [];
        theirs.concat(mine).forEach(function (x) {
          if (typeof x === 'string' && x && !seen[x]) { seen[x] = 1; merged.push(x); }
        });
        if (merged.length > _FORUM_IDS_MAX) merged = merged.slice(merged.length - _FORUM_IDS_MAX);
        var sm = JSON.stringify(merged);
        if (sm !== JSON.stringify(theirs)) needPush = true;   // on a plus qu'eux
        if (sm !== _cfgLs('pth_forum_read_ids')) { try { localStorage.setItem('pth_forum_read_ids', sm); changed = true; } catch (e) {} }
      }
    }
  } catch (e) {}
  // Badge/liste rafraichis en direct si le module forum est charge.
  if (changed) { try { if (window._forumReadSynced) window._forumReadSynced(); } catch (e) {} }
  return needPush;
}
// Accuse de reception des notices operateur (invite / compte). Valeur =
// updatedAt de la version acquittee. Seule la cle du COMPTE se synchronise
// (les invites n'ont pas de profil ; le canal /prefs-web n'existe de toute
// facon qu'avec un jeton emis sur InitAck authentifie). Reconciliation par
// FUSION comme pth_forum_read_base : maximum numerique — acquitte quelque
// part = acquitte partout, et une edition operateur (updatedAt plus grand)
// re-affiche sur tous les appareils.
var _NOTICE_SYNC_KEYS = ['pth_authnotice_seen'];
function _noticeMergeIn(o) {
  var needPush = false;
  try {
    var raw = o ? (o.pth_authnotice_seen != null ? o.pth_authnotice_seen : null) : null;
    if (typeof raw === 'string' && raw.length <= 32) {
      var theirs = parseInt(raw, 10) || 0;
      var mine = parseInt(_cfgLs('pth_authnotice_seen'), 10) || 0;
      var mx = Math.max(theirs, mine);
      if (mx > theirs) needPush = true;
      if (mx !== mine) { try { localStorage.setItem('pth_authnotice_seen', String(mx)); } catch (e) {} }
    }
  } catch (e) {}
  return needPush;
}
// Aide de l'As (modules/guide) : proposition déjà faite + astuces déjà vues.
// Même réconciliation par FUSION que les succès : proposée quelque part =
// proposée partout ; une astuce vue sur le téléphone ne revient pas sur le
// bureau ; « Revoir toutes les astuces » pose une date de remise à zéro qui
// gagne partout. La logique vit dans modules/guide/state.mjs::mergeIn (pont
// window._guideStore) ; si le module n'est pas encore chargé, le blob est
// mis de côté (window._guidePendingSync) et fusionné à son chargement.
var _GUIDE_SYNC_KEYS = ['pth_guide_offered', 'pth_guide_seen'];
function _guideMergeIn(o) {
  try {
    var st = window._guideStore;
    if (!st || typeof st.mergeIn !== 'function') { window._guidePendingSync = o; return false; }
    return !!st.mergeIn(o);
  } catch (e) { return false; }
}
var _cfgWebForcePush = false;   // le local était plus riche : repousser après fusion
function _achNorm(k, v) {       // sérialisation stable (comparaisons fiables)
  try {
    if (k === 'pth_ach_unlocked') {
      var o = v || {}, out = {};
      Object.keys(o).sort().forEach(function (id) { out[id] = o[id]; });
      return JSON.stringify(out);
    }
    if (k === 'pth_ach_hands' || k === 'pth_ach_gamesWon') return JSON.stringify(v || 0);
    return JSON.stringify((v || []).slice().sort());
  } catch (e) { return ''; }
}
function _achMergeOne(k, mine, theirs) {
  if (k === 'pth_ach_unlocked') {
    var out = {}, a = mine || {}, b = theirs || {};
    Object.keys(a).forEach(function (id) { out[id] = a[id]; });
    Object.keys(b).forEach(function (id) {
      out[id] = (out[id] == null) ? b[id] : Math.min(out[id], b[id]);   // 1er déblocage
    });
    return out;
  }
  if (k === 'pth_ach_hands' || k === 'pth_ach_gamesWon') {
    return Math.max(parseInt(mine, 10) || 0, parseInt(theirs, 10) || 0);
  }
  var set = {};
  (Array.isArray(mine) ? mine : []).concat(Array.isArray(theirs) ? theirs : [])
    .forEach(function (x) { if (x != null) set[x] = 1; });
  return Object.keys(set);
}
// Fusionne le blob distant dans le local. Renvoie true si le local est un
// sur-ensemble du distant (⇒ il faut repousser pour que le compte rattrape).
function _achMergeIn(o) {
  var needPush = false;
  _ACH_SYNC_KEYS.forEach(function (k) {
    var raw = o ? (o[k.toLowerCase()] != null ? o[k.toLowerCase()] : o[k]) : null;
    if (typeof raw !== 'string' || raw.length > 20000) return;
    var theirs = null, mine = null;
    try { theirs = JSON.parse(raw); } catch (e) { return; }
    try { var lv = _cfgLs(k); mine = lv == null ? null : JSON.parse(lv); } catch (e) { mine = null; }
    var merged = _achMergeOne(k, mine, theirs);
    var sm = _achNorm(k, merged);
    if (sm !== _achNorm(k, theirs)) needPush = true;          // on a plus qu'eux
    try { if (_cfgLs(k) !== sm) localStorage.setItem(k, sm); } catch (e) {}
  });
  return needPush;
}
function _cfgWebCollect() {
  var o = {};
  _CFG_WEB_SYNC_KEYS.forEach(function (k) {
    var v = _cfgLs(k);
    if (v != null && v.length <= 20000) o[k] = v;   // skippe les valeurs énormes (ex. avatar image)
  });
  _ACH_SYNC_KEYS.forEach(function (k) {
    var v = _cfgLs(k);
    // Le proxy ne retient que /^pth_[a-z0-9_]+$/ : on transmet en minuscules
    // (les clés locales gardent leur casse d'origine).
    if (v != null && v.length <= 20000) o[k.toLowerCase()] = v;
  });
  _FORUM_SYNC_KEYS.forEach(function (k) {
    var v = _cfgLs(k);
    if (v != null && v.length <= 20000) o[k] = v;   // clés déjà en minuscules
  });
  _NOTES_SYNC_KEYS.forEach(function (k) {
    var v = _cfgLs(k);
    if (v != null && v.length <= 20000) o[k] = v;
  });
  _NOTICE_SYNC_KEYS.forEach(function (k) {
    var v = _cfgLs(k);
    if (v != null && v.length <= 32) o[k] = v;
  });
  _GUIDE_SYNC_KEYS.forEach(function (k) {
    var v = _cfgLs(k);
    if (v != null && v.length <= 20000) o[k] = v;
  });
  return o;
}
function _cfgWebDirty() {
  try { return JSON.stringify(_cfgWebCollect()) !== (_cfgLs('pth_cfg_sync_weblast') || ''); }
  catch (e) { return false; }
}
function _cfgWebPushNow(keepalive) {
  if (!_cfgSyncToken || !_cfgSyncEnabled()) return;
  var body; try { body = JSON.stringify(_cfgWebCollect()); } catch (e) { return; }
  if (body === (_cfgLs('pth_cfg_sync_weblast') || '') && !_cfgWebForcePush) return;   // rien de neuf
  _cfgWebForcePush = false;
  fetch('/prefs-web',
        { method: 'PUT', headers: { 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + _cfgSyncToken }, body: body, keepalive: !!keepalive })
    .then(function (r) {
      if (r.status === 429) { if (!keepalive) _cfgSyncPushSoon(6000); return null; }
      return r.json();
    })
    .then(function (d) {
      if (d && d.ok) {
        try { localStorage.setItem('pth_cfg_sync_weblast', body); } catch (e) {}
        try { localStorage.setItem('pth_cfg_sync_webts', String(d.updatedAt || Date.now())); } catch (e) {}
      }
    }).catch(function () {}).finally(function () { _syncBusyEnd(); });
  _syncBusyBegin();
}
// Application silencieuse du blob reçu (mêmes chemins que les setters : les
// toggles avancés sont ré-appliqués live ; thème/langue prennent effet au
// prochain chargement, comme l'import de config.xml).
function _cfgWebApply(o) {
  if (!o || typeof o !== 'object') return;
  var changed = false;
  try {
    if (_achMergeIn(o)) { _cfgWebForcePush = true; _cfgSyncPushSoon(1500); }
  } catch (e) {}
  try {
    if (_forumMergeIn(o)) { _cfgWebForcePush = true; _cfgSyncPushSoon(1500); }
  } catch (e) {}
  try {
    if (_notesMergeIn(o)) { _cfgWebForcePush = true; _cfgSyncPushSoon(1500); }
  } catch (e) {}
  try {
    if (_noticeMergeIn(o)) { _cfgWebForcePush = true; _cfgSyncPushSoon(1500); }
  } catch (e) {}
  try {
    if (_guideMergeIn(o)) { _cfgWebForcePush = true; _cfgSyncPushSoon(1500); }
  } catch (e) {}
  // Même fusion que pour le config.xml : une clé modifiée ici depuis le dernier
  // envoi (elle diffère de l'instantané poussé) n'est PAS écrasée par le
  // serveur — elle sera repoussée. Sans instantané (1er appareil), on accepte.
  var last = null;
  try { last = JSON.parse(_cfgLs('pth_cfg_sync_weblast') || 'null'); } catch (e) { last = null; }
  var heldWeb = 0;
  _CFG_WEB_SYNC_KEYS.forEach(function (k) {
    if (typeof o[k] === 'string' && o[k].length <= 20000) {
      try {
        var cur = localStorage.getItem(k);
        if (last && typeof last === 'object') {
          var lv = last[k];
          if (lv == null ? (cur != null) : (cur !== lv)) { heldWeb++; return; }
        }
        if (cur !== o[k]) { localStorage.setItem(k, o[k]); changed = true; }
      } catch (e) {}
    }
  });
  if (heldWeb) { _cfgWebForcePush = true; _cfgSyncPushSoon(1500); }
  if (!changed) return;
  try { applyAdvOpts(); } catch (e) {}
  try { if (typeof applyTooltips === 'function') applyTooltips(); } catch (e) {}
  try {
    var sl = _cfgLs('pth_seat_layout'); if (sl) document.documentElement.setAttribute('data-seat-layout', sl);
    if (typeof window._renderSeatsNow === 'function') window._renderSeatsNow();
    else if (typeof window._renderSeats === 'function') window._renderSeats();
  } catch (e) {}
}
// ── Réglages modifiés ICI depuis le dernier envoi réussi ───────────────────
// La descente écrasait tout le config.xml local dès que le serveur était plus
// récent : un réglage changé sur cet appareil (typiquement les catégories de
// son) revenait en silence à la valeur d'un autre appareil — d'où le « je
// coupe le son et il revient ». On mémorise donc QUELLES clés ont bougé pour
// les protéger à la prochaine descente, puis les repousser.
// Table adv → clé officielle : miroir exact des setB() de _cfgApplyImported.
var PTH_CFG_ADV_KEYS = {
  fade_losers: 'ShowFadeOutCardsAnimation', anim_cards: 'ShowFlipCardsAnimation',
  fkeys_alt: 'AlternateFKeysUserActionMode', show_blinds: 'ShowBlindButtons',
  own_click: 'AntiPeekMode', guard_call: 'AccidentallyCallBlocker',
  focus_bet: 'EnableBetInputFocusSwitch', show_flag: 'ShowCountryFlagInAvatar',
  pot_btns: 'ShowPotPercentButtons', ping_avatar: 'ShowPingStateInAvatar',
  no_hide_ignored: 'DontHideAvatarsOfIgnored', lobby_chat: 'UseLobbyChat',
  react_muted: 'DisableEmojiReactions', reduce_fx: 'QmlReduceEffects',
  auto_leave: 'NetAutoLeaveGameAfterFinish', pause_hands: 'PauseBetweenHands',
  poker_en: 'DontTranslateInternationalPokerStringsFromStyle',
  splash: 'DisableSplashScreenOnStartup',
  snd_actions: 'PlayGameActions', snd_lobby: 'PlayLobbyChatNotification',
  snd_net: 'PlayNetworkGameNotification', snd_blinds: 'PlayBlindRaiseNotification'
};
// The table preferences deserve the same protection as the toggles above: a
// disk-button save (or a field edited in the advanced options) that has not
// been pushed yet must not be flattened by a newer server config.xml — and,
// held == 0 clearing the dirty flag, it would otherwise not just be
// overwritten but silently dropped, never pushed at all. These are the dirty
// marks the prefs writers leave (_cfgSyncMark('create_prefs') from the disk
// button, the raw field names from advPrefSet)…
var PTH_CFG_PREFS_DIRTY_MARKS = { create_prefs: 1, players: 1, stack: 1, blind: 1,
  raiseEvery: 1, timeout: 1, delayHands: 1, guiSpeed: 1, name: 1, gameType: 1,
  allowSpectators: 1 };
// …and these are ALL the official keys mergePrefs can read back into
// pth_prefs_local / pth_prefs_internet — the exact mirror of what
// _cfgBlindsKeys and the net section of the collector write. Anything
// mergePrefs reads must be listed here, or a dirty local save loses that
// field on the next descent (pinned by scripts/test-cfg-sync-hold.mjs).
var PTH_CFG_PREFS_SCALARS = (function () {
  var both = ['NumberOfPlayers', 'StartCash', 'FirstSmallBlind',
    'RaiseBlindsAtHands', 'RaiseBlindsAtMinutes', 'RaiseSmallBlindEveryHands',
    'RaiseSmallBlindEveryMinutes', 'AlwaysDoubleBlinds', 'ManualBlindsOrder',
    'AfterMBAlwaysDoubleBlinds', 'AfterMBAlwaysRaiseAbout',
    'AfterMBStayAtLastBlind', 'AfterMBAlwaysRaiseValue',
    'GameSpeed', 'TimeOutPlayerAction', 'DelayBetweenHands'];
  var out = ['InternetGameName', 'InternetGameType', 'InternetGameAllowSpectators',
    'UseInternetGamePassword', 'InternetGamePassword'];
  both.forEach(function (k) { out.push(k); out.push('Net' + k); });
  return out;
})();
var PTH_CFG_PREFS_LISTS = ['ManualBlindsList', 'NetManualBlindsList'];
function _cfgDirtyKeys() {
  try { var a = JSON.parse(_cfgLs('pth_cfg_sync_dirtykeys') || '[]'); return Array.isArray(a) ? a : []; }
  catch (e) { return []; }
}
function _cfgDirtyKeysAdd(key) {
  try {
    var a = _cfgDirtyKeys();
    if (a.indexOf(key) >= 0) return;
    a.push(key);
    localStorage.setItem('pth_cfg_sync_dirtykeys', JSON.stringify(a.slice(-60)));
  } catch (e) {}
}
function _cfgDirtyKeysClear() { try { localStorage.removeItem('pth_cfg_sync_dirtykeys'); } catch (e) {} }
function _cfgSyncMark(key) {
  if (key === 'cfg_sync') return;                 // (dé)cocher la sync n'est pas une donnée à pousser
  try { localStorage.setItem('pth_cfg_sync_dirty', '1'); } catch (e) {}
  _cfgDirtyKeysAdd(key);
  _cfgSyncPushSoon();
}
var _cfgPushReconciled = false;   // garde anti-boucle de la réconciliation d'avant-poussée
function _cfgSyncPushSoon(ms) {
  if (!_cfgSyncToken || !_cfgSyncEnabled()) return;
  _syncPendingSet(true);            // modifications en attente d'envoi
  clearTimeout(_cfgSyncPushTimer);
  _cfgSyncPushTimer = setTimeout(function () { _cfgSyncPushNow(); }, ms == null ? 5000 : ms);
}
function _cfgSyncPushNow(keepalive) {
  if (!_cfgSyncToken || !_cfgSyncEnabled()) { _syncPendingSet(false); return; }
  // Réconcilier AVANT de pousser : une poussée est un xml COMPLET reconstruit
  // depuis le storage local — depuis un onglet resté ouvert des jours, elle
  // repartait avec des préférences d'époque et écrasait ce qu'un autre
  // appareil avait réglé entre-temps (rapport forum : le nom de table
  // retombait sans cesse sur le défaut ; avant la correction du double
  // préfixe Net, le nom était d'ailleurs le SEUL champ que ces poussées
  // périmées pouvaient toucher — « tout est mémorisé sauf le nom »). On
  // relit donc le serveur : s'il a plus récent, on applique la descente —
  // les retenues protègent ce qui vient d'être modifié ici — puis on pousse
  // l'état fusionné. Au pagehide (keepalive), pas le temps d'un aller-retour :
  // poussée directe, la prochaine poussée normale réconciliera.
  if (!keepalive && !_cfgPushReconciled) {
    _cfgPushReconciled = true;         // un seul GET par poussée (pas de boucle)
    fetch('/prefs', { headers: { 'Authorization': 'Bearer ' + _cfgSyncToken } })
      .then(function (r) { return r.json(); })
      .then(function (d) {
        var localTs = parseInt(_cfgLs('pth_cfg_sync_ts') || '0', 10) || 0;
        if (d && d.ok && d.xml && (d.updatedAt || 0) > localTs) _cfgSyncApplyDescent(d, false);
      })
      .catch(function () {})
      .finally(function () { _cfgSyncPushNow(); _cfgPushReconciled = false; });
    return;
  }
  var xml; try { xml = _cfgBuildXml(); } catch (e) { _cfgPushReconciled = false; return; }
  fetch('/prefs',
        { method: 'PUT', headers: { 'Content-Type': 'application/xml', 'Authorization': 'Bearer ' + _cfgSyncToken }, body: xml, keepalive: !!keepalive })
    .then(function (r) {
      // 429 = rate-limit serveur (1 écriture/5 s par compte) : le drapeau dirty
      // reste posé, on re-tente un peu plus tard (pas au pagehide).
      if (r.status === 429) { if (!keepalive) _cfgSyncPushSoon(6000); return null; }
      return r.json();
    })
    .then(function (d) {
      if (d && d.ok) {
        try { localStorage.setItem('pth_cfg_sync_ts', String(d.updatedAt || Date.now())); } catch (e) {}
        try { localStorage.removeItem('pth_cfg_sync_dirty'); } catch (e) {}
        _cfgDirtyKeysClear();                    // nos valeurs sont chez le serveur
      }
    }).catch(function () {}).finally(function () { _syncBusyEnd(); });
  _syncBusyBegin();
  _cfgWebPushNow(keepalive);
}
// Descente serveur → local : parse, retenues des réglages localement sales
// (toggles + préférences de table), application, horodatage. Partagée entre
// le pull de connexion et la réconciliation d'avant-poussée. `toast` : la
// descente de connexion l'annonce, la réconciliation reste silencieuse.
function _cfgSyncApplyDescent(d, toast) {
  try {
    var cfg = _cfgParseXml(d.xml);
    try { localStorage.setItem(PTH_CFG_XML_KEY, String(d.xml).slice(0, 400000)); } catch (e) {}
    Object.keys(PTH_CFG_MACHINE_KEYS).forEach(function (k) { delete cfg.scalars[k]; });
    // Fusion : les réglages changés ici depuis le dernier envoi gagnent —
    // on les retire de la descente et on les repousse (sinon ils étaient
    // écrasés en silence, et le drapeau dirty effacé avec eux).
    var held = 0;
    _cfgDirtyKeys().forEach(function (k) {
      var ck = PTH_CFG_ADV_KEYS[k];
      if (ck && cfg.scalars[ck] != null) { delete cfg.scalars[ck]; held++; }
    });
    // Table prefs edited here since the last push: hold every prefs key
    // from the descent so mergePrefs cannot flatten the local save, and
    // keep the dirty flag (held > 0) so our values are pushed back.
    if (_cfgDirtyKeys().some(function (k) { return PTH_CFG_PREFS_DIRTY_MARKS[k] === 1; })) {
      PTH_CFG_PREFS_SCALARS.forEach(function (ck) { if (cfg.scalars[ck] != null) { delete cfg.scalars[ck]; held++; } });
      PTH_CFG_PREFS_LISTS.forEach(function (ck) { if (cfg.lists && cfg.lists[ck] != null) { delete cfg.lists[ck]; held++; } });
    }
    _cfgApplyImported(cfg);
    // Le panneau des préférences peut être déjà peuplé : refléter la
    // descente, sinon il affiche des valeurs qui ne sont plus en storage.
    try { _advSyncPrefs(); } catch (e) {}
    try { localStorage.setItem('pth_cfg_sync_ts', String(d.updatedAt)); } catch (e) {}
    if (held) { _cfgSyncPushSoon(1500); }   // dirty conservé : nos valeurs partent
    else {
      try { localStorage.removeItem('pth_cfg_sync_dirty'); } catch (e) {}
      _cfgDirtyKeysClear();
    }
    if (toast && typeof showToast === 'function') showToast(t('cfgSyncApplied') || 'Settings synced from your account');
  } catch (e) {}
}
function _cfgSyncPull() {
  if (!_cfgSyncToken || !_cfgSyncEnabled()) return;
  fetch('/prefs', { headers: { 'Authorization': 'Bearer ' + _cfgSyncToken } })
    .then(function (r) { return r.json(); })
    .then(function (d) {
      if (!d || !d.ok) return;
      var localTs = parseInt(_cfgLs('pth_cfg_sync_ts') || '0', 10) || 0;
      var dirty = _cfgLs('pth_cfg_sync_dirty') === '1';
      if (d.xml && (d.updatedAt || 0) > localTs) {
        _cfgSyncApplyDescent(d, true);
      } else if (!d.xml || dirty) {
        _cfgSyncPushSoon(500);                    // 1er appareil, ou modifs locales hors-ligne
      }
      // Blob web-only : même réconciliation, horodatage séparé.
      var webTs = parseInt(_cfgLs('pth_cfg_sync_webts') || '0', 10) || 0;
      if (d.web && typeof d.web === 'object' && (d.webUpdatedAt || 0) > webTs) {
        try {
          _cfgWebApply(d.web);
          localStorage.setItem('pth_cfg_sync_webts', String(d.webUpdatedAt));
          localStorage.setItem('pth_cfg_sync_weblast', JSON.stringify(_cfgWebCollect()));
        } catch (e) {}
      } else if (_cfgWebDirty()) {
        _cfgSyncPushSoon(500);
      }
    }).catch(function () {}).finally(function () { _syncBusyEnd(); });
  _syncBusyBegin();
}
// Jeton reçu du proxy (trame SYNCTOK:) — appelé par le handler WS.
window._cfgSyncOnToken = function (tok) {
  _cfgSyncToken = String(tok || '') || null;
  if (_cfgSyncToken) _cfgSyncPull();
};
// Case à cocher : activer = tirer d'abord (l'état du compte gagne sur un
// appareil qui vient d'activer) ; _cfgSyncPull() pousse s'il n'y a rien côté serveur.
window.cfgSyncToggle = function (el) {
  setAdvOpt('cfg_sync', !!(el && el.checked));
  if (el && el.checked) _cfgSyncPull();
};
// Dernière chance avant fermeture/onglet caché : push best-effort.
// Un succès vient d'être débloqué : programmer une remontée vers le compte
// (no-op hors ligne — la progression partira à la prochaine connexion).
window.addEventListener('pth-achievement', function () {
  try { localStorage.setItem('pth_cfg_sync_dirty', '1'); } catch (e) {}
  try { _cfgSyncPushSoon(3000); } catch (e) {}
});
window.addEventListener('pagehide', function () {
  try { if (_cfgLs('pth_cfg_sync_dirty') === '1' || _cfgWebDirty()) _cfgSyncPushNow(true); } catch (e) {}
});
// Placement des sièges (Options avancées) : 'auto' | 'pokerth-official' | 'pokerth-ellipse'. Persiste +
// re-rend les sièges via le hook global window._renderSeats.
// Style du widget d'assistance : « segs » (10 blocs, defaut) ou « bar » (barre
// de progression historique). Porte par <html data-assist-style> ; le calcul de
// la force est identique dans les deux cas (cf. _hsSet, odds-panel.mjs).
function setAssistStyle(v) {
  v = (v === 'bar') ? 'bar' : 'segs';
  try { localStorage.setItem('pth_assist_style', v); } catch (e) {}
  try { document.documentElement.setAttribute('data-assist-style', v); } catch (e) {}
}
window.setAssistStyle = setAssistStyle;

function setSeatLayout(v) {
  v = (v === 'pokerth-official' || v === 'pokerth-ellipse' || v === 'custom') ? v : 'auto';
  try { localStorage.setItem('pth_seat_layout', v); } catch (e) {}
  try { document.documentElement.setAttribute('data-seat-layout', v); } catch (e) {}
  // Quitter le mode custom pendant l'edition doit TERMINER l'edition, sinon le
  // rendu reste gele (window._seatEditMode) et les autres modes semblent inertes.
  if (window._seatEditMode && v !== 'custom' && typeof window._seatEditExit === 'function') {
    try { window._seatEditExit(); } catch (e) {}   // re-rend au passage
  } else {
    // iOS : le re-rendu via requestAnimationFrame (window._renderSeats) peut ne
    // PAS s'appliquer a la partie en cours apres la fermeture du selecteur natif
    // (rAF gele pendant l'ouverture du picker) -> impression qu'il faut rejoindre
    // une partie. On force donc un rendu SYNCHRONE immediat (window._renderSeatsNow),
    // puis on repete via setTimeout (les timers ne sont pas geles) pour rattraper
    // tout etat de mesure transitoire. Desktop/tablette : deja instantane, inchange.
    var _applyNow = function () {
      try {
        if (typeof window._renderSeatsNow === 'function') window._renderSeatsNow();
        else if (typeof window._renderSeats === 'function') window._renderSeats();
      } catch (e) {}
    };
    _applyNow();
    setTimeout(_applyNow, 120);
    setTimeout(_applyNow, 400);
  }
}
window.setSeatLayout = setSeatLayout;
// ── Synchronisation automatique du PACK de sieges avec l'orientation
// (Options avancees, sous le placement) : si activee, ecran PORTRAIT ->
// sieges « PokerTH portrait », ecran PAYSAGE -> sieges « PokerTH
// landscape ». Force le pack (le choix manuel du panneau Style est
// remplace tant que l'option est active). Applique au demarrage, au
// resize et au changement d'orientation.
// Bascule portrait/paysage UNIQUE (parité GamePage.qml:453 `wide: width >=
// height` sur la tableZone). tableZone web = #g-table-zone + player-bar
// visible (le QML inclut la self-box dans sa zone). Repli : orientation
// fenêtre (zone absente/cachée, ex. lobby au démarrage).
function _tableZonePortrait() {
  try {
    var z = document.getElementById('g-table-zone');
    var r = z ? z.getBoundingClientRect() : null;
    if (r && r.width > 0) {
      var h = r.height;
      var pb = document.querySelector('.player-bar');
      if (pb && pb.offsetParent !== null) h += pb.getBoundingClientRect().height;
      return h > r.width;
    }
  } catch (e) {}
  return window.innerHeight > window.innerWidth;
}
window._tableZonePortrait = _tableZonePortrait;

function _applySeatOrient(portrait) {
  try {
    // Orientation générique des sièges (fusion des packs pokerth /
    // pokerth-portrait, 0.3.691) : html[data-seat-orient="portrait|landscape"],
    // que TOUT pack peut cibler en CSS. Suit la DISPOSITION réellement retenue
    // quand renderSeats la connaît (_forceSeatPortrait passé en argument),
    // sinon le ratio de la tableZone (parité QML : GamePlayerBox.wideLayout
    // décide sur la tableZone, pas la fenêtre).
    var p = (typeof portrait === 'boolean') ? portrait : _tableZonePortrait();
    var want = p ? 'portrait' : 'landscape';
    if (document.documentElement.getAttribute('data-seat-orient') !== want)
      document.documentElement.setAttribute('data-seat-orient', want);
  } catch (e) {}
}
// ── Traduction du chat par l'endpoint Google gtx (même méthode que le client
// QML de sp0ck : fetch direct depuis le navigateur → l'IP du joueur porte le
// quota, rien à installer côté serveur). Opt-in via Options avancées
// (pth_chat_translate). Bouton 🌐 par message reçu : 1er tap = traduire vers
// la langue du client, 2e tap = revenir à l'original. Cache par message
// (dataset.trText). Hors-ligne ou endpoint indisponible : le tap échoue
// proprement (tr-err), le reste de l'app reste jouable.
window._chatTrSupported = (function () {
  try { return typeof fetch === 'function'; } catch (e) { return false; }
})();
function _chatTrTarget() {
  // Langue cible = langue VIVANTE de l'i18n (window._lang), qui vaut aussi en
  // mode auto-détection. pth_lang n'existe que si l'utilisateur a choisi
  // manuellement une langue — s'y fier seul envoyait tl=en par défaut et
  // traduisait en anglais des messages déjà dans la langue du joueur.
  var l = '';
  try { l = String(window._lang || ''); } catch (e) {}
  if (!l) { try { l = localStorage.getItem('pth_lang') || ''; } catch (e) {} }
  if (!l) { try { l = document.documentElement.lang || navigator.language || 'en'; } catch (e) { l = 'en'; } }
  var low = l.toLowerCase();
  if (low === 'zh-tw' || low === 'zh-hk') return 'zh-TW'; // gtx distingue trad./simplifié (pas de zh-HK)
  if (low === 'zh') return 'zh-CN';
  if (low === 'pt-pt') return 'pt-PT'; // gtx : pt = pt-BR
  return low.split('-')[0];
}
// Une seule porte pour la traduction (chat ET post du forum) : appel direct
// gtx d'abord — le quota reste porté par l'IP du joueur, comme dans le client
// QML — puis repli sur le relais serveur /api/translate si le navigateur
// refuse l'appel cross-origin. C'est le cas d'une PWA installée sur iOS : en
// mode standalone WebKit rejette le fetch alors que la même URL répond dans un
// onglet Safari. Résout par { text, src } ; rejette si les deux voies échouent.
window._gtxTranslate = function (text, target) {
  var q = String(text || '');
  var tl = String(target || 'en');
  var take = function (data) {
    var out = '';
    if (data && data[0] && data[0].length) {
      for (var i = 0; i < data[0].length; i++) {
        if (data[0][i] && typeof data[0][i][0] === 'string') out += data[0][i][0];
      }
    }
    if (!out.trim()) throw new Error('empty');
    return { text: out, src: (data && typeof data[2] === 'string') ? data[2] : '' };
  };
  var direct = 'https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=' +
    encodeURIComponent(tl) + '&dt=t&q=' + encodeURIComponent(q);
  return fetch(direct).then(function (r) {
    if (!r.ok) throw new Error('http ' + r.status);
    return r.json();
  }).then(take).catch(function () {
    // Parite QML 69ec0824 (« translation fallback hardening ») : Google
    // drossele l'endpoint gtx PAR IP (HTTP 429) — vu chez les joueurs sous
    // VPN. Deuxieme essai depuis l'IP DU JOUEUR via MyMemory, avant de
    // rabattre tout le monde sur l'IP du serveur (le relais), qui concentre
    // les appels et se fait throttler d'autant plus vite.
    return window._mmTranslate(q, tl);
  }).catch(function () {
    return fetch('/api/translate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tl: tl, q: q })
    }).then(function (r) {
      if (!r.ok) throw new Error('relay ' + r.status);
      return r.json();
    }).then(function (d) {
      if (!d || !d.ok || !String(d.text || '').trim()) throw new Error('relay_empty');
      return { text: String(d.text), src: String(d.src || '') };
    });
  });
};
// Repli MyMemory (parite QML 69ec0824, chattranslatorcore.cpp) : meme appel
// que startFallback upstream — « Autodetect|cible » (un « en » code en dur
// traduisait tout le non-anglais comme de l'anglais et privait les clients
// anglais de TOUT repli). responseStatus DOIT etre verifie : en erreur
// (paire invalide, quota gratuit epuise) MyMemory repond HTTP 200 avec
// l'avertissement EN MAJUSCULES dans translatedText — sans ce test, cet
// avertissement s'affichait comme « traduction ». Le champ arrive tantot en
// nombre (200), tantot en chaine (« 403 »), d'ou le parseInt. Cas special
// source == cible : 403 « PLEASE SELECT TWO DISTINCT LANGUAGES » — le
// message est deja dans la langue du client, on rend l'original avec
// src = cible (le globe affichera « deja dans ta langue »), comme gtx.
// Limite MyMemory : ~500 octets par requete — au-dela (posts de forum), on
// passe directement au relais.
window._mmTranslate = function (text, target) {
  var q = String(text || '');
  var tl = String(target || 'en');
  if (!q.trim() || q.length > 480) return Promise.reject(new Error('mm_skip'));
  var u = 'https://api.mymemory.translated.net/get?q=' + encodeURIComponent(q) +
    '&langpair=' + encodeURIComponent('Autodetect|' + tl);
  return fetch(u).then(function (r) {
    if (!r.ok) throw new Error('mm_http ' + r.status);
    return r.json();
  }).then(function (d) {
    var status = 0, out = '', det = '';
    if (d) {
      status = parseInt(d.responseStatus, 10) || 0;
      if (d.responseData) {
        out = String(d.responseData.translatedText || '');
        det = String(d.responseData.detectedLanguage || '');
      }
    }
    if (status !== 200) {
      if (/DISTINCT LANGUAGES/i.test(out)) return { text: q, src: tl };
      throw new Error('mm_status ' + status);
    }
    if (!out.trim()) throw new Error('mm_empty');
    return { text: out, src: det ? det.toLowerCase() : '' };
  });
};
window._chatTrTarget = _chatTrTarget;
function _applyChatTranslateFlag() {
  // ACTIVE par defaut (demande narmod) : seul un '0' explicite desactive.
  // L'interrupteur admin (chat_translate) coupe tout envoi a Google.
  var on = true;
  try { on = !(window._pthFeatureOff && window._pthFeatureOff.chat_translate) && localStorage.getItem('pth_chat_translate') !== '0'; } catch (e) {}
  document.body.classList.toggle('chat-tr-on', !!(on && window._chatTrSupported));
}
function setChatTranslate(on) {
  try { localStorage.setItem('pth_chat_translate', on ? '1' : '0'); } catch (e) {}
  _applyChatTranslateFlag();
}
window.setChatTranslate = setChatTranslate;
window._chatTranslate = function (btn) {
  // .msg/.txt = lobby and game chat; .pm-line/.pm-text = private messages.
  var msg = btn && btn.closest ? btn.closest('.msg, .pm-line') : null;
  var span = msg ? msg.querySelector('.txt, .pm-text') : null;
  if (!msg || !span) return;
  // Toggle retour a l'original
  if (msg.dataset.trShown === '1') {
    if (msg.dataset.origHtml) span.innerHTML = msg.dataset.origHtml;
    msg.dataset.trShown = '0'; btn.classList.remove('tr-active');
    return;
  }
  if (msg.dataset.trText) { // deja traduit : re-afficher depuis le cache
    if (!msg.dataset.origHtml) msg.dataset.origHtml = span.innerHTML;
    span.textContent = msg.dataset.trText;
    msg.dataset.trShown = '1'; btn.classList.add('tr-active');
    return;
  }
  var orig = msg.dataset.orig || span.textContent || '';
  if (!orig.trim() || !window._chatTrSupported) return;
  btn.disabled = true; btn.classList.add('tr-busy');
  var tgt = _chatTrTarget();
  // Pré-expansion des abréviations (gg → good game…) : Google ne développe pas
  // le jargon, on lui donne donc la forme longue anglaise à traduire. Additif :
  // no-op si le module chat/abbrev.mjs n'est pas chargé.
  var forTr = orig;
  try { if (typeof window._expandAbbrev === 'function') forTr = window._expandAbbrev(orig); } catch (_ex) {}
  window._gtxTranslate(forTr, tgt).then(function (res) {
    var src = String(res.src || '').split('-')[0];
    if (src && src === tgt) { // deja dans la langue du client
      btn.classList.add('tr-same');
      return;
    }
    var out = res.text;
    if (out && out.trim()) {
      msg.dataset.trText = out;
      if (!msg.dataset.origHtml) msg.dataset.origHtml = span.innerHTML;
      span.textContent = out;
      msg.dataset.trShown = '1'; btn.classList.add('tr-active');
    }
  }).catch(function (e) {
    btn.classList.add('tr-err');
    try { btn.title = t('chatTranslateFailed'); } catch (_e) {}
    // Parite QML 69ec0824 (postFailureNote) : sans note, la sanduhr clignote
    // et il ne se passe rien — indiscernable d'une fonction cassee. Throttle
    // 60 s pour que plusieurs clics pendant la panne ne repetent pas le
    // meme message. Cle existante (deja traduite en 55 langues).
    try {
      var _now = Date.now();
      if (!window._trFailNoteAt || (_now - window._trFailNoteAt) >= 60000) {
        window._trFailNoteAt = _now;
        if (window.showToast) window.showToast(t('chatTranslateFailed'), { tone: 'error', icon: '\u26a0', duration: 4000 });
      }
    } catch (_e2) {}
  }).finally(function () {
    btn.disabled = false; btn.classList.remove('tr-busy');
  });
};
try { _applyChatTranslateFlag(); } catch (e) {}
window._applySeatOrient = _applySeatOrient;
// ── Style de mise (parité QML config/SeatStyle.qml, upstream 414a89c) ──────
// 'inset' = la mise dans un SOCLE en bas, À L'INTÉRIEUR de la boîte joueur
// (PlayerBetStrip QML) ; 'classic' = jeton betside À CÔTÉ de la boîte (état
// historique). pth_bet_style vide => 'inset' sur TOUTES les plateformes, comme
// le QML depuis upstream f9a8906 (SeatStyle.defaultVariant : le socle dans la
// boîte ne réclame aucune place autour des boîtes et passe mieux sur les
// petits écrans). Jusqu'à 2.1.8-web.2 le mobile (pointer:coarse) restait en
// 'classic', reflet de l'ancien platformDefault QML.
// Ne s'applique qu'aux packs à politique betside QML (trait betOut) — les
// packs qui posent déjà la mise dans le pied ne sont pas concernés.
// Depuis 2.1.8-web.21 (demande narmod) l'option est limitée au pack de
// sièges « PokerTH » ; depuis web.22 les autres packs reviennent à la
// présentation d'AVANT l'option (jeton betside À CÔTÉ de la boîte,
// 'classic'), la préférence pth_bet_style est conservée mais ignorée.
function _betStyleVariant() {
  var sid = null;
  try { sid = localStorage.getItem('pth_seat'); } catch (e) {}
  if (sid === null || sid === undefined || sid === '') sid = 'pokerth'; // défaut de l'axe
  if (sid !== 'pokerth') return 'classic';
  var v = '';
  try { v = localStorage.getItem('pth_bet_style') || ''; } catch (e) {}
  if (v === 'inset' || v === 'classic') return v;
  return 'inset';
}
// Pose html[data-bet="inset|classic"] (consommé par pokerth.css : réservation
// de la place du socle sous .seat) puis re-rend les sièges si une partie est
// affichée — la bascule des réglages est donc LIVE, comme applySeatStyle QML.
function _applyBetStyle() {
  try { document.documentElement.setAttribute('data-bet', _betStyleVariant()); } catch (e) {}
  try { if (typeof window._renderSeats === 'function') window._renderSeats(); } catch (e) {}
}
window._betStyleVariant = _betStyleVariant;
window._applyBetStyle = _applyBetStyle;
try { _applyBetStyle(); } catch (e) {}
// ── Descripteur de pack de sièges (étape 3) ────────────────────────────────
// Traits comportementaux du pack actif, résolus par le module theme
// (window._seatPackTraits : packs intégrés + "traits" du seat.json des packs
// importés). Repli avant chargement du module : traits QML complets — la
// structure commune est la norme (seul un pack importé peut s'en écarter
// via ses traits, résolus dès que le module theme est chargé).
function _seatTraitsNow() {
  var id = '';
  try { id = document.documentElement.getAttribute('data-seat') || ''; } catch (e) {}
  try { if (typeof window._seatPackTraits === 'function') { var t = window._seatPackTraits(id); if (t) return t; } } catch (e) {}
  return { holePlate: true, betOut: true, pucksSide: true, flagInfo: true, timerRect: false,
           timerBar: true, winnerBadge: true, selfStrip: true, selfBigCards: true,
           badgeOnCards: true, qmlSelf: true, narrowByOrient: true, qmlStruct: true };
}
setTimeout(function () { try { _applySeatOrient(); } catch (e) {} }, 800);
// Appliquer les classes body dès l'init (les prefs sont reflétées au chargement).
try {
  if (document.readyState === 'loading')
    document.addEventListener('DOMContentLoaded', applyAdvOpts);
  else applyAdvOpts();
} catch (e) {}
try {
  if (document.readyState === 'loading')
    document.addEventListener('DOMContentLoaded', applyTooltips);
  else applyTooltips();
} catch (e) {}

// [Phase 2] animateDealMyCards + flashActionLabel déplacées dans
// public/modules/ui/anim.mjs (toujours globales via window.*).
// isBot/getPlayerInitial/getPlayerTypeBadge → déplacées dans la closure (voir renderSeats)

// Palette de couleurs pour les avatars joueurs (12 couleurs)
var AVATAR_PALETTE = [
  { bg: '#c0392b', border: '#e74c3c', text: '#fff' }, // rouge
  { bg: '#2471a3', border: '#3498db', text: '#fff' }, // bleu
  { bg: '#1e8449', border: '#27ae60', text: '#fff' }, // vert
  { bg: '#d68910', border: '#f39c12', text: '#fff' }, // orange
  { bg: '#7d3c98', border: '#9b59b6', text: '#fff' }, // violet
  { bg: '#1a5276', border: '#2980b9', text: '#fff' }, // bleu foncé
  { bg: '#a04000', border: '#ca6f1e', text: '#fff' }, // brun
  { bg: '#117a65', border: '#1abc9c', text: '#fff' }, // turquoise
  { bg: '#943126', border: '#c0392b', text: '#fff' }, // bordeaux
  { bg: '#1f618d', border: '#2e86c1', text: '#fff' }, // cobalt
  { bg: '#616a6b', border: '#95a5a6', text: '#fff' }, // gris
  { bg: '#b7950b', border: '#d4ac0d', text: '#fff' }, // or
];
function getAvatarColor(pid) {
  return AVATAR_PALETTE[Math.abs(pid || 0) % AVATAR_PALETTE.length];
}


// [Phase 2] Raccourcis clavier (détection clavier physique, bindings
// personnalisables, handlers F1-F8/lettres, showKeyHint) déplacés dans
// public/modules/ui/shortcuts.mjs (toujours globaux via window.*).

// Affichage du bandeau "blinds" (alerte au changement OU explication au tap).
// Le contenu HTML est préparé dans le handler HandStart (où l'on a accès au
// small blind, au mode de montée, etc.) et stocké dans window._blindsInfoHtml.
// withSound=true → alerte (son), false → simple info au clic.
function _showBlindsToast(html, withSound) {
  if (!html) return;
  var prev = document.getElementById('blinds-up-toast');
  if (prev) prev.remove();
  var el = document.createElement('div');
  el.id = 'blinds-up-toast';
  el.className = 'blinds-up-toast';
  el.innerHTML = html;
  document.body.appendChild(el);
  requestAnimationFrame(function(){ el.classList.add('show'); });
  setTimeout(function(){
    el.classList.remove('show');
    setTimeout(function(){ if (el.parentNode) el.remove(); }, 450);
  }, withSound ? 3000 : 2400);
  if (withSound && typeof notifyBlindsUp === 'function') notifyBlindsUp();
}
window._showBlindsToast = _showBlindsToast;
// Appelé au tap sur la pastille du bandeau (pas de son).
window.showBlindsInfo = function() { _showBlindsToast(window._blindsInfoHtml, false); };

// ── Reusable toast ────────────────────────────────────────────────────────
// Small transient confirmation, styled like the header ••• menu (.app-toast
// in pokerth.css). Generic on purpose so any feature can call it:
//   showToast(t('fieldsReset'));
//   showToast('Copié', { icon: '📋', duration: 1200 });
// Text is set via textContent (never innerHTML) so a translated/dynamic
// message can never inject markup.
function showToast(msg, opts) {
  opts = opts || {};
  var prev = document.getElementById('app-toast');
  if (prev) prev.remove();
  var el = document.createElement('div');
  el.id = 'app-toast';
  el.className = 'app-toast' + (opts.tone === 'error' ? ' app-toast--error' : '');
  if (opts.icon !== '') {
    var tick = document.createElement('span');
    tick.className = 'app-toast-tick';
    tick.textContent = opts.icon || '\u2713'; // ✓
    el.appendChild(tick);
  }
  var txt = document.createElement('span');
  txt.textContent = msg;
  el.appendChild(txt);
  document.body.appendChild(el);
  requestAnimationFrame(function() { el.classList.add('show'); });
  var dur = opts.duration || 1800;
  setTimeout(function() {
    el.classList.remove('show');
    setTimeout(function() { if (el.parentNode) el.remove(); }, 300);
  }, dur);
}
window.showToast = showToast;

// ── Scheduled server restart/update notice (dismissible toast) ─────────────
// Driven by a single "NOTICE:RESTART:<deadlineMs>:<kind>:<note>" proxy frame.
// No live countdown (by design): shows the restart clock time, which stays
// accurate, plus an optional admin note. Localised via t(); note is shown with
// textContent so it can never inject markup.
function _fmtRestartTime(ms) {
  var d = new Date(ms);
  var sameDay = d.toDateString() === new Date().toDateString();
  try {
    return sameDay ? d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                   : d.toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  } catch (e) { return d.toLocaleTimeString(); }
}
// Close cross of the operator notices: a 36px target (it was a bare 17x20px
// glyph), pulled back into the notice's padding so the look does not change,
// and sticky so it stays reachable when a long notice scrolls.
var _NOTICE_CLOSE_CSS = 'flex:none;position:sticky;top:0;align-self:flex-start;width:36px;height:36px;margin:-8px -10px -8px -4px;display:flex;align-items:center;justify-content:center;background:transparent;border:0;font-size:1.35rem;line-height:1;cursor:pointer;padding:0;-webkit-tap-highlight-color:transparent;touch-action:manipulation;';
function hideRestartNotice() { var el = document.getElementById('srv-restart-notice'); if (el) el.remove(); }
function showRestartNotice(deadlineMs, kind, note) {
  hideRestartNotice();
  var msg = (kind === 'restart' ? t('srvRestartOnly') : t('srvRestartUpdate')).replace('{t}', _fmtRestartTime(deadlineMs));
  if (note) msg += '\n' + note;
  var el = document.createElement('div');
  el.id = 'srv-restart-notice';
  el.style.cssText = 'position:fixed;top:calc(10px + var(--pth-sat, 0px));left:50%;transform:translateX(-50%);box-sizing:border-box;width:max-content;max-width:92%;max-height:calc(100dvh - 20px - var(--pth-sat, 0px) - var(--pth-sab, 0px));overflow:auto;z-index:10000;display:flex;align-items:flex-start;gap:10px;background:rgba(var(--red-rgb),.96);color:#fff;padding:10px 13px;border-radius:10px;box-shadow:0 6px 22px rgba(0,0,0,.45);font-size:.85rem;line-height:1.4;white-space:pre-line;';
  var span = document.createElement('span');
  span.textContent = msg;
  el.appendChild(span);
  var x = document.createElement('button');
  x.setAttribute('aria-label', 'Close');
  x.textContent = '\u00d7';
  x.style.cssText = _NOTICE_CLOSE_CSS + 'color:#fff;opacity:.85;';
  x.addEventListener('click', hideRestartNotice);
  el.appendChild(x);
  document.body.appendChild(el);
}
window.showRestartNotice = showRestartNotice;
window.hideRestartNotice = hideRestartNotice;

// ── Information broadcast (admin → all clients) ────────────────────────────
// Gold toast matching the blinds announcement palette; dismissible (×); stays
// until closed; a newer message replaces the previous one. Sits just below the
// restart notice when both are showing. Message is linkified (safe HTML).
// Operator announcements (broadcasts + welcome) may include links. We escape
// the text (XSS/layout-safe even though the author is the admin), then linkify
//   [label](https://url)  ·  bare http(s):// or mailto: URLs
// Only http/https/mailto are linked; links open in a new tab, rel-protected.
function _escHtml(s) {
  return String(s == null ? '' : s)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}
function _annLink(url, label) {
  return '<a href="' + url + '" target="_blank" rel="noopener noreferrer nofollow"'
       + ' style="color:inherit;text-decoration:underline">' + label + '</a>';
}
function _linkifyAnnounce(text) {
  var esc = _escHtml(text);
  // single pass, alternation: markdown link OR bare URL (avoids double-linking)
  var RE = /\[([^\]\n]+)\]\((https?:\/\/[^\s)]+|mailto:[^\s)]+)\)|((?:https?:\/\/|mailto:)[^\s<)\]]+)/g;
  return esc.replace(RE, function (whole, mdLabel, mdUrl, bareUrl) {
    if (mdUrl) return _annLink(mdUrl, mdLabel);
    var trail = '', m = bareUrl.match(/[.,!?]+$/);
    if (m) { trail = m[0]; bareUrl = bareUrl.slice(0, -trail.length); }
    return _annLink(bareUrl, bareUrl) + trail;
  });
}
// ── Liens cliquables dans le chat ──────────────────────────────────
// Rend cliquables les URLs http(s)/mailto d'un texte de chat DÉJÀ échappé HTML
// (pipeline chat : esc() + éventuel applyChatEmoteShortcuts, qui n'insère aucune
// balise — que du texte + emojis unicode). URLs nues uniquement ; la ponctuation
// de fin (.,!?) reste hors du lien ; les guillemets sont neutralisés pour l'attribut
// href (défense XSS : esc() côté chat n'échappe pas " / '). Ouvre dans un nouvel onglet.
function _linkifyChatHtml(html) {
  var RE = /((?:https?:\/\/|mailto:)[^\s<]+)/g;
  return String(html == null ? '' : html).replace(RE, function (url) {
    var trail = '', m = url.match(/[.,!?]+$/);
    if (m) { trail = m[0]; url = url.slice(0, -trail.length); }
    var href = url.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
    return _annLink(href, url) + trail;
  });
}
window._linkifyChatHtml = _linkifyChatHtml;
// ── Agrandissement des emojis unicode du chat (parité QML enlargeEmojis) ──
// Enveloppe les séquences d'emojis (pictographiques + variation-selectors / ZWJ
// / skin-tones / keycaps / tag-chars) dans un span ~22px. Opère sur du HTML DÉJÀ
// formaté (après esc + shortcodes + liens) ; \p{Extended_Pictographic} = même
// base de détection que _advStripEmoji. ©/®/™ isolés NON agrandis (parité QML :
// ce sont aussi des caractères de texte). No-op si le moteur regex ne gère pas
// les propriétés Unicode (fallback = HTML inchangé).
function _enlargeChatEmojis(html) {
  try {
    var RE = /(?:[#*0-9]\uFE0F?\u20E3|\p{Extended_Pictographic}[\uFE0F\u200D\u20E3\u{1F3FB}-\u{1F3FF}\u{E0020}-\u{E007F}]*)+/gu;
    // Text between tags only: runs after linkify, and an emoji inside an
    // href="…" wrapped in a <span> used to break the <a> tag (raw markup shown).
    return String(html == null ? '' : html).split(/(<[^>]*>)/).map(function (part, i) {
      if (i % 2) return part;
      return part.replace(RE, function (m) {
        var bare = m.replace(/\uFE0F/g, '');
        if (bare === '\u00A9' || bare === '\u00AE' || bare === '\u2122') return m;
        return '<span class="chat-emoji-lg">' + m + '</span>';
      });
    }).join('');
  } catch (e) { return html; }
}
window._enlargeChatEmojis = _enlargeChatEmojis;
function hideInfoToast() { if (window._infoToastCdTimer) { clearInterval(window._infoToastCdTimer); window._infoToastCdTimer = null; } var el = document.getElementById('srv-info-toast'); if (el) el.remove(); }
// Format compact d'un temps restant : '2d 03:04:05', '1:02:03' ou '12:34'.
function _fmtCountdown(ms) {
  if (ms < 0) ms = 0;
  var t = Math.floor(ms / 1000);
  var d = Math.floor(t / 86400); t -= d * 86400;
  var h = Math.floor(t / 3600);  t -= h * 3600;
  var m = Math.floor(t / 60), sec = t - m * 60;
  function p(n) { return (n < 10 ? '0' : '') + n; }
  if (d > 0) return d + 'd ' + p(h) + ':' + p(m) + ':' + p(sec);
  if (h > 0) return h + ':' + p(m) + ':' + p(sec);
  return m + ':' + p(sec);
}
function showInfoToast(message, icon, cdAt) {
  hideInfoToast();
  // Below the status bar / Dynamic Island (--pth-sat = env(safe-area-inset-top)):
  // at a flat top:16px the toast - and its close cross - sat under the iPhone
  // status bar in the installed app, where no tap reaches it (narmod, web.105).
  // Under a restart notice: below ITS real bottom edge (it used to be a fixed
  // 76px, right for a one-line notice only). Never taller than the screen.
  var _rn = document.getElementById('srv-restart-notice');
  var top = _rn ? Math.round(_rn.getBoundingClientRect().bottom + 8) + 'px' : 'calc(16px + var(--pth-sat, 0px))';
  var el = document.createElement('div');
  el.id = 'srv-info-toast';
  el.style.cssText = 'position:fixed;top:' + top + ';left:50%;transform:translateX(-50%);box-sizing:border-box;width:max-content;max-width:min(92vw,420px);max-height:calc(100dvh - ' + (_rn ? top : '16px - var(--pth-sat, 0px)') + ' - 12px - var(--pth-sab, 0px));overflow:auto;z-index:9999;display:flex;align-items:flex-start;gap:10px;background:var(--gold);color:var(--on-gold);padding:11px 15px;border-radius:14px;box-shadow:0 8px 28px rgba(0,0,0,.55),0 0 0 1px rgba(255,255,255,.25) inset;font-weight:600;font-size:.9rem;line-height:1.4;white-space:pre-line;';
  if (icon) { var ic = document.createElement('span'); ic.textContent = icon; ic.style.cssText = 'flex:none;font-size:1.1rem;line-height:1.3;'; el.appendChild(ic); }
  var span = document.createElement('span'); span.innerHTML = _linkifyAnnounce(message);
  // Compte à rebours optionnel (échéance en epoch ms) : ligne dédiée, tick 1 s,
  // s'arrête à 0:00. Timer nettoyé par hideInfoToast().
  if (cdAt && Number(cdAt) > 0) {
    var cdEl = document.createElement('span');
    cdEl.style.cssText = 'display:block;margin-top:4px;font-weight:700;font-variant-numeric:tabular-nums;';
    var _cdTick = function () {
      var left = Number(cdAt) - Date.now();
      cdEl.textContent = '\u23f3 ' + _fmtCountdown(left);
      if (left <= 0 && window._infoToastCdTimer) { clearInterval(window._infoToastCdTimer); window._infoToastCdTimer = null; }
    };
    _cdTick();
    window._infoToastCdTimer = setInterval(_cdTick, 1000);
    span.appendChild(cdEl);
  }
  el.appendChild(span);
  var x = document.createElement('button');
  x.setAttribute('aria-label', 'Close'); x.textContent = '\u00d7';
  x.style.cssText = _NOTICE_CLOSE_CSS + 'color:var(--on-gold);opacity:.7;';
  x.addEventListener('click', hideInfoToast);
  el.appendChild(x);
  document.body.appendChild(el);
}
window.showInfoToast = showInfoToast;
window.hideInfoToast = hideInfoToast;

// ── On-device translation (browser Translator API, progressive enhancement) ──
// Free, on-device, no server/key. Chromium-only; everywhere else these helpers
// resolve null and callers fall back to the operator's original text.
function _apiLang(code) {
  if (!code) return '';
  var c = String(code).toLowerCase();
  if (c === 'zh-tw' || c === 'zh-hk') return 'zh-Hant';
  if (c === 'zh-cn') return 'zh';
  if (c === 'pt-br' || c === 'pt-pt') return 'pt';
  return c.split('-')[0];
}
function _makeTranslator(fromCode, toCode) {
  if (typeof Translator === 'undefined') return Promise.resolve(null);
  var from = _apiLang(fromCode), to = _apiLang(toCode);
  if (!from || !to || from === to) return Promise.resolve(null);
  return Promise.resolve(Translator.availability({ sourceLanguage: from, targetLanguage: to }))
    .then(function (av) { if (!av || av === 'unavailable') return null; return Translator.create({ sourceLanguage: from, targetLanguage: to }); })
    .catch(function () { return null; });
}
// The on-device Translator collapses line breaks (it treats the input as one
// segment), which flattened the operator's layout. Translate each line on its
// own and re-join with the original newlines; empty/whitespace lines pass
// through untouched, and a per-line failure falls back to the source line.
function _translateLines(tr, text) {
  if (text == null) return Promise.resolve('');
  var parts = String(text).split('\n');
  return parts.reduce(function (acc, line) {
    return acc.then(function (out) {
      if (!line.trim()) { out.push(line); return out; }
      return Promise.resolve(tr.translate(line))
        .then(function (t) { out.push(t); return out; })
        .catch(function () { out.push(line); return out; });
    });
  }, Promise.resolve([])).then(function (out) { return out.join('\n'); });
}
function _translateEntry(title, body, fromCode, toCode) {
  return _makeTranslator(fromCode, toCode).then(function (tr) {
    if (!tr) return null;
    function one(s) { return s ? _translateLines(tr, s) : Promise.resolve(''); }
    return one(title).then(function (t) { return one(body).then(function (b) { return { title: t, body: b }; }); });
  }).catch(function () { return null; });
}
function _detectLang(text) {
  if (!text || typeof LanguageDetector === 'undefined') return Promise.resolve(null);
  return Promise.resolve(LanguageDetector.availability())
    .then(function (av) { if (!av || av === 'unavailable') return null; return LanguageDetector.create(); })
    .then(function (det) { return det ? det.detect(text) : null; })
    .then(function (res) { return (res && res.length && res[0].confidence > 0.5) ? res[0].detectedLanguage : null; })
    .catch(function () { return null; });
}
function _detectTranslate(text) {
  var target = (typeof _lang !== 'undefined' && _lang) ? _lang : '';
  if (!text || !target || typeof Translator === 'undefined') return Promise.resolve(null);
  return _detectLang(text).then(function (src) {
    if (!src || _apiLang(src) === _apiLang(target)) return null;
    return _makeTranslator(src, target).then(function (tr) { return tr ? _translateLines(tr, text) : null; });
  }).catch(function () { return null; });
}

// ── Network fallback for operator text (gtx pipeline, same gate as chat) ───
// On-device translation is Chromium-only: everywhere else (Safari, Firefox,
// iOS PWA) the helpers above resolve null and the welcome / broadcasts stayed
// in the operator's language. Fall back to the shared _gtxTranslate pipeline
// (gtx direct → MyMemory → /api/translate relay), exactly like chat and forum
// translations. Network use follows the chat-translation switch
// (pth_chat_translate, ON by default): an explicit '0' keeps operator text
// untouched. The swap is skipped when gtx reports the detected source equal
// to the client's language (message already readable) or a no-op result.
function _netTrOn() {
  try { if (window._pthFeatureOff && window._pthFeatureOff.chat_translate) return false; return localStorage.getItem('pth_chat_translate') !== '0'; } catch (e) { return true; }
}
function _gtxAuto(text) {
  if (!text || !String(text).trim() || !_netTrOn() || typeof window._gtxTranslate !== 'function') return Promise.resolve(null);
  var tgt = (typeof _chatTrTarget === 'function') ? _chatTrTarget() : 'en';
  return window._gtxTranslate(text, tgt).then(function (res) {
    if (!res || !res.text || !String(res.text).trim()) return null;
    var src = String(res.src || '').toLowerCase().split('-')[0];
    if (src && src === String(tgt).toLowerCase().split('-')[0]) return null;
    if (res.text === text) return null;
    return res.text;
  }).catch(function () { return null; });
}

// ── First-visit welcome / rules modal (admin-authored, per language) ────────
// Picks the operator's text for the client's active UI language (_lang), with
// fallback: exact code → primary subtag (pt-br → pt) → configured default → any.
// `exact` is true when the operator actually provided the client's language.
function _welcomeChoose(w) {
  var langs = (w && w.langs) || {};
  var keys = Object.keys(langs);
  if (!keys.length) return null;
  var code = (typeof _lang !== 'undefined' && _lang) ? String(_lang).toLowerCase() : '';
  var def = (w && w['default']) ? String(w['default']).toLowerCase() : 'fr';
  var prim = code.split('-')[0];
  function findBy(pred) { for (var i = 0; i < keys.length; i++) { if (pred(keys[i].toLowerCase())) return keys[i]; } return null; }
  var exact = code && findBy(function (x) { return x === code; });
  var sub = !exact && prim ? findBy(function (x) { return x.split('-')[0] === prim; }) : null;
  var chosen = exact || sub || findBy(function (x) { return x === def; }) || keys[0];
  var v = langs[chosen] || {};
  return { lang: chosen, title: v.title || '', body: v.body || '', exact: !!(exact || sub) };
}
function _welcomePick(w) { var c = _welcomeChoose(w); return c ? { title: c.title, body: c.body } : null; }
function hideWelcomeModal() { var el = document.getElementById('welcome-modal'); if (el) el.remove(); }
function showWelcomeModal(title, body, version) {
  hideWelcomeModal();
  var back = document.createElement('div');
  back.id = 'welcome-modal';
  back.style.cssText = 'position:fixed;inset:0;z-index:10001;display:flex;align-items:center;justify-content:center;box-sizing:border-box;padding:calc(18px + var(--pth-sat, 0px)) 18px calc(18px + var(--pth-sab, 0px));background:rgba(0,0,0,.62);backdrop-filter:blur(2px);';
  var card = document.createElement('div');
  card.style.cssText = 'max-width:480px;width:100%;max-height:min(84vh, 100%);display:flex;flex-direction:column;background:var(--modal-bg);color:var(--text);border:1px solid var(--border);border-radius:16px;box-shadow:0 18px 50px rgba(0,0,0,.6);overflow:hidden;';
  if (title) {
    var h = document.createElement('div');
    h.textContent = title;
    h.style.cssText = "padding:16px 20px;font-family:var(--ff-display);font-weight:700;font-size:1.15rem;color:var(--text-hi);border-bottom:1px solid var(--border);";
    card.appendChild(h);
  }
  var p = document.createElement('div');
  p.innerHTML = _linkifyAnnounce(body || '');
  p.style.cssText = 'padding:16px 20px;overflow:auto;white-space:pre-line;line-height:1.55;font-size:.95rem;';
  card.appendChild(p);
  var foot = document.createElement('div');
  foot.style.cssText = 'padding:12px 20px 16px;display:flex;justify-content:flex-end;border-top:1px solid var(--border);';
  var btn = document.createElement('button');
  btn.textContent = (typeof window.t === 'function' ? window.t('welcomeAck') : '') || 'I understand';
  btn.style.cssText = 'min-height:40px;padding:9px 18px;border-radius:10px;border:0;cursor:pointer;font-weight:700;background:var(--gold);color:var(--on-gold);';
  btn.addEventListener('click', function () { try { localStorage.setItem('pth_welcome_seen', String(version)); } catch (e) {} hideWelcomeModal(); });
  foot.appendChild(btn);
  card.appendChild(foot);
  back.appendChild(card);
  document.body.appendChild(back);
}
function maybeShowWelcome(w) {
  // /live is the spectator tool, not the web client's shop window: the
  // operator notices about the client have no place there (sp0ck, 2026-09-10).
  if (window.LIVE_MODE) return;
  if (!w || !w.enabled) return;
  try { if (String(localStorage.getItem('pth_welcome_seen')) === String(w.updatedAt)) return; } catch (e) {}
  var c = _welcomeChoose(w);
  if (!c || (!c.title && !c.body)) return;
  showWelcomeModal(c.title, c.body, w.updatedAt); // operator text shows immediately
  if (!c.exact) {
    // No operator version for the client's language → try on-device translation
    // first, then the gtx pipeline (chat/forum path) where on-device is
    // unavailable; swap the text in only while the modal is still open.
    var target = (typeof _lang !== 'undefined' && _lang) ? _lang : c.lang;
    _translateEntry(c.title, c.body, c.lang, target).then(function (tr) {
      if (tr && (tr.title || tr.body)) {
        if (document.getElementById('welcome-modal')) showWelcomeModal(tr.title || c.title, tr.body || c.body, w.updatedAt);
        return;
      }
      return _gtxAuto(c.title).then(function (tt) {
        return _gtxAuto(c.body).then(function (tb) {
          if ((tt || tb) && document.getElementById('welcome-modal')) showWelcomeModal(tt || c.title, tb || c.body, w.updatedAt);
        });
      });
    }).catch(function () {});
  }
}
// Broadcast info toast: show immediately, then (on supported browsers) detect
// the message language and replace it with an on-device translation if needed.
var _bcSeq = 0;
function _showBroadcast(message, icon, cdAt) {
  _bcSeq++; var seq = _bcSeq;
  showInfoToast(message, icon, cdAt);
  _detectTranslate(message).then(function (tr) {
    if (tr && tr !== message) {
      if (seq === _bcSeq && document.getElementById('srv-info-toast')) showInfoToast(tr, icon, cdAt);
      return;
    }
    // On-device gave nothing (non-Chromium, missing model pair, or same
    // language): the gtx pipeline decides — its own source check keeps
    // already-readable messages untouched.
    return _gtxAuto(message).then(function (g) {
      if (g && seq === _bcSeq && document.getElementById('srv-info-toast')) showInfoToast(g, icon, cdAt);
    });
  }).catch(function () {});
}
window.maybeShowWelcome = maybeShowWelcome;
window.showWelcomeModal = showWelcomeModal;
window.hideWelcomeModal = hideWelcomeModal;
window._showBroadcast = _showBroadcast;

// ── Guest notice (pokerth.net internet guests, every connection) ───────────
// Same operator-authored multilingual shape as the welcome message above
// (language pick via _welcomeChoose, on-device -> gtx translation fallback,
// linkified body). Shown at lobby entry (net/msg-lobby.mjs onInitAck) until
// the guest clicks "I understand": the acknowledged updatedAt is kept in
// pth_guestnotice_seen (local only — guests have no profile) and the popup
// only returns when the operator edits the message. Config arrives from /app-config as
// c.guestNotice (null unless the operator enabled it) and is kept in
// window._guestNoticeCfg until the connection happens.
function hideGuestNoticeModal() { var el = document.getElementById('guestnotice-modal'); if (el) el.remove(); }
function showGuestNoticeModal(title, body, version) {
  hideGuestNoticeModal();
  var back = document.createElement('div');
  back.id = 'guestnotice-modal';
  back.style.cssText = 'position:fixed;inset:0;z-index:10001;display:flex;align-items:center;justify-content:center;box-sizing:border-box;padding:calc(18px + var(--pth-sat, 0px)) 18px calc(18px + var(--pth-sab, 0px));background:rgba(0,0,0,.62);backdrop-filter:blur(2px);';
  var card = document.createElement('div');
  card.style.cssText = 'max-width:480px;width:100%;max-height:min(84vh, 100%);display:flex;flex-direction:column;background:var(--modal-bg);color:var(--text);border:1px solid var(--border);border-radius:16px;box-shadow:0 18px 50px rgba(0,0,0,.6);overflow:hidden;';
  if (title) {
    var h = document.createElement('div');
    h.textContent = title;
    h.style.cssText = "padding:16px 20px;font-family:var(--ff-display);font-weight:700;font-size:1.15rem;color:var(--text-hi);border-bottom:1px solid var(--border);";
    card.appendChild(h);
  }
  var p = document.createElement('div');
  p.innerHTML = _linkifyAnnounce(body || '');
  p.style.cssText = 'padding:16px 20px;overflow:auto;white-space:pre-line;line-height:1.55;font-size:.95rem;';
  card.appendChild(p);
  var foot = document.createElement('div');
  foot.style.cssText = 'padding:12px 20px 16px;display:flex;justify-content:flex-end;border-top:1px solid var(--border);';
  var btn = document.createElement('button');
  btn.textContent = (typeof window.t === 'function' ? window.t('welcomeAck') : '') || 'I understand';
  btn.style.cssText = 'min-height:40px;padding:9px 18px;border-radius:10px;border:0;cursor:pointer;font-weight:700;background:var(--gold);color:var(--on-gold);';
  // Acquittement : la version (updatedAt) est memorisee localement — le
  // popup ne revient que si l'operateur edite le message. Invite = pas de
  // profil, donc pas de synchronisation (contrairement a la notice compte).
  btn.addEventListener('click', function () { try { localStorage.setItem('pth_guestnotice_seen', String(version)); } catch (e) {} hideGuestNoticeModal(); });
  foot.appendChild(btn);
  card.appendChild(foot);
  back.appendChild(card);
  document.body.appendChild(back);
}
function maybeShowGuestNotice() {
  // /live is the spectator tool, not the web client's shop window: the
  // operator notices about the client have no place there (sp0ck, 2026-09-10).
  if (window.LIVE_MODE) return;
  var g = window._guestNoticeCfg;
  if (!g || !g.enabled) return;
  // Deja acquitte pour cette version du message -> silence.
  try { if ((parseInt(localStorage.getItem('pth_guestnotice_seen'), 10) || -1) >= (Number(g.updatedAt) || 0)) return; } catch (e) {}
  if (window._offlineMode) return;                                  // training never shows it
  if (!(typeof window._amGuestMode === 'function' && window._amGuestMode())) return; // pokerth.net GUEST only
  var c = _welcomeChoose(g);
  if (!c || (!c.title && !c.body)) return;
  showGuestNoticeModal(c.title, c.body, g.updatedAt || 0); // operator text shows immediately
  if (!c.exact) {
    // No operator version for the client's language -> on-device translation
    // first, then the gtx pipeline; swap only while the modal is still open.
    var target = (typeof _lang !== 'undefined' && _lang) ? _lang : c.lang;
    _translateEntry(c.title, c.body, c.lang, target).then(function (tr) {
      if (tr && (tr.title || tr.body)) {
        if (document.getElementById('guestnotice-modal')) showGuestNoticeModal(tr.title || c.title, tr.body || c.body, g.updatedAt || 0);
        return;
      }
      return _gtxAuto(c.title).then(function (tt) {
        return _gtxAuto(c.body).then(function (tb) {
          if ((tt || tb) && document.getElementById('guestnotice-modal')) showGuestNoticeModal(tt || c.title, tb || c.body, g.updatedAt || 0);
        });
      });
    }).catch(function () {});
  }
}
window.maybeShowGuestNotice = maybeShowGuestNotice;
window.showGuestNoticeModal = showGuestNoticeModal;
window.hideGuestNoticeModal = hideGuestNoticeModal;

// ── Registered-account notice (pokerth.net auth logins, every connection) ──
// Mirror of the guest notice above for players logged in WITH a pokerth.net
// account: same multilingual pick, same translation fallback. The
// acknowledgement (pth_authnotice_seen = updatedAt) is stored locally AND
// synced to the account profile through /prefs-web (_noticeMergeIn, maximum
// wins) — dismissed on one device means dismissed everywhere, and an
// operator edit re-shows it. Config arrives from /app-config as c.authNotice
// and waits in window._authNoticeCfg.
function hideAuthNoticeModal() { var el = document.getElementById('authnotice-modal'); if (el) el.remove(); }
function showAuthNoticeModal(title, body, version) {
  hideAuthNoticeModal();
  var back = document.createElement('div');
  back.id = 'authnotice-modal';
  back.style.cssText = 'position:fixed;inset:0;z-index:10001;display:flex;align-items:center;justify-content:center;box-sizing:border-box;padding:calc(18px + var(--pth-sat, 0px)) 18px calc(18px + var(--pth-sab, 0px));background:rgba(0,0,0,.62);backdrop-filter:blur(2px);';
  var card = document.createElement('div');
  card.style.cssText = 'max-width:480px;width:100%;max-height:min(84vh, 100%);display:flex;flex-direction:column;background:var(--modal-bg);color:var(--text);border:1px solid var(--border);border-radius:16px;box-shadow:0 18px 50px rgba(0,0,0,.6);overflow:hidden;';
  if (title) {
    var h = document.createElement('div');
    h.textContent = title;
    h.style.cssText = "padding:16px 20px;font-family:var(--ff-display);font-weight:700;font-size:1.15rem;color:var(--text-hi);border-bottom:1px solid var(--border);";
    card.appendChild(h);
  }
  var p = document.createElement('div');
  p.innerHTML = _linkifyAnnounce(body || '');
  p.style.cssText = 'padding:16px 20px;overflow:auto;white-space:pre-line;line-height:1.55;font-size:.95rem;';
  card.appendChild(p);
  var foot = document.createElement('div');
  foot.style.cssText = 'padding:12px 20px 16px;display:flex;justify-content:flex-end;border-top:1px solid var(--border);';
  var btn = document.createElement('button');
  btn.textContent = (typeof window.t === 'function' ? window.t('welcomeAck') : '') || 'I understand';
  btn.style.cssText = 'min-height:40px;padding:9px 18px;border-radius:10px;border:0;cursor:pointer;font-weight:700;background:var(--gold);color:var(--on-gold);';
  // Acquittement : version memorisee localement ET poussee sur le profil du
  // compte via le canal /prefs-web (fusion par maximum, _noticeMergeIn) — vu
  // sur un appareil = vu partout ; une edition operateur re-affiche.
  btn.addEventListener('click', function () {
    try { localStorage.setItem('pth_authnotice_seen', String(version)); } catch (e) {}
    try { if (typeof _cfgSyncPushSoon === 'function') _cfgSyncPushSoon(1500); } catch (e) {}
    hideAuthNoticeModal();
  });
  foot.appendChild(btn);
  card.appendChild(foot);
  back.appendChild(card);
  document.body.appendChild(back);
}
function maybeShowAuthNotice() {
  // /live is the spectator tool, not the web client's shop window: the
  // operator notices about the client have no place there (sp0ck, 2026-09-10).
  if (window.LIVE_MODE) return;
  var g = window._authNoticeCfg;
  if (!g || !g.enabled) return;
  // Deja acquitte pour cette version (localement ou via le profil) -> silence.
  try { if ((parseInt(localStorage.getItem('pth_authnotice_seen'), 10) || -1) >= (Number(g.updatedAt) || 0)) return; } catch (e) {}
  if (window._offlineMode) return;                                  // training never shows it
  if (!(typeof window._amAuthMode === 'function' && window._amAuthMode())) return; // pokerth.net ACCOUNT only
  var c = _welcomeChoose(g);
  if (!c || (!c.title && !c.body)) return;
  showAuthNoticeModal(c.title, c.body, g.updatedAt || 0); // operator text shows immediately
  if (!c.exact) {
    var target = (typeof _lang !== 'undefined' && _lang) ? _lang : c.lang;
    _translateEntry(c.title, c.body, c.lang, target).then(function (tr) {
      if (tr && (tr.title || tr.body)) {
        if (document.getElementById('authnotice-modal')) showAuthNoticeModal(tr.title || c.title, tr.body || c.body, g.updatedAt || 0);
        return;
      }
      return _gtxAuto(c.title).then(function (tt) {
        return _gtxAuto(c.body).then(function (tb) {
          if ((tt || tb) && document.getElementById('authnotice-modal')) showAuthNoticeModal(tt || c.title, tb || c.body, g.updatedAt || 0);
        });
      });
    }).catch(function () {});
  }
}
window.maybeShowAuthNotice = maybeShowAuthNotice;
window.showAuthNoticeModal = showAuthNoticeModal;
window.hideAuthNoticeModal = hideAuthNoticeModal;

// ── LAN / dedicated server notice (LAN / dedicated connections, every connection) ──
// Mirror of the guest/auth notices above, shown to everyone connecting in LAN
// or dedicated-server mode on this instance (not offline, not pokerth.net).
// Config arrives from /app-config as c.lanNotice and waits in window._lanNoticeCfg.
function hideLanNoticeModal() { var el = document.getElementById('lannotice-modal'); if (el) el.remove(); }
function showLanNoticeModal(title, body, version) {
  hideLanNoticeModal();
  var back = document.createElement('div');
  back.id = 'lannotice-modal';
  back.style.cssText = 'position:fixed;inset:0;z-index:10001;display:flex;align-items:center;justify-content:center;box-sizing:border-box;padding:calc(18px + var(--pth-sat, 0px)) 18px calc(18px + var(--pth-sab, 0px));background:rgba(0,0,0,.62);backdrop-filter:blur(2px);';
  var card = document.createElement('div');
  card.style.cssText = 'max-width:480px;width:100%;max-height:min(84vh, 100%);display:flex;flex-direction:column;background:var(--modal-bg);color:var(--text);border:1px solid var(--border);border-radius:16px;box-shadow:0 18px 50px rgba(0,0,0,.6);overflow:hidden;';
  if (title) {
    var h = document.createElement('div');
    h.textContent = title;
    h.style.cssText = "padding:16px 20px;font-family:var(--ff-display);font-weight:700;font-size:1.15rem;color:var(--text-hi);border-bottom:1px solid var(--border);";
    card.appendChild(h);
  }
  var p = document.createElement('div');
  p.innerHTML = _linkifyAnnounce(body || '');
  p.style.cssText = 'padding:16px 20px;overflow:auto;white-space:pre-line;line-height:1.55;font-size:.95rem;';
  card.appendChild(p);
  var foot = document.createElement('div');
  foot.style.cssText = 'padding:12px 20px 16px;display:flex;justify-content:flex-end;border-top:1px solid var(--border);';
  var btn = document.createElement('button');
  btn.textContent = (typeof window.t === 'function' ? window.t('welcomeAck') : '') || 'I understand';
  btn.style.cssText = 'min-height:40px;padding:9px 18px;border-radius:10px;border:0;cursor:pointer;font-weight:700;background:var(--gold);color:var(--on-gold);';
  // Acquittement local uniquement (pas de compte lie a un serveur LAN) :
  // meme logique que le guest notice, la version (updatedAt) memorisee.
  btn.addEventListener('click', function () { try { localStorage.setItem('pth_lannotice_seen', String(version)); } catch (e) {} hideLanNoticeModal(); });
  foot.appendChild(btn);
  card.appendChild(foot);
  back.appendChild(card);
  document.body.appendChild(back);
}
function maybeShowLanNotice() {
  if (window.LIVE_MODE) return;
  var g = window._lanNoticeCfg;
  if (!g || !g.enabled) return;
  try { if ((parseInt(localStorage.getItem('pth_lannotice_seen'), 10) || -1) >= (Number(g.updatedAt) || 0)) return; } catch (e) {}
  if (window._offlineMode) return;                                   // training never shows it
  if (!(typeof window._amLanMode === 'function' && window._amLanMode())) return; // LAN / dedicated only
  var c = _welcomeChoose(g);
  if (!c || (!c.title && !c.body)) return;
  showLanNoticeModal(c.title, c.body, g.updatedAt || 0);
  if (!c.exact) {
    var target = (typeof _lang !== 'undefined' && _lang) ? _lang : c.lang;
    _translateEntry(c.title, c.body, c.lang, target).then(function (tr) {
      if (tr && (tr.title || tr.body)) {
        if (document.getElementById('lannotice-modal')) showLanNoticeModal(tr.title || c.title, tr.body || c.body, g.updatedAt || 0);
        return;
      }
      return _gtxAuto(c.title).then(function (tt) {
        return _gtxAuto(c.body).then(function (tb) {
          if ((tt || tb) && document.getElementById('lannotice-modal')) showLanNoticeModal(tt || c.title, tb || c.body, g.updatedAt || 0);
        });
      });
    }).catch(function () {});
  }
}
window.maybeShowLanNotice = maybeShowLanNotice;
window.showLanNoticeModal = showLanNoticeModal;
window.hideLanNoticeModal = hideLanNoticeModal;


// Rafraîchit immédiatement l'avatar du joueur local dans l'UI
window.refreshMyAvatar = function() {
  // Resolve which avatar to use for ME (the local player).
  // Step 4 introduced a 3-way choice stored in localStorage.pth_avatar:
  //   '__pth__'  -> use the official PokerTH avatar image
  //   ''         -> use the initial letter
  //   anything else (e.g. '🦊') -> use that emoji
  // First-login auto-pick (Q2=c): if the user never expressed a choice
  // (key missing from localStorage, NOT just empty) AND we already have a
  // PokerTH avatar downloaded, default to the official one. Once the user
  // makes any selection in the popup, this auto-pick stops kicking in.
  var pthUrl = (typeof window._pthAvatarFor === 'function' && typeof myId !== 'undefined')
    ? window._pthAvatarFor(myId)
    : null;
  var stored = null;
  try { stored = localStorage.getItem('pth_avatar'); } catch(e) {}
  if (stored === null && pthUrl) {
    // First-login auto-pick: persist the sentinel.
    try { localStorage.setItem('pth_avatar', '__pth__'); } catch(e) {}
    stored = '__pth__';
    // Reflect the choice on the trigger and selected button if the popup
    // already exists. Safe no-ops if elements aren't there yet.
    var btnPth = document.getElementById('avp-btn-pth');
    if (btnPth) {
      btnPth.style.display = '';
      document.querySelectorAll('.avp-btn').forEach(function(b){
        b.classList.toggle('selected', b.dataset.av === '__pth__');
      });
    }
    var trig = document.getElementById('av-trigger');
    if (trig) {
      // Match the head selectAvatarPopup behaviour: trigger shows the
      // PokerTH chip logo, not the id-card emoji.
      trig.innerHTML = '<img src="/favicon.svg" alt="PokerTH" draggable="false" style="width:26px;height:26px;object-fit:contain;pointer-events:none">';
      trig.classList.add('has-avatar');
    }
  }
  // Image perso choisie par l'utilisateur (sentinelle '__img__') : le client
  // web ne peut PAS récupérer l'avatar serveur d'un compte (le serveur ne le
  // stocke pas par compte — il le reçoit du client à la connexion). On laisse
  // donc l'utilisateur fournir sa propre image, stockée localement en data URL.
  var customImg = (stored === '__img__')
    ? (function(){ try { return localStorage.getItem('pth_avatar_img') || null; } catch(e){ return null; } })()
    : null;
  // PokerTH avatar UPLOAD: render WHATEVER avatar was picked (custom image,
  // emoji, or initial letter) to a PNG so official clients see it. '__pth__'
  // uploads nothing -> the official default avatar is kept.
  try {
    var _upNm = (window.S && window.S.myName) ? window.S.myName
              : ((document.getElementById('nick') && document.getElementById('nick').value) || '');
    _pthRefreshUpload(stored, String(_upNm).trim());
  } catch(e) {}
  // L'upload ci-dessus prépare le choix COURANT (pour la prochaine connexion).
  // L'affichage, lui, suit l'avatar de SESSION figé à l'Init — parité QML :
  // ClientContext garde l'avatar de la connexion, le siège local aussi.
  // (hors de la portée du S de l'IIFE : passer par le pont window.PthState)
  var _sessAv = (window.PthState && window.PthState._sessAv) || null;
  if (_sessAv) {
    stored = _sessAv.choice;
    customImg = (stored === '__img__') ? (_sessAv.img || null) : null;
  }
  // Effective choice: 'pth' | 'img' | 'initial' | 'emoji-xxx'
  var usePth   = (stored === '__pth__') && !!pthUrl;
  var emojiAv  = (stored && stored !== '__pth__' && stored !== '__img__') ? stored : '';
  var av = emojiAv; // back-compat var name used in the rest of the function
  window._myAvatarCache = av; // global implicite historique (écrit-seul, ≠ cache S de l'IIFE — hors portée de S)
  var display = av || (function(){
    var _nm = (window.S && window.S.myName) ? window.S.myName
            : ((document.getElementById('nick') && document.getElementById('nick').value) || '');
    return String(_nm).trim().charAt(0).toUpperCase() || '?';
  })();
  // Player-bar
  var pbAv = document.getElementById('g-myseat-av');
  if (pbAv) {
    if (usePth) {
      pbAv.innerHTML = '<img class="pb-pth-img" src="' + pthUrl + '" alt="" draggable="false">';
      pbAv.classList.add('has-pth-avatar');
    } else if (customImg) {
      pbAv.innerHTML = '<img class="pb-pth-img" src="' + customImg + '" alt="" draggable="false">';
      pbAv.classList.add('has-pth-avatar');
    } else if (stored === '__pth__') {
      // Q2=b: user picked the PokerTH avatar but no image is available
      // (e.g. they're a LAN player, or a pokerth.net guest, or the
      // avatar hasn't been downloaded yet). Show the official PokerTH
      // chip logo as a graceful placeholder instead of an initial.
      pbAv.innerHTML = '<img class="pb-pth-img" src="/favicon.svg" alt="" draggable="false">';
      pbAv.classList.add('has-pth-avatar');
    } else if (!av) {
      // Aucun avatar/emoji choisi → jeton PokerTH par défaut (client officiel).
      pbAv.innerHTML = '<img class="pb-pth-img" src="/favicon.svg" alt="" draggable="false">';
      pbAv.classList.add('has-pth-avatar');
    } else {
      pbAv.textContent = display;
      pbAv.classList.remove('has-pth-avatar');
    }
  }
  // Siège autour de la table
  var seatEls = document.querySelectorAll('#g-seats .seat');
  seatEls.forEach(function(seat) {
    if (seat.classList.contains('me')) {
      var avatarEl = seat.querySelector('.seat-avatar');
      if (!avatarEl) return;
      var img = avatarEl.querySelector('.seat-pth-img');
      // Decide which URL to use, in order of preference:
      //   1) the player's actual downloaded pokerth.net avatar
      //   2) the PokerTH chip logo (placeholder if the user picked
      //      '__pth__' but nothing is available yet -- Q2=b)
      //   3) nothing (fall back to emoji or initial)
      var effectiveUrl = usePth ? pthUrl
                       : (customImg ? customImg
                       : (stored === '__pth__' ? '/favicon.svg'
                       : (av ? null : '/favicon.svg')));
      if (effectiveUrl) {
        if (!img) {
          img = document.createElement('img');
          img.className = 'seat-pth-img';
          img.draggable = false;
          img.alt = '';
          avatarEl.insertBefore(img, avatarEl.firstChild);
        }
        if (img.getAttribute('src') !== effectiveUrl) img.src = effectiveUrl;
        avatarEl.classList.add('has-pth-avatar');
      } else {
        if (img) img.remove();
        avatarEl.classList.remove('has-pth-avatar');
      }
      var ini = avatarEl.querySelector('.seat-initial');
      if (ini) ini.textContent = display;
      if (av) avatarEl.classList.add('emoji-av');
      else avatarEl.classList.remove('emoji-av');
    }
  });
  // Option (i): the PokerTH button stays visible in the popup at all
  // times (even before connect / for LAN users). If the user clicks it
  // but no avatar is ever downloaded, usePth ends up false (because the
  // && !!pthUrl guard above) and the rendering falls back gracefully to
  // the initial. This makes the popup behave consistently across all
  // login modes and lets users pre-pick "PokerTH avatar" before they
  // even connect.
};

  // ──────────────────────────────────────────────────────────────────
  // PokerTH avatar UPLOAD (scope A) — make the local *custom image* avatar
  // visible to official QML/desktop clients. Normalize to a small PNG,
  // compute its MD5, advertise the hash in InitMessage (field 8), and stream
  // the bytes back when the server asks (AvatarRequest handler). Chunks MUST
  // be <= 256 bytes (MAX_FILE_DATA_SIZE; server validates avatarblock 1..256).
  // Emoji avatars are rendered to a PNG and uploaded too; the initial letter
  // and the PokerTH default announce no hash (QML: empty MyAvatar).
  // ──────────────────────────────────────────────────────────────────

  // Compact MD5 (RFC 1321) over a Uint8Array -> Uint8Array(16). Pure JS:
  // SubtleCrypto offers SHA but not MD5, and PokerTH keys avatars by MD5.
  function _md5bytes(input) {
    function rol(x, c) { return (x << c) | (x >>> (32 - c)); }
    function add(a, b) { return (a + b) | 0; }
    var S = [7,12,17,22,7,12,17,22,7,12,17,22,7,12,17,22,
             5,9,14,20,5,9,14,20,5,9,14,20,5,9,14,20,
             4,11,16,23,4,11,16,23,4,11,16,23,4,11,16,23,
             6,10,15,21,6,10,15,21,6,10,15,21,6,10,15,21];
    var K = [], i;
    for (i = 0; i < 64; i++) K[i] = (Math.floor(Math.abs(Math.sin(i + 1)) * 4294967296)) | 0;
    var msgLen = input.length;
    var withOne = msgLen + 1;
    var padZeros = ((withOne % 64) <= 56) ? (56 - (withOne % 64)) : (120 - (withOne % 64));
    var total = withOne + padZeros + 8;
    var buf = new Uint8Array(total);
    buf.set(input, 0);
    buf[msgLen] = 0x80;
    var bitLen = msgLen * 8;
    buf[total - 8] = bitLen & 0xff;
    buf[total - 7] = (bitLen >>> 8) & 0xff;
    buf[total - 6] = (bitLen >>> 16) & 0xff;
    buf[total - 5] = (bitLen >>> 24) & 0xff;
    var a0 = 0x67452301, b0 = 0xefcdab89 | 0, c0 = 0x98badcfe | 0, d0 = 0x10325476;
    var off;
    for (off = 0; off < total; off += 64) {
      var M = [], j;
      for (j = 0; j < 16; j++) {
        M[j] = (buf[off + j*4]) | (buf[off + j*4 + 1] << 8) | (buf[off + j*4 + 2] << 16) | (buf[off + j*4 + 3] << 24);
      }
      var A = a0, B = b0, C = c0, D = d0, k;
      for (k = 0; k < 64; k++) {
        var F, g;
        if (k < 16) { F = (B & C) | ((~B) & D); g = k; }
        else if (k < 32) { F = (D & B) | ((~D) & C); g = (5*k + 1) % 16; }
        else if (k < 48) { F = B ^ C ^ D; g = (3*k + 5) % 16; }
        else { F = C ^ (B | (~D)); g = (7*k) % 16; }
        F = add(add(add(F, A), K[k]), M[g]);
        A = D; D = C; C = B;
        B = add(B, rol(F, S[k]));
      }
      a0 = add(a0, A); b0 = add(b0, B); c0 = add(c0, C); d0 = add(d0, D);
    }
    var out = new Uint8Array(16), w, words = [a0, b0, c0, d0];
    for (w = 0; w < 4; w++) {
      out[w*4]     = words[w] & 0xff;
      out[w*4 + 1] = (words[w] >>> 8) & 0xff;
      out[w*4 + 2] = (words[w] >>> 16) & 0xff;
      out[w*4 + 3] = (words[w] >>> 24) & 0xff;
    }
    return out;
  }

  var _pthUploadSrc = null;
  var _pthUploadKey = null;
  // Clé de gel du choix EN COURS de préparation : un encodage asynchrone
  // (toBlob) terminé après un nouveau choix ne doit rien publier.
  var _pthPendingKey = null;
  // Clé du dernier échec déjà signalé, pour ne prévenir qu'UNE fois par choix
  // (sinon toast à chaque tentative de reconnexion tant que l'image reste
  // invalide). Se réarme naturellement dès que `key` change (nouvel avatar).
  var _pthWarnedUploadKey = null;
  // Parité upstream 665d80a (« avatar check with warning popup ») côté
  // web : le ré-encodage réseau (_pthCanvasToUpload, ci-dessous) tourne à
  // CHAQUE connexion, contrairement au sélecteur de fichier
  // (_processAvatarFile, pokerth-client.html) qui avertit déjà via _avWarn.
  // Un avatar qui passait ce premier contrôle peut quand même échouer ici
  // (PNG plus lourd que le JPEG affiché, décodeur qui échoue, etc.) — sans
  // ce relai l'annonce s'éteignait silencieusement à chaque login.
  function _pthWarnUpload(key, i18nKey, fallback) {
    if (key && key === _pthWarnedUploadKey) return;
    _pthWarnedUploadKey = key || null;
    try {
      if (typeof window._avWarn === 'function') { window._avWarn(i18nKey, fallback); return; }
    } catch (e) {}
    try {
      var m = (typeof t === 'function' ? t(i18nKey) : null) || fallback;
      if (typeof showToast === 'function') showToast(m, { tone: 'error', icon: '\u2715' });
    } catch (e) {}
  }
  function _pthClearMyUpload() {
    _pthUploadSrc = null;
    _pthUploadKey = null;
    _pthPendingKey = null;
    try { window._pthMyUpload = null; } catch(e) {}
  }
  function _pthPrepareMyUpload(dataUrl, key) {
    if (!dataUrl || typeof dataUrl !== 'string') { _pthClearMyUpload(); return; }
    if (dataUrl === _pthUploadSrc && window._pthMyUpload) return;
    _pthUploadSrc = dataUrl;
    var img = new Image();
    img.onload = function() {
      try {
        var SZ = 96;
        var cv = document.createElement('canvas');
        cv.width = SZ; cv.height = SZ;
        var ctx = cv.getContext('2d');
        var s = Math.min(img.width, img.height) || SZ;
        var sx = (img.width - s) / 2, sy = (img.height - s) / 2;
        ctx.drawImage(img, sx, sy, s, s, 0, 0, SZ, SZ);
        _pthCanvasToUpload(cv, key);
      } catch(e) { _pthWarnUpload(key, 'avImgFailed', 'This image could not be processed.'); _pthClearMyUpload(); }
    };
    img.onerror = function() { _pthWarnUpload(key, 'avImgInvalid', 'Invalid image.'); _pthClearMyUpload(); };
    img.src = dataUrl;
  }


  // Shared tail for the avatar-upload feature: take a 96x96 canvas, encode it
  // as PNG, enforce the server's size window [32, 30720], compute the MD5 and
  // publish window._pthMyUpload (consumed by buildInit + the AvatarRequest
  // handler). Out-of-range -> no announce (never a broken connection).
  //
  // FROZEN BYTES (rapport sp0ck 28/08 : le meme avatar arrivait au serveur
  // sous PLUSIEURS hashes) : le PNG encode ici est PERSISTE tel quel
  // (pth_avatar_up, base64) et resservi octet pour octet aux sessions
  // suivantes par _pthRefreshUpload. Auparavant l'image etait RE-encodee a
  // chaque session — or toBlob/toDataURL dependent de l'encodeur PNG et du
  // decodeur JPEG du navigateur DU JOUR : une mise a jour de Firefox, un
  // autre moteur, et les memes pixels donnaient d'autres octets, donc un
  // autre MD5 — le serveur accumulait un doublon par environnement. Le
  // desktop QML hashe les octets du FICHIER une fois pour toutes ; geler
  // notre PNG a l'encodage est l'equivalent web : un choix d'avatar = un
  // hash, stable a travers sessions et mises a jour.
  function _pthCanvasToUpload(cv, key) {
    cv.toBlob(function(blob) {
      if (key !== _pthPendingKey) return; // choix remplacé pendant l'encodage
      if (!blob) { _pthWarnUpload(key, 'avImgFailed', 'This image could not be processed.'); _pthClearMyUpload(); return; }
      blob.arrayBuffer().then(function(ab) {
        if (key !== _pthPendingKey) return;
        var bytes = new Uint8Array(ab);
        if (bytes.length > 30720) { _pthWarnUpload(key, 'avImgTooLarge', 'This image is too large. Please choose a smaller one.'); _pthClearMyUpload(); return; }
        if (bytes.length < 32) { _pthWarnUpload(key, 'avImgInvalid', 'Invalid image.'); _pthClearMyUpload(); return; }
        window._pthMyUpload = { bytes: bytes, hashBytes: _md5bytes(bytes), type: 1, size: bytes.length };
        if (key) {
          try {
            var b64 = '', i;
            for (i = 0; i < bytes.length; i++) b64 += String.fromCharCode(bytes[i]);
            localStorage.setItem('pth_avatar_up', JSON.stringify({ k: key, b64: btoa(b64) }));
          } catch (e) {} // stockage plein : on retombe sur le re-encodage d'avant, sans casser l'upload
        }
      }).catch(function() { if (key === _pthPendingKey) { _pthWarnUpload(key, 'avImgFailed', 'This image could not be processed.'); _pthClearMyUpload(); } });
    }, 'image/png');
  }
  function _pthHex(b) {
    var h = '', i;
    for (i = 0; i < b.length; i++) h += (b[i] < 16 ? '0' : '') + b[i].toString(16);
    return h;
  }
  function _pthAsciiBytes(str) {
    var out = new Uint8Array(str.length), i;
    for (i = 0; i < str.length; i++) out[i] = str.charCodeAt(i) & 0xff;
    return out;
  }
  // Recharge les octets geles si (et seulement si) ils correspondent au choix
  // courant. true = _pthMyUpload restaure, rien a re-encoder.
  function _pthLoadFrozenUpload(key) {
    try {
      var raw = localStorage.getItem('pth_avatar_up');
      if (!raw) return false;
      var rec = JSON.parse(raw);
      if (!rec || rec.k !== key || !rec.b64) return false;
      var bin = atob(rec.b64);
      var bytes = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      if (bytes.length < 32 || bytes.length > 30720) return false;
      window._pthMyUpload = { bytes: bytes, hashBytes: _md5bytes(bytes), type: 1, size: bytes.length };
      return true;
    } catch (e) { return false; }
  }
  // Render an EMOJI avatar to a PNG (dark PokerTH disc + the emoji centered),
  // so official clients see the same thing shown on the web seat.
  function _pthPrepareEmojiUpload(emoji) {
    try {
      var SZ = 96;
      var cv = document.createElement('canvas'); cv.width = SZ; cv.height = SZ;
      var ctx = cv.getContext('2d');
      ctx.beginPath(); ctx.arc(SZ/2, SZ/2, SZ/2, 0, Math.PI*2); ctx.closePath();
      ctx.fillStyle = '#1d222b'; ctx.fill();
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.font = "60px 'Apple Color Emoji','Segoe UI Emoji','Noto Color Emoji','Twemoji Mozilla',sans-serif";
      ctx.fillText(emoji, SZ/2, SZ/2 + 2);
      _pthCanvasToUpload(cv, 'emoji:' + emoji);
    } catch(e) { _pthClearMyUpload(); }
  }
  // Dispatcher: prepare the upload for WHATEVER avatar is selected.
  //   '__img__' -> custom image ; non-empty -> emoji string
  //   '__pth__' / '' (initial letter) -> nothing: like the QML client with an
  //   empty MyAvatar, no hash is announced and others see the default avatar.
  // De-duped by key so we don't re-render on every avatar refresh.
  function _pthRefreshUpload(stored, name) {
    try {
      // Chaque branche recharge d'abord les octets GELES du choix courant
      // (pth_avatar_up) : re-encoder ne se produit qu'au premier passage ou
      // apres un changement d'avatar (les writers de pth_avatar_img effacent
      // pth_avatar_up). C'est ce qui garde le hash serveur stable.
      if (stored === '__img__') {
        var url = null; try { url = localStorage.getItem('pth_avatar_img') || null; } catch(e) {}
        if (!url) { _pthClearMyUpload(); return; }
        var ki = 'img:' + url;
        if (ki === _pthUploadKey && window._pthMyUpload) return;
        _pthUploadKey = ki;
        // Clé de gel liée au CONTENU de l'image (MD5 du data URL) : une autre
        // image — import de sauvegarde, synchro, autre appareil — ne peut plus
        // se voir resservir les octets gelés d'une précédente. Ce qui part au
        // serveur est toujours ce qui est affiché (parité QML : un fichier, un
        // hash). L'ancienne clé fixe 'img' ne correspond plus : ré-encodage unique.
        var kf = 'img:' + _pthHex(_md5bytes(_pthAsciiBytes(url)));
        _pthPendingKey = kf;
        if (_pthLoadFrozenUpload(kf)) return;
        _pthPrepareMyUpload(url, kf);
      } else if (stored === '__pth__') {
        _pthClearMyUpload();
      } else if (stored) {
        var ke = 'emoji:' + stored;
        if (ke === _pthUploadKey && window._pthMyUpload) return;
        _pthUploadKey = ke;
        _pthPendingKey = ke;
        if (_pthLoadFrozenUpload(ke)) return;
        _pthPrepareEmojiUpload(stored);
      } else {
        // '' : l'initiale (choix « Aa », valeur par défaut). Parité QML : sans
        // avatar choisi, le client officiel n'annonce aucun hash — les autres
        // joueurs voient l'avatar par défaut, l'initiale reste locale.
        _pthClearMyUpload();
      }
    } catch(e) { _pthClearMyUpload(); }
  }

window.toggleAvatarPopup = function() {
  try { if (typeof window.avStudioReset === 'function') window.avStudioReset(); } catch (e) {}
  var popup = document.getElementById('avatar-popup');
  if (!popup) return;
  // A window fading out (pthMotion) counts as closed: tapping again reopens it.
  var isOpen = popup.style.display && popup.style.display !== 'none' && !popup._pthClosing;
  if (isOpen) {
    // Fermeture propre : retire la classe modale + réattache le popup à sa
    // place d'origine dans le formulaire (no-op si jamais ouvert en modale).
    if (typeof window.closeAvatarPickerFromLobby === 'function') window.closeAvatarPickerFromLobby();
    else popup.style.display = 'none';
  } else if (typeof window.openAvatarPickerFromLobby === 'function') {
    // Ouverture en fenêtre flottante centrée (même mécanisme que depuis le
    // lobby), mais sans les actions post-sélection propres au lobby.
    window.openAvatarPickerFromLobby({ onPicked: function(){} });
  } else {
    // Repli si le module n'est pas encore chargé : ouverture en flux.
    popup.style.display = 'block';
    if (typeof window.avpApplyDefaultCat === 'function') window.avpApplyDefaultCat();
  }
};

// selectAvatarPopup() lives in the <head> of pokerth-client.html. It
// must be defined inline so that buttons with onclick="selectAvatarPopup()"
// in the connect screen can call it before pokerth.js has loaded. A
// duplicate copy used to live here; it shadowed the head version and
// didn't know about the '__pth__' sentinel, leading to the visible
// '__pth__' string leaking into the trigger button. Removed.

// [Phase 2] toggleLang moved to public/modules/i18n.mjs (still global via window.toggleLang)

// [Phase 2] Évaluateur de main (_getCombos, _evalFive, _cmpHand,
// _qmlWinningHandText) déplacé dans public/modules/game/cards.mjs
// (toujours global via window.*).

// [Phase 2] Réactions rapides /emoji (compteurs, dédup 2 canaux, FX,
// mute/pin) déplacées dans public/modules/ui/reactions.mjs (toujours
// globales via window.*).


// [Phase 2] Force pré-flop, normalizeHoleCard, evaluateBestHand, glue phe et
// _oddsCompute déplacés dans public/modules/game/cards.mjs (toujours globaux
// via window.*).


function animateChipToPot(pid, amount) {
  // Source : siège du joueur localisé via data-pid (fiable indépendamment de l'ordre DOM)
  var seatEl = document.querySelector('#g-seats [data-pid="' + pid + '"]');
  if (!seatEl) return;
  var sr = seatEl.getBoundingClientRect();
  var sx = sr.left + sr.width  / 2;
  var sy = sr.top  + sr.height / 2;

  // Cible : libellé du pot (#g-pot dans le pot-strip)
  var potEl = document.getElementById('g-pot');
  var zone  = document.getElementById('g-table-zone');
  var tx, ty;
  if (potEl) {
    var pr = potEl.getBoundingClientRect();
    tx = pr.left + pr.width  / 2;
    ty = pr.top  + pr.height / 2;
  } else if (zone) {
    var zr = zone.getBoundingClientRect();
    tx = zr.left + zr.width  / 2;
    ty = zr.top  + zr.height / 2;
  } else {
    return;
  }

  // Créer le jeton volant
  var chip = document.createElement('div');
  chip.className = 'flying-chip';
  chip.textContent = amount > 0 ? (amount > 999 ? Math.round(amount / 100) / 10 + 'k' : amount) : '';
  chip.style.left      = sx + 'px';
  chip.style.top       = sy + 'px';
  chip.style.transform = 'scale(0.7)';
  document.body.appendChild(chip);

  requestAnimationFrame(function() {
    requestAnimationFrame(function() {
      chip.style.left      = tx + 'px';
      chip.style.top       = ty + 'px';
      chip.style.transform = 'scale(1.1)';
      chip.style.opacity   = '0';
      setTimeout(function() { if (chip.parentNode) chip.parentNode.removeChild(chip); }, 700);
    });
  });
}



// [Phase 2] setLang moved to public/modules/i18n.mjs (still global via window.setLang)

// ══ FULLSCREEN ══
function toggleFullscreen() {
  if (!document.fullscreenElement &&
      !document.webkitFullscreenElement &&
      !document.mozFullScreenElement) {
    // Enter fullscreen
    var el = document.documentElement;
    if      (el.requestFullscreen)       el.requestFullscreen();
    else if (el.webkitRequestFullscreen) el.webkitRequestFullscreen();
    else if (el.mozRequestFullScreen)    el.mozRequestFullScreen();
    else if (el.msRequestFullscreen)     el.msRequestFullscreen();
  } else {
    // Exit fullscreen
    if      (document.exitFullscreen)       document.exitFullscreen();
    else if (document.webkitExitFullscreen) document.webkitExitFullscreen();
    else if (document.mozCancelFullScreen)  document.mozCancelFullScreen();
    else if (document.msExitFullscreen)     document.msExitFullscreen();
  }
}

function _updateFsButtons() {
  var isFs = !!(document.fullscreenElement ||
    document.webkitFullscreenElement ||
    document.mozFullScreenElement);
  var icon = isFs ? '⊠' : '⛶';
  var title = isFs ? 'Exit fullscreen' : 'Fullscreen';
  ['fs-btn-connect','fs-btn-lobby','fs-btn-game'].forEach(function(id) {
    var btn = document.getElementById(id);
    if (btn) { btn.textContent = icon; btn.title = title; }
  });
}

// Listen for fullscreen change (user pressing Escape etc.)
['fullscreenchange','webkitfullscreenchange','mozfullscreenchange','MSFullscreenChange']
  .forEach(function(evt) { document.addEventListener(evt, _updateFsButtons); });

// iOS (iPhone) Safari n'expose AUCUNE API Fullscreen sur les éléments : le
// bouton ⛶ ne faisait donc rien. On masque toutes les commandes plein écran
// quand l'API est absente (détection de capacité, pas de sniff d'UA → on
// garde le bouton sur desktop / Android / iPad qui, eux, le supportent).
function _hideFullscreenIfUnsupported() {
  var de = document.documentElement;
  var supported = !!(de.requestFullscreen || de.webkitRequestFullscreen
                     || de.mozRequestFullScreen || de.msRequestFullscreen);
  if (supported) return;
  try {
    document.querySelectorAll('[onclick*="toggleFullscreen"]').forEach(function(el) {
      el.style.display = 'none';
    });
  } catch(e) {}
}
_hideFullscreenIfUnsupported();

/* ═══════════════════ PWA INSTALL ═══════════════════
   Chromium (Android, desktop Chrome/Edge) fires `beforeinstallprompt`,
   giving a native one-tap install flow. iOS Safari exposes NO such API,
   so we show manual "Add to Home Screen" instructions in a popup. Other
   browsers fall back to the same manual popup once they expose the event.
   The control stays hidden whenever the app already runs standalone
   (i.e. it's already installed). */
(function () {
  var _deferredPrompt = null;

  function _isStandalone() {
    return (window.navigator && window.navigator.standalone === true)
      || (window.matchMedia && window.matchMedia('(display-mode: standalone)').matches);
  }
  function _isIOS() {
    var ua = navigator.userAgent || '';
    // iPadOS 13+ masquerades as Macintosh → detect via touch points.
    return /iP(hone|ad|od)/.test(ua)
      || (/Macintosh/.test(ua) && navigator.maxTouchPoints > 1);
  }
  function _showBtn() { var b = document.getElementById('install-btn'); if (b) b.style.display = ''; }
  function _hideBtn() { var b = document.getElementById('install-btn'); if (b) b.style.display = 'none'; }

  function _tr(k, fallback) {
    try { if (typeof window.t === 'function') { var v = window.t(k); if (v && v !== k) return v; } } catch (e) {}
    return fallback;
  }

  // Capture Chromium's install event (suppress its own banner, defer to our button).
  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
    _deferredPrompt = e;
    if (!_isStandalone()) _showBtn();
  });

  // Once installed, retire the control.
  window.addEventListener('appinstalled', function () {
    _deferredPrompt = null;
    _hideBtn();
  });

  function _initInstallUI() {
    if (_isStandalone()) { _hideBtn(); return; }   // already installed → nothing to do
    if (_deferredPrompt)  { _showBtn(); return; }   // native prompt ready
    if (_isIOS())         { _showBtn(); return; }   // manual path (Safari has no event)
    // Other browsers: button is revealed by beforeinstallprompt above when it fires.
  }

  function _openManualPopup() {
    var body = document.getElementById('install-popup-body');
    var pop  = document.getElementById('install-popup');
    if (!body || !pop) return;
    var html;
    if (_isIOS()) {
      html =
        '<div class="ip-step"><span class="ip-ico">1.</span><span>' +
          _tr('installIosStep1', 'Tap the Share button <b>\u2191\u25A1</b> in Safari\u2019s toolbar.') + '</span></div>' +
        '<div class="ip-step"><span class="ip-ico">2.</span><span>' +
          _tr('installIosStep2', 'Choose <b>\u201CAdd to Home Screen\u201D</b>.') + '</span></div>' +
        '<div class="ip-step"><span class="ip-ico">3.</span><span>' +
          _tr('installIosStep3', 'Confirm with <b>Add</b> — the app lands on your home screen.') + '</span></div>';
    } else {
      html =
        '<div class="ip-step"><span class="ip-ico">\u22EE</span><span>' +
          _tr('installGenericStep1', 'Open your browser menu (\u22EE or \u22EF).') + '</span></div>' +
        '<div class="ip-step"><span class="ip-ico">\uFF0B</span><span>' +
          _tr('installGenericStep2', 'Choose <b>\u201CInstall app\u201D</b> or <b>\u201CAdd to Home Screen\u201D</b>.') + '</span></div>';
    }
    body.innerHTML = html;
    pop.style.display = 'flex';
  }

  // Wired to the install button in the connect icon bar.
  window.pwaInstall = function () {
    if (_deferredPrompt) {
      var dp = _deferredPrompt;
      _deferredPrompt = null;
      try { dp.prompt(); } catch (e) {}
      if (dp.userChoice && dp.userChoice.then) {
        dp.userChoice.then(function (res) {
          if (res && res.outcome === 'accepted') _hideBtn();
        }).catch(function () {});
      }
      return;
    }
    _openManualPopup();   // no native prompt → manual instructions
  };
  // Ace's Help (web.274): can « Install now » open the browser's own install prompt?
  window.pwaCanPrompt = function () { return !!_deferredPrompt && !_isStandalone(); };
  window.pwaInstalled = _isStandalone;
  window.pwaInstallClose = function () {
    var pop = document.getElementById('install-popup');
    if (pop) pop.style.display = 'none';
  };

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', _initInstallUI);
  } else {
    _initInstallUI();
  }
})();

// Unlock audio on first interaction
// [Phase 2] AudioContext warm-up moved to public/modules/sounds.mjs

/* ═══════════════════ */

/* Shared nickname across modes (pth_nick), single source of truth.
 *
 * Declared at TOP LEVEL on purpose: it is pure localStorage plumbing with no
 * DOM dependency, and callers such as App.onLoginModeChange() live outside the
 * DOMContentLoaded handler. Keeping it inside that handler made it hostage to
 * anything throwing earlier in the same handler (e.g. a bare identifier from a
 * module that failed to load), which silently killed the handler and left
 * window._pthNick undefined -> "Cannot read properties of undefined (reading
 * 'get')" on the next login-mode change. Fallback order below migrates the
 * legacy per-mode keys. The pokerth.net Guest name keeps its own rule
 * (GuestXXXXX via pth_guest_name, read-only field) and is never synced here.
 */
window._pthNick = {
  get: function () {
    try {
      return localStorage.getItem('pth_nick')
          || localStorage.getItem('pth_offline_nick')
          || localStorage.getItem('pth_lan_nick')
          || localStorage.getItem('pth_unauth_nick')
          || localStorage.getItem('pth_auth_login')
          || '';
    } catch (e) { return ''; }
  },
  set: function (v) {
    if (!v) return;
    try { localStorage.setItem('pth_nick', v); } catch (e) {}
  }
};

document.addEventListener("DOMContentLoaded", function() {
  // Auto-fill nick
  // One-time housekeeping: scrub the legacy 'pth_pass' key in case
  // it's still in localStorage from an older client version. The
  // password is NEVER persisted by this app — only the browser's
  // own keychain (via the <input autocomplete='current-password'>
  // attribute) holds it.
  try { localStorage.removeItem('pth_pass'); } catch(e) {}
  // Note: nickname restore for all modes is handled inside
  // App.onLoginModeChange(), which fires below once the saved mode
  // is reapplied. This gives us a single source of truth for the
  // 'which nickname to show for this mode' logic.
  // Restaurer l'avatar sauvegardé
  try {
    var savedAv = localStorage.getItem('pth_avatar') || '';
    selectAvatarPopup(savedAv);
  } catch(e) {}
  // Initialiser l'apparence du bouton d'assistance (état mémorisé).
  try { if (typeof window._applyAssistUI === 'function') window._applyAssistUI(); } catch(e) {}
  // Restore sound button state
  var sbtn = document.getElementById('sound-toggle-btn');
  if (sbtn && !window._soundEnabled) {
    sbtn.innerHTML = '<svg viewBox="0 0 24 24" style="display:block;width:22px;height:22px" fill="currentColor" aria-hidden="true"><path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73 4.27 3zM12 4L9.91 6.09 12 8.18V4z"/></svg>';
    sbtn.style.opacity = '0.5';
    sbtn.title = 'Unmute';
  }
  /**
   * Returns a stable Guest-XXXXX name persisted in localStorage.
   *
   * Without this, each tab / reload would generate a different random
   * Guest name. When several tabs of the same browser hit the server
   * within a few seconds (or worse: a desktop tab + a phone tab + a
   * PWA), the PokerTH server sees the same IP sending different Init
   * messages back-to-back and flags it as a brute-force attempt,
   * returning initBlocked for ~1 minute.
   *
   * By persisting one name per browser, all simultaneous sessions
   * from the same machine identify themselves with the same string,
   * which the server doesn't flag.
   *
   * Falls through to a fresh random name if localStorage is unavailable
   * (private mode under some browsers, disabled storage policy, etc.).
   */

  window.getOrCreateGuestName = function() {
    try {
      var k = 'pth_guest_name';
      var existing = localStorage.getItem(k);
      if (existing && /^Guest\d{5}$/.test(existing)) return existing;
      var fresh = 'Guest' + Math.floor(10000 + Math.random()*90000);
      localStorage.setItem(k, fresh);
      return fresh;
    } catch (e) {
      return 'Guest' + Math.floor(10000 + Math.random()*90000);
    }
  };

  var n = document.getElementById("nick");
  if (!n.value) n.value = window.getOrCreateGuestName();

  // Filter the avatar grid to a single category on load (otherwise the
  // connect-screen picker would show every category's emojis at once).
  try { if (typeof avpApplyDefaultCat === 'function') avpApplyDefaultCat(); } catch(e) {}

  // ── Share-link parameters (?host=&port=&tls=&table=) ──────────
  // If the page was opened from a "copy table link", prefill the
  // connect form with the encoded server params and remember which
  // table to auto-join once the lobby has loaded.
  // NOTE: this DOMContentLoaded block runs at GLOBAL scope (it is NOT
  // inside the App IIFE that contains handleMsg). So we publish the
  // pending table id on window._pendingAutoJoin, which the GameListNew
  // handler inside the IIFE reads. A bare `let _pendingAutoJoin` here
  // would be invisible to handleMsg and throw 'ReferenceError'.
  // window._shareLinkActive records that we arrived from a share link,
  // so the saved-prefs restore block below knows NOT to clobber the
  // host/port/mode we just prefilled, and so we can auto-connect.
  window._shareLinkActive = false;
  (function parseShareLink() {
    try {
      var sp = new URLSearchParams(window.location.search);
      var h = sp.get('host'), p = sp.get('port'),
          tls = sp.get('tls'), table = sp.get('table'),
          go = sp.get('go');
      // PWA manifest shortcuts open /?go=play or /?go=create. Remember the
      // intent on window so show('s-lobby') can fire it once the user has
      // connected and the lobby is visible. Read at GLOBAL scope (the App
      // IIFE's show() reads window._pendingGo).
      if (go === 'play' || go === 'create') window._pendingGo = go;
      // ?go=train (CTA of /play-against-computer): land on the connect screen
      // already in Local / training. Written as the saved server mode BEFORE
      // the saved-prefs restore below, so restore and the 400 ms select
      // watcher both agree on 'offline'; the 2-step wizard is then jumped to
      // the training form once restore has run (see _pendingTrainPick). The
      // player still presses Connect: nothing starts by itself.
      if (go === 'train') {
        window._pendingTrainPick = true;
        try { localStorage.setItem('pth_server_mode', 'offline'); } catch (eT) {}
      }
      if (h) { var hi = document.getElementById('host'); if (hi) hi.value = h; }
      if (p) { var pi = document.getElementById('port'); if (pi) pi.value = p; }
      if (tls !== null) {
        var ti = document.getElementById('use-tls');
        if (ti) ti.checked = (tls === '1');
      }
      // Legacy share links: keep the target authoritative across the
      // mode-change re-derives too (see _shareLanTarget in _lanFields).
      if (h) window._shareLanTarget = { host: h, port: p || '', tls: tls };
      if (table) {
        var t = parseInt(table, 10);
        // Published on window because parseShareLink runs at GLOBAL
        // scope (outside the App IIFE) — the GameListNew handler
        // inside the IIFE reads window._pendingAutoJoin.
        if (t > 0) window._pendingAutoJoin = t;
      }
      // When a share link targets a specific server, the most likely
      // intent is "join my friend's private server as an internet
      // guest". Pre-select that login mode so the guest doesn't have
      // to fiddle with the dropdown. Only override if a table was
      // actually specified (a bare host link could be anything).
      if (table) {
        var lm = document.getElementById('login-mode');
        if (lm && lm.value === 'auth') { /* keep credentialed if chosen */ }
        else if (lm) { lm.value = 'unauth'; if (App && App.onLoginModeChange) App.onLoginModeChange(); }
      }
      // ── Invite links (#join=<name>&s=<target>[&tls=1]) ──────────
      // Canonical share format (also parseable by the QML client): the
      // game NAME (stable while the table exists, unlike the numeric
      // gameId) plus the target server. Carried in the URL FRAGMENT so
      // it never reaches server/CDN logs. The password is NEVER part of
      // the link \u2014 joinGame() prompts for it if the table is protected.
      var joinName = '', joinSrv = '', joinTls = null;
      try {
        var hp = new URLSearchParams(String(window.location.hash || '').replace(/^#/, ''));
        joinName = hp.get('join') || '';
        joinSrv  = hp.get('s') || '';
        joinTls  = hp.get('tls');
      } catch(eH) {}
      // Lien protocolaire web+pokerth://join?name=<table>&s=<serveur>[&tls=1],
      // enregistre par manifest.protocol_handlers : le systeme nous passe
      // l'URL entiere dans ?proto=. Repli seulement (le #join= reste maitre).
      if (!joinName) {
        try {
          var _pr = sp.get('proto');
          if (_pr) {
            var _pu = decodeURIComponent(_pr), _pq = _pu.indexOf('?');
            var _pp = new URLSearchParams(_pq >= 0 ? _pu.slice(_pq + 1) : '');
            joinName = _pp.get('name') || _pp.get('join') || '';
            joinSrv  = _pp.get('s') || _pp.get('server') || '';
            joinTls  = _pp.get('tls');
          }
        } catch (eP) {}
      }
      if (joinName) {
        // Published on window (this block runs at GLOBAL scope, outside
        // the App IIFE) \u2014 consumed by onGameListNew in msg-lobby.mjs.
        window._pendingAutoJoinName = joinName;
        // Route the login wizard onto the mode matching the target:
        // 's=pokerth.net' \u2192 Internet (saved account if any, guest
        // otherwise) ; 's=<host[:port]>' \u2192 LAN / dedicated, prefilled.
        var _jMode = (!joinSrv || joinSrv === 'pokerth.net') ? 'pokerthnet' : 'lan-dedi';
        if (_jMode === 'lan-dedi') {
          var _jhp = joinSrv.split(':');
          var _jh = document.getElementById('host'); if (_jh) _jh.value = _jhp[0] || '';
          var _jp = document.getElementById('port'); if (_jp && _jhp[1]) _jp.value = _jhp[1];
          var _jt = document.getElementById('use-tls'); if (_jt && joinTls !== null) _jt.checked = (joinTls === '1');
          // The server-mode 'change' below re-derives the LAN fields via
          // _lanFields(), which would overwrite them with the player's saved
          // pth_lan_* / the instance defaults \u2014 losing the invite target.
          // Publish it on window so _lanFields() gives it top priority.
          window._shareLanTarget = { host: _jhp[0] || '', port: _jhp[1] || '', tls: joinTls };
        }
        // Set BEFORE the change event so every guarded re-derive path
        // (load / app-config / iOS select watcher) already sees the flag.
        window._shareLinkActive = true;
        var _jsm = document.getElementById('server-mode');
        if (_jsm) { _jsm.value = _jMode; _jsm.dispatchEvent(new Event('change', { bubbles: true })); }
        // Jump the 2-step wizard straight to that mode's form \u2014 same
        // path as a manual card tap (keeps back-bar icon/label in sync).
        try {
          var _jcard = document.querySelector('.login-card[onclick*="' + _jMode + '"]');
          if (_jcard && typeof loginPickMode === 'function') loginPickMode(_jcard, _jMode);
        } catch(eC) {}
        // Invite landing (web): show WHICH table the link points at on
        // the login screen and pre-focus the nickname field \u2014 the
        // invitee only types a name and connects. Static text is
        // translated via data-i18n (the catalogue may not be loaded yet
        // when this global code runs); only the table name is injected.
        try {
          var _jbn = document.getElementById('invite-banner-name');
          if (_jbn) _jbn.textContent = joinName;
          var _jbb = document.getElementById('invite-banner');
          if (_jbb) _jbb.style.display = '';
          setTimeout(function(){
            try {
              var _jn = document.getElementById('nick');
              if (_jn && _jn.offsetParent && !_jn.value) _jn.focus();
            } catch(eF) {}
          }, 400);
        } catch(eB) {}
        window._shareLinkActive = true;
        // If the shared table never shows up in the lobby list (already
        // finished, wrong server\u2026), tell the user instead of waiting
        // silently forever. The watch counts from the CONNECTION, not from
        // page load (modules/net/invite-link.mjs), so a friend slow to type
        // a nickname still gets the message and the stale name is dropped.
        if (window.InviteLink && window.InviteLink.armNotFoundWatch) window.InviteLink.armNotFoundWatch();
        else setTimeout(function(){
          try {
            var _S2 = window.PthState;
            if (window._pendingAutoJoinName && _S2 && _S2.loaded) {
              window._pendingAutoJoinName = '';
              if (typeof window.showKeyHint === 'function')
                window.showKeyHint((window.t || function(k){ return k; })('sharedTableNotFound'));
            }
          } catch(eN) {}
        }, 20000);
        try { window.history.replaceState({}, '', window.location.pathname); } catch(eR) {}
      }
      // A deliberate edit of the server fields releases the invite target:
      // from then on the player's own input is the truth again.
      try {
        ['host', 'port'].forEach(function (id) {
          var el = document.getElementById(id);
          if (el) el.addEventListener('input', function () { window._shareLanTarget = null; });
        });
      } catch (eL) {}
      if (h || p || table || go || sp.get('proto') || sp.get('share') || sp.get('open')) {
        // Only treat as a "share link" (which suppresses saved-prefs
        // restore of host/port/mode) when a server/table was actually
        // encoded. A bare ?go= shortcut must keep the user's saved server.
        if (h || p || table) window._shareLinkActive = true;
        // Clean the URL so a manual refresh doesn't re-trigger auto-join
        // (and so the link doesn't linger in the address bar). We keep
        // the pending join in memory (window._pendingAutoJoin).
        // ?lang= (a localized landing link) is kept: i18n.mjs may read it
        // after this runs, and it only ever applies to this visit.
        var _keepLang = sp.get('lang');
        try { window.history.replaceState({}, '', window.location.pathname + (_keepLang ? '?lang=' + encodeURIComponent(_keepLang) : '')); } catch(e) {}
      }
    } catch(e) {}
  })();

  // Detect the page's own host/port FIRST, before restoring the saved mode
  // (which triggers onLoginModeChange). onLoginModeChange's LAN/private
  // branches read hostInput.dataset.autoHost to reset the server host back to
  // this machine; if autoHost isn't set yet, switching from a pokerth.net
  // mode to LAN/private wouldn't restore the local host and the form kept
  // pokerth.net:7234 — which is exactly why it only worked after a refresh.
  (function () {
    var _h = window.location.hostname;
    var _hi = document.getElementById('host');
    if (_hi && _h && _h !== 'localhost' && _h !== '127.0.0.1') {
      _hi.dataset.autoHost = _h;
    }
  })();

  // Snapshot "premier visiteur ?" de façon SYNCHRONE, AVANT que le handler
  // window.load (-> onServerOrGuestChange) n'écrive pth_server_mode avec la
  // valeur par défaut du menu. Sans ce snapshot, _applyLoginDefaults (async,
  // via /app-config) verrait la clé déjà écrite et croirait à un visiteur
  // existant -> le mode par défaut admin (ex. pokerth.net) ne s'appliquait jamais.
  try { window._pthHadServerMode = (localStorage.getItem('pth_server_mode') !== null); }
  catch (e) { window._pthHadServerMode = true; }

  // Restaurer le serveur préféré sauvegardé — SAUF si on arrive d'un
  // lien de partage, auquel cas les paramètres du lien doivent gagner
  // (sinon le host sauvegardé d'une session précédente écrase celui
  // du lien d'invitation).
  try {
    if (!window._shareLinkActive) {
      var savedHost  = localStorage.getItem('pth_host');
      var savedPort  = localStorage.getItem('pth_port');
      var savedProxy = localStorage.getItem('pth_proxy');
      var savedMode  = localStorage.getItem('pth_login_mode');
      if (savedHost)  { var hi = document.getElementById('host');  if (hi) hi.value = savedHost; }
      if (savedPort)  { var pi = document.getElementById('port');  if (pi) pi.value = savedPort; }
      if (savedProxy) { var xi = document.getElementById('proxy'); if (xi) xi.value = savedProxy; }
      if (savedMode)  { var mi = document.getElementById('login-mode'); if (mi) { mi.value = savedMode; App.onLoginModeChange && App.onLoginModeChange(); } }
      // Restore the visible server-mode (incl. 'offline' = training) and re-derive
      // the WHOLE connect UI from it, so the hint + shown/hidden fields always match
      // the dropdown — even when the browser restored the <select> by itself without
      // firing onchange (the bug where training showed the LAN/unauth hint).
      var savedSrv = localStorage.getItem('pth_server_mode');
      var smEl = document.getElementById('server-mode');
      if (savedSrv && smEl) smEl.value = savedSrv;
      if (App.onServerOrGuestChange && smEl && (savedSrv || savedMode || smEl.value === 'offline')) {
        App.onServerOrGuestChange();
      }
    }
  } catch(e) {}
  // ?go=train: jump the wizard to the training form, as a tap on its card
  // would — unless the operator disabled training (card hidden, see
  // applyModes), in which case the normal first step stays.
  if (window._pendingTrainPick) {
    window._pendingTrainPick = false;
    try {
      var _tcard = document.querySelector('.login-card[onclick*="offline"]');
      var _tsm = document.getElementById('server-mode');
      var _topt = _tsm && Array.prototype.filter.call(_tsm.options, function (o) { return o.value === 'offline'; })[0];
      if (_tcard && _tcard.offsetParent !== null && !(_topt && _topt.disabled) && typeof loginPickMode === 'function') loginPickMode(_tcard, 'offline');
    } catch (eTP) {}
  }

  // Back/forward cache (bfcache) restores form state (incl. the server-mode
  // <select>) without firing onchange — re-sync the connect UI when shown.
  window.addEventListener('pageshow', function (ev) {
    if (ev.persisted) {
      try { if (!window._shareLinkActive && App && App.onServerOrGuestChange) App.onServerOrGuestChange(); } catch (e) {}
    }
  });

  // Some browsers (notably iOS Safari) restore the server-mode <select> value
  // AFTER deferred scripts run — i.e. after our restore above — without firing
  // onchange. Re-sync once more on window 'load', when the select holds its final
  // restored value, so the hint / label / nick always match the visible dropdown
  // (incl. training, which would otherwise keep the previous mode's UI).
  window.addEventListener('load', function () {
    try { if (!window._shareLinkActive && App && App.onServerOrGuestChange) App.onServerOrGuestChange(); } catch (e) {}
  });

  // ── App-mode gating (admin → /app-config). The connect screen offers three
  //    entry modes via #server-mode: lan-dedi (LAN), pokerthnet, offline (bots).
  //    The admin can disable any; we hide the matching <option> here. fetch() is
  //    async so this lands AFTER the synchronous restore above. The 400 ms watcher
  //    treats localStorage('pth_server_mode') as the single source of truth, so if
  //    the mode we'd land on is disabled we rewrite that key to the first enabled
  //    mode — otherwise the watcher would keep forcing the disabled choice back.
  (function () {
    var MAP = { 'lan-dedi': 'lan', 'pokerthnet': 'pokerthnet', 'offline': 'offline' };
    function applyModes(modes) {
      var sm = document.getElementById('server-mode');
      if (!sm || !sm.options || !sm.options.length) return;
      var firstEnabled = null;
      for (var i = 0; i < sm.options.length; i++) {
        var opt = sm.options[i], key = MAP[opt.value], off = key && modes[key] === false;
        if (off) { opt.hidden = true; opt.disabled = true; opt.style.display = 'none'; }
        else if (firstEnabled === null) firstEnabled = opt.value;
      }
      if (firstEnabled === null) return;
      var want = null; try { want = localStorage.getItem('pth_server_mode'); } catch (e) {}
      var effective = want || sm.value;
      if (MAP[effective] && modes[MAP[effective]] === false) {
        try { localStorage.setItem('pth_server_mode', firstEnabled); } catch (e) {}
        sm.value = firstEnabled;
        try { if (window.App && App.onServerOrGuestChange) App.onServerOrGuestChange(); } catch (e) {}
      }
    }
    // First-visit default theme (admin → /app-config.defaultTheme). Applied ONCE,
    // and only when this browser has no theme picked yet — existing users keep
    // theirs. window.applyThemePreset comes from modules/theme.mjs (a module loaded
    // async), so we poll briefly for it. The preset writes the axis localStorage
    // keys, so on the next visit the early <head> applier restores it (zero flash)
    // and this guard short-circuits — it never re-applies.
    function _applyDefaultTheme(presetId) {
      if (!presetId) return;
      // theme.mjs writes every axis as it boots, so a stored key no longer
      // means the player chose: the <head> notes which axes were empty when
      // the page started (window._pthLookFresh). Older pages fall back to the
      // stored keys, as before.
      var _fr = window._pthLookFresh;
      if (_fr) { if (!(_fr.palette && _fr.table && _fr.deck)) return; }
      else try {
        var keys = ['pth_theme', 'pth_table', 'pth_deck', 'pth_buttons', 'pth_pucks', 'pth_seat', 'pth_cardback', 'pth_cardback_img', 'pth_cardback_ext'];
        for (var i = 0; i < keys.length; i++) { if (localStorage.getItem(keys[i]) !== null) return; }
      } catch (e) { return; }
      if (_fr) { _fr.palette = false; _fr.table = false; _fr.deck = false; }
      var tries = 0;
      (function waitApply() {
        if (typeof window.applyThemePreset === 'function') { try { window.applyThemePreset(presetId); } catch (e) {} return; }
        if (tries++ < 60) setTimeout(waitApply, 50);
      })();
    }
    // First-visit look (admin → /app-config.lookDefaults): palette, table,
    // deck, seats through theme.mjs (first visit per axis, see applyFirstVisit),
    // and the interface size, written only if this browser never set one.
    function _applyLookDefaults(look) {
      if (!look || typeof look !== 'object') return;
      if (look.size === 'standard' || look.size === 'large' || look.size === 'extra-large') {
        try { if (localStorage.getItem('pth_interface_size') === null) { localStorage.setItem('pth_interface_size', look.size); if (typeof window.applyAccessibilityPreferences === 'function') window.applyAccessibilityPreferences(); } } catch (e) {}
      }
      var tries = 0;
      (function waitTheme() {
        if (window.THEME && typeof window.THEME.applyFirstVisit === 'function') { try { window.THEME.applyFirstVisit(look); } catch (e) {} return; }
        if (tries++ < 60) setTimeout(waitTheme, 50);
      })();
    }
    // First-visit default in-game settings (admin → /app-config.defaults). Same
    // first-visit-only rule as the theme, applied per toggle: we write each flag
    // ONLY when this browser has never set it, so a player's own choice is never
    // overridden, and once written it is never re-applied. Values are '0'/'1'
    // ('1' = on/active), matching the in-game toggles. Note: the menu reflects
    // these the moment it is opened; the flags the game state reads at load are
    // pushed into it as well (see LIVE below).
    function _applyDefaultSettings(defaults) {
      if (!defaults || typeof defaults !== 'object') return;
      var MAP = { haptic: 'pth_haptic', voice: 'pth_voice', assist: 'pth_assist', displaybb: 'pth_display_bb', sound: 'pth_sound', contrast: 'pth_high_contrast' };
      // These four flags are read into the game state when the modules load,
      // before /app-config answers: a default written now is pushed into that
      // state too, so it holds on the first visit instead of the second.
      var LIVE = {
        haptic: function (v, st) { st._hapticEnabled = (v !== '0'); },
        voice: function (v, st) { st._voiceEnabled = (v === '1'); },
        assist: function (v, st) { st._assistOn = (v !== '0'); },
        displaybb: function (v, st) { st._displayBB = (v === '1'); },
        // sounds.mjs re-reads pth_sound before every sound; the storage event
        // refreshes the header button at once. Contrast is applied live.
        sound: function () { try { window.dispatchEvent(new StorageEvent('storage', { key: 'pth_sound' })); } catch (e) {} },
        contrast: function () { try { if (typeof window.applyAccessibilityPreferences === 'function') window.applyAccessibilityPreferences(); } catch (e) {} }
      };
      Object.keys(MAP).forEach(function (k) {
        var v = defaults[k];
        if (v !== '0' && v !== '1') return;
        try {
          if (localStorage.getItem(MAP[k]) !== null) return;
          localStorage.setItem(MAP[k], v);
          if (k === 'sound' || k === 'contrast') LIVE[k](v);
          else if (window.PthState) LIVE[k](v, window.PthState);   // modules/game/state.mjs
        } catch (e) {}
      });
    }
    // Default login form (admin → /app-config.loginDefaults). Two knobs:
    //  • mode — pre-selects the entry screen on a FIRST visit only (a returning player
    //           keeps whatever they last chose);
    //  • host — points LAN / dedicated at a specific server. The LAN/unauth branches
    //           derive BOTH host and proxy from hostInput.dataset.autoHost and rebuild
    //           them on every (re)connect, so the proxy auto-follows the host and can
    //           never go stale — the client always reconnects to this server.
    // A share link still wins; we re-derive the connect UI once at the end.
    // Politique d'instance sur le champ proxy, RÉÉVALUÉE à chaque changement de
    // mode : elle ne vaut qu'en LAN / serveur dédié. En Internet (pokerth.net)
    // et en entraînement, le proxy n'est pas un choix d'infra locale — on ne
    // force rien et on ne masque rien (demande narmod 22/07).
    //   url  : adresse imposée, champ verrouillé (vide = auto-détection) ;
    //   hide : champ + libellé (#f-proxy) masqués.
    window._applyProxyPolicy = function () {
      var pol = window._pthProxyPolicy || {};
      var sm = document.getElementById('server-mode');
      var isLan = !!(sm && sm.value === 'lan-dedi');
      var px = document.getElementById('proxy');
      if (px) {
        if (isLan && pol.url) {
          if (px.value !== pol.url) px.value = pol.url;
          px.readOnly = true;
          px.dataset.forced = '1';
        } else if (px.dataset && px.dataset.forced === '1') {
          px.readOnly = false;
          delete px.dataset.forced;
        }
      }
      var fp = document.getElementById('f-proxy');
      if (fp) fp.style.display = (isLan && pol.hide) ? 'none' : '';
    };

    // Mémoire LAN du joueur, écrite à chaque connexion en LAN / serveur dédié.
    // On ne retient QUE ce qu'il a délibérément changé par rapport à la valeur
    // par défaut de l'instance : si sa saisie correspond à cette valeur, la clé
    // est effacée. Sans cette règle, la première connexion figerait l'adresse
    // du moment dans le navigateur et un déménagement du serveur (côté admin)
    // ne serait plus jamais suivi par les joueurs déjà venus.
    window._pthLanRemember = function () {
      try {
        var lm = document.getElementById('login-mode');
        if (!lm || (lm.value !== 'lan' && lm.value !== 'unauth')) return;
        // Garde-fou : le mode entraînement force login-mode='unauth' alors que les
        // champs serveur (masqués) gardent les valeurs du mode précédent (ex.
        // Internet, TLS coché). Sans ce test, un Connect en entraînement les
        // persistait comme préférences LAN — au retour en LAN, hôte/port changés
        // et TLS coché. Seul le mode LAN / dédié VISIBLE peut mémoriser.
        var smR = document.getElementById('server-mode');
        if (!smR || smR.value !== 'lan-dedi') return;
        var d = window._pthLanDefaults ? window._pthLanDefaults() : null;
        if (!d) return;
        var put = function (k, v, dflt) {
          try { if (v === dflt) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) {}
        };
        var hi = document.getElementById('host');
        var pi = document.getElementById('port');
        var ti = document.getElementById('use-tls');
        if (hi) put('pth_lan_host', hi.value.trim(), d.host);
        if (pi) put('pth_lan_port', pi.value.trim(), d.port);
        if (ti) put('pth_lan_tls', ti.checked ? '1' : '0', d.tls ? '1' : '0');
      } catch (e) {}
    };
    // Valeurs par défaut des champs serveur en LAN / dédié, dérivées de la
    // politique d'instance. Partagées par _lanFields() (remplissage) et
    // _pthLanRemember() (mémorisation) pour que les deux ne divergent jamais.
    // A server address the player typed in the LAN form is marked (data-typed)
    // so a later re-derive of the form keeps it: /app-config answering after
    // the player had typed (slow network) used to put the saved address or
    // port 7234 back (_lanFields, via _applyLoginDefaults). The pokerth.net
    // modes, which write their own address, clear the mark.
    try {
      document.addEventListener('input', function (ev) {
        var el = ev && ev.target;
        if (el && (el.id === 'host' || el.id === 'port')) el.dataset.typed = '1';
      }, true);
    } catch (eT) {}
    window._pthLanDefaults = function () {
      var pol = window._pthLanPolicy || {};
      var hi = document.getElementById('host');
      var auto = (hi && hi.dataset && hi.dataset.autoHost) || window.location.hostname || '';
      return {
        host: (pol.forced && pol.host) ? pol.host : auto,
        port: (pol.forced && pol.port) ? pol.port : '7234',
        tls: !!(pol.forced && pol.tls)
      };
    };
    function _applyLoginDefaults(login) {
      if (!login || typeof login !== 'object') return;
      // Réglages d'INSTANCE sur le champ « URL du proxy WebSocket ». Ils
      // s'appliquent même via un lien de partage, car ils décrivent l'infra du
      // serveur qui sert la page (et non le choix du joueur) — mais UNIQUEMENT
      // en mode LAN / serveur dédié (voir _applyProxyPolicy).
      window._pthProxyPolicy = { url: login.proxyUrl || '', hide: !!login.hideProxy };
      try { window._applyProxyPolicy(); } catch (e) {}
      // Politique d'INSTANCE sur le serveur LAN / dédié (admin → « Default login
      // form »). Elle ne fixe que la VALEUR PAR DÉFAUT des champs serveur :
      //   forced : l'hôte, le port et le TLS choisis par l'admin ;
      //   auto   : l'adresse de la page, le port 7234, sans TLS.
      // Dans les DEUX cas, ce que le joueur a saisi en dernier (pth_lan_host /
      // pth_lan_port / pth_lan_tls) est prioritaire et les champs restent
      // éditables — la politique n'impose jamais rien, elle propose.
      window._pthLanPolicy = {
        forced: (login.lanMode === 'forced'),
        host: login.host || '',
        port: (login.lanPort > 0) ? String(login.lanPort) : '',
        tls: !!login.lanTls
      };
      if (window._shareLinkActive) return;
      // En mode forcé seulement : l'hôte de l'admin devient aussi l'« autoHost »,
      // dont l'URL du proxy WebSocket est dérivée — le proxy suit donc le serveur
      // et ne peut pas rester périmé (comportement historique conservé).
      if (login.host && login.lanMode === 'forced') { try { var _hi = document.getElementById('host'); if (_hi) _hi.dataset.autoHost = login.host; } catch (e) {} }
      // Default entry mode: pre-select it on a first visit only if it's an enabled option.
      if (login.mode) {
        var hadMode = (window._pthHadServerMode !== false); // snapshot pris au chargement, avant que load n'écrive la clé
        if (!hadMode) {
          var sm = document.getElementById('server-mode');
          if (sm) {
            var okOpt = false;
            for (var i = 0; i < sm.options.length; i++) { if (sm.options[i].value === login.mode && !sm.options[i].disabled) { okOpt = true; break; } }
            if (okOpt) {
              sm.value = login.mode;
              var gc = document.getElementById('guest-mode-cb'); if (gc) gc.checked = (login.mode === 'pokerthnet'); // pokerth.net → Guest (no friction)
            }
          }
        }
      }
      try { if (window.App && App.onServerOrGuestChange) App.onServerOrGuestChange(); } catch (e) {}
    }
    // Server identity + admin table defaults pushed from /app-config.
    function _applyBranding(c) {
      if (!c) return;
      if (c.tableDefaults && typeof c.tableDefaults === 'object') window._adminTableDefaults = c.tableDefaults;
      if (c.tableNames && typeof c.tableNames === 'object') window._adminTableNames = c.tableNames;
      if (c.serverName) {
        var tn = document.querySelector('#s-connect .card-title-big');
        if (tn) tn.textContent = c.serverName;
        try { document.title = c.serverName; } catch (e) {}
      }
      if (c.serverTagline) {
        var ts = document.querySelector('#s-connect .card-subtitle');
        if (ts) ts.textContent = c.serverTagline;
      }
    }
    window._setSrvSourceTag = function (show) {
      var el = document.getElementById('srv-source-tag');
      if (!el) return;
      if (!show || window._pthNetSource !== 'auto') { el.style.display = 'none'; el.textContent = ''; el.removeAttribute('title'); return; }
      var resolved = !!(window._pthNetServer && window._pthNetServer.host);
      el.style.display = 'inline-block';
      if (resolved) {
        el.textContent = '\uD83C\uDF10 auto \u00b7 serverlist';
        el.style.color = 'var(--ok, #4ade80)';
        el.title = 'Server taken from the official PokerTH serverlist (auto-updating)';
      } else {
        el.textContent = '\uD83C\uDF10 auto \u00b7 serverlist \u26a0';
        el.style.color = 'var(--warn, #f59e0b)';
        el.title = 'Serverlist unreachable — using the built-in pokerth.net fallback';
      }
    };
    // Lecteur MP3 : interrupteur d'instance (admin -> onglet Music). Coupe, les 4
    // entrees 🎵 des menus ••• disparaissent et le panneau se referme s'il etait
    // ouvert. Les menus ••• sont fermes au boot, donc l'arrivee asynchrone de
    // /app-config ne provoque aucun clignotement visible. Cle absente = actif.
    function _applyMusicFlag(on) {
      window._musicOff = !on;
      ['music-toggle-connect-mob', 'music-toggle-lobby-mob', 'music-toggle-create-mob', 'music-toggle-game-mob']
        .forEach(function (id) { var el = document.getElementById(id); if (el) el.style.display = on ? '' : 'none'; });
      if (!on) { var mp = document.getElementById('music-panel'); if (mp) mp.style.display = 'none'; }
    }
    // Interrupteurs d'arrêt poussés par l'admin. La case correspondante des
    // Options avancées est décochée, gelée et étiquetée : le joueur voit
    // pourquoi elle ne répond pas, plutôt qu'une case qui refuse de rester
    // cochée. On rejoue applyAdvOpts() ensuite, car /app-config arrive après.
    function _applyFeatureOff(list) {
      var map = {};
      for (var i = 0; i < list.length; i++) map[String(list[i])] = true;
      window._pthFeatureOff = map;
      // Last known list, read back at boot by pokerth-client.html: what runs
      // once at startup (splash, back guard) is then already off next visit.
      try { localStorage.setItem('pth_feature_off', JSON.stringify(Object.keys(map))); } catch (e) {}
      // Features installed at boot re-read their switch now.
      try { if (typeof window.refreshBackGuard === 'function') window.refreshBackGuard(); } catch (e) {}
      try { if (typeof _loupeBtnSync === 'function') _loupeBtnSync(); } catch (e) {}
      try {
        var rows = document.querySelectorAll('.adv-row input[type=checkbox]');
        for (var j = 0; j < rows.length; j++) {
          var inp = rows[j], oc = inp.getAttribute('onchange') || '';
          var m = oc.match(/setAdvOpt\('([a-z_0-9]+)'/), fk = m ? m[1] : inp.getAttribute('data-feat');
          if (!fk) continue;
          var off = !!map[fk];
          inp.disabled = off;
          if (off) inp.checked = false;
          var row = inp.closest ? inp.closest('.adv-row') : null;
          if (!row) continue;
          row.classList.toggle('adv-locked', off);
          var tag = row.querySelector('.adv-lockedtag');
          if (off && !tag) {
            tag = document.createElement('em');
            tag.className = 'adv-webtag adv-lockedtag';
            tag.setAttribute('data-i18n', 'advOffByAdmin');
            tag.textContent = (typeof window.t === 'function') ? window.t('advOffByAdmin') : 'off (admin)';
            row.appendChild(tag);
          } else if (!off && tag) { tag.remove(); }
        }
      } catch (e) {}
      try { applyAdvOpts(); } catch (e) {}
      try { _applyChatTranslateFlag(); } catch (e) {}
    }
    // /app-config carries the admin's choices, the Internet transport among
    // them (« Via proxy » / « Direct »), and nothing else may decide it: the
    // gate in App.connect holds every dial until this loader has settled.
    //  - 200 with a JSON object: applied, then the gate is released;
    //  - 404: this site has no admin config at all (the client served as
    //    static files): the built-in defaults ARE the configuration, release;
    //  - anything else (network error, 5xx, the service worker's 503
    //    « Offline », no answer within 10 s, a body that is not JSON) says
    //    nothing about the admin's choice: keep the gate shut and ask again,
    //    after 1, 2, 4, 8 s, then every 10 s.
    // Until web.229 every failure released the gate after at most 5 s with
    // the transport unknown, read as « Direct »: players of a « Via proxy »
    // instance on a slow network went straight to pokerth.net (seen in the
    // admin as « Direct client » notice channels, 21/10/2026).
    var _cfgTries = 0;
    function _applyAppConfig(c) {
      window._pthNetServer = (c.pokerthnetServer && c.pokerthnetServer.host) ? c.pokerthnetServer : null; window._pthNetSource = (c.pokerthnetSource === 'auto') ? 'auto' : 'manual'; window._pthNetTransport = (c.internetTransport === 'proxy') ? 'proxy' : 'direct'; window._pthLiveTransport = (c.liveTransport === 'proxy' || c.liveTransport === 'direct') ? c.liveTransport : 'inherit'; window._pthLiveDefaults = c.liveDefaults || null;
      try { if (c && c.modes) applyModes(c.modes); if (c) _applyMusicFlag(c.musicEnabled !== false); if (c && c.loginDefaults) _applyLoginDefaults(c.loginDefaults); if (c && c.welcome && c.welcome.enabled && typeof window.maybeShowWelcome === 'function') window.maybeShowWelcome(c.welcome); window._guestNoticeCfg = (c && c.guestNotice) || null; window._authNoticeCfg = (c && c.authNotice) || null; window._lanNoticeCfg = (c && c.lanNotice) || null; if (typeof window._pollSetConfig === 'function') window._pollSetConfig(c && c.poll); if (c) { var _lvT = (window.LIVE_MODE && c.liveDefaults && c.liveDefaults.theme) ? c.liveDefaults.theme : null; if (_lvT) _applyDefaultTheme(_lvT); else { if (typeof c.defaultTheme === 'string') _applyDefaultTheme(c.defaultTheme); if (c.lookDefaults) _applyLookDefaults(c.lookDefaults); } } if (c && typeof c.showLoginTitle === 'boolean') { try { document.body.classList.toggle('adv-show-title', c.showLoginTitle); } catch (e) {} } if (c && c.defaults) _applyDefaultSettings(c.defaults); if (c && Array.isArray(c.featureOff)) _applyFeatureOff(c.featureOff); window._lanDirCfg = (c && c.lanDirectory) || null; try { if (window.LanDirUI) window.LanDirUI.setConfig(window._lanDirCfg); } catch (e) {} _applyBranding(c); try { if (!window._shareLinkActive && window.App && App.onServerOrGuestChange) App.onServerOrGuestChange(); } catch (e) {} } catch (e) { try { console.error('[app-config] apply failed:', e); } catch (_e) {} }
    }
    function _releaseCfgGate() {
      window._appConfigSettled = true;
      var q = window._appConfigWaiters || []; window._appConfigWaiters = [];
      q.forEach(function (f) { try { f(); } catch (e) {} });
    }
    function go() {
      var ac = (typeof AbortController === 'function') ? new AbortController() : null;
      var tmo = ac ? setTimeout(function () { try { ac.abort(); } catch (e) {} }, 10000) : null;
      fetch('/app-config', ac ? { cache: 'no-store', signal: ac.signal } : { cache: 'no-store' })
        .then(function (r) {
          if (r.status === 404) return null;
          if (!r.ok) throw new Error('HTTP ' + r.status);
          return r.json().then(function (c) {
            if (!c || typeof c !== 'object') throw new Error('not a config object');
            return c;
          });
        })
        .then(function (c) {
          if (tmo) clearTimeout(tmo);
          if (c) _applyAppConfig(c);
          _releaseCfgGate();
        }, function (err) {
          if (tmo) clearTimeout(tmo);
          _cfgTries++;
          var d = Math.min(10000, 1000 * Math.pow(2, _cfgTries - 1));
          try { console.warn('[app-config] ' + ((err && err.message) || err) + ' - retry in ' + d + ' ms'); } catch (e) {}
          // A player is waiting on the gate: after the third miss, say it is slow.
          try {
            if (_cfgTries >= 3 && (window._appConfigWaiters || []).length && typeof window.setStatus === 'function') {
              window.setStatus('⏳ ' + ((typeof window.t === 'function' && window.t('connectSlow')) || 'Initialisation…'));
            }
          } catch (e) {}
          setTimeout(go, d);
        });
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', go); else go();
  })();

  // iOS Safari restores <select> values at an UNPREDICTABLE time — sometimes
  // even after 'load' — and WITHOUT firing onchange, silently desyncing the
  // connect UI from the visible dropdown (e.g. menu shows training but the hint
  // /label/nick stay on the previous mode). autocomplete=off is ignored there,
  // so we can't prevent it; instead we briefly watch the server-mode value after
  // load and re-derive the UI whenever it changes — whenever iOS lands it.
  (function () {
    var sm = document.getElementById('server-mode');
    if (!sm) return;
    // iOS Safari restores <select> values at unpredictable times — and keeps
    // FLIP-FLOPPING them — WITHOUT firing onchange, so the visible dropdown can
    // silently disagree with the user's real choice; re-deriving the UI off that
    // wrong value is exactly what rewrote the training screen with the previous
    // mode's pseudo / label / hint. So treat localStorage (pth_server_mode, written
    // on every REAL onchange) as the SINGLE SOURCE OF TRUTH: whenever the <select>
    // drifts from it, force it back and re-derive the whole connect UI. Permanent
    // and cheap (one compare / 400 ms); never fights the native picker (focused).
    setInterval(function () {
      if (window._shareLinkActive) return;
      // Ce contournement ne concerne QUE l'écran de connexion : ne rien faire
      // ailleurs (lobby/table) évite un réveil CPU ~2,5x/s inutile à vie (batterie).
      var _sc = document.getElementById('s-connect');
      if (!_sc || !_sc.classList.contains('active')) return;
      var want = null; try { want = localStorage.getItem('pth_server_mode'); } catch (e) {}
      if (want && sm.value !== want && document.activeElement !== sm) {
        sm.value = want;
        try { if (App && App.onServerOrGuestChange) App.onServerOrGuestChange(); } catch (e) {}
      }
      // While in training, hold the isolated training UI against late restoration:
      // login-mode on a no-account value (so setLang can't print the account label
      // and connect() can't demand a password), re-assert the free-nick label, and
      // restore the isolated pseudo (never while the user is actively typing).
      if (window._offlineMode || sm.value === 'offline') {
        var _lmf = document.getElementById('login-mode'); if (_lmf && _lmf.value !== 'unauth') _lmf.value = 'unauth';
        var _lblf = document.getElementById('nick-label');
        try { if (_lblf && window.I18N && window.I18N.t) _lblf.textContent = window.I18N.t('enterNickFree'); } catch (e) {}
        var _nf = document.getElementById('nick');
        var _w = window._pthNick.get();
        if (_nf && document.activeElement !== _nf && _nf.value !== _w) _nf.value = _w;
        // The hint (#cstatus) isn't reasserted above, so a network-mode hint that
        // leaked in from a previous mode ('Chat… serveur privé', 'Entrez vos
        // identifiants pokerth.net', LAN note, guest hint) would persist in
        // training. Repair it — but ONLY when it currently shows one of those
        // KNOWN network hints, never a transient message (Initialisation…, errors),
        // so legitimate status text is left untouched.
        try {
          var T = (window.I18N && window.I18N.t) ? window.I18N.t : null;
          var _cs = document.getElementById('cstatus');
          if (T && _cs && window._forceOfflineHint) {
            var _t = _cs.textContent;
            if (_t === T('chatAvailPrivate') || _t === T('enterCredentials') ||
                _t === T('lanModeNote') || _t === T('guestHint')) {
              window._forceOfflineHint();
            }
          }
        } catch (e) {}
      }
    }, 800);
  })();

  // Pseudo PARTAGÉ : persisté à chaque frappe dans tous les modes éditables
  // (entraînement, LAN, dédié, compte pokerth.net). Le champ invité est
  // readonly → aucun événement 'input', le GuestXXXXX ne peut donc jamais
  // fuiter dans pth_nick.
  (function () {
    var _nk = document.getElementById('nick');
    if (_nk) _nk.addEventListener('input', function () {
      if (!_nk.hasAttribute('readonly')) window._pthNick.set(_nk.value.trim());
    });
  })();

  // Auto-fill proxy URL from current page URL
  var proto = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  var host  = window.location.hostname;
  var port  = window.location.port || (proto === 'wss:' ? '443' : '80');
  var wsUrl = proto + '//' + host + ':' + port;
  var proxyInput = document.getElementById("proxy");
  if (proxyInput) proxyInput.value = wsUrl;

  // Auto-fill PokerTH server host (same machine by default on LAN)
  var hostInput = document.getElementById("host");
  if (hostInput && host !== 'localhost' && host !== '127.0.0.1') {
    hostInput.dataset.autoHost = host; // remember the auto-detected value
    // Do NOT override the host if the current login mode targets pokerth.net
    // (onLoginModeChange already set it correctly above) — and NOT if we
    // arrived from a share link (its host param must win).
    var __modeEl = document.getElementById('login-mode');
    var __currentMode = __modeEl ? __modeEl.value : '';
    if (!window._shareLinkActive && __currentMode !== 'guest' && __currentMode !== 'auth') {
      hostInput.value = host;
    }
  }

  // ── Auto-connect from a share link ────────────────────────────
  // If we arrived via a "copy table link", connect automatically so
  // the guest lands straight in the lobby (and then auto-joins the
  // shared table via window._pendingAutoJoin). The nick field is
  // already populated — either a saved per-mode nick or a generated
  // guest name — so connect() has everything it needs. If for some
  // reason the nick is empty, we focus it instead and let the user
  // hit Connect themselves.
  if (window._shareLinkActive) {
    setTimeout(function() {
      try {
        var nickEl = document.getElementById('nick');
        var hasNick = nickEl && nickEl.value.trim();
        if (!hasNick) {
          // No usable nick — focus the field so the user just types
          // a name and hits enter/Connect.
          if (nickEl) { nickEl.focus(); }
          return;
        }
        // Invite link \u2192 pokerth.net with a registered account
        // selected but no saved password: don't fire a doomed connect;
        // focus the password field instead (the pending auto-join
        // survives until the user hits Connect).
        var _lmEl = document.getElementById('login-mode');
        var _pwEl = document.getElementById('pass');
        if (_lmEl && _lmEl.value === 'auth' && _pwEl && !_pwEl.value) { _pwEl.focus(); return; }
        if (App && typeof App.connect === 'function') {
          App.connect();
        }
      } catch(e) {}
    }, 350); // small delay so the SW-ready gate + form are settled
  }
});

/* ═══════════════════ */

// [Phase 2] Proto (encodeur/décodeur protobuf minimal) déplacé dans
// public/modules/net/proto.mjs (toujours global via window.Proto).


// [Phase 2] PTHCrypto (déchiffrement AES des cartes pokerth.net) déplacé
// dans public/modules/net/crypto.mjs (toujours global via window.PTHCrypto).


// [Phase 2] MSG (constructeurs/parseur des messages PokerTH + SCRAM) déplacé
// dans public/modules/net/messages.mjs (toujours global via window.MSG).


// ═══════════════════════════════════════════════════════════
//  APPLICATION
// ═══════════════════════════════════════════════════════════
const App = (() => {
  const S = window.PthState; // état partagé — modules/game/state.mjs (ESM #9e)
  const $ = id => document.getElementById(id); // restauré (hotfix 0.3.849 — avalé par le segment 9f-10)

  // ── Reconnect backoff: what counts as a successful attempt ────────────
  // A PokerTH server sends its Announce the instant the socket opens, so
  // "some bytes arrived" proves nothing about the connection being usable.
  // A target that hangs up right after the Announce (server-side
  // anti-brute-force, PROXY-protocol mismatch, ban) therefore used to reset
  // the attempt counter on every try: the backoff never grew past its first
  // step and the client hammered the server every 5 s forever, which is what
  // earns the "blockedByServer" reply in the end. An attempt now only counts
  // as successful once the socket has STAYED open for a few seconds (or once
  // an InitAck lands, which resets the counter from msg-lobby.mjs).
  const RECONNECT_STABLE_MS = 10000;
  function _armReconnectStable() {
    clearTimeout(window._reconnectStableTimer);
    const w = S.ws;
    window._reconnectStableTimer = setTimeout(function () {
      if (S.ws === w && S.ws && S.ws.readyState === WebSocket.OPEN) {
        S._reconnectAttempts = 0;
        // The link has been back and stable for 10 s: the notice goes now. It
        // used to wait for the next frame from the server - but after a rebind
        // on MY turn there is none (the server waits for my action), so the
        // "re-authenticating" pill stayed over the community cards for the
        // whole of my thinking time (scripts/test-reconnect-browser.mjs, D).
        try { _hideBanner(); } catch (e) {}
      }
    }, RECONNECT_STABLE_MS);
  }
  // ── Game state ──

  // ── Blind-raise schedule (forum: "better notification of blind increases") ──
  // Captured from NetGameInfo at JoinGameAck. _raiseMode: 1=every N hands,
  // 2=every N minutes. _raiseEvery: N (hands or minutes per mode).
  // _lastBlindsUpHand dedupes the "blinds up" toast per hand.
  // endRaiseMode: 1=doubler, 2=ajouter _endRaiseValue, 3=garder la dernière.
  // Sert à prédire la PROCHAINE valeur de blind affichée dans l'explication.
  // [9g-B1] Minuteur de montée des blinds (_start/_stop/_fmtBlindsCountdown) déplacé dans public/modules/ui/game-info.mjs
  // (toujours global via window.*).


  // ── Chip display mode: absolute value ($) or big blinds (BB) ──
  // Pure display feature, no protocol impact. Toggled from the in-game
  // overflow menu and persisted. fmtChips() is the single formatter used
  // everywhere a live game amount is shown (pot, stacks, bets, action
  // buttons) so the whole table switches consistently.
  try { S._displayBB = (localStorage.getItem('pth_display_bb') === '1'); } catch (e) {}
  // Format a raw chip amount as either "$1234" or "61,7 BB" depending on
  // the current mode. The big blind is smallBlind*2; if it's not known yet
  // (0, before the first hand) we fall back to the raw value to avoid a
  // divide-by-zero. One decimal, shown only when non-zero, with the decimal
  // separator following the active language.
  // Group a whole number with thousands separators following the active
  // language: French (and most others) use a thin/regular space — 1 000 000;
  // English uses a comma — 1,000,000. Improves readability of big stacks/pots.
  // [9f-1] _groupThousands / fmtChips / fmtChipsVoice déplacés dans
  // public/modules/ui/fmt.mjs (toujours globaux via window.*).

  // Assistance (aide « force de la main » affichée au-dessus des actions) :
  // activée par défaut, mémorisée localement. '0' = désactivée.
  try { S._assistOn = (localStorage.getItem('pth_assist') !== '0'); } catch(e) {}
  // Step 1 of "PokerTH official avatar" feature: when PlayerInfoReply
  // arrives for a registered player who uploaded an avatar on pokerth.net,
  // it carries an AvatarData sub-message (field 5) with the hash + format.
  // We just record what we see here; downloading + displaying come later.
  //   S._pthAvatarHashes[pid] = { type: 1|2|3, hashHex: 'a3f5...' }
  //   type: NetAvatarType from proto -- 1=PNG, 2=JPG, 3=GIF
  //   hashHex: lower-case hex string (easy logging & future cache keys)
  // pid -> code pays ISO 3166-1 alpha-2 (ex. 'FR'), reçu via PlayerInfoReply
  // (champ 4). Vide sur LAN / serveur privé qui ne le renseignent pas.
  // pid -> droits PokerTH (1=invité, 2=enregistré, 3=admin), via PlayerInfoReply.
  // Step 2: outgoing AvatarRequest tracking. Keyed by hashHex so the same
  // avatar shared by N players is downloaded ONCE (Q2=A, dedup by hash).
  //   S._pthAvatarsByHash[hex] = {
  //     status: 'pending' | 'done' | 'unknown' | 'error',
  //     type:   1|2|3,
  //     expectedSize: <bytes from AvatarHeader>,
  //     chunks: [Uint8Array, ...],   // not concatenated yet (step 3)
  //     received: <running total>,
  //   }
  // requestId -> hashHex, so AvatarHeader/Data/End handlers can map
  // their requestId back to the right entry (the server's reply does
  // NOT echo the hash, only the requestId we chose).
  // Monotonic counter for AvatarRequest.requestId. Starts at 1 because
  // some servers refuse 0. Wraps around at 2^32 (we'll be long dead).
  // Step 3: assembled Data URLs keyed by hashHex (the actual displayable
  // image, e.g. 'data:image/png;base64,iVBORw0KG...'). Built from chunks
  // at AvatarEnd, or restored from localStorage cache on startup.

  // [Phase 2 / 9c] Cache LRU d'avatars (PTH_AV_*, _pthLoadLruList,
  // _pthSaveLruList, _pthCacheGet, _pthCachePut, _pthAssembleDataUrl)
  // déplacé dans public/modules/net/avatar-cache.mjs (toujours global via
  // window.*). L'état en mémoire (S._pthAvatarsByHash…) et _pthAvatarFor
  // restent ici (closure).

  // [9f-7] _pthAvatarFor / _myAvatarDisplay / _avatarChipHtml déplacés dans
  // public/modules/ui/player-popup.mjs (avec _myAvChoice / _myAvImg).
  // [9g-B1] refreshStartNoBotsVisibility déplacé dans public/modules/ui/game-info.mjs
  // (toujours global via window.*).


  // [9g-B1] updateLobbyPill (pill lobby) déplacé dans public/modules/ui/game-info.mjs
  // (toujours global via window.*).


  // [9f-7] Popup joueur (openPlayerInfoPopup, _renderProfileStats, picker
  // avatar lobby, _ccToFlag…) déplacé dans public/modules/ui/player-popup.mjs
  // (toujours global via window.*).

  // [9f-8] _gameTypeLabel / _updateGameHeader déplacés dans
  // public/modules/ui/lobby.mjs.
  window._updateGameHeader = _updateGameHeader;

  // [9g-B1] _resetGameHeader déplacé dans public/modules/ui/game-info.mjs
  // (toujours global via window.*).


  // [9g-B1] openGameInfoPopup / closeGameInfoPopup déplacé dans public/modules/ui/game-info.mjs
  // (toujours global via window.*).


  // ── Classement de la table (parité QML GameTableStatsPage) : contexte pour
  //    le modal de client.html — nom de la table + nicks dans l'ordre des
  //    sièges (GameTable.tableStatsNicks() côté officiel). Les pids sans nom
  //    connu sont omis (le serveur ignore de toute façon les nicks inconnus).
  //    null hors partie ou en mode entraînement (bots sans classement). ──
  window.getTableRankingCtx = function () {
    if (window._offlineMode || !S.gId) return null;
    var g = S.games[S.gId] || {};
    var order = (S.seats && S.seats.length) ? S.seats : (g.seats || []);
    var nicks = [];
    for (var i = 0; i < order.length && nicks.length < 10; i++) {
      var nm = S.players[order[i]];
      if (nm) nicks.push(nm);
    }
    return { name: g.name || '', nicks: nicks };
  };
  // Clé/IV AES dérivés du mot de passe pour déchiffrer les cartes envoyées
  // chiffrées par pokerth.net aux comptes authentifiés (encryptedCards,
  // HandStart champ 3). Renseignés au moment de l'Init (mode 'auth'),
  // nuls sinon (LAN / invité → plainCards en clair).
  // Starting stack for this table. Pulled from NetGameInfo.startMoney
  // (field 13, written by buildCreateGame) or set directly by the table
  // creator. Used as the default money value when GameStartInitial
  // initializes seatData — without this the stacks all start at 0 and the
  // Call button mis-fires as "Call 0 (All-In)" before any action lands.

  // ── Statistiques de session ──

  // [9f-4] Famille _life* / _pushStats / _lifeSeedFromServer déplacée dans
  // public/modules/game/stats.mjs (toujours globale via window.*).
  // Snapshot des résultats figés à la FIN de la main (avant que la main
  // suivante ne réinitialise les stacks). Lu par showWinnerOverlay() pour
  // afficher des nets corrects, même si la donne suivante a déjà démarré.
  // {pid: {money, net, card1, card2, folded, inHand}}

  // ── Positions des sièges (pour les animations) ──

  // Nom de table par défaut localisé (FR: "Table de X", EN: "X's table").
  function _localDefaultName() {
    var tpl = (typeof t === 'function' && t('tableNameDefault')) || 'Table {name}';
    return tpl.replace('{name}', S.myName || 'PokerTH');
  }
  // Nom de table imposé par l'admin pour le mode de connexion courant
  // (admin -> /app-config.tableNames). Renvoie null si l'admin n'a rien fixé
  // pour ce mode -> on retombe alors sur le nom auto localisé. Mapping :
  // offline -> 'offline' ; pokerth.net (guest/auth) -> 'pokerthnet' ;
  // LAN / serveur privé (lan/unauth) -> 'lan'.
  function _adminNameForMode() {
    var a = window._adminTableNames;
    if (!a || typeof a !== 'object') return null;
    var key = window._offlineMode ? 'offline'
            : (S._currentLoginMode === 'guest' || S._currentLoginMode === 'auth') ? 'pokerthnet'
            : 'lan';
    var v = a[key];
    return (typeof v === 'string' && v.trim()) ? v.trim() : null;
  }
  // Nom par défaut effectif du champ « nom de la table » : nom admin du mode
  // courant s'il existe, sinon le défaut auto localisé (« Table {nom} »).
  function _defaultNameForMode() {
    return _adminNameForMode() || _localDefaultName();
  }
  window._defaultNameForMode = _defaultNameForMode; // pont requis par net/msg-lobby.mjs (9g-C3)
  // Make a game name the PokerTH server will accept. Server rule
  // (serverlobbythread.cpp): the name is trimmed, then rejected as
  // badGameName if it is empty OR isprint() is false for its first *byte*.
  // In the server's C locale isprint() is false for bytes >127, so a name
  // whose first character is non-ASCII (Cyrillic, Arabic, CJK, an emoji…)
  // is refused — e.g. the Russian default "Стол…" starts with 0xD0. We
  // guarantee a printable-ASCII leading character; the rest may be any
  // script (only the first byte is checked server-side).
  // Max game-name length accepted, aligned with the official PokerTH client
  // (createInternetGameDialog uses maxLength=48). The web client refuses to
  // create a table when the typed name exceeds it, with a translated message.
  function _safeGameName(raw) {
    var s = (raw || '').trim();
    var leadOk = function(str) {
      if (!str) return false;
      var c = str.charCodeAt(0);
      return c >= 0x20 && c <= 0x7E;
    };
    if (leadOk(s)) return s;
    if (!s) {                              // empty after trim
      var nm = (S.myName || '').trim();
      return leadOk(nm) ? nm : 'PokerTH';
    }
    return 'PokerTH - ' + s;               // keep the user's text, ASCII lead
  }
  // Un nom de table est-il un nom AUTO (défaut du mode, nom admin, variantes
  // localisées connues, suffixe « 2 »… de _freeGameName inclus) plutôt qu'un
  // choix du joueur ? Sert à deux endroits : createGame ne doit pas figer un
  // pré-remplissage comme si le joueur l'avait tapé (rapport forum : le
  // défaut « My online game » enregistré une fois recouvrait pour toujours le
  // nom réglé dans les préférences), et la restauration ne doit pas laisser
  // un auto d'une session passée recouvrir les préférences.
  function _isAutoGameName(v) {
    var s = String(v == null ? '' : v).trim();
    if (!s) return true;
    var nm = S.myName || 'PokerTH';
    // Défauts canoniques STATIQUES : les variantes localisées connues, plus
    // « My online game » (défaut du client QML officiel et exemple canonique
    // du panneau admin). Statique exprès : la reconnaissance ne doit jamais
    // dépendre du chargement asynchrone d'/app-config — sinon un vieux nom
    // auto figé redevenait « un choix » tant que la config n'était pas là.
    var known = ['Table de ' + nm, nm + "'s table", 'Table ' + nm, 'My table',
                 'My online game'];
    try { var dflt = _defaultNameForMode(); if (dflt) known.push(dflt); } catch (e) {}
    // Noms admin : celui d'aujourd'hui, ET ceux déjà vus (cache) — un nom
    // admin renommé ou retiré côté serveur ne doit pas transformer ses
    // vieilles copies figées en « choix du joueur ».
    try {
      var adminN0 = _adminNameForMode();
      var seen = [];
      try { seen = JSON.parse(localStorage.getItem('pth_auto_names_seen') || '[]'); } catch (e2) {}
      if (adminN0) {
        known.push(adminN0);
        if (seen.indexOf(adminN0) < 0) {
          seen.push(adminN0);
          try { localStorage.setItem('pth_auto_names_seen', JSON.stringify(seen.slice(-8))); } catch (e3) {}
        }
      }
      for (var j = 0; j < seen.length; j++) known.push(seen[j]);
    } catch (e) {}
    var stem = s.replace(/ \d+$/, '');       // « Nom 2 » de _freeGameName
    for (var i = 0; i < known.length; i++) {
      var k = String(known[i]).trim();
      if (s === k || stem === k) return true;
    }
    return false;
  }
  window._isAutoGameName = _isAutoGameName;
  // Re-localise le champ "nom de la table" au changement de langue, MAIS seulement
  // s'il est vide ou contient encore un nom par défaut connu (on ne touche jamais à
  // un nom personnalisé par l'utilisateur). Appelé depuis setLang (i18n.mjs).
  window._localizeCreateNameField = function() {
    var el = document.getElementById('cf-name');
    if (!el) return;
    var cur = (el.value || '').trim();
    if (cur === '' || _isAutoGameName(cur)) el.value = _defaultNameForMode();
  };
  // Table-list filter (design A chips): 'all' | 'open' | 'nopass' | 'live'.
  // Persisted so the choice survives reloads, like other lobby prefs.

  // Snapshot of the current table's settings, captured at JoinGameAck.
  // games[gId] is deleted from the lobby dict when the table closes
  // (GameListUpdate with mode === 3), so we keep our own copy. Used
  // by openGameInfoPopup() to populate the table-info modal even
  // after the table no longer appears in the lobby list.

  // [9f-2] hapticBuzz / toggleHaptic déplacés dans public/modules/ui/media.mjs
  // (toujours globaux via window.*).

  // ── Toggle chip display between absolute value ($) and big blinds (BB) ──
  function toggleDisplayBB() {
    S._displayBB = !S._displayBB;
    try { localStorage.setItem('pth_display_bb', S._displayBB ? '1' : '0'); } catch (e) {}
    // Repaint everything that shows a live amount.
    try { if (typeof renderSeats === 'function' && S.seats.length) renderSeats(); } catch (e) {}
    // Re-render the action buttons only if they're currently showing (i.e.
    // it's our turn — the bar holds a raise input). Otherwise they'll be
    // rebuilt with the right unit on the next turn anyway.
    try {
      if (typeof renderMyTurnActions === 'function' &&
          document.getElementById('raise-amt')) renderMyTurnActions();
    } catch (e) {}
    try { repaintPot(); } catch (e) {}
    if (typeof showKeyHint === 'function') showKeyHint(S._displayBB ? t('displayBB') : t('displayChips'));
    return S._displayBB;
  }
  // Re-render the pot label from the last known pot value, in the current
  // mode. We keep the last numeric pot in _lastPotValue (set by setPot) so a
  // mode switch can repaint without a server message.
  function setPot(_potVal) {
    var _prevPot = (typeof S._lastPotValue === 'number') ? S._lastPotValue : 0;
    S._lastPotValue = (typeof _potVal === 'number') ? _potVal : (parseInt(_potVal, 10) || 0);
    window._lastPotTotal = S._lastPotValue;   // pot total (lu par le popup d'info)
    // Parité GameStatusBar QML §7 : « Total » = pot collecté des streets
    // précédentes (collectedPot), « Bets/Mises » = mises de la street en
    // cours (= totalPot − collecté). Le badge au-dessus des cartes
    // (#g-potbar) garde le pot TOTAL, comme le pot badge QML.
    var _cp    = (typeof S.collectedPot === 'number') ? Math.min(S.collectedPot, S._lastPotValue) : S._lastPotValue;
    var _bets  = Math.max(0, S._lastPotValue - _cp);
    var _potAmt = esc(fmtChips(S._lastPotValue));
    var a  = document.getElementById('g-pot');
    var eb = document.getElementById('g-bets');
    var b  = document.getElementById('g-potbar');
    if (a)  a.innerHTML  = esc(fmtChips(_cp));
    if (eb) eb.innerHTML = esc(fmtChips(_bets));
    if (b) { b.innerHTML = _potAmt; b.classList.toggle('has-pot', S._lastPotValue > 0); }
    // « Pop » à chaque hausse du pot (parité pot badge QML, bible §9) —
    // relance de l'animation par reflow, pas de listener à nettoyer.
    if (S._lastPotValue > _prevPot) {
      [a, b].forEach(function (el) {
        if (!el) return;
        el.classList.remove('pot-pop');
        void el.offsetWidth;
        el.classList.add('pot-pop');
      });
    }
  }
  window.setPot = setPot; // pont requis par net/msg-game-join.mjs (9g-C4)
  // Statut spectateur dans le bandeau du pot (#pot-strip), en remplacement de
  // l'ancien bandeau séparé — parité GameStatusBar QML §7. Pastille « Spectating »
  // si je regarde, et œil + compteur de spectateurs (moi inclus) dès qu'au moins
  // un spectateur est présent. _specPids exclut le pid local, d'où le +1.
  function updateSpectatorStrip() {
    try {
      var badge = document.getElementById('g-spec-badge');
      var cnt   = document.getElementById('g-spec-count');
      var num   = document.getElementById('g-spec-n');
      if (badge) badge.classList.toggle('on', !!S._amSpectator);
      // Mobile (<640px, CSS) : la pastille texte est masquee et c'est l'oeil
      // qui prend le contour jaune quand JE regarde -> classe .me.
      if (cnt) cnt.classList.toggle('me', !!S._amSpectator);
      var n = (S._specPids ? S._specPids.size : 0) + (S._amSpectator ? 1 : 0);
      if (num) num.textContent = n;
      if (cnt) {
        cnt.classList.toggle('on', n > 0);
        // Tooltip = noms des spectateurs (parité ToolTip QML spectatorNames)
        var names = [];
        if (S._amSpectator) names.push(t('piYou'));
        if (S._specPids) S._specPids.forEach(function(pid) {
          var nm = (typeof getPlayerName === 'function') ? getPlayerName(pid) : null;
          names.push(nm || ('#' + pid));
        });
        cnt.title = names.join('\n');
      }
    } catch (e) {}
    // ── Spectator send-lock (sp0ck 31/07/2026, supersedes the 24/07 full block) ──
    // Spectators SEE the game chat and the emoji reactions (QML parity: the
    // upstream ChatBox / reactions have no spectator gating and the server
    // broadcasts game chat to Spectating sessions) but must NOT SEND either —
    // sending could be abused to annoy players at the table. Marker
    // <body class="spectator-nosend">: the CSS hides the chat input row, the
    // emoji-insert panel, the 😊 reactions button and the reactions panel.
    // sendGameChat / sendReaction keep JS guards as defense in depth.
    try {
      var _noSend = !!S._amSpectator;
      document.body.classList.toggle('spectator-nosend', _noSend);
      if (_noSend) {
        var _rp = document.getElementById('g-reaction-panel');
        if (_rp && _rp.style.display !== 'none' && _rp.style.display !== '') _rp.style.display = 'none';
      }
    } catch (e) {}
  }
  window.updateSpectatorStrip = updateSpectatorStrip;

  function repaintPot() {
    if (typeof S._lastPotValue !== 'number') return;
    setPot(S._lastPotValue);
  }
  window.toggleDisplayBB = toggleDisplayBB;

  // [9f-2] Voix (speak, _speakNext, _pickVoice, voiceActionPhrase,
  // _syncMediaToggleButtons…) déplacée dans public/modules/ui/media.mjs ;
  // toggleVoice et le choix de sortie des annonces dans modules/ui/announcer.mjs.
  // Spectators present on the current table. Populated by
  // GameSpectatorJoined messages from the server (one is sent per
  // existing spectator when we ourselves join, plus live updates
  // as people come and go). Reset on JoinGameAck / closeTable.
  // ── Feature flag: auto-check / auto-fold next-turn checkbox ────────
  // When true, the action bar shows a checkbox above the action buttons
  // that arms an automatic fold (or check, if currently free) for the
  // user's next turn this hand. When false, the checkbox is not rendered
  // at all but the underlying logic stays intact — flipping this back to
  // `true` reinstates the feature without touching anything else.
  // Mode de jeu PERSISTANT (comme le client officiel) : 0 = Manuel,
  // 1 = Auto Check/Call, 2 = Auto Check/Fold. Reste actif jusqu'a un clic
  // manuel sur une action ou un changement de dropdown (pas de reset par main).
  // [9g-B4] _playAutoMode déplacé dans public/modules/ui/action-bar.mjs
  // (toujours global via window.*).

  // Panneau "aperçu des actions" ouvert en tapant ses cartes hors de son tour.
  // Le sélecteur de mode (Manuel/Auto Check-Call/Auto Check-Fold) y reste
  // activable. Les boutons d'action y sont affichés en APERÇU seulement
  // (non cliquables). Se ferme automatiquement quand c'est notre tour.
  // Pré-sélection d'action (comme le client officiel, bible §5.3) : on peut
  // armer Fold/Call/Raise/All-In avant son tour (bord or), recliquer pour
  // désarmer, et l'action s'exécute quand notre tour arrive. Invalidée si la
  // mise à suivre change, reset à chaque nouvelle main.
                              // à l'armement. Invalidation alignée sur l'officiel
                              // (onCallAmountChanged) : comparer le montant QUE JE DOIS,
                              // pas highestBet brut — sinon la pose des blinds ou ma
                              // propre mise comptabilisée désarmaient silencieusement la
                              // pré-action (bug « je dois re-sélectionner à mon tour »).
  // Verrou anti-fermeture du picker natif (iOS) du selecteur de mode : tant
  // que l'utilisateur manipule #mode-sel, on differe les reconstructions
  // d'apercu (renderMyTurnActions(true)) pour ne pas detruire le <select> ouvert.
  // Epingle : garder le panneau d'apercu ouvert en permanence hors-tour
  // (au lieu de retaper ses cartes a chaque main). Memorise entre sessions.
  // Sélecteur de mode auto & boutons quick-bet : toujours affichés dans la
  // barre d'action (les options de masquage ont été retirées des réglages).
  // On nettoie les classes héritées au cas où un ancien CSS serait encore en cache.
  try { document.body.classList.remove('hide-auto-btn', 'hide-pct-btns'); } catch (e) {}
  // Setters (etat precis) pour les cases des Options avancees : bascule le toggle
  // existant seulement si l'etat courant differe de la valeur voulue, ce qui
  // reutilise toute la logique d'application + retour visuel des toggles.
  // Voice: built-in voice on/off, routed through the announcer (modules/ui/announcer.mjs).
  window.setVoice = function (on) { if (typeof window.setAnnounceMode === 'function') window.setAnnounceMode(on ? 'voice' : 'off'); };
  window.setDisplayBB = function (on) { if (!!on !== S._displayBB) toggleDisplayBB(); };
  window.setHaptic = function (on) { if (!!on !== S._hapticEnabled) toggleHaptic(); };
  // [9f-10] Cycle de connexion (show, _beginConnecting/_endConnecting,
  // _armRejoin, _maybeReconnectOnResume, _forceReconnect) déplacé dans
  // public/modules/net/session.mjs (toujours global via window.*).

  // 'online' : la route réseau a changé (wifi→5G…) → l'ancien socket est quasi
  // sûrement mort même s'il affiche OPEN → on force la reconnexion.
  window.addEventListener('online', _forceReconnect);
  // 'offline' : on prévient l'utilisateur ; la reconnexion se fera au retour du
  // réseau ('online') ou via le watchdog ci-dessous.
  window.addEventListener('offline', function () {
    if (S._intentionalDisconnect || !S._lastConnectParams) return;
    var sg = document.getElementById('s-game');
    var sl = document.getElementById('s-lobby');
    if (!((sg && sg.classList.contains('active')) || (sl && sl.classList.contains('active')))) return;
    try { _showBanner(t('reconnInProgress')); } catch(e) {}
  });

  // Watchdog liveness : si AUCUN message reçu depuis le seuil alors qu'on est à
  // une table, visible et « en ligne », le socket est présumé mort (cas d'une
  // bascule réseau « transparente » où online/offline ne se déclenchent pas).
  // ⚠ Le seuil DOIT rester supérieur au timeout d'action de la table : pendant
  // TON tour, le serveur n'envoie rien tant que tu n'as pas joué, donc un seuil
  // trop court déclencherait une reconnexion à tort si tu réfléchis longtemps.
  // → Seuil ADAPTATIF : max(45 s, timeout_table + 20 s de marge). gameTimeout
  // est renseigné depuis NetGameInfo au JoinGameAck (défaut 15 s). C'est un
  // filet de sécurité ; les vrais déclencheurs rapides sont
  // online/focus/visibilitychange (et le rebranchement proxy est transparent).
  setInterval(function () {
    if (S._intentionalDisconnect || !S._lastConnectParams) return;
    // The active watchdog (modules/net/watchdog.mjs: connection probe, 2.1+
    // servers) is in charge whenever it runs; this passive one covers the rest.
    try { if (window._wdProbing && window._wdProbing()) return; } catch (eWd) {}
    // Entraînement (offline) : pas de socket réseau à surveiller. Le FakeServer
    // peut rester muet légitimement (pause entre les mains, overlay de fin de
    // partie, onglet revenu d'arrière-plan avec timers gelés) → le watchdog
    // déclenchait _forceReconnect et ÉJECTAIT le joueur de sa partie locale.
    if (window._offlineMode) return;
    if (document.hidden) return;                                            // arrière-plan : timers gelés
    if (typeof navigator.onLine === 'boolean' && !navigator.onLine) return; // hors-ligne géré ailleurs
    var sg = document.getElementById('s-game');
    var sl = document.getElementById('s-lobby');
    var _inGame  = !!(sg && sg.classList.contains('active'));
    var _inLobby = !!(sl && sl.classList.contains('active'));
    if (!_inGame && !_inLobby) return;                                      // ni table ni lobby
    if (!S.ws || S.ws.readyState !== WebSocket.OPEN) return;                    // sinon déjà géré
    var _thr;
    if (_inGame) {
      var _tt = (typeof S.gameTimeout === 'number' && S.gameTimeout > 0) ? S.gameTimeout : 15;
      _thr = Math.max(S._RX_WATCHDOG_MIN_MS, (_tt + 20) * 1000);              // > timeout d'action de la table
    } else {
      // LOBBY. Le watchdog ne couvrait que la table : un socket zombie
      // (readyState OPEN, TCP mort — coupure serveur derrière le proxy, bascule
      // réseau) ne déclenchait donc aucun onclose et le lobby restait affiché
      // indéfiniment, liste de tables figée. Rapport forum : « le client se
      // déconnecte du lobby et reste sur le lobby ».
      // Le seuil ne peut PAS être celui de la table : un lobby calme est
      // légitimement muet, sauf pour le battement serveur (45 s). On s'y adosse,
      // en mesurant l'intervalle réel plutôt qu'en le supposant.
      // Deux battements exigés avant d'armer : un serveur antérieur à la 2.1.0
      // n'en envoie aucun, et l'y armer le ferait reconnecter en boucle.
      if (S._hbCount < 2 || !S._hbInterval) return;
      _thr = Math.max(S._HB_WATCHDOG_MIN_MS, Math.round(S._hbInterval * 2.5));
    }
    if (Date.now() - S._lastRxTime > _thr) _forceReconnect('no data from the server');
  }, 5000);

  // ── User diagnostics: type pthDiag() in the console ─────────────────────
  // Returns (and logs) a JSON snapshot of the client state, to paste into
  // a bug report. See docs/DIAGNOSTIC.md.
  window.pthDiag = function () {
    var d = {};
    try {
      d.build   = window.BUILD_VERSION || null;
      d.date    = new Date().toISOString();
      d.ua      = navigator.userAgent;
      d.screen  = window.innerWidth + 'x' + window.innerHeight +
                  ((window.matchMedia && window.matchMedia('(orientation: portrait)').matches) ? ' portrait' : ' landscape');
      try { d.lang = localStorage.getItem('pth_lang') || navigator.language; } catch (e) { d.lang = navigator.language; }
      d.sw      = !!(navigator.serviceWorker && navigator.serviceWorker.controller);
      d.online  = navigator.onLine;
      d.offlineMode = !!window._offlineMode;
      d.loginMode = S._currentLoginMode;
      d.ws      = S.ws ? (['CONNECTING','OPEN','CLOSING','CLOSED'][S.ws.readyState] || S.ws.readyState) : null;
      d.nick    = S.myName || null;
      d.playerId = S.myId || 0;
      d.gameId  = S.gId || 0;
      d.hand    = S.handNum;
      d.phase   = S.gameState;
      d.sb      = S.smallBlind;
      d.seats   = S.seats.length;
      d.myCards = [S.myCards[0] != null, S.myCards[1] != null];
      d.cardKey = !!S._cardKey;
      d.cardDiag = window._pthCardDiag || null;
    } catch (e) { d.error = String(e); }
    try { console.log('[pthDiag]', JSON.stringify(d, null, 1)); } catch (e) {}
    return d;
  };

  // [9f-6] _chatLocalCmd déplacée dans public/modules/ui/chat.mjs.

  // [9f-10] setStatus déplacée dans public/modules/net/session.mjs.
  // Re-pose le hint « 🤖 mode entraînement ». Exposé pour que la veille (portée
  // globale) puisse RÉPARER un hint réseau qui aurait fui en entraînement, sans
  // jamais toucher un message transitoire. setStatus + t sont en portée ici.
  window._forceOfflineHint = function () {
    try { setStatus(t('offlineHint'), '', 'offlineHint'); } catch (e) {}
  };
  // Re-applique le statut de l'écran de connexion dans la langue courante.
  // Le hint dépend du mode (clé mémorisée par setStatus) ; posé impérativement
  // (sans data-i18n) il restait figé dans la langue précédente. Les messages
  // transitoires (sans clé) ne sont jamais réécrasés. Appelé par setLang().
  window._refreshConnectStatus = function() {
    try {
      if (!S._statusKey) return;
      var sc = document.getElementById('s-connect');
      if (!sc || !sc.classList.contains('active')) return;
      var el = document.getElementById('cstatus');
      if (el) el.textContent = t(S._statusKey);
    } catch (e) {}
  };

  // ── Régulation d'envoi des réactions /emoji ──────────────────────────
  // Le serveur limite le chat diffusé à 5 messages/seconde PAR CONNEXION
  // (SessionData::AcquireChatToken, upstream 771384d4 du 25/08/2026). En lobby
  // le dépassement renvoie un ChatReject ; en partie le message est abandonné
  // SANS notification — nos réactions disparaîtraient alors sans que personne
  // ne le sache. Le client officiel (GamePage.qml::sendReaction) n'applique
  // aucun throttle : son seul frein est ergonomique, le picker se referme après
  // chaque réaction. On réplique ce frein (cf. toggleReactionPanel) et la file
  // ci-dessous n'est plus qu'un filet de sécurité pour les chemins non-UI —
  // d'où un écart minimal de 250 ms (soit 4 msg/s, sous le budget serveur), et
  // non plus le bridage prudent de 1,5 s d'avant la connaissance du seuil réel.
  // Le badge local et le canal proxy REACT (web↔web, qui contourne le chat
  // serveur) restent immédiats. NB : doit vivre DANS l'IIFE App pour voir
  // ws/gId/send/MSG/S._lastMsgWasReaction (cf. avertissement en tête).

  function _flushReactEmoji() {
    S._reactEmojiTimer = null;
    if (!S._reactEmojiQueue.length) return;
    if (!S.ws || !S.gId || S.ws.readyState !== WebSocket.OPEN) { S._reactEmojiQueue.length = 0; return; }
    const now = Date.now();
    const wait = S.REACT_EMOJI_MIN_GAP - (now - S._reactEmojiLastSent);
    if (wait > 0) { S._reactEmojiTimer = setTimeout(_flushReactEmoji, wait); return; }
    const emoji = S._reactEmojiQueue.shift();
    S._reactEmojiLastSent = now;
    S._lastMsgWasReaction = true;
    try { send(MSG.buildGameChat(S.gId, '/emoji ' + emoji)); } catch (e) {}
    if (S._reactEmojiQueue.length) S._reactEmojiTimer = setTimeout(_flushReactEmoji, S.REACT_EMOJI_MIN_GAP);
  }

  function _queueReactEmoji(emoji) {
    S._reactEmojiQueue.push(emoji);
    while (S._reactEmojiQueue.length > S.REACT_EMOJI_QUEUE_MAX) S._reactEmojiQueue.shift(); // garde les plus récentes
    if (!S._reactEmojiTimer) _flushReactEmoji();
  }

  // [Phase 2 / 9d] _handleCtrlFrame déplacée dans public/modules/ui/misc.mjs.

  // ── Canal notify-only (mode pokerth.net direct) ──────────────────────
  // En direct, la socket de jeu va droit sur wss://www.pokerth.net/pthlive :
  // elle ne traverse pas notre proxy, donc broadcastNotice() côté serveur ne
  // peut pas l'atteindre. On ouvre un second WebSocket minimal vers le proxy
  // (?notify=1) qui ne transporte QUE les trames texte NOTICE:/INFO:.
  // Reconnexion silencieuse (15 s) tant que le canal est demandé.
  function _closeNotifyWS() {
    S._notifyUrl = '';
    if (S._notifyTimer) { clearTimeout(S._notifyTimer); S._notifyTimer = null; }
    if (S._notifyWS) { try { S._notifyWS.onclose = null; S._notifyWS.close(); } catch (e) {} S._notifyWS = null; }
  }
  function _openNotifyWS(baseUrl, mode) {
    if (!baseUrl) return;
    // &v= : version du client annoncée au proxy, purement descriptive (tableau
    // de bord admin → qui tourne encore sur une version périmée). Jamais lue
    // pour prendre une décision côté serveur.
    const u = baseUrl + (baseUrl.indexOf('?') >= 0 ? '&' : '?') + 'notify=1&mode=' + (mode === 'offline' ? 'offline' : 'pthnet') + (window.LIVE_MODE ? '&live=1' : '') + (window.BUILD_VERSION ? '&v=' + encodeURIComponent(window.BUILD_VERSION) : '')
      // &tz= : the browser time zone, read by the proxy as a country code for the
      // admin's Live › Map; kept with the connection only, never stored.
      + (function(){ try { var z = window._pthTimeZone && window._pthTimeZone(); return z ? '&tz=' + encodeURIComponent(z) : ''; } catch (e) { return ''; } })();
    if (S._notifyWS && S._notifyUrl === u) return; // déjà ouvert sur la bonne URL
    _closeNotifyWS();
    S._notifyUrl = u;
    (function dial() {
      if (!S._notifyUrl) return;
      var sck = null;
      try { sck = new WebSocket(S._notifyUrl); } catch (e) {}
      if (!sck) { S._notifyTimer = setTimeout(dial, 30000); return; }
      S._notifyWS = sck;
      sck.onmessage = function (e) { if (typeof e.data === 'string') _handleCtrlFrame(e.data); };
      sck.onerror = function () { try { sck.close(); } catch (e) {} };
      sck.onclose = function () {
        if (sck !== S._notifyWS) return;
        S._notifyWS = null;
        if (S._notifyUrl) S._notifyTimer = setTimeout(dial, 15000);
      };
    })();
  }

  // [9f-10] send déplacée dans public/modules/net/session.mjs (toujours
  // globale via window.send).

  function onRawData(chunk) {
    S._lastRxTime = Date.now();              // liveness : un message reçu = socket vivant
    // Données qui arrivent = lien rétabli. Sur un rebranchement transparent
    // (le proxy a gardé la session PokerTH vivante), il n'y a NI Announce NI
    // InitAck → aucun handler ne masquerait la bannière « reconnexion ». On la
    // masque donc dès la 1ʳᵉ frame reçue.
    try {
      var _rb = document.getElementById('reconnect-banner');
      var _rp = document.getElementById('g-conn-pill');
      // Depuis 0.3.928 l'indicateur à table est la pastille #g-conn-pill (le
      // bandeau reste pour les autres écrans) : tester les DEUX, sinon après un
      // rebranchement transparent la pastille restait affichée à vie (bug vu en
      // LAN après mode avion). _hideBanner() masque bandeau + pastille.
      if ((_rb && _rb.classList.contains('visible')) ||
          (_rp && _rp.style.display !== 'none')) _hideBanner();
      // Same reasoning for the connect watchdog. _beginConnecting arms a 20 s
      // timer that fires connectSlow ("taking a while... retry if needed");
      // _endConnecting disarms it, but it only runs on InitAck or on close.
      // A transparent reattach produces neither, so the timer kept firing
      // ~20 s after a reconnection that had already succeeded -- an error
      // toast over the action bar, in the middle of a hand. A received frame
      // is proof the link is back: that is the acknowledgement we were
      // waiting for.
      if (S._preserveConnect && S._connectingNow) _endConnecting();
    } catch (e) {}
    if (typeof chunk === 'string') return; // ignore text frames
    if (window.directWS) {
      // Direct WSS: each WS message is one complete protobuf (no length prefix)
      handleMsg(new Uint8Array(chunk));
      return;
    }
    const tmp = new Uint8Array(S.rxBuf.length + chunk.byteLength);
    tmp.set(S.rxBuf);
    tmp.set(new Uint8Array(chunk), S.rxBuf.length);
    S.rxBuf = tmp;

    while (S.rxBuf.length >= 4) {
      const len = new DataView(S.rxBuf.buffer, S.rxBuf.byteOffset).getUint32(0, false);
      if (S.rxBuf.length < 4 + len) break;
      // Consume the frame BEFORE handling it: a handler that throws used to
      // leave it at the head of the buffer, replayed (and throwing) on every
      // later chunk while the frames behind it piled up — a frozen session the
      // watchdog never saw, since _lastRxTime kept moving. The error is
      // rethrown asynchronously so window.onerror still reports it.
      const frame = S.rxBuf.slice(4, 4 + len);
      S.rxBuf = S.rxBuf.slice(4 + len);
      try { handleMsg(frame); } catch (e) { setTimeout(function () { throw e; }, 0); }
    }
  }

  // Text frames from the proxy (control protocol). Shared by the first socket
  // and the automatic-reconnect sockets: the latter used to pass text frames
  // to onRawData, which drops them — NOTICE:/INFO: broadcasts, REACT: and the
  // SYNCTOK: re-sent on reattach were lost after the first reconnection.
  function _onProxyText(data) {
    if (_handleCtrlFrame(data)) return;
    // Jeton de sync des préférences (émis à l'InitAck d'un login authentifié)
    if (data.startsWith('SYNCTOK:')) {
      try { if (window._cfgSyncOnToken) window._cfgSyncOnToken(data.slice(8)); } catch (_e) {}
      return;
    }
    // AVATAR:/AVATARIMG: (ancien relais d'avatar entre clients web) : plus
    // émis ni affichés, le proxy les absorbe — l'avatar passe uniquement
    // par le protocole PokerTH, comme pour le client QML. Une trame
    // résiduelle tombe sur le « return » ci-dessous, sans effet.
    if (data.startsWith('REACT:')) {
      var parts = data.split(':');
      var fromPid = parseInt(parts[1]);
      var reactEmoji = parts[2];
      if (fromPid !== S.myId) {
        handleIncomingReaction(fromPid, reactEmoji, 'react');
        // Pas d'affichage dans le chat — uniquement animation flottante
      }
    }
  }

  // Closes that must NOT lead to another reconnection attempt. Returns true
  // when it handled the close. Shared by the first socket and the automatic-
  // reconnect sockets, which used to skip it: a kick arriving after a
  // reconnection left the player on a frozen lobby or table.
  function _closeIsTerminal(e) {
    // Annuaire LAN : ce serveur limite le nombre de joueurs par adresse IP
    // (proxy, code 4430 « lan-ip-cap:N »). Pas de reconnexion automatique —
    // elle buterait sur la même limite.
    if (e && e.code === 4430) {
      var _capN = parseInt(String(e.reason || '').split(':')[1], 10) || 0;
      var _capMsg = t('lanErr_ipCap', { n: _capN });
      S._intentionalDisconnect = true;
      _closeNotifyWS();
      _hideBanner();
      try { show('s-connect'); } catch (e4) {}
      setStatus(_capMsg, 'err');
      try { window._connLostShow && window._connLostShow(_capMsg); } catch (e4) {}
      return true;
    }
    // User asked to leave (clicked ✕ / disconnect): do NOT auto-reconnect.
    // Without this guard, ws.close() from disconnect() falls through to the
    // reconnect scheduler below and drops the user back into the lobby a few
    // seconds after they returned to the home screen.
    if (S._intentionalDisconnect) {
      _closeNotifyWS();
      _hideBanner();
      // …sauf quand c'est le SERVEUR qui a rejeté la session (kick, ban,
      // timeout d'inactivité) : onError pose le même drapeau pour couper le
      // backoff, mais personne ne changeait d'écran — le lobby restait
      // affiché et figé, le motif écrit par setStatus n'étant visible que
      // sur l'écran de connexion. Parité QML (onConnectionFailed) : retour
      // à l'écran de connexion + fenêtre « Connexion perdue ». Un départ
      // volontaire n'a pas de motif et a déjà changé d'écran.
      if (S._connLostReason) {
        var _clr = S._connLostReason;
        S._connLostReason = '';
        try { show('s-connect'); } catch (e3) {}
        try { window._connLostShow && window._connLostShow(_clr); } catch (e3) {}
      }
      return true;
    }
    return false;
  }

  // ── HANDLER DE MESSAGES ──
  // [9f-5] Invitations (_invite*) déplacées dans
  // public/modules/net/petitions.mjs (toujours globaux via window.*).

  function handleMsg(buf) {
    const { type, sub } = MSG.parse(buf);
    const T = MSG.T;
    // ── /msglog & /netdbg: lightweight stats (total + ring of last 30 types) ──
    try {
      var _ms = window._pthMsgStats || (window._pthMsgStats = { total: 0, ring: [] });
      _ms.total++;
      _ms.ring.push({ t: type, ts: Date.now() });
      if (_ms.ring.length > 30) _ms.ring.shift();
      // /logdump: optional verbose capture (type + size + field numbers present)
      if (window._pthMsgVerbose) {
        var _vr = window._pthMsgVerboseRing || (window._pthMsgVerboseRing = []);
        _vr.push({ t: type, ts: Date.now(), len: buf.length, f: Object.keys(sub).join(',') });
        if (_vr.length > 50) _vr.shift();
      }
    } catch (_eMs) {}

    switch (type) {

      // Le serveur s'annonce → on envoie notre Init

      // ── Game invitation: the host invited us to a table ──
      case T.InviteNotify: { onInviteNotify(sub); break; } // [9g-C2] → net/msg-social.mjs
      // Someone declined an invite WE sent — outgoing invites not yet a
      // web feature, so nothing to surface; swallow to avoid the default.
      case T.RejectInvNotify: { onRejectInvNotify(sub); break; } // [9g-C2] → net/msg-social.mjs

      case T.Announce: { onAnnounce(sub); break; } // [9g-C3] → net/msg-lobby.mjs

      // Connexion acceptée
      case T.InitAck: { onInitAck(sub); break; } // [9g-C3] → net/msg-lobby.mjs

      // Erreur serveur
      case T.AuthChallenge: { onAuthChallenge(sub); break; } // [9g-C3] → net/msg-lobby.mjs

      case T.ReportGameAck: { onReportGameAck(sub); break; } // [9g-C3] → net/msg-lobby.mjs
      case T.ReportAvatarAck: { onReportAvatarAck(sub); break; } // → net/msg-lobby.mjs

      case T.AdminBanPlayerAck: { onAdminBanPlayerAck(sub); break; } // [9g-C3] → net/msg-lobby.mjs

      case T.AdminGlobalNoticeAck: { onAdminGlobalNoticeAck(sub); break; } // → net/msg-lobby.mjs

      case T.Error: { onError(sub); break; } // [9g-C3] → net/msg-lobby.mjs

      // ── Lobby player roster (PlayerListMessage) ──
      // Sent by the server when a player joins or leaves the lobby.
      // We maintain a local _lobbyPlayerCount fallback for servers
      // (typical of LAN / private deployments) that don't send the
      // periodic StatisticsMessage. If StatisticsMessage IS received,
      // its value takes precedence — see _hasStatistics flag.
      case T.PlayerList: { onPlayerList(sub); break; } // [9g-C3] → net/msg-lobby.mjs

      // Statistiques (nombre de joueurs connectés)
      case T.Statistics: { onStatistics(sub); break; } // [9g-C3] → net/msg-lobby.mjs

      // Profil d'un joueur reçu
      case T.PlayerInfoReply: { onPlayerInfoReply(sub); break; } // [9g-C3] → net/msg-lobby.mjs

      // ──────────────────────────────────────────────────────────────
      // PokerTH avatar download flow -- STEP 2: parse server replies.
      // No assembly into a Blob/Data URL yet, no display. Just log so
      // we can verify the server actually streams the bytes back.
      // ──────────────────────────────────────────────────────────────
      // ── PokerTH avatar UPLOAD (scope A): the server got our hash from Init,
      // lacks the file, and asks US for it. Stream it back, chunked at 256
      // (MAX_FILE_DATA_SIZE — server rejects avatarblock > 256). Hash-matched.
      case T.AvatarRequest: { onAvatarRequest(sub); break; } // [9g-C1] → net/msg-avatars.mjs

      case T.AvatarHeader: { onAvatarHeader(sub); break; } // [9g-C1] → net/msg-avatars.mjs
      case T.AvatarData: { onAvatarData(sub); break; } // [9g-C1] → net/msg-avatars.mjs
      case T.AvatarEnd: { onAvatarEnd(sub); break; } // [9g-C1] → net/msg-avatars.mjs
      case T.UnknownAvatar: { onUnknownAvatar(sub); break; } // [9g-C1] → net/msg-avatars.mjs

      // Nouvelle table dans la liste
      case T.GameListNew: { onGameListNew(sub); break; } // [9g-C3] → net/msg-lobby.mjs

      // Mise à jour d'une table (état)
      case T.GameListUpdate: { onGameListUpdate(sub); break; } // [9g-C3] → net/msg-lobby.mjs

      // Un joueur rejoint / quitte une table
      case T.GameListPlayerJoined: { onGameListPlayerJoined(sub); break; } // [9g-C3] → net/msg-lobby.mjs
      case T.GameListPlayerLeft: { onGameListPlayerLeft(sub); break; } // [9g-C3] → net/msg-lobby.mjs
      case T.GameListSpectatorJoined: { onGameListSpectatorJoined(sub); break; } // [9g-C3] → net/msg-lobby.mjs
      case T.GameListSpectatorLeft: { onGameListSpectatorLeft(sub); break; } // [9g-C3] → net/msg-lobby.mjs
      // L'admin d'une table a change (badge « Admin », parite QML GameAdminBadge)
      case T.GameListAdminChanged: { onGameListAdminChanged(sub); break; } // → net/msg-lobby.mjs

      // ── Spectator events SCOPED to the current game ──
      // Type 80/81. The lobby-level 78/79 above are different (they
      // tick a spectator count on each table card in the games list).
      // 80/81 only arrive while we're inside a game (player OR
      // spectator) and refer to OTHER spectators watching the same
      // table. The server replays Joined for each existing spectator
      // right after our JoinGameAck, so we don't need a separate
      // "fetch initial list" round-trip.
      case T.GameSpectatorJoined: { onGameSpectatorJoined(sub); break; } // [9g-C4] → net/msg-game-join.mjs
      case T.GameSpectatorLeft: { onGameSpectatorLeft(sub); break; } // [9g-C4] → net/msg-game-join.mjs

      // Message de chat
      case T.Chat: { onChat(sub); break; } // [9g-C2] → net/msg-social.mjs
      case T.TimeoutWarning: { onTimeoutWarning(sub); break; } // [9g-C2] → net/msg-social.mjs

      case T.ChatReject: { onChatReject(sub); break; } // [9g-C2] → net/msg-social.mjs

      // Message d'information libre du serveur (MOTD / annonce admin)
      case T.Dialog: { onDialog(sub); break; } // → net/msg-social.mjs

      case T.JoinGameAck: { onJoinGameAck(sub); break; } // [9g-C4] → net/msg-game-join.mjs

      case T.JoinGameFailed: { onJoinGameFailed(sub); break; } // [9g-C4] → net/msg-game-join.mjs

      case T.GamePlayerJoined: { onGamePlayerJoined(sub); break; } // [9g-C4] → net/msg-game-join.mjs

      case T.GamePlayerLeft: { onGamePlayerLeft(sub); break; } // [9g-C4] → net/msg-game-join.mjs

      // Un joueur a repris sa place avec un nouveau pid → remap complet
      case T.PlayerIdChanged: { onPlayerIdChanged(sub); break; } // → net/msg-game-join.mjs

      case T.RemovedFromGame: { onRemovedFromGame(sub); break; } // [9g-C4] → net/msg-game-join.mjs

      case T.StartEvent: { onStartEvent(sub); break; } // [9g-C4] → net/msg-game-join.mjs

      case T.GameStartInitial: { onGameStartInitial(sub); break; } // [9g-C5a] → game/msg-hand.mjs

      // Reprise de partie : reponse a notre RejoinExistingGame (sieges + stacks reels)
      case T.GameStartRejoin: { onGameStartRejoin(sub); break; } // → game/msg-hand.mjs

      case T.HandStart: { onHandStart(sub); break; } // [9g-C5a] → game/msg-hand.mjs

      case T.PlayersTurn: { onPlayersTurn(sub); break; } // [9g-C5b] → game/msg-hand.mjs

      case T.PlayersActionDone: { onPlayersActionDone(sub); break; } // [9g-C5b] → game/msg-hand.mjs
      case T.DealFlop: { onDealFlop(sub); break; } // [9g-C5b] → game/msg-hand.mjs

      case T.DealTurn: { onDealTurn(sub); break; } // [9g-C5b] → game/msg-hand.mjs

      case T.DealRiver: { onDealRiver(sub); break; } // [9g-C5b] → game/msg-hand.mjs

      case T.AllInShowCards: { onAllInShowCards(sub); break; } // [9g-C5b] → game/msg-hand.mjs

      case T.EndOfHandShow: { onEndOfHandShow(sub); break; } // [9g-C5b] → game/msg-hand.mjs

      case T.EndOfHandHide: { onEndOfHandHide(sub); break; } // [9g-C5b] → game/msg-hand.mjs

      case T.GameAdminChanged: { onGameAdminChanged(sub); break; } // [9g-C4] → net/msg-game-join.mjs

      case T.YourActionRejected: { onYourActionRejected(sub); break; } // [9g-C5b] → game/msg-hand.mjs

      case T.AfterHandShowCards: { onAfterHandShowCards(sub); break; } // [9g-C5b] → game/msg-hand.mjs

      case T.EndOfGame: { onEndOfGame(sub); break; } // [9g-C5b] → game/msg-hand.mjs
    }
  }

  // [9f-8] Lobby (MODE_LABEL, GTYPE, filtres, renderTablePlayers, panneau
  // infos de partie, wait-actions) déplacé dans public/modules/ui/lobby.mjs.
  function _tableHasPid(pid) {
    for (const k of S._openTables) {
      const g = S.games[k];
      if (g && g.seats && g.seats.indexOf(pid) !== -1) return true;
    }
    return false;
  }
  window._tableHasPid = _tableHasPid; // pont requis par net/msg-lobby.mjs (9g-C3)

  // [9g-B3] _setCanShow (« Show » post-main) déplacé dans public/modules/ui/table-cards.mjs
  // (toujours global via window.*).


  // [9g-B1] _remainCount déplacé dans public/modules/ui/game-info.mjs
  // (toujours global via window.*).


  // [9f-8] updateLobbyStatsBar / renderGames déplacés dans
  // public/modules/ui/lobby.mjs (toujours globaux via window.*).

  // [9f-6] addChat déplacée dans public/modules/ui/chat.mjs (toujours
  // globale via window.addChat).

  // [Phase 2 / 9d] esc (échappement HTML) déplacée dans public/modules/ui/misc.mjs.

  // ── API PUBLIQUE ──
  // [Phase 2 / 9b] Rendu des cartes (cardName, _deckFace/_deckBack,
  // _refreshDeck, cardToHtml, cardHtml) déplacé dans
  // public/modules/ui/deck.mjs (toujours global via window.*).

  // [9g-B3] _ownCardsHidden / renderMyCards / window._refreshOwnCards déplacé dans public/modules/ui/table-cards.mjs
  // (toujours global via window.*).




  // ═══════════════════════════════════════════════════════════
  // ANIMATIONS — Distribution, jetons, stats
  // ═══════════════════════════════════════════════════════════

  // [9g-B3] animateCardDeal / animateChipToPot déplacé dans public/modules/ui/table-cards.mjs
  // (toujours global via window.*).


  // [Phase 2 / 9b] flipCommCards déplacée dans public/modules/ui/deck.mjs.

  // [9f-4] Panneau stats (toggleStats, renderStats, renderBoard, initStats,
  // recordHand…) déplacé dans public/modules/game/stats.mjs.

  // [9g-B2] Force de la main (calcWinProb, _hs*, _gipAssistSync, renderPreFlop/HandStrength) déplacé dans public/modules/ui/odds-panel.mjs
  // (toujours global via window.*).


  // [9g-B3] renderComm déplacé dans public/modules/ui/table-cards.mjs
  // (toujours global via window.*).


  // ─── Seat positions (% of oval) — 10 max, starting from bottom going clockwise ───

  // Hardcoded seat positions (% within oval): index 0 = ME (bottom center)
  // Seat positions OUTSIDE the oval (% of oval size, can be negative or >100)
  // Index 0 = ME always at bottom-center outside
  // Others = opponents clockwise from top-left

  function getSeatPositions(n) {
    var mob = window.innerWidth < 640;
    var layouts = mob ? S.SEAT_LAYOUTS_MOB : S.SEAT_LAYOUTS_DESK;
    return layouts[n] || layouts[10].slice(0, n);
  }

  // [Phase 2 / 9b] _pthPuck, chipSvg, dealerChipSvg déplacées dans
  // public/modules/ui/deck.mjs (toujours globales via window.*).
  // Fallback used by the puck <img onerror>: rebuild the built-in SVG chip so a
  // missing/removed puck image (e.g. a stale --puck-* left in localStorage by a
  // gallery theme that was later deleted) shows a proper D/SB/BB chip instead of
  // a broken-image square.
  window._pthChip = function (label) {
    var d = (label === 'D');
    var bg = d ? '#1a1a1a' : (label === 'SB' ? '#1565c0' : '#b71c1c');
    var fg = d ? '#ffd700' : '#fff';
    var edge = d ? '#3d2b00' : (label === 'SB' ? '#0a3d7a' : '#6d0c0c');
    var nf = d ? '#c8a850' : 'white';
    var ringStroke = d ? '#c8a850' : 'rgba(255,255,255,0.7)';
    var cls = d ? 'dealer-chip' : 'blind-chip';
    var txt = d ? 'D' : label;
    var fs = d ? 9 : 7;
    var notches = '';
    for (var i = 0; i < 8; i++) {
      notches += '<rect x="13" y="0.5" width="6" height="7" rx="2" fill="' + nf + '"'
               + ' transform="rotate(' + (i * 45) + ' 16 16)" opacity="0.9"/>';
    }
    return '<svg class="' + cls + '" viewBox="0 0 32 32" width="20" height="20" xmlns="http://www.w3.org/2000/svg">'
      + '<circle cx="16" cy="16" r="15.5" fill="' + edge + '"/>'
      + '<circle cx="16" cy="16" r="13" fill="' + bg + '"/>'
      + notches
      + '<circle cx="16" cy="16" r="9" fill="' + bg + '" stroke="' + ringStroke + '" stroke-width="1.5"/>'
      + '<text x="16" y="16.5" text-anchor="middle" dominant-baseline="central"'
      + ' fill="' + fg + '" font-size="' + fs + '" font-weight="900"'
      + ' font-family="Arial Black,Arial,sans-serif">' + txt + '</text>'
      + '</svg>';
  };
  // Variante inline du jeton integre pour la barre heros (.player-bar) : pas de
  // classe blind-chip/dealer-chip (position:absolute -> se calerait sur le coin
  // de la barre fixe et partirait hors ecran), mais un rendu inline-block.
  window._pthBarChip = function (label) {
    return String(window._pthChip(label) || '')
      .replace(/class="(?:blind|dealer)-chip"/,
        'style="display:inline-block;width:18px;height:18px;vertical-align:middle;flex:none;filter:drop-shadow(0 1px 3px rgba(0,0,0,.4))"');
  };

  // [9g-C6] getPlayerName déplacé dans public/modules/game/seat-render.mjs
  // (toujours global via window.*).

  // [9f-9] _hlEliminatedPids déplacée dans public/modules/game/showdown.mjs.
  // Liste des joueurs actuellement à la table (pour le panneau stats).
  window._statsTablePlayers = function () {
    try {
      return (S.seats || []).filter(function (pid) {
        // Joueur éliminé (tapis à 0, encore assis) : retiré de la liste des
        // stats — il ne joue plus, ses lignes n'apportent rien au tour en
        // cours (demande forum). Ses mains restent dans l'historique et le
        // .pdb ; seul l'affichage « table » l'exclut. Tant que le stack est
        // inconnu (non transmis), on garde le joueur.
        var _sd = S.seatData && S.seatData[pid];
        if (!_sd) return true;
        if (_sd.gone) return false;
        return !(typeof _sd.money === 'number' && _sd.money === 0);
      }).map(function (pid) {
        return {
          pid: pid,
          name: getPlayerName(pid),
          // Droits serveur (PlayerInfo champ 3) : 1=invite, 2=enregistre,
          // 3=admin. Absent tant que la reponse n'est pas arrivee -> 0.
          rights: (S._playerRights && S._playerRights[pid]) || 0,
          me: pid === S.myId,
          bot: (typeof isBot === 'function') ? !!isBot(pid) : false,
        };
      });
    } catch (_e) { return []; }
  };
  // URLs du moteur SQLite vendored (pour l'export .pdb).
  window._sqlJsUrl = '/vendor/sql-wasm.js';
  window._sqlJsWasmUrl = '/vendor/sql-wasm.wasm';
  // Export .pdb depuis les options avancées (bouton).
  window._advExportPdb = function (scope, btn) {
    if (typeof window._exportPdb !== 'function') return;
    var old = btn ? btn.innerHTML : null;
    if (btn) { btn.disabled = true; btn.innerHTML = '…'; }
    Promise.resolve(window._exportPdb(scope)).catch(function () {}).then(function () {
      if (btn) { btn.disabled = false; btn.innerHTML = old; }
    });
  };

  // [Phase 2 / 9b] _timerSvg déplacée dans public/modules/ui/deck.mjs.

  // [9f-3] _timerRectSvg / _updateTimer / startTurnTimer / stopTurnTimer
  // déplacés dans public/modules/game/turn-timer.mjs (globaux via window.*).

  // [9g-C6] isBot / getPlayerInitial / getPlayerTypeBadge déplacé dans public/modules/game/seat-render.mjs
  // (toujours global via window.*).


  // [Phase 2 / 9a] Géométrie officielle QML (_qmlLandscapeLayout,
  // _qmlPortraitScale, _officialSeatPix, _applyQmlBgCenter) déplacée dans
  // public/modules/game/layout.mjs (toujours globale via window.*). Les
  // appels nus ci-dessous résolvent via window, comme pour #1-#8.

  // [9g-C6] renderSeatsImmediate déplacé dans public/modules/game/seat-render.mjs
  // (toujours global via window.*).


  // ── Coalesced public entry point ──
  // [9g-C6] renderSeats (débounce rAF) déplacé dans public/modules/game/seat-render.mjs
  // (toujours global via window.*).


  // Mode spectateur : aucune barre d'action, comme le client QML officiel
  // (rien n'est affiché à la place des boutons). On vide simplement #g-actions.
  function clearSpectatorActions() {
    var ga = document.getElementById('g-actions');
    if (ga) ga.innerHTML = '';
    try { updateBottomLayout(); } catch (e) {}
  }
  window.clearSpectatorActions = clearSpectatorActions; // pont requis par ui/action-bar.mjs (9g-B4)

  function renderGameWaiting(msg, isHtml) {
    // Si le panneau "aperçu" est ouvert et que ce n'est pas notre tour, on
    // affiche le panneau au lieu du message d'attente (et on le garde sticky
    // face aux mises à jour serveur — tour d'un autre joueur, etc.).
    S._lastWaitingMsg = msg; S._lastWaitingIsHtml = !!isHtml;
    // Barre TOUJOURS présente pendant la partie (demande narmod 2026-07-17) :
    //  - plus de condition sur myCards : au showdown / entre les mains les
    //    cartes sont nulles mais la barre doit rester (boutons inertes) pour
    //    ne pas effondrer #g-actions → re-layout de la table (zoom/dézoom) ;
    //  - le garde « pas à notre tour » devient « pas notre tour LIVE » : en
    //    fin de main turnPid peut rester sur nous (dernier acteur) alors que
    //    setMyTurnActive(false) a déjà éteint le tour — la barre d'aperçu
    //    doit alors remplacer le message, pas l'inverse.
    var _liveTurn = false;
    try { var _mzL = document.querySelector('.my-zone'); _liveTurn = !!(_mzL && _mzL.classList.contains('my-turn-active')); } catch (e) {}
    var _pinShow = !S._amSpectator && S._gameStarted; // barre toujours affichée (mode masqué permanent)
    if ((S._preActionOpen || _pinShow) && !(S.turnPid === S.myId && _liveTurn)) { _renderPreActionPanel(); updateBottomLayout(); return; }
    // Message vide = narrateur de tour retiré (fidélité QML : l'officiel
    // n'affiche aucun texte, le tour est signalé par la surbrillance du
    // siège). On vide #g-actions au lieu d'y laisser un bloc creux.
    if (!msg) { $('g-actions').innerHTML = ''; updateBottomLayout(); return; }
    // isHtml=true : msg contient du HTML interne sûr (généré par notre code)
    $('g-actions').innerHTML = '<div class="waiting-msg">' + (isHtml ? msg : esc(msg)) + '</div>';
    updateBottomLayout();
  }
  window.renderGameWaiting = renderGameWaiting; // pont requis par ui/action-bar.mjs (9g-B4)

  // Rendu du panneau "aperçu des actions" (cartes tapées hors de notre tour).
  // Boutons d'action en APERÇU (désactivés) + le seul réglage activable :
  // l'auto-check/fold. Toujours rendu dans #g-actions.
  function _flushPreviewIfPending() {
    if (!S._modeSelPendingPreview) return;
    S._modeSelPendingPreview = false;
    if (S._preActionOpen && S.turnPid !== S.myId) renderMyTurnActions(true);
  }

  // [9g-B4] _updatePinBtn / _renderPreActionPanel / _closePreActionPanel déplacé dans public/modules/ui/action-bar.mjs
  // (toujours global via window.*).


  // ── Join send guard + watchdog (fix: silent « Join button not working ») ──
  // send() now returns false when the WebSocket is no longer open (tab put
  // to sleep, network dropped): without this guard, clicking Join printed
  // « Joining… » and then nothing. On failure we warn the user
  // (errConnLost) and force a reconnect. If the frame *was* sent but neither
  // JoinGameAck nor JoinGameFailed arrives within 6 s (network lost right
  // after sending), the watchdog reports the missing reply (errJoinTimeout).
  // The timer is disarmed by both handlers in net/msg-game-join.mjs.
  function _sendJoin(data) {
    if (!send(data)) {
      setStatus('⚠ ' + (t('errConnLost') || 'Connection lost.'), 'err');
      try { _forceReconnect('send failed while joining'); } catch (e) {}
      return false;
    }
    if (S._joinWd) clearTimeout(S._joinWd);
    S._joinWd = setTimeout(function () {
      S._joinWd = 0;
      setStatus('⚠ ' + (t('errJoinTimeout') || 'No reply from the server — check your connection.'), 'err');
    }, 6000);
    return true;
  }

  // ─────────────────────────────────────────────────────────────────
  // Waiting-room panel — shown between JoinGameAck and GameStartInitial.
  // Displays:
  //   * current/max player count + progress bar
  //   * minimum-to-start indicator (poker needs 2 humans/bots)
  //   * the list of players currently in the room, each with their
  //     avatar (cached emoji or '?') and pseudo
  //   * admin-vs-guest action hint
  // Refreshed automatically by GamePlayerJoined, GamePlayerLeft and
  // PlayerInfoReply handlers; frozen once GameStartInitial fires.
  // ─────────────────────────────────────────────────────────────────
  // État de la case « Compléter avec des joueurs ordinateur » de la wait-page
  // (parité fillCpuCheck.checked côté QML). En mémoire de session seulement.
  window._wpFillBots = window._wpFillBots || false;
  // A été explicitement (dé)coché par l'utilisateur ? Tant que non, le défaut
  // suit le mode : coché en entraînement (offline), décoché ailleurs.
  window._wpFillBotsUserSet = window._wpFillBotsUserSet || false;
  window._wpSetFillBots = function(v) { window._wpFillBots = !!v; window._wpFillBotsUserSet = true; try { if (window._renderLobbyWaitActions) window._renderLobbyWaitActions(); } catch (e) {} };

  function renderWaitingPanel() {
    if (S._gameStarted) return;
    // Refonte « wait-page dans le lobby » : pendant l'attente on reste sur
    // s-lobby et c'est le panneau central #lobby-gameinfo qui porte les infos
    // de partie, la liste des joueurs et les options d'attente (case bots +
    // Démarrer / Quitter, selon admin ou joueur simple). On rafraîchit donc
    // simplement ce panneau à chaque join / leave / PlayerInfoReply.
    try {
      if (S.gId) {
        if (S._selectedGame !== S.gId) S._selectedGame = S.gId;
        renderGameInfoPanel(S.gId);
      }
    } catch (e) {}
    try { _updateLobbyWaitStatus(); } catch (e) {}
  }
  window.renderWaitingPanel = renderWaitingPanel; // pont requis par net/msg-lobby.mjs (9g-C3)

  // [9f-8] _updateLobbyWaitStatus déplacée dans public/modules/ui/lobby.mjs.

  // Masque la wait-page et révèle le feutre. Appelé à GameStartInitial et
  // au départ de la table.
  function _wpHide() {
    var el = document.getElementById('g-wait-page');
    if (el) { el.style.display = 'none'; el.innerHTML = ''; }
    try { _updateLobbyWaitStatus(); } catch (e) {}
    // Garantit que le dos de carte (--card-back) est posé quand on entre en
    // jeu : le boot inline peut échouer sur certaines sessions (nouvel
    // utilisateur, cache), laissant le dos SVG vert de secours de :root.
    // _refreshDeck relit data-deck et réapplique le vrai flipside. (narmod 19/07)
    try { if (typeof window._refreshDeck === 'function') window._refreshDeck(); } catch (e) {}
  }
  window._wpHide = _wpHide;
  window._renderWaitingPanel = renderWaitingPanel;

  // [9f-9] showEndGameOverlay déplacée dans public/modules/game/showdown.mjs
  // (toujours globale via window.*).

  function updateBottomLayout() {
    _updatePinBtn();
    // Echelle continue de la barre d'action (--bar-k) : suit la fenetre
    // comme le client QML, et ATTERRIT sur les valeurs du profil paysage
    // mobile a la frontiere (plus de « marche ») : a h=500, 54*k = 30px
    // pile (k plancher 0.55, h/900 et w/1300). Les polices suivent une
    // courbe plus douce (--bar-kf = 0.55 + 0.45k -> 0.8 a la frontiere,
    // soit 0.72rem = la valeur paysage). Pose partout : sur telephone les
    // blocs medias surchargent avec leurs valeurs fixes, sans effet.
    try {
      var _bw = window.innerWidth, _bh = window.innerHeight;
      // Échelle QML DISCRÈTE (GameActionBar 2.1.3) : le client officiel n'a
      // AUCUNE échelle continue — rangée 54 px constante, 56 si Theme.compact
      // (largeur < 600), 40 en landscapeCompact. k = rowHeight/54, police
      // kf = 12/15 = 0.8 en landscapeCompact, 1 sinon. (Remplace le rétreint
      // continu min(W/1300, H/900) qui faisait des boutons de 45 px sur des
      // fenêtres où le QML en affiche 54 — demande narmod 15/07.)
      // compactActions QML = landscapeCompact && isMobile : le desktop
      // ultrawide GARDE 54 px (« Auf dem Desktop bleiben die Buttons groß »).
      // isMobile web = pointer:coarse (une fenetre desktop basse restait
      // faussement « mobile » avec le seul critere h<600 -> boutons 40 px
      // la ou le QML en met 54). Theme.compact desktop = largeur < 900
      // (threeColumnMinWidth, bible §2) -> 56 px aussi entre 600 et 900.
      var _coarse = false;
      try { _coarse = window.matchMedia('(pointer: coarse)').matches; } catch (e2) {}
      var _lcB = _bw > _bh && _bh < 600 && _coarse;
      // web.223 : Theme.compact QML = windowWidth < 600 (config/Theme.qml),
      // PAS < 900 (seuil de Responsive, 3 colonnes) — GameActionBar lit bien
      // Config.Theme.compact. Les boutons faisaient 56 px entre 600 et 900.
      var _bk = _lcB ? 0.741 : (_bw < 600 ? 1.037 : 1);
      var _bkf = _lcB ? 0.8 : 1;
      if (window.__barK !== _bk) {
        window.__barK = _bk;
        document.documentElement.style.setProperty('--bar-k', _bk);
        document.documentElement.style.setProperty('--bar-kf', _bkf);
      }
      // ── Barre d'action ORDINATEUR : un seul format + un seul facteur (web.225)
      // Souris (hover + pointer fine) : la barre garde le gabarit QML desktop
      // (115 px, polices 13/11/12/11/15) quelle que soit la forme de la fenêtre
      // — plus de bascule vers les formats téléphone (portrait < 740 px,
      // paysage ≤ 500 px de haut) qui la faisaient sauter de 131 à 104 px et
      // changer de polices en redimensionnant. Les petites fenêtres la
      // réduisent d'un bloc : --abar-k = min(h/720, w/760) borné [0.8, 1]
      // (0.8 = gabarit téléphone QML, polices 12/15). Voir pokerth.css
      // « data-abar-desk ». Téléphones / tablettes tactiles : inchangés.
      var _fine = false;
      try { _fine = window.matchMedia('(hover: hover) and (pointer: fine)').matches; } catch (eF) {}
      // web.226 (narmod) : une PETITE fenêtre d'ordinateur repasse en mode
      // TÉLÉPHONE, exactement aux seuils des blocs CSS téléphone — portrait
      // ≤ 740 px de large, paysage ≤ 500 px de haut — pour pouvoir vérifier
      // le rendu mobile depuis un ordinateur. Au-dessus : format ordinateur
      // unique, réduit par --abar-k.
      var _phoneWin = (_bh > _bw && _bw <= 740) || (_bw >= _bh && _bh <= 500);
      var _de = document.documentElement;
      if (_fine && !_phoneWin) {
        // Plancher 0.8 atteint vers 576 px de haut / 608 px de large : le
        // passage au mode téléphone (≤ 500 / ≤ 740) se fait depuis ce palier.
        var _ak = Math.max(0.8, Math.min(1, _bh / 720, _bw / 760));
        _ak = Math.round(_ak * 1000) / 1000;
        if (_de.getAttribute('data-abar-desk') !== '1') _de.setAttribute('data-abar-desk', '1');
        if (window.__abarK !== _ak) { window.__abarK = _ak; _de.style.setProperty('--abar-k', _ak); }
      } else if (_de.hasAttribute('data-abar-desk')) {
        _de.removeAttribute('data-abar-desk'); _de.style.removeProperty('--abar-k'); window.__abarK = null;
      }
      // web.227 (narmod) : format TÉLÉPHONE en paysage très bas (< 380 px de
      // haut, souris ou tactile) — la barre (≈ 93 px) plus la table au
      // plancher d'échelle dépassaient la fenêtre : barre coupée de 17 à 20 px
      // en bas à 682×297 (déjà vrai en web.215). Réduction d'un bloc, polices
      // comprises : --abar-kp = h/380, plancher 0.75. Voir pokerth.css.
      var _shortPh = !(_fine && !_phoneWin) && _bw >= _bh && _bh < 380;
      if (_shortPh) {
        var _kp = Math.round(Math.max(0.75, Math.min(1, _bh / 380)) * 1000) / 1000;
        if (_de.getAttribute('data-abar-short') !== '1') _de.setAttribute('data-abar-short', '1');
        if (window.__abarKp !== _kp) { window.__abarKp = _kp; _de.style.setProperty('--abar-kp', _kp); }
      } else if (_de.hasAttribute('data-abar-short')) {
        _de.removeAttribute('data-abar-short'); _de.style.removeProperty('--abar-kp'); window.__abarKp = null;
      }
    } catch (e) {}
    var pb = document.querySelector('.player-bar');
    var mz = document.querySelector('.my-zone');
    var ga = document.querySelector('.game-area');
    if (pb && mz) {
      var _masked = document.body.classList.contains('adv-hide-pbar');
      // Player-bar masquee : elle est display:none (offsetHeight=0 -> le fallback
      // 52 ferait flotter la barre d'action). On la colle a bottom:0 et on reserve
      // SA hauteur sous les sieges pour que la self-box reste visible (pas de
      // chevauchement avec la barre d'action epinglee).
      var pbH = _masked ? 0 : (pb.offsetHeight || 52);
      mz.style.bottom = pbH + 'px';
      // Reserve EXACTE sous la table -> le tapis colle au-dessus de la barre
      // d'action (demande narmod). Quand les barres sont position:fixed
      // (portrait mobile, desktop), on MESURE leur hauteur reelle (dock +
      // barre d'action) au lieu du clamp CSS approximatif (110-140 px) qui
      // laissait un grand vide sous la self-box ou masquait le bas de zone.
      // En paysage court les barres sont en FLUX : le CSS force deja
      // padding-bottom:0 !important -> on nettoie l'inline.
      if (ga) {
        var _fixed = false;
        try { _fixed = getComputedStyle(mz).position === 'fixed'; } catch (e) {}
        // web.225 : barre ordinateur (data-abar-desk) — hauteur VISUELLE
        // (zoom --abar-k compris, offsetHeight l'ignore) et réserve posée en
        // !important : en fenêtre basse (≤ 500 px) le CSS téléphone force
        // padding-bottom:0 !important sur .game-area, or la barre ordinateur
        // reste flottante (fixed) et recouvrait les sièges du bas.
        var _desk = document.documentElement.getAttribute('data-abar-desk') === '1';
        if (_fixed) {
          var _res = pbH + (_desk ? Math.round(mz.getBoundingClientRect().height) : (mz.offsetHeight || 0));
          var _cur = parseInt(ga.style.paddingBottom, 10) || 0;
          if (_cur !== _res || (_desk && ga.style.getPropertyPriority('padding-bottom') !== 'important')) {
            if (_desk) ga.style.setProperty('padding-bottom', _res + 'px', 'important');
            else ga.style.paddingBottom = _res + 'px';
            // La hauteur visible de la zone vient de changer : replacer les
            // sieges (guard _cur!==_res -> pas de boucle de re-rendu).
            setTimeout(function () { try { if (typeof renderSeats === 'function' && typeof S.seats !== 'undefined' && S.seats.length) renderSeats(); } catch (e) {} }, 50);
          }
        } else ga.style.removeProperty('padding-bottom');
      }
    }
  }
  window.updateBottomLayout = updateBottomLayout; // pont requis par ui/action-bar.mjs (9g-B4)

  // Track action history
  // Le journal stocke des FONCTIONS de rendu (thunks), pas des chaînes figées :
  // chaque entrée est rejouée à chaque rendu, donc les appels à t() reflètent
  // la langue active. renderLog() est exposé en window._retranslateLog et
  // rappelé par _retranslateSysChat() (lui-même appelé par setLang) → le journal
  // se re-traduit instantanément au changement de langue. Une chaîne passée
  // directement (lignes sans terme traduisible) est simplement figée.
  // `role` (optionnel) colore la ligne comme le fait le client officiel :
  // 'board' pour flop/turn/river, 'win' pour le gagnant du pot principal,
  // 'win-side' pour un side pot (upstream e90593e, TableChatColors). Il peut
  // etre une FONCTION, evaluee au rendu comme le texte : au moment ou la ligne
  // d'un gagnant est ecrite, on ne sait pas encore si un autre joueur ramassera
  // davantage sur la meme main. Une valeur inconnue ne pose aucune classe.
  function logAction(entry, isAction, role) {
    // Parite QML LogsSettings : LogOnOff coupe la collecte (les entrees deja
    // enregistrees restent affichees) ; LogInterval 'hand' saute les lignes
    // d'action individuelles (isAction) et ne garde que les etapes de main.
    try {
      if (!_advGet('log_on', true)) return;
      if (isAction && _getLogInterval() === 'hand') return;
    } catch (e) {}
    var _src = (typeof entry === 'function') ? entry : function(){ return entry; };
    // Enveloppe systematique : le role est porte par la fonction stockee, et
    // deux appels peuvent partager la meme fonction source avec des roles
    // differents. _buildLogText et renderLog n'appellent que fn().
    var fn = function(){ return _src(); };
    fn.role = role || null;
    S.actionLog.push(fn);
    if (S.actionLog.length > 500) S.actionLog.shift();
    renderLog(1);   // une ligne de plus en tete (liste inversee) — cf. renderLog
  }
  window.logAction = logAction; // pont requis par ui/action-bar.mjs (9g-B4)
  // Defilement du journal — parite client Qt-Widgets / QML : le suivi
  // automatique se met en PAUSE des que le joueur quitte le bord « direct »
  // pour relire une main precedente, et reprend tout seul au retour. La
  // mecanique (ancrage + barre « aller au plus recent ») vit dans
  // ui/livescroll.mjs ; repli sur l'ancien comportement s'il n'est pas la.
  // `addedTop` = nombre de lignes gagnees en tete depuis le dernier rendu (1
  // depuis logAction, 0 pour une simple retraduction). Indispensable une fois
  // le plafond de 500 entrees atteint : chaque nouvelle ligne en chasse une en
  // queue, le nombre de lignes ne bouge donc plus et la seule geometrie ne
  // suffit plus a retrouver la ligne que le joueur est en train de lire.
  function renderLog(addedTop) {
    const el = document.getElementById('g-log-body');
    if (!el) return;
    var _n = (typeof addedTop === 'number') ? addedTop : 0;
    var _ls = (typeof window._liveBefore === 'function') ? window._liveBefore(el) : null;
    el.innerHTML = S.actionLog.slice().reverse().map(function(fn){
      var s; try { s = fn(); } catch (_e) { s = ''; }
      // Role de la ligne (cf. logAction) : resolu A CHAQUE rendu, donc un role
      // fonction voit l'etat final de la main meme si la ligne a ete ecrite
      // pendant l'abattage.
      var r = fn && fn.role; if (typeof r === 'function') { try { r = r(); } catch (_e2) { r = null; } }
      var cls = (r === 'board' || r === 'win' || r === 'win-side') ? ' lg-' + r : '';
      return '<div class="log-line'+cls+'">'+esc(s)+'</div>';
    }).join('');
    if (_ls) window._liveAfter(el, _ls, _n);
    else el.scrollTop = 0; // le plus recent est en haut (liste inversee)
  }
  window._retranslateLog = renderLog;
  // Vide le journal de partie (nouvelle partie — parite QML GameHandler::setGame,
  // qui vide m_gameLogModel avec le chat). Vidage EN PLACE : S.actionLog est
  // partage par reference (export, retraduction).
  function clearGameLog() {
    S.actionLog.length = 0;
    renderLog(0);
    var el = document.getElementById('g-log-body');
    if (el && typeof window._liveReset === 'function') window._liveReset(el);
  }
  window.clearGameLog = clearGameLog;
  // Texte brut du journal (ordre chronologique) pour l'export.
  function _buildLogText() {
    return S.actionLog.map(function(fn){ var s; try { s = fn(); } catch (_e) { s = ''; } return s; }).join('\n');
  }
  window._buildLogText = _buildLogText;
  // Joueurs déjà signalés comme éliminés (stack à 0) — évite de re-logguer à
  // chaque main suivante tant qu'ils n'ont pas quitté la table. Vidé au début
  // de chaque nouvelle partie (StartEvent).
  function logEliminations() {
    for (var _i = 0; _i < S.seats.length; _i++) {
      var _ep = S.seats[_i];
      var _sd = S.seatData[_ep];
      if (_sd && !_sd.gone && _sd.money === 0 && !S._eliminatedLogged.has(_ep)) {
        S._eliminatedLogged.add(_ep);
        const _ce = _ep;
        logAction(function(){ return '\u2620 ' + t('logEliminated', { name: getPlayerName(_ce) }); });
      }
    }
  }
  window.logEliminations = logEliminations; // pont requis par game/msg-hand.mjs (9g-C5b)
  // [Phase 2 / 9d] setPct déplacée dans public/modules/ui/misc.mjs.
  window.setPct = setPct;
  // Exposer pour les animations + fonctions globales
  Object.defineProperty(window, 'seats',       {get: function(){ return S.seats; }});
  Object.defineProperty(window, 'seatData',    {get: function(){ return S.seatData; }});
  Object.defineProperty(window, 'myId',        {get: function(){ return S.myId; }});
  Object.defineProperty(window, 'players',     {get: function(){ return S.players; }});
  Object.defineProperty(window, '_ipBlockUntil',{
    get: function(){ return S._ipBlockUntil; },
    set: function(v){ S._ipBlockUntil = v; }
  });
  // Exposer pour les fonctions globales (avatar, etc.)
  // [9g-B4] notifyMyTurnVisuals / clearTurnNotif déplacé dans public/modules/ui/action-bar.mjs
  // (toujours global via window.*).


  window._renderSeats = function() { if (S.seats.length) renderSeats(); try { if (typeof window._hudRender === 'function') window._hudRender(); } catch (e) {} };
  // Variante SYNCHRONE (sans requestAnimationFrame) : rend immediatement, utilisee
  // par setSeatLayout sur iOS ou le rAF peut etre gele apres le selecteur natif.
  window._renderSeatsNow = function() { if (S.seats.length) { try { renderSeatsImmediate(); } catch (e) {} } try { if (typeof window._hudRender === 'function') window._hudRender(); } catch (e) {} };
  // Pseudos pour la complétion Tab du chat (parité ChatBox QML, bible §11) :
  // en jeu = les joueurs de la table ; au lobby = tous les joueurs connus.
  // Activité d'un joueur pour le panneau « Joueurs » (parité tooltip QML
  // 2.1) : nom de la table où il est assis — games[*].seats est tenu à jour
  // en continu par GameListNew / GameListPlayerJoined / GameListPlayerLeft —
  // ou '' s'il est au lobby.
  window._playerActivity = function (pid) {
    try {
      for (var id in S.games) {
        var g = S.games[id];
        if (g && g.mode !== 3 && g.seats && g.seats.indexOf(pid) !== -1) {
          return g.name || ('#' + id);
        }
      }
      // Parité QML 26018c9 : un spectateur n'est pas « idle » non plus
      // (syncPlayerGameMembership balaie info.spectators puis info.players,
      // le siège prime — d'où la seconde passe ici). games[*].watchers est
      // tenu à jour par GameListSpectatorJoined / Left (msg-lobby.mjs).
      for (var id2 in S.games) {
        var g2 = S.games[id2];
        if (g2 && g2.mode !== 3 && g2.watchers && g2.watchers.indexOf(pid) !== -1) {
          return g2.name || ('#' + id2);
        }
      }
    } catch (e) {}
    return '';
  };
  // Parite QML isPlayerInRunningGame : partie DEMARREE seulement (mode 2 =
  // netGameStarted). _playerActivity ci-dessus ne distingue pas une partie
  // ouverte d'une partie lancee, et le serveur ne refuse les messages prives
  // que vers une table en cours.
  window._playerInRunningGame = function (pid) {
    try {
      for (var id in S.games) {
        var g = S.games[id];
        if (g && g.mode === 2 && g.seats && g.seats.indexOf(pid) !== -1) return true;
      }
    } catch (e) {}
    return false;
  };
  // Suis-je admin pokerth.net (playerRights = 3) ? Parite QML
  // isCurrentPlayerAdmin, qui conditionne l'icone marteau de la liste.
  window._amServerAdmin = function () {
    try { return ((S._playerRights && S.myId) ? (S._playerRights[S.myId] || 0) : 0) === 3; }
    catch (e) { return false; }
  };
  // Suis-je connecte en invite ? Le serveur refuse tout chat des invites.
  window._amGuestMode = function () {
    try { return S._currentLoginMode === 'guest'; } catch (e) { return false; }
  };
  // Suis-je un joueur invite (droits serveur 1, ou mode de connexion invite) ?
  // Parite QML Lobby.isMyPlayerGuest (upstream 04f5839) : les invites ne
  // peuvent plus signaler d'avatar ni de nom de table, le serveur refuse.
  window._amMyPlayerGuest = function () {
    try {
      if (S._currentLoginMode === 'guest') return true;
      return ((S._playerRights && S.myId) ? (S._playerRights[S.myId] || 0) : 0) === 1;
    } catch (e) { return false; }
  };
  // Suis-je connecte avec un COMPTE pokerth.net ? (miroir de _amGuestMode,
  // utilise par la notice operateur des comptes enregistres.)
  window._amAuthMode = function () {
    try { return S._currentLoginMode === 'auth'; } catch (e) { return false; }
  };
  // Suis-je en LAN / serveur dedie ? Ni offline (entrainement), ni pokerth.net
  // (guest/auth) -> tout le reste est LAN/dedicated (meme mapping que
  // _adminNameForMode). Utilise par la notice LAN operateur.
  window._amLanMode = function () {
    try { return !window._offlineMode && S._currentLoginMode !== 'guest' && S._currentLoginMode !== 'auth'; }
    catch (e) { return false; }
  };
  window._chatNicks = function (gameScope) {
    try {
      if (gameScope && S.seats.length) {
        return S.seats.map(function (p) { return S.players[p] || ''; }).filter(Boolean);
      }
      return Object.values(S.players || {}).filter(Boolean);
    } catch (e) { return []; }
  };
  // Repeindre la pastille "N joueur(s)" du header lobby dans la langue
  // courante. Posée imperativement à la réception des messages serveur
  // (PlayerList / Statistics), elle n'a pas de data-i18n et restait donc
  // figée dans la langue précédente lors d'un changement de langue.
  // Appelée par setLang() (i18n.mjs).
  window._refreshPlayersPill = function() {
    try {
      var el = document.getElementById('h-players');
      if (el && el.textContent !== '—') {
        el.textContent = S._lobbyPlayerCount + ' ' + t('playersOnline');
      }
    } catch (e) {}
  };
  // Retraduire les panneaux/popups OUVERTS dont le contenu est posé
  // impérativement (donc sans data-i18n, invisibles pour setLang). Si l'un
  // d'eux est affiché au moment d'un changement de langue, son texte resterait
  // figé dans la langue précédente jusqu'à fermeture/réouverture. Appelé par
  // setLang() (i18n.mjs). Chaque bloc est gardé : on ne re-rend que si ouvert.
  window._refreshOpenPanels = function() {
    // Panneau statistiques de session
    try { if (S._statsOpen && typeof renderStats === 'function') renderStats(); } catch (e) {}
    // Liste des joueurs en ligne (lobby)
    try {
      var pp = document.getElementById('players-panel');
      if (pp && pp.style.display !== 'none' && typeof renderPlayersList === 'function') renderPlayersList();
    } catch (e) {}
    // Détails de la partie
    try {
      var gim = document.getElementById('game-info-modal');
      if (gim && gim.style.display !== 'none' && typeof openGameInfoPopup === 'function') openGameInfoPopup();
    } catch (e) {}
    // Profil / avatar
    try {
      var pim = document.getElementById('player-info-modal');
      if (pim && pim.style.display !== 'none' && typeof openPlayerInfoPopup === 'function') openPlayerInfoPopup(S._pimPid);
    } catch (e) {}
  };
  window.renderGames = renderGames;
  window.toggleStats  = toggleStats;
  window._toggleStats = toggleStats;
  // Parité QML : l'avatar ne voyage QUE par le protocole PokerTH — hash dans
  // l'InitMessage, octets sur AvatarRequest, et chaque client le récupère au
  // serveur via PlayerInfoReply. Le relais AVATAR:/AVATARIMG: entre clients web
  // est retiré : ce canal parallèle montrait aux joueurs web un avatar que les
  // clients officiels ne voyaient pas (changement en cours de session, octets
  // gelés d'une autre image). Le nom reste pour les appelants (sélecteur,
  // import, studio) : il ne fait plus que rafraîchir l'affichage local.
  window._broadcastMyAvatar = function(emoji) {
    // En session, MON avatar affiché reste celui figé à l'Init (S._sessAv) :
    // le nouveau choix vaudra à la connexion suivante.
    if (!S._sessAv) S._myAvatarCache = (emoji && emoji !== '__img__' && emoji !== '__pth__') ? emoji : '';
    // Lobby pill is now an avatar+name combo (clickable, opens the
    // player-info modal). Refresh it so the user sees their pick
    // immediately, both when picking from the connect screen popup
    // AND when picking from the in-lobby popup.
    try { if (typeof updateLobbyPill === 'function') updateLobbyPill(); } catch(e) {}
  };

  // [9g-B4] _applyAssistUI + window.toggleAssist/setAssist (assistance) déplacé dans public/modules/ui/action-bar.mjs
  // (toujours global via window.*).


  // [Phase 2 / 9d] _attachPanelDrag déplacée dans public/modules/ui/misc.mjs.

  // [9g-B2] renderOddsMonitor (+ alias window._renderOdds) déplacé dans public/modules/ui/odds-panel.mjs
  // (toujours global via window.*).


  // [9g-B4] _runPreAction déplacé dans public/modules/ui/action-bar.mjs
  // (toujours global via window.*).


  // [9g-B4] renderMyTurnActions déplacé dans public/modules/ui/action-bar.mjs
  // (toujours global via window.*).


  // [9g-B4] doAction / confirmCall / doRaise déplacé dans public/modules/ui/action-bar.mjs
  // (toujours global via window.*).


// [9f-9] Showdown (snapshot des résultats, badge main gagnante, overlay
// vainqueur, dismissWinner, bouton main suivante) déplacé dans
// public/modules/game/showdown.mjs (toujours global via window.*).

  return {
    onLoginModeChange() {
      // Offline (training) mode has no network login. Keep the training hint
      // and skip BOTH the network-mode field wiring and the server-mode
      // reverse-sync at the tail (which would otherwise flip the dropdown back
      // to LAN and overwrite the hint with the 'private server' message — the
      // bug where offline showed 'Chat et réactions… serveur privé').
      if (window._offlineMode || ($('server-mode') && $('server-mode').value === 'offline')) {
        // Fully restore the training-mode UI here too, so this stays correct
        // no matter which function ran last: free-nick label, placeholder, and
        // the training hint (never the pokerth.net account label / auth hint).
        var _oln = $('nick-label'); if (_oln) _oln.textContent = t('enterNickFree');
        var _oni = $('nick'); if (_oni) { _oni.removeAttribute('readonly'); _oni.placeholder = t('nickPlaceholder'); }
        if (typeof _stopIpBlockCountdown === 'function') _stopIpBlockCountdown();
        setStatus(t('offlineHint'), '', 'offlineHint');
        var _offReg = document.getElementById('register-link-row'); if (_offReg) _offReg.style.display = 'none';
        var _offFpw = document.getElementById('forgot-pw-link'); if (_offFpw) _offFpw.style.display = 'none';
        try { if (window._setSrvSourceTag) window._setSrvSourceTag(false); } catch (e) {}
        return;
      }
      const mode = $('login-mode').value;
      $('f-pass').style.display = mode === 'auth' ? '' : 'none';
      // Lien d'inscription pokerth.net : visible uniquement en Internet/PokerTH.net
      // (modes internes guest/auth) — l'inscription n'a de sens que sur le serveur
      // officiel. Le libellé est déjà traduit par data-i18n (retraduit par setLang).
      var _regRow = document.getElementById('register-link-row');
      if (_regRow) _regRow.style.display = (mode === 'guest' || mode === 'auth') ? '' : 'none';
      // Lien « mot de passe oublié ? » (à droite de la case Mode invité) :
      // même règle — la récupération de mot de passe est un service
      // pokerth.net, elle n'a aucun sens en LAN / serveur dédié.
      var _fpwLink = document.getElementById('forgot-pw-link');
      if (_fpwLink) _fpwLink.style.display = (mode === 'guest' || mode === 'auth') ? '' : 'none';
      // TLS is only ever meaningful when connecting to pokerth.net
      // (which mandates it). On LAN / private servers it's almost
      // always uncheck-and-forget, so we just hide the row there to
      // declutter the form. The setting itself stays in the DOM —
      // each branch below still sets $('use-tls').checked appropriately.
      var tlsRow = document.getElementById('tls-row');
      // TLS : option avancée dans TOUS les modes — visible uniquement quand la
      // roue crantée est ouverte. La case ($('use-tls').checked) garde la valeur
      // fixée par mode plus bas (TLS reste actif pour pokerth.net même masqué,
      // d'autant que guest/auth passent par une connexion wss directe).
      if (tlsRow) {
        var advBtn = document.getElementById('conn-adv-btn');
        // LAN / dédié seulement : en Internet la roue est masquée (et refermée
        // plus bas) — la lire ici laissait la case TLS visible en arrivant de
        // LAN avec la roue ouverte.
        tlsRow.style.display = ((mode === 'lan' || mode === 'unauth') && advBtn && advBtn.classList.contains('open')) ? '' : 'none';
      }

      // Champ mot de passe SERVEUR : seuls les serveurs auto-hébergés
      // (LAN / dédié privé) peuvent en exiger un. pokerth.net est le build
      // officiel et l'ignore, donc on masque le champ dans les modes
      // guest/auth. Il vit dans le bloc « roue crantée » (conn-advanced) :
      // doublement masqué tant que la roue n'est pas ouverte.
      var advWrap = document.getElementById('f-server-pass');
      if (advWrap) advWrap.style.display = (mode === 'lan' || mode === 'unauth') ? '' : 'none';
      // URL du proxy WebSocket : en mode pokerth.net (guest/auth) le pont est
      // toujours le meme (celui qui sert l'app), donc l'exposer prete a confusion.
      // Masque dans ces modes ; visible en LAN / dedie (ou l'on peut pointer vers
      // un autre pont). La valeur reste fixee par mode plus bas, connexion inchangee.
      var proxyWrap = document.getElementById('f-proxy');
      if (proxyWrap) proxyWrap.style.display = (mode === 'lan' || mode === 'unauth') ? '' : 'none';
      // Mot de passe UTILISATEUR (compte) : option avancée placée sous le login.
      // En mode LAN / dédié il suit l'état de la roue crantée (comme le TLS) ;
      // sinon caché. Seul le login (pseudo) reste toujours visible.
      var userWrap = document.getElementById('f-user-pass');
      if (userWrap) {
        if (mode === 'lan' || mode === 'unauth') {
          var advBtnU = document.getElementById('conn-adv-btn');
          userWrap.style.display = (advBtnU && advBtnU.classList.contains('open')) ? '' : 'none';
        } else {
          userWrap.style.display = 'none';
        }
      }
      // Roue crantee (options avancees) : visible seulement en LAN / dedie, ou
      // l'on peut devoir saisir un hote personnalise. En Internet/PokerTH.net,
      // l'hote/port/TLS sont geres automatiquement -> on cache la roue ET on
      // referme le bloc avance (rien d'editable n'est expose au joueur).
      var gearBtn = document.getElementById('conn-adv-btn');
      var advBlock = document.getElementById('conn-advanced');
      if (mode === 'lan' || mode === 'unauth') {
        if (gearBtn) gearBtn.style.display = '';
      } else {
        if (gearBtn) { gearBtn.style.display = 'none'; gearBtn.classList.remove('open'); gearBtn.setAttribute('aria-expanded', 'false'); }
        if (advBlock) advBlock.style.display = 'none';
      }
      // Politique d'instance sur le champ proxy : ne vaut qu'en LAN / dédié.
      try { if (typeof window._applyProxyPolicy === 'function') window._applyProxyPolicy(); } catch (e) {}

      // Case « Mode invité » : en Internet (guest/auth) elle reste toujours
      // visible (c'est le sélecteur invité/compte). En LAN / dédié c'est une
      // option avancée : visible seulement quand la roue crantée est ouverte
      // (demande narmod 2026-07-21).
      var guestRow = document.getElementById('guest-mode-row');
      if (guestRow) {
        if (mode === 'lan' || mode === 'unauth') {
          var advBtnG = document.getElementById('conn-adv-btn');
          guestRow.style.display = (advBtnG && advBtnG.classList.contains('open')) ? '' : 'none';
        } else {
          guestRow.style.display = '';
        }
      }

      const hostInput  = $('host');
      const proxyInput = $('proxy');
      const autoHost   = hostInput ? (hostInput.dataset.autoHost || window.location.hostname) : '';
      const proto      = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
      // Match the page-load auto-fill: when served on a standard port (e.g.
      // 443 behind an HTTPS reverse proxy) window.location.port is EMPTY, so
      // fall back to the scheme default (443/80), NOT 8080. Falling back to
      // 8080 rebuilt wss://host:8080 on every mode change — a direct-TLS URL
      // to a plain-HTTP port — which failed until a refresh restored :443.
      const port       = window.location.port || (proto === 'wss:' ? '443' : '80');

      // Helper: read a string from localStorage with try/catch so private
      // browsing modes that disable storage don't crash the page.
      var lsGet = function(k) {
        try { return localStorage.getItem(k); } catch(e) { return null; }
      };

      // Nick field state machine (spec narmod 2026-07-18) :
      //   lan / unauth / auth → éditables, préremplis depuis le pseudo
      //     PARTAGÉ pth_nick (un seul nom pour tous les modes ; en auth
      //     seul le login est stocké, jamais le mot de passe — le
      //     trousseau du navigateur s'en charge)
      //   guest → READONLY, toujours le GuestXXXXX persistant (règle à
      //     part, jamais synchronisé avec pth_nick)
      var nickEl = $('nick');
      // Always reset the readonly flag first; only Guest re-applies it.
      if (nickEl) nickEl.removeAttribute('readonly');

      // Champs « serveur » des modes LAN / serveur dédié. Règle unique, quelle
      // que soit la politique d'instance (admin → loginDefaults.lanMode) :
      //   1. ce que le joueur a saisi en dernier (pth_lan_host/port/tls) gagne ;
      //   2. à défaut, la valeur de l'instance — l'adresse de l'admin en
      //      « forced », l'adresse de la page en « automatic ».
      // Les champs restent éditables : le joueur peut toujours viser un autre
      // serveur du réseau, et son choix est retenu par _pthLanRemember().
      var _lanFields = function () {
        var d = window._pthLanDefaults ? window._pthLanDefaults() : { host: autoHost, port: '7234', tls: false };
        // URL du proxy WebSocket par defaut = l'ORIGINE DE LA PAGE, jamais
        // dataset.autoHost. En politique d'instance « forced » (admin ->
        // loginDefaults.lanMode), autoHost porte l'hote du SERVEUR DE JEU :
        // en deriver le proxy envoyait le navigateur vers wss://<serveur-de-jeu>/,
        // ou aucun proxy n'ecoute des que le web client et le serveur LAN sont
        // sur deux machines -> echec a l'ouverture du WebSocket (« le proxy
        // est-il lance ? ») et aucune trace dans les logs du vrai proxy.
        // C'est aussi ce que le libelle admin promet (« auto: page address »).
        // Une URL imposee (loginDefaults.proxyUrl) reste prioritaire :
        // _applyProxyPolicy() la reecrit juste apres.
        if (proxyInput) proxyInput.value = proto + '//' + (window.location.hostname || 'localhost') + ':' + port;
        // Invite / share link target (#join=\u2026&s=host:port) FIRST: without it,
        // switching onto the LAN form would clobber the shared address with the
        // invitee's own saved server or the instance default \u2014 the guest would
        // land on the wrong server. Cleared when the player edits the fields.
        var st = window._shareLanTarget || null;
        if (hostInput && hostInput.dataset.typed !== '1') hostInput.value = ((st && st.host) || lsGet('pth_lan_host') || d.host || hostInput.value);
        if ($('port') && $('port').dataset.typed !== '1') $('port').value = ((st && st.port) || lsGet('pth_lan_port') || d.port || '7234');
        if ($('use-tls')) {
          if (st && (st.tls === '1' || st.tls === '0')) $('use-tls').checked = (st.tls === '1');
          else if (!st) {
            var _t = lsGet('pth_lan_tls');
            $('use-tls').checked = (_t === '1' || _t === '0') ? (_t === '1') : !!d.tls;
          } // st sans tls explicite : ne pas toucher la case (etat du lien conserve)
        }
      };

      if (mode === 'lan') {
        $('nick-label').textContent = t('enterNickFree');
        $('nick').placeholder = t('nickPlaceholder');
        // Restore the per-mode saved pseudo (overrides whatever was
        // typed under another mode — same UX as switching profiles).
        if (nickEl) nickEl.value = window._pthNick.get();
        _lanFields();
        setStatus(t('lanModeNote'), '', 'lanModeNote');
      } else if (mode === 'unauth') {
        $('nick-label').textContent = t('enterNickFree');
        $('nick').placeholder = t('nickPlaceholder');
        if (nickEl) nickEl.value = window._pthNick.get();
        _lanFields();
        setStatus(t('chatAvailPrivate'), '', 'chatAvailPrivate');
      } else if (mode === 'guest') {
        $('nick-label').textContent = t('enterNickGuest');
        // Compute the stable GuestXXXXX name, put it in the field,
        // and lock it. The user CAN'T change a Guest nick — the
        // server-issued IDs are not user-controllable anyway.
        var guestName = (window.getOrCreateGuestName && window.getOrCreateGuestName())
                       || ('Guest' + String(Math.floor(10000 + Math.random()*90000)));
        if (nickEl) {
          nickEl.value = guestName;
          nickEl.setAttribute('readonly', 'readonly');
          nickEl.placeholder = guestName;
        }
        // Internet / PokerTH.net target: admin-selected server (from /app-config)
        // or the built-in pokerth.net:7234 default. Guest follows the server's
        // own TLS flag (set in the /app-config handler -> window._pthNetServer).
        var _ps = window._pthNetServer;
        $('use-tls').checked = _ps ? !!_ps.tls : false;
        if (proxyInput) proxyInput.value = proto + '//' + (window.location.hostname||'localhost') + ':' + port;
        if (hostInput) { hostInput.value = _ps ? _ps.host : 'pokerth.net'; delete hostInput.dataset.typed; }
        if ($('port')) { $('port').value = String(_ps ? _ps.port : 7234); delete $('port').dataset.typed; }
        setStatus(t('guestHint'), '', 'guestHint');
      } else {
        // mode === 'auth'  (pokerth.net registered account)
        $('nick-label').textContent = t('enterAccount');
        $('nick').placeholder = 'MyAccount';
        // Prefill the login if we saved one previously. The password
        // is NEVER persisted in localStorage — that's what the browser
        // keychain (via autocomplete='current-password') is for.
        if (nickEl) nickEl.value = window._pthNick.get();
        // Internet / PokerTH.net target: admin-selected server (from /app-config)
        // or the built-in pokerth.net:7234 default. Credentialed login always TLS.
        var _ps2 = window._pthNetServer;
        // TLS : en direct WS le flag est sans objet (wss:// de toute façon) et
        // on le laisse coché. Via le proxy (transport admin 'proxy' OU cible
        // hors pokerth.net, ex. loopback co-hébergé), suivre le flag TLS du
        // serveur actif : un serveur local sans TLS doit rester joignable — le
        // tronçon navigateur→proxy est déjà chiffré (WSS) et SCRAM protège le
        // mot de passe de bout en bout.
        var _viaProxy2 = (window._pthNetTransport === 'proxy') || (_ps2 && String(_ps2.host).indexOf('pokerth.net') < 0);
        $('use-tls').checked = _viaProxy2 ? (_ps2 ? !!_ps2.tls : true) : true;
        if (proxyInput) proxyInput.value = proto + '//' + (window.location.hostname||'localhost') + ':' + port;
        if (hostInput) { hostInput.value = _ps2 ? _ps2.host : 'pokerth.net'; delete hostInput.dataset.typed; }
        if ($('port')) { $('port').value = String(_ps2 ? _ps2.port : 7234); delete $('port').dataset.typed; }
        setStatus(t('enterCredentials'), '', 'enterCredentials');
      }

      // Garder les 2 contrôles visibles (serveur + case « Mode invité ») en
      // phase avec le mode interne, quel que soit le chemin ayant fixé
      // login-mode.value (choix utilisateur, restauration, lien partagé…).
      try {
        var _sm = $('server-mode'), _gc = $('guest-mode-cb');
        if (_sm && _gc) {
          if (mode === 'guest' || mode === 'auth') { _sm.value = 'pokerthnet'; _gc.checked = (mode === 'guest'); }
          else { _sm.value = 'lan-dedi'; _gc.checked = (mode === 'lan'); }
        }
      } catch (e) {}
      try { if (window._setSrvSourceTag) window._setSrvSourceTag(mode === 'guest' || mode === 'auth'); } catch (e) {}
      // Annuaire LAN (modules/ui/lan-directory.mjs) : liste déroulante des
      // serveurs validés, recalculée d'après les champs qu'on vient de remplir.
      try { if (window.LanDirUI) window.LanDirUI.sync(); } catch (e) {}
    },

    // Mappe (serveur visible × case « Mode invité ») vers l'un des 4 modes
    // internes, puis délègue à onLoginModeChange() — inchangé.
    //   LAN/dédié + invité  → lan (type 0, sans chat)  |  sans invité → unauth (type 2, avec chat)
    //   pokerth.net + invité → guest                    |  sans invité → auth
    onServerOrGuestChange() {
      var srvEl = $('server-mode'), gcEl = $('guest-mode-cb'), lmEl = $('login-mode');
      // NB: the training pseudo is persisted LIVE by the #nick 'input' listener
      // (every keystroke while offline) and on Connect — we deliberately do NOT
      // snapshot the field here on mode change: iOS form-restoration can briefly
      // drop a network pseudo into the field while still offline, and snapshotting
      // that would corrupt pth_offline_nick (the bug where the LAN / pokerth.net
      // name overwrote the training pseudo).
      // Offline (vs bots) mode: no network. Drive a local fake server.
      var off = !!(srvEl && srvEl.value === 'offline');
      window._offlineMode = off;
      // [tick invité par mode] mode serveur précédent, AVANT écrasement.
      var _prevSrv = '';
      try { _prevSrv = localStorage.getItem('pth_server_mode') || ''; } catch (e) {}
      try { if (srvEl) localStorage.setItem('pth_server_mode', srvEl.value); } catch (e) {}
      // Connection-detail fields that only make sense for a real network
      // connection. In offline mode none of them apply, so hide them all
      // (and the advanced gear) — the screen keeps just nickname + Connect.
      var _connDetailIds = ['conn-adv-btn','conn-advanced','tls-row','guest-mode-row','f-pass','f-server-pass','f-user-pass','register-link-row','forgot-pw-link'];
      if (off) {
        // login-mode is irrelevant offline; force a no-password value so a
        // stale 'auth' (left by a previous pokerth.net selection) can't make
        // connect() demand a password.
        if (lmEl) lmEl.value = 'unauth';
        // Keep #server-mode on 'offline'. Do NOT call onLoginModeChange():
        // its tail reverse-syncs the visible select back to 'lan-dedi'.
        var _gear = $('conn-adv-btn');
        if (_gear) { _gear.classList.remove('open'); _gear.setAttribute('aria-expanded', 'false'); }
        for (var _i = 0; _i < _connDetailIds.length; _i++) {
          var _el = document.getElementById(_connDetailIds[_i]);
          if (_el) _el.style.display = 'none';
        }
        // Le mode entraînement utilise le pseudo PARTAGÉ pth_nick, comme
        // tous les modes réseau (sauf invité pokerth.net). Sync narmod
        // 2026-07-18 — l'ancienne isolation pth_offline_nick est retirée.
        var _onk = $('nick');
        if (_onk) {
          _onk.removeAttribute('readonly');
          _onk.placeholder = t('nickPlaceholder');
          _onk.value = window._pthNick.get();
        }
        var _onl = $('nick-label'); if (_onl) _onl.textContent = t('enterNickFree');
        if (typeof _stopIpBlockCountdown === 'function') _stopIpBlockCountdown();
        setStatus(t('offlineHint'), '', 'offlineHint');
        // LAN server list: this early return skips onLoginModeChange(), whose
        // tail re-derives it — coming from LAN, the list (and its lock on the
        // address fields) stayed on the training screen. sync() hides it
        // (_isLan() is false offline); the explicit hide covers a module
        // that is not loaded yet.
        try { if (window.LanDirUI && window.LanDirUI.sync) window.LanDirUI.sync(); } catch (e) {}
        try { var _ld = $('lan-dir'); if (_ld) _ld.style.display = 'none'; document.body.classList.remove('lan-dir-locked'); } catch (e) {}
        import('/modules/offline/index.mjs').catch(function(){});
        // Hidden mini-games (secret word as the training nickname, see connect()).
        import('/modules/games/index.mjs').catch(function(){});
        return;
      }
      // Leaving offline -> bring back the advanced gear + guest toggle; the
      // remaining fields (TLS / passwords / advanced block) are re-derived
      // from the mode + gear state by onLoginModeChange() just below.
      var _gearOn = $('conn-adv-btn'); if (_gearOn) _gearOn.style.display = '';
      var _guestRow = $('guest-mode-row'); if (_guestRow) _guestRow.style.display = '';
      // [tick invité par mode] La case « Mode invité » est mémorisée PAR mode
      // serveur (pth_guest_inet / pth_guest_lan) : cocher en Internet ne
      // coche plus en LAN, et inversement (demande narmod 2026-07-19).
      //  • serveur inchangé → le déclencheur est la case : on sauvegarde ;
      //  • serveur changé   → on restaure le tick propre au nouveau mode
      //    (1re bascule sans valeur : l'état courant devient la préférence
      //    initiale du mode, puis les deux vivent indépendamment).
      if (srvEl && gcEl) {
        var _gk = 'pth_guest_' + (srvEl.value === 'pokerthnet' ? 'inet' : 'lan');
        if (_prevSrv && srvEl.value !== _prevSrv) {
          // changement de serveur (offline compris) → tick du nouveau mode
          var _sv = null; try { _sv = localStorage.getItem(_gk); } catch (e) {}
          if (_sv !== null) gcEl.checked = (_sv === '1');
          else {
            // 1re visite de ce mode : son réglage par défaut (décoché), pas
            // celui du mode quitté — seul le pseudo passe d'un mode à l'autre
            // (narmod 2026-10-14). Avant, cocher « invité » en Internet
            // basculait aussi le LAN en invité à la 1re bascule.
            gcEl.checked = false;
            try { localStorage.setItem(_gk, '0'); } catch (e) {}
          }
        } else {
          // même serveur (ou 1re visite) → le déclencheur est la case
          try { localStorage.setItem(_gk, gcEl.checked ? '1' : '0'); } catch (e) {}
        }
      }
      if (srvEl && gcEl && lmEl) {
        var guest = gcEl.checked;
        lmEl.value = (srvEl.value === 'pokerthnet')
          ? (guest ? 'guest' : 'auth')
          : (guest ? 'lan' : 'unauth');
      }
      this.onLoginModeChange();
    },

    connect(opts) {
      opts = opts || {};
      var _preserve = !!opts.preserve;
      // ── Hidden mini-games (modules/games/index.mjs) ──
      // In training, a secret word typed as the nickname (« mascot » or its
      // translation) opens a mini-game instead of a table; the real nickname
      // is put back. The registry is loaded with the training mode, so this is
      // synchronous; if it is not there yet, load it and decide then.
      if (!opts._gameChecked && $('server-mode') && $('server-mode').value === 'offline' && !S._connectingNow) {
        var _gNick = (($('nick') && $('nick').value) || '').trim();
        if (_gNick && window.PthGames) {
          if (window.PthGames.tryLaunch(_gNick)) return;
        } else if (_gNick) {
          var _gSelf = this, _gOpts = Object.assign({}, opts, { _gameChecked: true });
          import('/modules/games/index.mjs').then(function () {
            if (!(window.PthGames && window.PthGames.tryLaunch(_gNick))) _gSelf.connect(_gOpts);
          }).catch(function () { _gSelf.connect(_gOpts); });
          return;
        }
      }
      // Un appel à connect() (clic manuel OU réessai auto « pseudo occupé »)
      // annule le compte à rebours en cours : une seule tentative à la fois.
      try { if (window._nickBusyCancel) window._nickBusyCancel(); } catch (e) {}
      // ── Fix 2 + 3: re-entrancy guard ──
      // Disable double-clicks: if a connect() is already in progress
      // (either waiting on SW, waiting on previous WS to close, or
      // waiting for mode-swap gap), ignore the new click.
      if (S._connectingNow) {
        return;
      }
      // ── SW-ready gate (one-shot per page lifetime) ──
      // First-time visitors trigger a Service Worker install on page load.
      // The SW does skipWaiting() + clients.claim(), which can take control
      // of the page WHILE our first WebSocket is being established. The
      // takeover kills the in-flight WS (browser closes it with code 1005),
      // and the PokerTH server interprets that as a suspicious connect-then-
      // immediately-drop pattern, blocking the IP for a few minutes.
      //
      // Fix: on the FIRST call only, wait until the SW is settled before
      // actually opening the upstream. Uses navigator.serviceWorker.ready,
      // which resolves the moment the SW has reached the 'activated' state
      // — usually <100ms when already installed, up to a second on first
      // visit while the SW caches assets.
      if (!window._swReadyOnce && 'serviceWorker' in navigator) {
        window._swReadyOnce = true;
        var self = this;
        var fired = false;
        var go = function() {
          if (fired) return; fired = true;
          self.connect();
        };
        setStatus('⏳ ' + (t('initializing') || 'Initialisation…'));
        navigator.serviceWorker.ready.then(go);
        setTimeout(go, 1500);   // safety timeout
        return;
      }

      // ── /app-config gate ──
      // The admin's Internet transport (« Via proxy » / « Direct ») arrives
      // with /app-config, and only that answer may decide it. Before it,
      // _pthNetTransport is undefined; the old wait here was bounded (5 s)
      // and then dialled anyway, reading undefined as « Direct »: on a slow
      // network a « Via proxy » instance sent players straight to
      // pokerth.net (admin: « Direct client » notice channels, 21/10/2026).
      // So the dial now waits for the answer however long it takes; the
      // loader keeps asking and says so after a few misses. Waiting does
      // NOT set S._connectingNow: an unbounded wait must never lock the
      // form. A later connect() (another click, the training button) or a
      // disconnect() replaces the held one instead of adding to it.
      // Training does not depend on the config and never waits.
      var _gateSm = $('server-mode') ? $('server-mode').value : '';
      if (!window._appConfigSettled && !window._offlineMode && _gateSm !== 'offline') {
        var selfCfg = this;
        var tokCfg = window._cfgGateTok = (window._cfgGateTok || 0) + 1;
        (window._appConfigWaiters || (window._appConfigWaiters = [])).push(function () {
          if (tokCfg !== window._cfgGateTok) return;   // replaced or cancelled meanwhile
          selfCfg.connect(opts);
        });
        setStatus('⏳ ' + (t('initializing') || 'Initialisation…'));
        return;
      }
      window._cfgGateTok = (window._cfgGateTok || 0) + 1;   // this dial goes ahead: a held one is void

      // ── Fix 1: anti-blocage 'rapid mode swap' ──
      // Read the current mode + nickname BEFORE doing any rate-limit check
      // so we can decide whether this call needs the extra mode-swap delay.
      const _curMode = $('login-mode') ? $('login-mode').value : 'guest';
      const _curNick = ($('nick') ? $('nick').value.trim() : '');
      const _modeChanged = (S._lastInitMode !== null) &&
                           (_curMode !== S._lastInitMode || _curNick !== S._lastInitNick);
      const _gapNow = Date.now() - S._lastInitTime;
      if (_modeChanged && _gapNow < S.MODE_SWAP_MIN_GAP) {
        const wait_ms = S.MODE_SWAP_MIN_GAP - _gapNow;
        const wait_s = Math.ceil(wait_ms / 1000);
        const that = this;
        // Disable the connect button so the user can't pile clicks
        S._connectingNow = true;
        var btn = document.querySelector('#s-connect .btn-primary');
        if (btn) btn.disabled = true;
        // Live countdown so the user understands what's happening
        var remain = wait_s;
        setStatus('⏳ ' + t('preparingConnection', { n: remain }));
        var iv = setInterval(function(){
          remain--;
          if (remain > 0) setStatus('⏳ ' + t('preparingConnection', { n: remain }));
        }, 1000);
        setTimeout(function() {
          clearInterval(iv);
          if (btn) btn.disabled = false;
          S._connectingNow = false;
          that.connect();
        }, wait_ms);
        return;
      }

      // ── Fix 2: properly close any lingering WebSocket before reopening ──
      // The original code did `ws.close()` then immediately created a new
      // one. That works most of the time, but `ws.close()` is async — the
      // socket can stay in CLOSING state for a few hundred ms. If we open
      // the new one immediately, the server briefly sees two active
      // connections from the same IP, which can also trigger initBlocked.
      // Defer the rest of connect() until the old WS reaches CLOSED, with
      // a 500ms hard cap so we never hang.
      if (S.ws && S.ws.readyState !== WebSocket.CLOSED) {
        S._connectingNow = true;
        var that2 = this;
        var btn2 = document.querySelector('#s-connect .btn-primary');
        if (btn2) btn2.disabled = true;
        setStatus('⏳ ' + (t('closingPrevious') || 'Closing previous connection…'));
        // Detach the old onclose to avoid the disconnect handler kicking in
        var prevWs = S.ws;
        prevWs.onclose = null;
        prevWs.onerror = null;
        try { prevWs.close(); } catch(e) {}
        S.ws = null;
        var done = false;
        var resume = function() {
          if (done) return; done = true;
          if (btn2) btn2.disabled = false;
          S._connectingNow = false;
          that2.connect();
        };
        // The CLOSING → CLOSED transition is typically <50ms. We poll for
        // it instead of relying on an event because we removed the
        // listeners above.
        var poll = setInterval(function() {
          if (!prevWs || prevWs.readyState === WebSocket.CLOSED) {
            clearInterval(poll); resume();
          }
        }, 30);
        setTimeout(function(){ clearInterval(poll); resume(); }, 500);
        return;
      }

      // ── Rate limiter : éviter le spam qui provoque le blocage IP ──
      const now = Date.now();
      var _gateOffline = !!(window._offlineMode || ($('server-mode') && $('server-mode').value === 'offline'));
      if (!_gateOffline && S._ipBlockUntil > now) {
        const remaining = Math.ceil((S._ipBlockUntil - now) / 1000);
        const mins = Math.floor(remaining / 60), secs = remaining % 60;
        setStatus(t('ipBlockedWaitPrefix') + (mins > 0 ? mins + 'min ' : '') + secs + 's', 'err', null, { local: true });
        _startIpBlockCountdown();
        return;
      }
      // Rate limiter seulement après un échec (pas après une déco normale)
      if (S._lastConnectFailed && now - S._lastConnectTime < S.MIN_CONNECT_INTERVAL) {
        const wait = Math.ceil((S.MIN_CONNECT_INTERVAL - (now - S._lastConnectTime)) / 1000);
        setStatus(t('waitBeforeRetry', { n: wait }), 'err', null, { local: true });
        return;
      }
      S._lastConnectTime = now;
      // Sauvegarder le serveur préféré
      try {
        var lm2 = $('login-mode'); var hv = $('host'); var pv = $('port'); var xv = $('proxy');
        // En entraînement, les champs serveur sont masqués et contiennent les
        // valeurs résiduelles du mode précédent : ne rien persister (ni le
        // login-mode, forcé à 'unauth' par la branche offline).
        var _offSave = !!($('server-mode') && $('server-mode').value === 'offline');
        if (!_offSave) {
        if (lm2) localStorage.setItem('pth_login_mode', lm2.value);
        if (hv)  localStorage.setItem('pth_host',  hv.value.trim());
        if (pv)  localStorage.setItem('pth_port',  pv.value.trim());
        // Mémoire propre aux modes LAN / dédié (adresse, port, TLS) : ne retient
        // que ce qui s'écarte de la valeur d'instance (cf. _pthLanRemember).
        // pth_host / pth_port, eux, suivent tous les modes sans condition.
        if (window._pthLanRemember) window._pthLanRemember();
        if (xv)  localStorage.setItem('pth_proxy', xv.value.trim());
        }
        // Auto-save the nickname per-mode (no Remember-me checkbox
        // needed — silent persistence is the new default). Guest is
        // skipped because it manages its own pth_guest_name key, and
        // auth saves only the LOGIN (never the password — that's the
        // browser keychain's job via autocomplete='current-password').
        var nickVal = ($('nick') && $('nick').value || '').trim();
        if (nickVal) {
          var _smEl = $('server-mode');
          var _isOff2 = !!(_smEl && _smEl.value === 'offline');
          // Pseudo PARTAGÉ (pth_nick) pour tous les modes SAUF l'invité
          // pokerth.net, qui garde sa clé pth_guest_name dédiée.
          if ((_isOff2 || (lm2 && lm2.value !== 'guest')) && window._pthNick) {
            window._pthNick.set(nickVal);
          }
        }
      } catch(e) {}
      const proxyUrl  = $('proxy').value.trim();
      // Mode Internet/pokerth.net et entraînement : le proxy est TOUJOURS le
      // site qui sert l'app — jamais le champ #proxy, réservé au LAN/serveur
      // dédié. Ce champ est repeuplé depuis localStorage (pth_proxy) même
      // quand il est masqué : une vieille adresse (p.ex. le serveur de démo)
      // détournait silencieusement la connexion vers un AUTRE proxy — le
      // handshake réussissait (« Proxy connecté »), puis plus rien, et aucune
      // trace dans les logs du bon serveur.
      const _smVal = $('server-mode') ? $('server-mode').value : '';
      const _sameOriginWs = (location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host;
      const effProxyUrl = (_smVal === 'pokerthnet' || _smVal === 'offline') ? _sameOriginWs : proxyUrl;
      const host      = $('host').value.trim();
      const port      = $('port').value.trim() || '7234';
      // Classement LAN du serveur visé : celui de son entrée d'annuaire
      // (server/lan-boards.js), sinon le classement historique ('').
      try { S._lanBoard = (window.LanDirUI && window.LanDirUI.boardFor) ? window.LanDirUI.boardFor(host, port) : ''; } catch (e) { S._lanBoard = ''; }
      // Serveur d'annuaire absent de la liste publique (non listé, masqué,
      // événement terminé — atteint par un lien d'invitation) : le proxy donne
      // son classement d'après l'adresse. _lifeSeedFromServer attend la réponse.
      S._lanBoardReady = null;
      try {
        if (!S._lanBoard && $('server-mode') && $('server-mode').value === 'lan-dedi' && window.LanDirUI && window.LanDirUI.resolveBoard) {
          const _bHost = host, _bPort = port;
          S._lanBoardReady = window.LanDirUI.resolveBoard(_bHost, _bPort).then(function (id) {
            if (id && $('host') && $('host').value.trim() === _bHost) S._lanBoard = id;
          });
        }
      } catch (e) { S._lanBoardReady = null; }
      const loginMode = $('login-mode') ? $('login-mode').value : 'guest';
      const _off = !!($('server-mode') && $('server-mode').value === 'offline');
      S.myName          = $('nick').value.trim();

      if (!S.myName && loginMode === 'guest') {
        // Persistent Guest name: re-use the same identifier across tabs
        // and reloads so the server doesn't see different pseudos flooding
        // from the same IP (a key trigger of the initBlocked behaviour).
        S.myName = (window.getOrCreateGuestName && window.getOrCreateGuestName())
                 || ('Guest' + String(Math.floor(10000 + Math.random()*90000)));
        $('nick').value = S.myName;
      }
      if (!S.myName) { setStatus(t('enterNick'), 'err', null, { local: true }); return; }
      // Prépare l'avatar-upload du choix courant AVANT l'Init.
      try { if (window.refreshMyAvatar) window.refreshMyAvatar(); } catch(e) {}
      if (S.myName.length < 3 && !window.PokerRoom) { setStatus(t('nickTooShort'), 'err', null, { local: true }); return; }
      if (!_off && (!effProxyUrl || !host)) { setStatus(t('fillFields'), 'err', null, { local: true }); return; }

      if (!_off && loginMode === 'auth' && (!$('pass') || !$('pass').value.trim())) {
        setStatus(t('enterPassword'), 'err', null, { local: true });
        return;
      }

      const useTls   = $('use-tls').checked;
      const tlsParam = useTls ? '1' : '0';
      // Close any existing connection first
      if (S.ws && S.ws.readyState !== WebSocket.CLOSED) {
        S.ws.onclose = null; // don't trigger the disconnect handler
        S.ws.close();
        S.ws = null;
      }
      S.rxBuf   = new Uint8Array(0);
      // En reconnexion « preserve » (bascule réseau), on NE vide PAS l'état de
      // la table / du lobby : le proxy rebranche le WebSocket sur la session
      // PokerTH déjà en cours (pas de nouvel Announce/Init), donc le serveur ne
      // renvoie pas la liste des joueurs/avatars — il faut les garder en mémoire
      // pour ne pas afficher des sièges vides. Repli (session expirée) : on
      // recevra un Announce → le flux normal repeuplera tout.
      if (!_preserve) {
        S.games   = {};
        S.players = {};
        S._playerCountries = {};
        S._playerRights = {};
        S._raiseMode = 1; S._raiseEvery = 0; S._lastBlindsUpHand = 0;
        S._blindsClockStart = 0; _stopBlindsCountdown();
        S._endRaiseMode = 1; S._endRaiseValue = 0; S._manualBlinds = [];
        // Avatars : indexés par pid (stables tant que la session lobby dure) ou
        // par hash (cache réutilisable). Donc même cycle de vie que 'players' :
        // on ne les vide qu'à la déconnexion complète, pas en quittant une partie
        // (sinon les avatars disparaissent au retour au lobby — les hashes ne
        // sont re-reçus qu'une fois). L'avatar de session (S._sessAv, figé à
        // l'Init) tombe avec : la nouvelle session figera le choix courant.
        S._sessAv = null; S._sessUpload = null; S._myAvatarCache = '';
        S._pthAvatarHashes = {}; S._pthAvatarsByHash = {}; S._pthAvatarReqIdToHash = {}; S._pthDataUrls = {};
        S.loaded  = false;
        // Repeindre tout de suite la liste (désormais vide) : sinon, dans un
        // lobby calme/vide (ex. retour de l'entraînement vers un serveur en
        // ligne sans table), aucun GameListNew n'arrive pour déclencher un
        // redraw et les tables de l'ancien mode RESTENT affichées jusqu'à un
        // clic sur une pastille filtre. renderGames() rétablit l'état « en
        // chargement » jusqu'au premier GameListNew qui repeuplera la liste.
        renderGames();
      }

      // Direct WSS for any pokerth.net mode (guest or authenticated). The
      // /pthlive endpoint is the only one publicly exposed by pokerth.net
      // (port 7234 is not reachable in TLS from the outside). It accepts
      // authenticated logins as long as the InitMessage carries the password
      // in clientUserData.
      const isPokerThDirect = (loginMode === 'guest' || loginMode === 'auth');
      const targetIsPokerTH = host.includes('pokerth.net');
      // Admin transport switch (/app-config.internetTransport) : 'proxy' routes
      // the Internet mode through our proxy (session grace on wifi drops,
      // buffered reconnect) even when the target is pokerth.net itself.
      // 'direct' (default) keeps the historical hostname-based behavior.
      // /live has its own transport setting, because an install sitting next
      // to the game server and one on a separate machine do not want the same
      // answer. 'inherit' (the default) falls back to the Internet setting, so
      // nothing changes for the ordinary client.
      const _liveTr = window._pthLiveTransport;
      const _tr = (window.LIVE_MODE && (_liveTr === 'direct' || _liveTr === 'proxy'))
        ? _liveTr : window._pthNetTransport;
      window.directWS = isPokerThDirect && targetIsPokerTH && (_tr !== 'proxy');
      // Mode CHOISI par le joueur, source unique pour le compteur de trafic ET
      // pour le ciblage des diffusions cote proxy. Ne PAS le deduire du
      // transport : avec « Via proxy » la socket va vers notre proxy dans les
      // trois modes, et l'hote amont peut etre un serveur manuel (pas
      // pokerth.net) tout en etant le bouton « Internet / PokerTH.net ».
      // #server-mode vaut 'pokerthnet' | 'offline' | 'lan-dedi'.
      var _cntMode = function () {
        var sm = ($('server-mode') && $('server-mode').value) || '';
        if (window._offlineMode || sm === 'offline') return 'offline';
        if (window.directWS || sm === 'pokerthnet') return 'pokerthnet';
        return 'lan';
      };
      var _bcMode = (function () { var m = _cntMode(); return m === 'pokerthnet' ? 'pthnet' : m; })();
      const finalUrl = window.directWS
        ? 'wss://www.pokerth.net:443/pthlive'
        : effProxyUrl + '?host=' + encodeURIComponent(host) + '&port=' + encodeURIComponent(port) + '&tls=' + tlsParam + '&sid=' + encodeURIComponent(_getSessionId()) + '&mode=' + _bcMode + (window.LIVE_MODE ? '&live=1' : '') + (window.BUILD_VERSION ? '&v=' + encodeURIComponent(window.BUILD_VERSION) : '') + (function(){ try { var z = window._pthTimeZone && window._pthTimeZone(); return z ? '&tz=' + encodeURIComponent(z) : ''; } catch (e) { return ''; } })();

      setStatus(window.directWS ? t('connDirect') : t('connProxy'));

      // Réactions emoji : relayées partout via la convention /emoji dans le chat
      // de partie (interop web <-> Qt/QML, y compris pokerth.net). Le bouton
      // reste donc toujours visible quel que soit le mode de connexion.
      window._directWS = window.directWS;
      // Marqueur de mode pour le CSS : drapeaux agrandis uniquement sur pokerth.net.
      try { document.body.classList.toggle('pth-net', !!window.directWS); } catch (e) {}
      // Diffusions admin : quand la socket de jeu ne passe pas par le proxy
      // (direct pokerth.net OU entraînement offline), ouvrir le canal
      // notify-only. En mode proxy la socket principale les reçoit déjà.
      // Repli d'URL en offline (champ proxy potentiellement vide) : le site
      // qui sert l'app héberge aussi le proxy → dériver de location.
      try {
        if (window.directWS || _off) {
          var _nBase = effProxyUrl || _sameOriginWs;
          _openNotifyWS(_nBase, _off ? 'offline' : 'pthnet');
        } else {
          _closeNotifyWS();
        }
      } catch (e) {}
      try {
        var _rtb = document.getElementById('react-toggle-btn');
        if (_rtb) _rtb.style.display = '';
      } catch (e) {}

      // Sauvegarder les paramètres pour la reconnexion auto
      // Record this Init's identity so the NEXT connect() can compare
      // and apply the mode-swap delay if needed.
      S._lastInitMode = loginMode;
      S._lastInitNick = S.myName;
      S._lastInitTime = Date.now();
      S._lastConnectParams = { host, port, loginMode, finalUrl, myName: S.myName,
        pass: $('pass') ? $('pass').value : '' };
      S._reconnectAttempts = 0;
      S._intentionalDisconnect = false;
      // NOT on a preserve reconnect (wake from sleep, dead socket found by the
      // watchdog, 'online' event): the proxy rebinds the page to the SAME,
      // already authenticated server session, which sends no Announce and no
      // InitAck — the only place that sets the flag back to true. Clearing it
      // here left it false for the rest of the session, so _afkActivity
      // (msg-social.mjs) never sent a ResetTimeout again and the player was
      // kicked by the in-game AFK timer 21 min later, warning popup and OK
      // click included (report sp0ck 20/10/2026, Teressa, BBC game 802).
      // If the grace has expired the proxy opens a new upstream: onAnnounce
      // clears the flag until the InitAck of that new session.
      if (!_preserve) S._wasAuthenticated = false;
      S._currentLoginMode = loginMode; // sauvegarder pour ChatReject
      // The CreateGame form defaults depend on this mode. Refresh them
      // now so the values are correct the first time the user opens it.
      try { App._applyCreateFormDefaults(true); } catch (e) {}
      if ($('server-mode') && $('server-mode').value === 'offline') {
        // ── OFFLINE vs BOTS ── swap the transport for a local fake server.
        window.directWS = false;
        if (!(window.PokerOffline && window.PokerOffline.createSocket)) {
          try { setStatus(t('loadingOffline')); } catch (e) { setStatus('Loading offline mode…'); }
          import('/modules/offline/index.mjs')
            .then(function(){ App.connect(); })
            .catch(function(e){
              // Say WHY (a module missing from the SW cache shows up here as
              // a failed dynamic import) instead of a bare message.
              try { console.error('[offline] init failed:', e); } catch (_) {}
              setStatus('Offline init failed' + (e && e.message ? ': ' + e.message : ''), 'err');
            });
          return;
        }
        try {
          S.ws = window.PokerOffline.createSocket({ nick: S.myName,
            botSkill: (function(){ try { return localStorage.getItem('pth_offline_skill') || 'mixed'; } catch (e) { return 'mixed'; } })(),
            // Pause entre les mains (parité QML PauseBetweenHands) : lue en
            // direct pour être basculable en cours de partie.
            pauseGate: function () { return _advGet('pause_hands', false); } });
        } catch (e) {
          setStatus('Offline init failed: ' + e.message, 'err');
          return;
        }
      } else {
        try {
          // App.connect() est TOUJOURS une poignée de main neuve : l'état
          // protocolaire de la page est vierge, on attend l'Announce puis on
          // enverra un Init. &fresh=1 le dit au proxy : s'il tient encore une
          // session vivante sous ce sid (PWA tuée puis relancée — le sid
          // persiste en localStorage exprès), il doit FERMER ce fantôme et
          // ouvrir un amont neuf, pas nous y rebrancher. Un rebranchement sur
          // un amont déjà annoncé laissait la page attendre l'Announce toute
          // la grâce (2 min par défaut) — « Proxy connected — waiting for the
          // PokerTH server… », rapport forum. Le paramètre n'est PAS mémorisé
          // dans _lastConnectParams.finalUrl : le chemin de reconnexion
          // rapide (même page, état intact) reste un pur rebranchement.
          // FIX web.24 (logs proxy narmod 09/08, 11:13:29) : fresh=1 SEULEMENT
          // hors preserve. _forceReconnect (socket zombie iOS : mort sans
          // événement close, seul le heartbeat proxy le voit) appelle
          // connect({preserve:true}) — et le fresh inconditionnel faisait
          // détruire la session en grâce par le proxy (« Fresh connect sur
          // session vivante — fantôme fermé »), la table avec bots fermait,
          // RejoinExisting → JoinGameFailed → « Reprise impossible ». En
          // preserve, on rebranche : pas d'Announce → pas d'Init, le premier
          // frame rejoué désarme le watchdog (S._preserveConnect) ; grâce
          // expirée → le proxy ouvre un amont neuf, l'Announce arrive et le
          // flux normal (Init → rejoin) reprend. fresh=1 garde son rôle
          // d'origine : poignée de main NEUVE (clic manuel, page vierge).
          S.ws = new WebSocket(window.directWS ? finalUrl : finalUrl + (_preserve ? '' : '&fresh=1'));
        } catch (e) {
          setStatus(t('invalidUrl', { msg: e.message }), 'err', null, { local: true });
          return;
        }
      }

      // A transparent reattach replays no Init, so InitAck -- the only thing
      // that normally calls _endConnecting() -- never comes. Flag it here so
      // the first received frame can disarm the watchdog (see onRawData).
      S._preserveConnect = _preserve;
      _beginConnecting();   // lock button for the whole attempt (anti IP-block)
      S.ws.binaryType = 'arraybuffer';
      S.ws.onopen    = () => { S._lastRxTime = Date.now(); setStatus(t('proxyConnectedWait')); try { window._pthCountConnect && window._pthCountConnect(_cntMode(), host + ':' + port); } catch (e) {} };
      S.ws.onerror   = () => { S._lastConnectFailed = true; _endConnecting(); setStatus(t('wsError'), 'err', null, { local: true }); };
      S.ws.onmessage = function(e) {
        if (typeof e.data === 'string') { _onProxyText(e.data); return; }
        onRawData(e.data);
      };
      S.ws.onclose = function(e) {
        // Debug log (ui/debuglog.mjs): why the link to the proxy ended.
        try { console.log('[net] connection closed — code ' + (e && e.code) + (e && e.reason ? ' (' + e.reason + ')' : '') +
          (S.gId ? ' — at table ' + S.gId : '') + (S._intentionalDisconnect ? ' — intentional' : '')); } catch (eL) {}
        _endConnecting();   // free the connect button on any close
        // Une alerte de timeout appartient a la session qui vient de mourir :
        // laisser un compte a rebours mort a l'ecran serait pire que le silence
        // qu'il corrige (parite QML : onConnectionFailed ferme le popup).
        try { window._timeoutWarnClose && window._timeoutWarnClose(); } catch (e2) {}
        S.ws = null;
        clearTimeout(window._reconnectTimer);
        clearInterval(window._reconnectCountdown);
        clearTimeout(window._reconnectStableTimer);
        _hideBanner();

        if (_closeIsTerminal(e)) return;

        // Mémoriser la table pour réclamer le siège à la reconnexion (sinon on
        // se ferait renommer au pseudo « déjà pris »).
        _armRejoin();

        // --- RECONNEXION AUTO (limitée pour éviter le blocage IP) ---
        S._reconnectAttempts++;
        // 6, comme _reconnectContinue qui mène TOUTES les tentatives suivantes : ce
        // premier passage affichait « (1/3) », puis la suite « (2/6) », « (3/6) »…
        // (trouvé par scripts/test-reconnect-browser.mjs). La politique réelle est
        // inchangée : 6 tentatives, 5 s puis 6 · 12 · 24 · 30 · 30 s.
        var maxAttempts = 6;
        if (S._reconnectAttempts > maxAttempts) {
          _hideBanner();
          S._wasAuthenticated = false;
          show('s-connect');
          setStatus(t('reconnFailed', { n: maxAttempts }), 'err');
          try { window._connLostShow && window._connLostShow(t('reconnFailed', { n: maxAttempts })); } catch (eCl) {}
          return;
        }
        // Délai croissant : 5s, 15s, 30s — assez long pour ne pas spammer
        var delay = [5000, 15000, 30000][S._reconnectAttempts - 1] || 30000;
        var secs = Math.round(delay/1000);
        _showBanner(t('reconnIn') + secs + 's… (' + S._reconnectAttempts + '/' + maxAttempts + ')');
        window._reconnectTimer = setTimeout(function() {
          if (S.ws) return; // déjà reconnecté
          _showBanner(t('reconnInProgress'));
          try {
            S.ws = new WebSocket(S._lastConnectParams.finalUrl);
            S.ws.binaryType = 'arraybuffer';
            S.rxBuf = new Uint8Array(0);   // a partial frame from the dead socket would corrupt the stream
            S.ws.onopen = function() {
              _showBanner(t('reauthBanner'));
              _armReconnectStable();
            };
            S.ws.onerror = function() {
              S.ws = null;
              // Déclencher onclose pour retenter
              var fakeClose = new Event('close');
              S.ws && S.ws.dispatchEvent(fakeClose);
            };
            S.ws.onmessage = function(e) {
              if (typeof e.data === 'string') { _onProxyText(e.data); return; }
              onRawData(e.data);
              // Le compteur n'est PAS remis à zéro ici : voir _armReconnectStable.
              // La bannière, elle, disparaît toujours dès la première trame.
              if (S._reconnectAttempts > 0) setTimeout(_hideBanner, 1500);
            };
            // Réutiliser le même handler onclose pour les tentatives suivantes.
            // (fix 2026-07-31 : l'ancienne ligne `arguments.callee.caller`
            // jetait une TypeError en mode strict (ESM) dès le déclenchement
            // du timer — le vrai handler ci-dessous n'était jamais assigné,
            // aucune reconnexion n'aboutissait ; rapport forum.)
            S.ws.onclose = function(ev) {
              S.ws = null;
              clearTimeout(window._reconnectTimer);
              if (_closeIsTerminal(ev)) return;
              // Relancer le processus de reconnexion
              App && App.connect && App._reconnectContinue && App._reconnectContinue();
            };
          } catch(err) {
            _showBanner(t('errGeneric', { code: err.message }));
          }
        }, delay);
      };
    },

    _reconnectContinue() {
      // Relancer le processus de reconnexion — backoff exponentiel
      if (!S._lastConnectParams || S._intentionalDisconnect) return;
      S._reconnectAttempts++;
      var maxAttempts = 6;
      if (S._reconnectAttempts > maxAttempts) {
        _hideBanner();
        show('s-connect');
        setStatus(t('reconnFailed', { n: maxAttempts }), 'err');
        // The status line only exists inside the login FORM: the player who was
        // just thrown out of his table landed on the mode picker with no word of
        // explanation (found by scripts/test-reconnect-browser.mjs). Same
        // "connection lost" window as a server-side rejection (QML parity).
        try { window._connLostShow && window._connLostShow(t('reconnFailed', { n: maxAttempts })); } catch (eCl) {}
        return;
      }
      // Exponentiel : 3s → 6s → 12s → 24s → 30s → 30s
      var delay = Math.min(3000 * Math.pow(2, S._reconnectAttempts - 1), 30000);
      var secsTotal = Math.round(delay / 1000);
      // Countdown live dans le banner
      clearInterval(window._reconnectCountdown);
      var secsLeft = secsTotal;
      function _updateBannerCountdown() {
        var pfx = t('reconnIn');
        var sfx = ' ('+S._reconnectAttempts+'/'+maxAttempts+')';
        _showBanner(pfx + secsLeft + 's' + sfx);
        if (secsLeft > 0) secsLeft--;
      }
      _updateBannerCountdown();
      window._reconnectCountdown = setInterval(_updateBannerCountdown, 1000);
      window._reconnectTimer = setTimeout(function() {
        clearInterval(window._reconnectCountdown);
        // FIX web.23 (rapport narmod : 5G→Wi-Fi → « Reprise impossible ») :
        // App.connect() est une poignée de main NEUVE avec &fresh=1 — le proxy
        // DÉTRUIT alors la session en grâce (une table où il ne reste que des
        // bots ferme dès que notre joueur tombe) et le rejoin qui suit échoue
        // forcément → retour au lobby. La 1re tentative (onclose) faisait déjà
        // un pur rebranchement ; les suivantes passaient par connect() et
        // cassaient donc la grâce dès que le réseau mettait plus de 5 s à
        // revenir (Wi-Fi qui se ré-associe après le mode avion), d'où
        // l'asymétrie 5G→Wi-Fi vs Wi-Fi→5G. Désormais TOUTES les tentatives
        // sont rebind-first : même URL sans fresh. Si la grâce a expiré, le
        // proxy ouvre un amont neuf de lui-même, l'Announce arrive et le flux
        // normal (Init → rejoin) reprend — fresh=1 reste réservé au clic
        // manuel (PWA relancée, état de page vierge).
        if (S.ws || !S._lastConnectParams || S._intentionalDisconnect || window._offlineMode) return;
        _showBanner(t('reconnInProgress'));
        try {
          S.ws = new WebSocket(S._lastConnectParams.finalUrl);
          S.ws.binaryType = 'arraybuffer';
          S.rxBuf = new Uint8Array(0);   // a partial frame from the dead socket would corrupt the stream
          S.ws.onopen = function() { _showBanner(t('reauthBanner')); _armReconnectStable(); };
          S.ws.onmessage = function(e) {
            if (typeof e.data === 'string') { _onProxyText(e.data); return; }
            onRawData(e.data);
            // Idem : la remise à zéro vient de _armReconnectStable / InitAck.
            if (S._reconnectAttempts > 0) setTimeout(_hideBanner, 1500);
          };
          S.ws.onclose = function(ev) {
            S.ws = null;
            clearTimeout(window._reconnectTimer);
            if (_closeIsTerminal(ev)) return;
            App && App._reconnectContinue && App._reconnectContinue();
          };
          S.ws.onerror = function() {};
        } catch (err) {
          _showBanner(t('errGeneric', { code: err.message }));
        }
      }, delay);
    },

    abortReconnect() {
      // ✕ de la pastille / « Annuler » du bandeau pendant une reconnexion
      // automatique (parité QML 2.1.6, ServerConnectionHandler::
      // abortAutoReconnect) : interrompt la reco en cours et termine la
      // session proprement. On réutilise disconnect(), qui fait déjà tout —
      // couper les timers de reco, détacher/fermer un WS de tentative
      // naissant (code 4001 → le proxy libère le joueur immédiatement, pas
      // de zombie), faire tourner le sid, revenir à l'écran de connexion.
      // On désarme d'abord le rejoin (sans quoi la mention « siège
      // réservé » pourrait réapparaître) et on affiche un statut neutre.
      S._pendingRejoin = 0; S._rejoinNickRetries = 0;
      this.disconnect();
      setStatus(t('disconnected'), '');
    },

    confirmDisconnect() {
      // Public entry point for the lobby ✕ button. Opens a small
      // confirmation modal — clicking 'Disconnect' then routes to the
      // existing disconnect() flow; clicking 'Cancel' just closes the
      // modal and leaves the user in the lobby.
      var dd = document.getElementById('disconnect-dialog');
      if (dd) dd.style.display = 'flex';
    },

    confirmDisconnectQuit() {
      // Confirmed — hide the modal and disconnect normally. The user
      // lands on the login screen via the ws.onclose handler.
      var dd = document.getElementById('disconnect-dialog');
      if (dd) dd.style.display = 'none';
      this.disconnect();
    },

    cancelDisconnect() {
      // Cancelled — just dismiss the modal. The connection stays open.
      var dd = document.getElementById('disconnect-dialog');
      if (dd) dd.style.display = 'none';
    },

    // Clean teardown before an intentional page reload (version update ONLY):
    // close the proxy WebSocket with code 4001 so the proxy frees the PokerTH
    // player right away — no 2-min grace, no server-side zombie. The sid is
    // deliberately kept, so if the close frame doesn't flush before navigation
    // the reloaded page can still rebind to the grace session rather than
    // collide with it. NOT used by the ↺ refresh button, which keeps the
    // session alive via grace + sid rebind.
    teardownForReload() {
      try {
        if (S.ws) {
          S.ws.onclose = null; S.ws.onerror = null; S.ws.onmessage = null; S.ws.onopen = null;
          S.ws.close(4001, 'reload');
          S.ws = null;
        }
      } catch (e) {}
    },
    disconnect() {
      // A pending table invitation is declined while the socket is still open
      // (parity upstream 52661f2), then the banner goes with the session.
      try { window._inviteDrop && window._inviteDrop(true); } catch (e) {}
      // A connect() still held by the /app-config gate must not fire later.
      window._cfgGateTok = (window._cfgGateTok || 0) + 1;
      S._intentionalDisconnect = true;
      _closeNotifyWS();
      S._wasAuthenticated = false;
      S._lastConnectFailed = false; // déco propre → pas de rate limit
      // Déconnexion volontaire → faire tourner le sid : la prochaine connexion
      // doit créer une session PokerTH NEUVE (pseudo éventuellement changé), et
      // non se rebrancher sur l'ancienne que le proxy garde ~2 min. On vide les
      // deux stockages (le contexte standalone/onglet ne change pas, mais c'est
      // sans risque et robuste).
      try { localStorage.removeItem('pth_sid'); } catch (e) {}
      try { sessionStorage.removeItem('pth_sid'); } catch (e) {}
      document.body.classList.remove('in-game');
      _hideBanner();
      // Cancel any pending auto-reconnect that a previous onclose may have
      // scheduled, so it can't fire after we're back on the home screen.
      clearTimeout(window._reconnectTimer);
      clearInterval(window._reconnectCountdown);
      S._reconnectAttempts = 0;
      if (S.ws) {
        // Detach handlers BEFORE closing: ws.close() triggers onclose
        // synchronously-ish, and we don't want the reconnect scheduler to run.
        S.ws.onclose = null;
        S.ws.onerror = null;
        S.ws.onmessage = null;
        S.ws.onopen = null;
        // Intentional disconnect → close with code 4001 so the proxy frees the
        // PokerTH player immediately (no 2-min reconnect grace → no zombie).
        try { S.ws.close(4001, 'user disconnect'); } catch (e) {}
        S.ws = null;
      }
      S.games = {};
      // Reset lobby counters so the next connect starts at 0 instead
      // of inheriting the previous session's tally.
      S._lobbyPlayerCount = 0;
      S._hasStatistics = false;
      S._lobbyPids.clear();
      S._pendingNameRequests.clear();
      show('s-connect');
    },


    // ──────────────────────────────────────────────────────────
    // Kick player flow (admin only). See pokerth.proto:
    //   KickPlayerRequestMessage (type 30) → server broadcasts
    //   GamePlayerLeft(leftKicked) to all + RemovedFromGame to victim.
    //   Existing handlers in this file already remove the player
    //   from seats[] on receipt, so the UI updates itself.
    // ──────────────────────────────────────────────────────────
    openKickModal() {
      if (!S.amGameAdmin) return; // double-check; button shouldn't be visible
      var modal = document.getElementById('kick-modal');
      var list  = document.getElementById('km-list');
      if (!modal || !list) return;
      // Build the list from seatData (covers both pre-game and in-game
      // phases; GamePlayerJoined writes here on first sight). Filter out
      // pids the server has marked as gone, just in case.
      var pids = Object.keys(S.seatData).map(function(s){ return parseInt(s,10); })
                       .filter(function(p){ return !S.seatData[p].gone; });
      // Sort: me first, then alphabetical by name.
      pids.sort(function(a, b) {
        if (a === S.myId && b !== S.myId) return -1;
        if (b === S.myId && a !== S.myId) return 1;
        var na = (S.players[a] || ('#' + a)).toLowerCase();
        var nb = (S.players[b] || ('#' + b)).toLowerCase();
        return na < nb ? -1 : na > nb ? 1 : 0;
      });
      if (!pids.length) {
        list.innerHTML = '<div class="km-empty">— ' + t('kickNoPlayers') + ' —</div>';
      } else {
        var html = pids.map(function(pid) {
          var name = S.players[pid] || ('#' + pid);
          var sd   = S.seatData[pid] || {};
          var stack= (typeof sd.money === 'number') ? fmtChips(sd.money) : '';
          var isMe = (pid === S.myId);
          var avChip = (typeof window._avatarChipHtml === 'function')
            ? window._avatarChipHtml(pid, name, 'km-av')
            : '<span class="km-av letter">' + (name[0] || '?').toUpperCase() + '</span>';
          // No kick button for self (admin can't kick themselves; the
          // server would reject it anyway).
          var rowCls = 'km-row' + (isMe ? ' km-self' : '');
          // Escape name for safe HTML injection
          var escName = String(name).replace(/[<>&"]/g, function(c){
            return {'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[c];
          });
          var btn = isMe ? '' :
            '<button class="km-kick" type="button" ' +
              'onclick="App.askConfirmKick(' + pid + ')" ' +
              'title="' + t('kickTooltip') + '" ' +
              'aria-label="Kick">🗑️</button>';
          return '<div class="' + rowCls + '">' +
                   avChip +
                   '<div class="km-info">' +
                     '<div class="km-name">' + escName + '</div>' +
                     (stack ? '<div class="km-meta">' + stack + '</div>' : '') +
                   '</div>' +
                   btn +
                 '</div>';
        }).join('');
        list.innerHTML = html;
      }
      modal.style.display = 'flex';
    },
    closeKickModal() {
      var modal = document.getElementById('kick-modal');
      if (modal) modal.style.display = 'none';
    },
    // ── Send invitations (InvitePlayerToGame) — opened from the ≡ menu ──
    // Lists online lobby players who aren't already at this table; each
    // row sends an invite for the current gId. The recipient gets the
    // Accept/Decline banner (handled by InviteNotify on their side).
    // Invite-only tables only (parity QML canInviteFromCurrentGame).
    _canInviteHere() {
      try { return !!(window.InviteLink && window.InviteLink.canInviteFromCurrentGame()); } catch (e) { return false; }
    },
    openInviteModal() {
      if (window._offlineMode || S._amSpectator || !S.gId || !App._canInviteHere()) return;
      var modal = document.getElementById('invite-modal');
      var list  = document.getElementById('im-list');
      if (!modal || !list) return;
      S._invSent = {}; // fresh session
      App._renderInviteList(App._inviteEligiblePids());
      modal.style.display = 'flex';
    },
    _inviteEligiblePids() {
      var seated = {};
      Object.keys(S.seatData).forEach(function(s){ seated[parseInt(s,10)] = true; });
      var pids = [];
      S._lobbyPids.forEach(function(p){ if (p !== S.myId && !seated[p]) pids.push(p); });
      pids.sort(function(a,b){
        var na=(S.players[a]||('#'+a)).toLowerCase(), nb=(S.players[b]||('#'+b)).toLowerCase();
        return na<nb?-1:na>nb?1:0;
      });
      return pids;
    },
    _renderInviteList(pids) {
      var list = document.getElementById('im-list');
      if (!list) return;
      if (!pids.length) {
        list.innerHTML = '<div class="km-empty">— ' + t('inviteNoPlayers') + ' —</div>';
        return;
      }
      list.innerHTML = pids.map(function(pid) {
        var name = S.players[pid] || ('#' + pid);
        var avChip = (typeof window._avatarChipHtml === 'function')
          ? window._avatarChipHtml(pid, name, 'km-av')
          : '<span class="km-av letter">' + (name[0]||'?').toUpperCase() + '</span>';
        var escName = String(name).replace(/[<>&"]/g, function(c){
          return {'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[c];
        });
        var btn = S._invSent[pid]
          ? '<button class="im-invite" type="button" disabled style="opacity:.55;border:1px solid var(--border,#444);background:transparent;color:var(--text,#eff1f5);border-radius:8px;padding:6px 12px;font-weight:600">' + t('inviteSent') + '</button>'
          : '<button class="im-invite" type="button" onclick="App.sendInvite(' + pid + ')" style="border:1px solid var(--green,#3fae5a);background:transparent;color:var(--text,#eff1f5);border-radius:8px;padding:6px 12px;font-weight:600;cursor:pointer">' + t('inviteBtn') + '</button>';
        return '<div class="km-row">' +
                 avChip +
                 '<div class="km-info"><div class="km-name">' + escName + '</div></div>' +
                 btn +
               '</div>';
      }).join('');
    },
    inviteSentTo(pid) { return !!S._invSent[pid]; },
    sendInvite(pid) {
      if (window._offlineMode || !S.gId || pid === S.myId || !App._canInviteHere()) return;
      try {
        if (_advGet('confirm_social', true)) {
          var _inm = S.players[pid] || ('#' + pid);
          var _iq = t('inviteConfirm', { name: _inm });
          if (_iq === 'inviteConfirm') _iq = 'Invite ' + _inm + ' to your game?';
          if (!window.confirm(_iq)) return;
        }
      } catch (e) {}
      try { send(MSG.buildInvitePlayer(S.gId, pid)); } catch(e) {}
      S._invSent[pid] = true;
      App._renderInviteList(App._inviteEligiblePids());
      if (typeof showToast === 'function') showToast(t('inviteSentToast', { name: S.players[pid] || ('#'+pid) }));
    },
    closeInviteModal() {
      var modal = document.getElementById('invite-modal');
      if (modal) modal.style.display = 'none';
    },
    // Step 2: ask confirmation before sending the kick.
    askConfirmKick(pid) {
      if (!S.amGameAdmin) return;
      var name = S.players[pid] || ('#' + pid);
      var msgEl = document.getElementById('kcm-msg');
      var titleEl = document.getElementById('kcm-title');
      if (titleEl) {
        titleEl.textContent = t('kickThisPlayer');
      }
      if (msgEl) {
        msgEl.textContent = t('kickConfirmMsg', { name: name });
      }
      // Stash the target pid for the confirm button.
      window._pendingKickPid = pid;
      var modal = document.getElementById('kick-confirm-modal');
      if (modal) modal.style.display = 'flex';
    },
    cancelKickConfirm() {
      window._pendingKickPid = null;
      var modal = document.getElementById('kick-confirm-modal');
      if (modal) modal.style.display = 'none';
    },
    doKickConfirmed() {
      var pid = window._pendingKickPid;
      var modal = document.getElementById('kick-confirm-modal');
      if (modal) modal.style.display = 'none';
      if (!pid || !S.amGameAdmin || !S.gId) {
        window._pendingKickPid = null;
        return;
      }
      var name = S.players[pid] || ('#' + pid);
      // Try BOTH paths so we work with both server implementations:
      //   1. KickPlayerRequestMessage (type 30) — the proto-level
      //      admin action. Some PokerTH servers honour this, others
      //      ignore it for non-real-player pids (e.g. bots) or have
      //      it disabled for stability reasons (see ChangeLog v2.0.6
      //      "admin actions functional again" — i.e. it was broken).
      //   2. "/kick <name>" via game-scoped chat — the canonical
      //      path documented on the PokerTH forum ("the game admin
      //      can kick a user by typing /kick username at the chat").
      //      The server's admin bot / chatcleaner parses this.
      // Whichever the server supports, one of the two will work; the
      // other is a no-op (server ignores it).
      try { send(MSG.buildKickPlayer(S.gId, pid)); } catch(e) {}
      try { send(MSG.buildGameChat(S.gId, '/kick ' + name)); } catch(e) {}
      // Optimistic log so the admin gets immediate feedback even
      // before the server broadcasts GamePlayerLeft. Localised.
      var fr = (typeof _lang === 'undefined' || _lang !== 'en');
      addGameChat(null, '🗑️ ' + t('kickRequested', { name: name }), 'sys', { prefix: '🗑️ ', key: 'kickRequested', params: { name: name } });
      // Watchdog: if the server hasn't broadcast a GamePlayerLeft
      // within 3s, the kick has almost certainly failed silently.
      // This happens on PokerTH servers older than v2.0.6 (March 2026,
      // changelog: "admin actions functional again"). Warn the admin.
      // Skipped in training mode (offline): the FakeServer applies a kick
      // as a deferred removal at end-of-hand, which can legitimately take
      // longer than 3s — the bot WILL leave, so no warning is warranted.
      if (!window._offlineMode)
      (function(targetPid, targetName, gameAtRequest) {
        setTimeout(function() {
          // Bail if we left the table / changed game in the meantime.
          if (S.gId !== gameAtRequest) return;
          // Player still present means the kick was not honoured.
          if (S.seatData[targetPid] && !S.seatData[targetPid].gone) {
            addGameChat(null, '⚠ ' + t('kickNotProcessed', { name: targetName }), 'sys', { prefix: '⚠ ', key: 'kickNotProcessed', params: { name: targetName } });
          }
        }, 3000);
      })(pid, name, S.gId);
      window._pendingKickPid = null;
      // Refresh the kick list so the row disappears once the server
      // confirms. We don't close the modal automatically: if the admin
      // wants to kick several players in a row, they can.
      // (We do trigger a re-render after a short delay to give the
      // GamePlayerLeft message time to arrive.)
      setTimeout(function() {
        var m = document.getElementById('kick-modal');
        if (m && m.style.display === 'flex') {
          // Re-open / re-render with the (hopefully) updated seatData
          App.openKickModal();
        }
      }, 600);
    },

    closeTable() {
      // Admin closes table: send leave, server closes game for all
      if (S.ws && S.gId) { try { send(MSG.buildLeaveGame(S.gId)); } catch(e) {} }
      S._pendingRejoin = 0; S._rejoinNickRetries = 0;
      try { localStorage.removeItem('pth_resume'); } catch(e) {}
      // BUGFIX narmod : _peakSeatCount (parité QML _peakSeatCount, seat-render.mjs)
      // n'était jamais remis à 0 en quittant une table -> une nouvelle partie
      // avec MOINS de joueurs héritait de la géométrie de sièges de la
      // précédente (boîtes/rangée cartes mal dimensionnées).
      S._peakSeatCount = 0;
      S.amInGame = false; S.amGameAdmin = false; S._gameStarted = false; S._seatsFrozen = false; S._amSpectator = false;
      S.gId = 0; S.seats = []; S.seatData = {}; S._specPids = new Set(); updateSpectatorStrip();
      var _ego = document.getElementById('g-endgame-overlay');
      if (_ego) _ego.style.display = 'none';
      try { _wpHide(); } catch(e) {}
      S._selectedGame = null; try { renderGameInfoPanel(null); } catch(e) {}
      S.myCards = [null,null]; S.commCards = [];
      stopTurnTimer();
      dismissWinner();
      S._chatRejectShown = false;
      S._lastMsgWasReaction = false;
      document.body.classList.remove('in-game');
      var acb = document.getElementById('admin-close-btn');
      if (acb) acb.style.display = 'none';
      var akb = document.getElementById('admin-kick-btn');
      if (akb) akb.style.display = 'none';
      var akbm = document.getElementById('admin-kick-mob');
      if (akbm) akbm.style.display = 'none';
      var asnb = document.getElementById('admin-startnobots-btn');
      if (asnb) asnb.style.display = 'none';
      var asnbm = document.getElementById('admin-startnobots-mob');
      if (asnbm) asnbm.style.display = 'none';
      var badge = document.getElementById('g-admin-badge');
      if (badge) badge.style.display = 'none';
      show('s-lobby');
      addChat(null, t('tableClosedMsg'), 'sys', { key: 'tableClosedMsg' });
    },

    endGameClose() {
      // Just dismiss the end-of-game overlay; the user stays on the
      // table view (final stacks visible, chat still readable).
      var el = document.getElementById('g-endgame-overlay');
      if (el) el.style.display = 'none';
    },

    endGameLeave() {
      // Dismiss the overlay then perform the normal leaveGame() flow:
      // send a LeaveGame to the server, reset client state, and return
      // to the lobby. Reuses everything leaveGame() already does so
      // there's no special-case cleanup path to maintain.
      var el = document.getElementById('g-endgame-overlay');
      if (el) el.style.display = 'none';
      this.leaveGame();
    },

    offlineReplay() {
      // Mode entraînement uniquement : relancer une partie avec les mêmes
      // réglages, en place. On revient au lobby (la socket hors-ligne reste
      // ouverte), on recrée la table depuis le formulaire, puis startWithBots()
      // est déclenché par le hook JoinGameAck dès que gId est connu (événementiel,
      // pas de minuteur fragile).
      if (!window._offlineMode) { this.endGameLeave(); return; }
      var el = document.getElementById('g-endgame-overlay');
      if (el) el.style.display = 'none';
      window._offlineAutoReplay = true;
      this.leaveGame();    // -> lobby, FakeServer remis à zéro, socket conservée
      try { this.createGame(); } catch (e) { window._offlineAutoReplay = false; }
    },

    // Sélecteur de mode de jeu PERSISTANT (officiel) : 0=Manuel,
    // 1=Auto Check/Call, 2=Auto Check/Fold. Si on choisit un mode auto alors
    // que c'est déjà notre tour, l'action est jouée immédiatement.
    _modeSelHold(on){
      // Pose/leve le verrou anti-fermeture du picker de mode (#mode-sel).
      S._modeSelBusy = !!on;
      clearTimeout(S._modeSelHoldTimer); S._modeSelHoldTimer = null;
      if (on) S._modeSelHoldTimer = setTimeout(function(){ S._modeSelBusy = false; _flushPreviewIfPending(); }, 8000);
      else _flushPreviewIfPending();
    },

    toggleActionPin() {
      S._actionBarPinned = !S._actionBarPinned;
      try { localStorage.setItem('pth_pin_actionbar', S._actionBarPinned ? '1' : '0'); } catch(e){}
      _updatePinBtn();
      // rafraichit immediatement l'UI hors-tour pour refleter le nouvel etat
      if (S.turnPid !== S.myId && S._gameStarted) renderGameWaiting(S._lastWaitingMsg, S._lastWaitingIsHtml);
    },

    setPlayingMode(idx) {
      var n = parseInt(idx, 10);
      if (!(n === 1 || n === 2)) n = 0;
      S._playingMode = n;
      var sel = document.getElementById('mode-sel');
      if (sel && sel.selectedIndex !== n) sel.selectedIndex = n;
      // Cadre or immédiat sur le dropdown quand un mode auto est actif (QML).
      try { var _msw = sel && sel.closest ? sel.closest('.mode-sel-wrap') : null; if (_msw) _msw.classList.toggle('mode-auto', n !== 0); } catch (e) {}
      if (n !== 0 && S.turnPid === S.myId) _playAutoMode();
    },

    // Ouvre/ferme le panneau "aperçu" en tapant ses cartes. Volontairement
    // sans effet à NOTRE tour (on ne change rien au fonctionnement actuel) ;
    // requiert une main en cours avec des cartes, hors mode spectateur.
    togglePreActionPanel() {
      if (S.turnPid === S.myId) return;                 // à notre tour : inchangé
      if (S._amSpectator || !S._gameStarted) return;
      if (S.myCards[0] == null && S.myCards[1] == null) return; // pas de cartes
      S._preActionOpen = !S._preActionOpen;
      if (S._preActionOpen) _renderPreActionPanel();
      else _closePreActionPanel();
    },

    // Arme / désarme une pré-action (Fold/Call/Raise/All-In) avant notre tour,
    // comme le client officiel. Reclic sur la même = désarmement. Le bouton armé
    // est surligné en or ; l'action s'exécute quand notre tour arrive.
    armPreAction(name) {
      if (S.turnPid === S.myId) return;  // à notre tour : inchangé (les boutons agissent)
      if (S._amSpectator || !S._gameStarted) return;
      if (S.myCards[0] == null && S.myCards[1] == null) return; // pas de cartes
      // Rien à décider pour l'instant (main jetée, tapis, ou j'ai déjà parlé
      // sans être relancé) : la barre est une zone morte, comme les clients
      // officiels.
      if (typeof window._barLocked === 'function' && window._barLocked()) return;
      // Arming a pre-action is a manual click too: like the official client
      // (GameActionBar.qml clickAction() -> `if (playingMode !== 0) playingMode = 0`),
      // it takes precedence over any active auto mode, which falls back to
      // Manual. Forum report 2026-08-02.
      if (S._playingMode !== 0) this.setPlayingMode(0);
      S._preAction = (S._preAction === name) ? '' : name;      // toggle
      S._preActionToCall = Math.max(0, S.highestBet - ((S.seatData[S.myId] || {}).bet || 0)); // onCallAmountChanged : MON à-suivre
      renderMyTurnActions(true);                            // re-render pour le surlignage or
    },

    // Bascule rapide du mode depuis le panneau aperçu : Manuel <-> Auto Check/Fold.
    // (Conservé pour compat ; le dropdown du panneau pilote App.setPlayingMode.)
    togglePreAuto() {
      S._playingMode = (S._playingMode === 0) ? 2 : 0;
      if (S._preActionOpen) _renderPreActionPanel();
    },

    confirmLeaveGame() {
      // Public entry point for the header ✕ button. Opens the quit
      // confirmation modal — clicking 'Quit' will then call leaveGame()
      // as usual; clicking 'Cancel' just dismisses the modal.
      closeHeaderOverflow();
      var ld = document.getElementById('leave-dialog');
      if (ld) ld.style.display = 'flex';
    },

    confirmLeaveQuit() {
      // Confirmed — close the modal and perform the standard leave
      // flow (send LeaveGame, reset client state, back to lobby).
      var ld = document.getElementById('leave-dialog');
      if (ld) ld.style.display = 'none';
      this.leaveGame();
    },

    cancelLeaveGame() {
      // Cancelled — just hide the modal, user stays in the game.
      var ld = document.getElementById('leave-dialog');
      if (ld) ld.style.display = 'none';
    },

    // Reset all in-game / table state back to a clean lobby baseline.
    // Pure local cleanup: it sends nothing on the wire, does NOT touch
    // _pendingRejoin/pth_resume (each caller manages those), and does NOT
    // navigate (each caller decides where to go). Used by every path that
    // lands back in the lobby — leaving, being removed, a failed rejoin, or
    // a fresh InitAck — so they all clear the same state and none can leave
    // a stale "still in my game / still admin" flag that blocks creating a
    // new table.
    _resetGameState() {
      S.amInGame = false; S.amGameAdmin = false; S._gameStarted = false;
      // BUGFIX narmod : cf. closeTable()/leaveGame() — _peakSeatCount (parité
      // QML _peakSeatCount) devait déjà retomber ici mais avait été oublié ;
      // sans ce reset, RemovedFromGame/rejoin raté/InitAck héritaient de la
      // géométrie de sièges d'une partie précédente à effectif différent.
      S._peakSeatCount = 0;
      S._seatsFrozen = false; S._amSpectator = false;
      S.gId = 0; S.seats = []; S.seatData = {};
      try { stopTurnTimer(); } catch (e) {}
      try { dismissWinner(); } catch (e) {}
      try { if (typeof clearUnreadChat === 'function') clearUnreadChat(); } catch (e) {}
      document.body.classList.remove('in-game');
      [ 'admin-close-btn', 'admin-close-mob',
        'admin-start-btn', 'admin-start-mob',
        'admin-kick-btn', 'admin-kick-mob',
        'g-admin-badge', 'g-public-badge', 'g-endgame-overlay'
      ].forEach(function (id) {
        var el = document.getElementById(id);
        if (el) el.style.display = 'none';
      });
      try { _resetGameHeader(); } catch (e) {}
      // Bandeau « En attente de joueurs » + options d'attente de la footbar :
      // remis à jour immédiatement (sinon un retour au lobby initié par le
      // serveur — RemovedFromGame, rejoin raté, InitAck — laissait le ⏳ figé
      // dans le header jusqu'au prochain événement lobby). (narmod 26/07)
      try { _updateLobbyWaitStatus(); } catch (e) {}
      try { _renderLobbyWaitActions(); } catch (e) {}
    },

    leaveGame() {
      // Annuler tout auto-retour programmé + masquer le dot de ping + Show
      try { clearTimeout(window._autoLeaveTimer); } catch (e) {}
      try { _setCanShow(false); } catch (e) {}
      try { _pingDotHide(); } catch (e) {}
      // Offline (vs bots) returns to the lobby just like online: the fake
      // server closes the current game (GameListUpdate=closed) on leave, so the
      // lobby ends up clean and the user can create another table.
      // Send proper leave request then stay connected (return to lobby)
      if (S.ws && S.gId) { try { send(MSG.buildLeaveGame(S.gId)); } catch(e) {} }
      // Départ volontaire : oublier le marqueur de reprise (sinon on serait
      // ré-aspiré dans la table à la prochaine reconnexion/réouverture).
      S._pendingRejoin = 0; S._rejoinNickRetries = 0;
      try { localStorage.removeItem('pth_resume'); } catch(e) {}
      // BUGFIX narmod : cf. closeTable() ci-dessus — même oubli de reset.
      S._peakSeatCount = 0;
      S.amInGame = false; S.amGameAdmin = false; S._gameStarted = false; S._seatsFrozen = false; S._amSpectator = false;
      S.gId = 0; S.seats = []; S.seatData = {}; S._specPids = new Set(); updateSpectatorStrip();
      var _ego = document.getElementById('g-endgame-overlay');
      if (_ego) _ego.style.display = 'none';
      try { _wpHide(); } catch(e) {}
      S._selectedGame = null; try { renderGameInfoPanel(null); } catch(e) {}
      S.myCards = [null,null]; S.commCards = [];
      stopTurnTimer();
      dismissWinner();
      closeHeaderOverflow();
      // Hide admin badge + close button
      var acb = document.getElementById('admin-close-btn');
      if (acb) acb.style.display = 'none';
      var acbm = document.getElementById('admin-close-mob');
      if (acbm) acbm.style.display = 'none';
      var badge = document.getElementById('g-admin-badge');
      if (badge) badge.style.display = 'none';
      // Mode entraînement : retour direct à la page de création de partie
      // (le lobby offline n'a pas d'intérêt). Exception : le replay auto
      // (offlineReplay) recrée la table immédiatement après — on garde alors
      // le passage lobby pour ne pas ré-initialiser le formulaire
      // (openCreatePage ré-applique le preset persisté).
      if (window._offlineMode && !window._offlineAutoReplay) { this.openCreatePage(); return; }
      show('s-lobby');  // back to lobby, stay connected
    },

    sendReaction(emoji) {
      if (window._reactMuted) return;                    // reactions coupees : on n'envoie rien
      if (S._amSpectator) return;                        // spectators must not send reactions (sp0ck 31/07/2026)
      if (!S.ws || !S.gId) return;
      // Affichage immediat pour moi.
      handleIncomingReaction(S.myId, emoji, 'self');
      // Canal rapide web<->web via le proxy (trame texte, contourne le throttle chat serveur).
      if (!window.directWS && S.ws.readyState === WebSocket.OPEN) {
        try { S.ws.send('REACT:' + S.myId + ':' + emoji); } catch (e) {}
      }
      // Canal partage cross-client : commande /emoji interpretee comme une reaction par
      // tous les clients (convention sp0ck, facon /me) -> interop web <-> Qt/QML (dont pokerth.net).
      // Régulé via une file (anti-flood chat serveur) : voir _queueReactEmoji.
      _queueReactEmoji(emoji);
      // Parité QML (ReactionPicker) : la fenêtre se ferme après la réaction,
      // sauf si elle est épinglée (📌 dans la barre de titre).
      try {
        var _rp = document.getElementById('g-reaction-panel');
        if (!window._reactPinned && _rp && _rp.style.display !== 'none' && _rp.style.display !== '')
          toggleReactionPanel();
      } catch (e) {}
    },

    // Bascule le mute local des reactions (bouton barre dans le panneau).
    toggleReactionsMute() {
      window._reactMuted = !window._reactMuted;
      try { localStorage.setItem('pth_react_muted', window._reactMuted ? '1' : '0'); } catch (e) {}
      _applyReactMuteUI();
    },

    // Épingle la fenêtre de réactions : épinglée = ne se ferme plus après
    // l'envoi d'une réaction (le défaut suit le QML : fermeture immédiate).
    toggleReactionsPin() {
      window._reactPinned = !window._reactPinned;
      try { localStorage.setItem('pth_react_pin', window._reactPinned ? '1' : '0'); } catch (e) {}
      _applyReactPinUI();
    },

    // Coupe/rétablit le son de notification du chat de PARTIE (icône à côté
    // de la corbeille, ui/chat.mjs). Réglage indépendant de l'option avancée
    // « Notification du chat lobby » (Options avancées → Son).
    toggleGameChatMute() {
      if (typeof setGameChatSoundMuted !== 'function') return;
      var on = !(typeof isGameChatSoundMuted === 'function' && isGameChatSoundMuted());
      setGameChatSoundMuted(on);
    },

    // Même principe pour le chat du LOBBY (notifyLobbyChat, msg-social.mjs) —
    // état séparé, ne coupe pas le son du chat de partie et inversement.
    toggleLobbyChatMute() {
      if (typeof setLobbyChatSoundMuted !== 'function') return;
      var on = !(typeof isLobbyChatSoundMuted === 'function' && isLobbyChatSoundMuted());
      setLobbyChatSoundMuted(on);
    },

    // Pagination du panneau réactions : flèches ‹ › (l'indicateur N/3 est passif).
    reactPage(i) { setReactionPage(i); },
    reactPageStep(d) { setReactionPage(_reactPageCurrent() + (d || 0), d > 0 ? 'left' : 'right'); },

    sendGameChat() {
      var input = document.getElementById('g-chat-in');
      if (!input) return;
      // Spectators must not send game chat (sp0ck 31/07/2026) — the input row
      // is hidden by CSS; this guard is defense in depth (Enter key, scripts).
      if (S._amSpectator) { input.value = ''; return; }
      var text = input.value.trim();
      if (!text || !S.ws) return;
      input.value = '';
      S._lastMsgWasReaction = false;
      // ── /seatdbg : diagnostic LOCAL des sieges (rien n'est envoye) ──
      // Affiche dans le chat les mesures qui pilotent la bisection QML :
      // zone (tableZone px), boxScale applique, rawBoxScale (avant rabot),
      // dims mesurees (w/h adversaire, sh self), fenetre et reserves. Sert
      // au debug iPhone (pas de console) : tailles de sieges, self-box.
      if (text === '/seatdbg') {
        try {
          var _d = window._seatDbg || {};
          var _ga = document.querySelector('.game-area');
          var _mz = document.querySelector('.my-zone');
          var _hd = document.querySelector('#s-game .header');
          var _zn = document.getElementById('g-table-zone');
          var _zr = _zn ? _zn.getBoundingClientRect() : null;
          var _ga2 = _ga ? _ga.getBoundingClientRect() : null;
          var _me = document.querySelector('#g-seats .seat.me');
          var _mer = _me ? _me.getBoundingClientRect() : null;
          var _zoomV = 1;
          try { if (typeof _getTableZoom === 'function') _zoomV = _getTableZoom(); } catch (eZ) {}
          var _info = {
            win: window.innerWidth + 'x' + window.innerHeight,
            zone: _d.zone || (_zr ? Math.round(_zr.width) + 'x' + Math.round(_zr.height) : '?'),
            zoneLive: _zr ? Math.round(_zr.width) + 'x' + Math.round(_zr.height) + '@y' + Math.round(_zr.top) : null,
            gaRect: _ga2 ? Math.round(_ga2.width) + 'x' + Math.round(_ga2.height) + '@y' + Math.round(_ga2.top) : null,
            zoom: +(+_zoomV).toFixed(3),
            selfRect: _mer ? Math.round(_mer.width) + 'x' + Math.round(_mer.height) + '@y' + Math.round(_mer.top) : null,
            boxScale: _d.boxScale != null ? +(+_d.boxScale).toFixed(3) : null,
            rawBoxScale: _d.rawBoxScale != null ? +(+_d.rawBoxScale).toFixed(3) : null,
            fitShave: +((window._seatFitShave || 1)).toFixed(3),
            dims: _d.dims || window._seatDimsMeasured || null,
            commScale: _d.commScale != null ? +(+_d.commScale).toFixed(3) : null,
            headerH: _hd ? _hd.offsetHeight : null,
            barH: _mz ? _mz.offsetHeight : null,
            gaPadB: _ga ? (_ga.style.paddingBottom || getComputedStyle(_ga).paddingBottom) : null,
            seat: document.documentElement.getAttribute('data-seat') || '',
            layout: document.documentElement.getAttribute('data-seat-layout') || 'auto',
            players: (typeof S.seats !== 'undefined' && S.seats) ? S.seats.length : 0
          };
          // cls 'mine' (et pas 'sys' : les messages systeme sont filtres
          // d'addGameChat) — affichage local uniquement, rien n'est envoye.
          addGameChat('seatdbg', JSON.stringify(_info), 'mine');
        } catch (eDbg) { try { addGameChat('seatdbg', 'error: ' + eDbg, 'mine'); } catch (e2) {} }
        return;
      }
      // ── Local diagnostic/setting commands (/help /diag /update …) — nothing
      // is sent to the server. See _chatLocalCmd and docs/DIAGNOSTIC.md.
      // ── /gn <texte> : durchsage serveur (admins pokerth.net) ─────────
      // Parité QML (LobbyHandler::sendChatMessage, correctif sp0ck du 29/07) :
      // la commande part TOUJOURS au serveur, c'est lui seul qui juge les
      // droits. Filtrer ici sur nos droits locaux enverrait la durchsage d'un
      // admin dont le PlayerInfo n'est pas encore arrivé en chat ordinaire,
      // visible de tous. Le résultat revient par AdminGlobalNoticeAck.
      if (/^\/gn\s+\S/i.test(text)) {
        try { send(MSG.buildAdminGlobalNotice(text.replace(/^\/gn\s+/i, ''))); } catch (eGn) {}
        try { if (window._chatPushHist) window._chatPushHist(text); } catch (eGh) {}
        return;
      }
      if (text.charAt(0) === '/' && _chatLocalCmd(text, function (n, s2) { addGameChat(n, s2, 'mine'); })) return;
      try { if (window._chatPushHist) window._chatPushHist(text); } catch (e) {}
      send(S.gId ? MSG.buildGameChat(S.gId, text) : MSG.buildChat(text));
      addGameChat(S.myName, text, 'mine');
    },
    // « Show » : envoie ShowMyCardsRequest (type 51, corps vide) pendant la
    // fenêtre d'attente ; la rediffusion AfterHandShowCards rendra les cartes.
    showMyCards() {
      if (!window._canShowCards || !S.ws || !S.gId) return;
      try { send(MSG.buildShowMyCards()); } catch (e) {}
      _setCanShow(false);
    },
    // Bouton « durchsage » du chat lobby (visible aux seuls admins) : il
    // préremplit la commande au lieu d'ouvrir une boîte — l'admin relit son
    // texte, garde l'historique du chat et la limite de saisie habituelle.
    globalNoticePrompt() {
      const input = $('chat-in');
      if (!input) return;
      input.value = '/gn ' + input.value.replace(/^\/gn\s*/i, '');
      try {
        input.focus();
        input.setSelectionRange(input.value.length, input.value.length);
      } catch (e) {}
    },
    sendChat() {
      const input = $('chat-in');
      const text  = input.value.trim();
      if (!text || !S.ws) return;
      input.value = '';
      // ── Local diagnostic/setting commands (/help /diag /update …) — nothing
      // is sent to the server. See _chatLocalCmd and docs/DIAGNOSTIC.md.
      // ── /gn <texte> : durchsage serveur (admins pokerth.net) ─────────
      // Parité QML (LobbyHandler::sendChatMessage, correctif sp0ck du 29/07) :
      // la commande part TOUJOURS au serveur, c'est lui seul qui juge les
      // droits. Filtrer ici sur nos droits locaux enverrait la durchsage d'un
      // admin dont le PlayerInfo n'est pas encore arrivé en chat ordinaire,
      // visible de tous. Le résultat revient par AdminGlobalNoticeAck.
      if (/^\/gn\s+\S/i.test(text)) {
        try { send(MSG.buildAdminGlobalNotice(text.replace(/^\/gn\s+/i, ''))); } catch (eGn) {}
        try { if (window._chatPushHist) window._chatPushHist(text); } catch (eGh) {}
        return;
      }
      // ── /msg <pseudo> <texte> : message privé ────────────────────────
      // Parité QML (LobbyHandler::sendChatMessage + parsePrivateMessageTarget) :
      // pseudo simple, ou entre guillemets s'il contient des espaces. Le texte
      // est tronqué à 128 octets UTF-8 par _pmSendTo. Rien ne part en chat
      // public : sans cette interception la commande serait diffusée telle
      // quelle à tout le lobby.
      if (/^\/msg\s+\S/i.test(text)) {
        var _pmRest = text.replace(/^\/msg\s+/i, '');
        var _pmTo = '', _pmBody = '';
        var _pmQ = _pmRest.match(/^"([^"]+)"\s*([\s\S]*)$/);
        if (_pmQ) { _pmTo = _pmQ[1]; _pmBody = _pmQ[2]; }
        else {
          var _pmSp = _pmRest.indexOf(' ');
          if (_pmSp > 0) { _pmTo = _pmRest.slice(0, _pmSp); _pmBody = _pmRest.slice(_pmSp + 1); }
        }
        _pmTo = _pmTo.trim(); _pmBody = _pmBody.trim();
        try { if (window._chatPushHist) window._chatPushHist(text); } catch (ePh) {}
        if (!_pmTo || !_pmBody) {
          addChat(null, t('pmUsage'), 'sys', { force: true, key: 'pmUsage' });
          return;
        }
        var _pmErr = (typeof window._pmSendTo === 'function') ? window._pmSendTo(_pmTo, _pmBody) : 'offline';
        if (_pmErr === 'notFound')
          addChat(null, t('pmNotFound'), 'sys', { force: true, key: 'pmNotFound' });
        else if (_pmErr === 'atTable')
          addChat(null, t('pmAtTable'), 'sys', { force: true, key: 'pmAtTable' });
        else if (_pmErr === 'self')
          addChat(null, t('pmSelf'), 'sys', { force: true, key: 'pmSelf' });
        else if (_pmErr === 'offline')
          addChat(null, t('pmOffline'), 'sys', { force: true, key: 'pmOffline' });
        else if (!_pmErr)
          addChat(_pmTo, _pmBody, 'mine pm');
        return;
      }
      if (text.charAt(0) === '/' && _chatLocalCmd(text, function (n, s2) { addChat(n, s2, 'mine'); })) return;
      try { if (window._chatPushHist) window._chatPushHist(text); } catch (e) {}
      send(MSG.buildChat(text, 0));
      // Affichage optimiste
      addChat(S.myName, text, 'mine');
    },
    // ── Copy a shareable link to the current table ──────────────
    // Copies the canonical invite link (see _inviteLink / shareTableLink):
    //   https://<thispage>/#join=<gameName>&s=pokerth.net
    // The legacy ?host=&port=&table=<id> links are still READ at load
    // (parseShareLink) so the ones already sent keep working.
    //
    // The link is copied to the clipboard via the async Clipboard
    // API with a legacy execCommand fallback for older / insecure
    // (non-HTTPS) contexts where navigator.clipboard is unavailable.
    copyTableLink() {
      var fr = (typeof _lang === 'undefined' || _lang !== 'en');
      if (!S.gId) {
        if (typeof showKeyHint === 'function')
          showKeyHint(t('noActiveTable'));
        return;
      }
      // Same canonical link as the « Invite friends » dialog (#join=<name>
      // &s=<server>): the old ?host=&port=&table=<id> format sent the
      // friend into LAN mode even for a pokerth.net table.
      var _il = this._inviteLink();
      if (!_il) { if (typeof showKeyHint === 'function') showKeyHint(t('noActiveTable')); return; }
      var url = _il.url;

      // Copy with graceful fallbacks.
      function done(ok) {
        if (typeof showKeyHint === 'function') {
          // Copied, but the link cannot work for everyone: say why.
          var _w = (ok && _il.warnings && _il.warnings.length) ? ' \u2014 ' + t(_il.warnings[0]) : '';
          showKeyHint(ok
            ? t('linkCopied') + _w
            : t('linkCopyFailed'));
        }
        // Reflect status on the modal button if present.
        var btn = document.getElementById('gim-copy-link-btn');
        if (btn) {
          var orig = btn.getAttribute('data-orig') || btn.innerHTML;
          btn.setAttribute('data-orig', orig);
          btn.innerHTML = ok ? '✓ ' + t('copiedShort') : '⚠';
          setTimeout(function(){ btn.innerHTML = orig; }, 1800);
        }
        if (!ok) {
          // Last resort: show the URL so the user can copy by hand.
          try { window.prompt(t('copyThisLink'), url); } catch(e) {}
        }
      }
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(url).then(function(){ done(true); }, function(){ legacyCopy(); });
        } else {
          legacyCopy();
        }
      } catch(e) { legacyCopy(); }

      function legacyCopy() {
        try {
          var ta = document.createElement('textarea');
          ta.value = url;
          ta.style.position = 'fixed';
          ta.style.opacity = '0';
          document.body.appendChild(ta);
          ta.focus(); ta.select();
          var ok = document.execCommand('copy');
          document.body.removeChild(ta);
          done(!!ok);
        } catch(e) { done(false); }
      }
    },

    // ── Share an invite link to the current table ───────────────
    // Canonical format (the QML client can emit/parse the same one):
    //   https://<thispage>/#join=<gameName>&s=pokerth.net
    //   https://<thispage>/#join=<gameName>&s=<host[:port]>[&tls=1]
    // Game NAME rather than the ephemeral numeric id; target derived
    // from how *I* am connected (never hard-coded, so every install \u2014
    // pokerth.net, a ddns test server, a LAN box \u2014 emits links that
    // point at itself). The password is NEVER in the link: joinGame()
    // prompts the invitee if the table is protected. Native share
    // sheet when available (phones), clipboard otherwise.
    // Canonical link of the current table: { url, name, warnings } or null.
    // Built by modules/net/invite-link.mjs (shared with copyTableLink, the
    // hashchange handler and scripts/test-invite-link.mjs); the inline
    // builder below is only a fallback for a stale cached module graph.
    _inviteLink() {
      if (!S.gId) return null;
      var g = S.games[S.gId] || {};
      var name = g.name || (S._gameMeta && S._gameMeta.name) || '';
      if (!name) return null;
      var host = '', port = '', tls = false;
      try { host = (document.getElementById('host') || {}).value || ''; } catch(e) {}
      try { port = (document.getElementById('port') || {}).value || ''; } catch(e) {}
      try { tls = !!(document.getElementById('use-tls') && document.getElementById('use-tls').checked); } catch(e) {}
      var IL = window.InviteLink;
      var base = window.location.origin + window.location.pathname;
      if (IL && IL.buildInviteUrl) {
        var target = IL.inviteTarget(S._currentLoginMode || '', host, port, tls);
        var type = g.type || (S._gameMeta && S._gameMeta.type) || 1;
        return { url: IL.buildInviteUrl(base, name, target), name: name,
                 warnings: IL.inviteWarnings({ type: type }, target) };
      }
      var mode = S._currentLoginMode || '';
      var tgt = (mode === 'guest' || mode === 'auth') ? 'pokerth.net'
        : String(host).trim() + (String(port).trim() ? ':' + String(port).trim() : '');
      return { url: base + '#join=' + encodeURIComponent(name) + '&s=' + encodeURIComponent(tgt) +
               ((tgt !== 'pokerth.net' && tls) ? '&tls=1' : ''), name: name, warnings: [] };
    },
    shareTableLink() {
      var _il = this._inviteLink();
      if (!_il) { if (typeof showKeyHint === 'function') showKeyHint(t('noActiveTable')); return; }
      var name = _il.name, url = _il.url;
      // Rich share dialog (QR code + copy + messenger shortcuts, see
      // modules/ui/invite.mjs) when available; direct native share /
      // clipboard kept as fallback for a stale cached page.
      if (window.InviteUI && document.getElementById('invite-dialog')) {
        // If the dialog module throws for any reason, fall through to the
        // native share sheet instead of silently doing nothing.
        try { window.InviteUI.open(url, name, _il.warnings); return; }
        catch(eInv) { try { console.error('[invite] dialog failed, falling back', eInv); } catch(e2){} }
      }
      var self = this;
      if (navigator.share) {
        // AbortError = user closed the share sheet \u2014 not a failure,
        // don't surprise them with a clipboard write.
        navigator.share({ title: 'PokerTH', text: name, url: url })
          .catch(function(err){ if (!err || err.name !== 'AbortError') self._copyInviteUrl(url); });
        return;
      }
      this._copyInviteUrl(url);
    },
    _copyInviteUrl(url) {
      function done(ok) {
        if (typeof showKeyHint === 'function') showKeyHint(ok ? t('linkCopied') : t('linkCopyFailed'));
        if (!ok) { try { window.prompt(t('copyThisLink'), url); } catch(e) {} }
      }
      function legacyCopy() {
        try {
          var ta = document.createElement('textarea');
          ta.value = url; ta.style.position = 'fixed'; ta.style.opacity = '0';
          document.body.appendChild(ta); ta.focus(); ta.select();
          var ok = document.execCommand('copy'); document.body.removeChild(ta);
          done(!!ok);
        } catch(e) { done(false); }
      }
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(url).then(function(){ done(true); }, legacyCopy);
        } else legacyCopy();
      } catch(e) { legacyCopy(); }
    },

    spectateGame(gameId) {
      var g = S.games[gameId];
      if (!g) return;
      // Remember that we joined as spectator. Used by JoinGameAck to flip
      // the UI into 'watch only' mode (banner up top, action area replaced
      // with a message instead of fold/call buttons).
      S._amSpectator = true; updateSpectatorStrip();
      addChat(null, '👁 ' + t('spectatingTable') + (g.name||('#'+gameId)) + '…', 'sys', { prefix: '👁 ', key: 'spectatingTable', suffix: (g.name||('#'+gameId)) + '…' });
      // Use the shared MSG.buildJoinGame helper which now correctly
      // encodes spectateOnly into field 4. The previous hand-rolled
      // message set field 3 (autoLeave) instead, which the server did
      // not interpret as spectate, and silently dropped the request —
      // the user saw 'Joining…' but never got a JoinGameAck back.
      _sendJoin(MSG.buildJoinGame(gameId, true));
    },

    autoJoinOrCreate() {
      // ⚡ Quick Game button. Two paths:
      //   1) A joinable table (not started, not full) exists → join it
      //      directly, no questions asked.
      //   2) No joinable table → ask the user how many players the new
      //      table should support via the quick-create modal. Avoids
      //      the previous behaviour of silently creating a 2-player
      //      table (too restrictive on busy servers).
      let target = null;
      for (const id of Object.keys(S.games)) {
        const g = S.games[id];
        if (g && !g.started && g.players < g.maxPlayers) { target = id; break; }
      }
      if (target) {
        S.autoAction = true;
        const btn = document.getElementById('btn-autojoin');
        if (btn) { btn.textContent = '⏳...'; btn.disabled = true; }
        addChat(null, t('autoTableFound', { n: target }), 'sys', { key: 'autoTableFound', params: { n: target } });
        _sendJoin(MSG.buildJoinGame(parseInt(target), false));
      } else {
        // No table — show the player-count dialog. The actual CreateGame
        // is dispatched by confirmQuickCreate() if the user confirms.
        // Pre-fill the player-count field with the per-mode default (2
        // for LAN/private, 5 for pokerth.net public).
        this._applyCreateFormDefaults(false);
        var qc = document.getElementById('quick-create-dialog');
        if (qc) qc.style.display = 'flex';
      }
    },

    confirmQuickCreate() {
      // 'Create' clicked in the quick-create dialog. Read the player
      // count, clamp to the allowed range 2..10, and dispatch the
      // CreateGame request with the same other defaults the previous
      // hardcoded path used (10s blind / 3000 stack / 30s timeout).
      var qc = document.getElementById('quick-create-dialog');
      var inp = document.getElementById('qc-players');
      var n = parseInt(inp && inp.value, 10);
      if (!Number.isFinite(n)) n = 5;
      if (n < 2) n = 2;
      if (n > 10) n = 10;
      if (qc) qc.style.display = 'none';
      S.autoAction = true;
      const btn = document.getElementById('btn-autojoin');
      if (btn) { btn.textContent = '⏳...'; btn.disabled = true; }
      addChat(null, t('autoNoTable'), 'sys', { key: 'autoNoTable' });
      // Use the per-login-mode defaults so a Quick Game on pokerth.net
      // behaves like the public server (30s timeout) and a Quick Game on
      // a LAN/private box stays snappy (15s).
      var d = this._getCreateDefaults();
      // Suffixe court aléatoire : évite la collision avec une table du même nom
      // qui traînerait encore (session « fantôme » gardée par la grâce proxy),
      // ce qui ferait échouer/fermer la création côté serveur.
      var _autoName = 'WebGame-' + S.myName + '-' + Math.random().toString(36).slice(2, 5);
      send(MSG.buildCreateGame(_safeGameName(_autoName), n, d.blind, d.stack, d.timeout));
    },

    cancelQuickCreate() {
      // 'Cancel' clicked — just close the dialog and leave the lobby
      // alone. The Quick Game button is NOT disabled in this path, so
      // the user can try again right away.
      var qc = document.getElementById('quick-create-dialog');
      if (qc) qc.style.display = 'none';
    },

    joinGameWithPassword(gameId, pass) {
      var g = S.games[gameId];
      var gName = g ? g.name : '#' + gameId;
      addChat(null, 'Joining "' + esc(gName) + '"...', 'sys');
      // JoinExistingGameMessage: gameId=1, password=2
      var msg = Proto.encode([[1,0,gameId],[2,2,pass||'']]);
      _sendJoin(Proto.encode([[1,0,21],[22,2,msg]]));
    },
    // Clic sur une ligne de partie → sélection + panneau « Infos de partie »
    // (remplace l'ancienne liste dépliable sous la ligne).
    // Rejoindre la partie sélectionnée depuis le bouton du bas (parité QML).
    joinSelectedGame() {
      if (S._selectedGame == null || typeof S.games === 'undefined') return;
      var g = S.games[S._selectedGame];
      if (g && g.mode === 1) this.joinGame(S._selectedGame);
    },
    // Regarder (spectateur) la partie en cours sélectionnée depuis le bouton du bas.
    spectateSelectedGame() {
      if (S._selectedGame == null || typeof S.games === 'undefined') return;
      var g = S.games[S._selectedGame];
      if (g && g.mode === 2) this.spectateGame(S._selectedGame);
    },
    selectGame(gid) {
      S._selectedGame = gid;
      renderGameInfoPanel(gid);
      renderGames();  // surbrillance de la ligne sélectionnée
      if (window._lobby3OpenInfo) window._lobby3OpenInfo();  // slide-in en compact
    },
    // Conservé pour rétro-compat éventuelle ; délègue à la sélection.
    // Déplie/replie la liste des joueurs d'une table dans la liste (accordéon).
    toggleTablePlayers(gid) {
      var k = String(gid);
      if (S._openTables.has(k)) { S._openTables.delete(k); }
      else {
        S._openTables.add(k);
        var g = S.games[gid];
        if (g && g.seats) g.seats.forEach(function(pid){
          if (pid && !S.players[pid] && !S._pendingNameRequests.has(pid)) {
            S._pendingNameRequests.add(pid);
            try { send(Proto.encode([[1,0,MSG.T.PlayerInfoRequest],[19,2,Proto.encode([[1,0,pid]])]])); } catch(e){ S._pendingNameRequests.delete(pid); }  // T exists only inside handleMsg
          }
        });
      }
      renderGames();
    },

    // ── Signalements officiels : nom de partie et avatar ─────────────
    // Deux motifs, un seul modal de confirmation (#report-confirm-modal) :
    // _reportKind dit lequel est en cours et doReport() aiguille. Le titre est
    // réécrit à chaque ouverture, data-i18n compris, sinon un changement de
    // langue ferait réapparaître le libellé de l'autre motif.
    _reportKind: null,
    _reportGid: null,
    _reportPid: null,
    _openReportModal(kind, titleKey, msgText) {
      this._reportKind = kind;
      var ttl = document.getElementById('rcm-title');
      if (ttl) { ttl.setAttribute('data-i18n', titleKey); ttl.textContent = t(titleKey); }
      var msg = document.getElementById('rcm-msg');
      if (msg) msg.textContent = msgText;
      var modal = document.getElementById('report-confirm-modal');
      if (modal) modal.style.display = 'flex';
    },
    reportGameName(gid) {
      // Invites exclus (parite QML LobbyHandler::reportGameName, upstream 04f5839).
      if (window._amMyPlayerGuest()) return;
      var g = S.games[gid]; if (!g) return;
      this._reportGid = gid;
      this._openReportModal('game', 'reportGameTitle',
        t('reportGameMsg', { name: g.name || ('#' + gid) }));
    },
    // Signaler l'avatar d'un joueur — parité GamePlayerBox.qml (entrée
    // « Report inappropriate avatar » du menu contextuel). Le QML n'expose ce
    // menu qu'en mode desktop ; ici l'action vit dans le popup joueur, donc
    // elle reste atteignable au doigt (choix web, cf. ROADMAP).
    reportAvatar(pid) {
      if (pid == null || pid === S.myId) return;
      // Invites exclus (parite QML GameHandler::reportAvatar, upstream 04f5839).
      if (window._amMyPlayerGuest()) return;
      var h = S._pthAvatarHashes[pid];
      if (!h || !h.hashHex) return;   // pas d'avatar chargé → rien à signaler
      this._reportPid = pid;
      var nm = (typeof window.getPlayerName === 'function') ? window.getPlayerName(pid) : '';
      this._openReportModal('avatar', 'reportAvatarTitle',
        t('reportAvatarMsg', { name: nm || ('#' + pid) }));
    },
    cancelReport() {
      var modal = document.getElementById('report-confirm-modal');
      if (modal) modal.style.display = 'none';
      this._reportKind = null; this._reportGid = null; this._reportPid = null;
    },
    doReport() {
      var kind = this._reportKind, gid = this._reportGid, pid = this._reportPid;
      this.cancelReport();
      if (window._amMyPlayerGuest()) return;   // invites : le serveur refuse
      if (kind === 'avatar') {
        if (pid == null) return;
        var h = S._pthAvatarHashes[pid];
        // Envoi réel du ReportAvatarMessage (type 69) : le serveur enregistre
        // une entrée de modération sur le hash et répond par un
        // ReportAvatarAck (accepté / déjà signalé / erreur) → toast.
        try {
          var _ra = MSG.buildReportAvatar(pid >>> 0, MSG.hexToMd5Bytes(h && h.hashHex));
          if (_ra) send(_ra);
        } catch(e) {}
        return;
      }
      if (gid == null) return;
      // Envoi réel du ReportGameMessage (type 71) : le serveur crée une
      // entrée de modération (créateur + nom de table) et répond par un
      // ReportGameAck (accepté / déjà signalé / erreur) → toast ci-dessous.
      try {
        var _rg = Proto.encode([[1, 0, 71], [72, 2, Proto.encode([[1, 0, gid >>> 0]])]]);
        send(_rg);
      } catch(e) {}
      var btn = document.querySelector('#lobby-gameinfo .lgi-report');
      if (btn) { var o = btn.textContent; btn.textContent = '✅'; setTimeout(function(){ btn.textContent = o; }, 1800); }
    },
    // Alias historiques : du code et des tests appellent encore ces noms.
    cancelReportGame() { return this.cancelReport(); },
    doReportGame() { return this.doReport(); },
    joinGame(gameId) {
      const g = S.games[gameId];
      if (!g) return;
      if (g.mode === 3) { addChat(null, 'Table closed.', 'sys'); return; }
      if (_guestJoinBlocked(g)) { setStatus(t('guestJoinBlocked') || 'Guests can only join normal games.', 'err'); return; }
      if (g.priv || g.type === 3) {
        if (g.type === 3 && !g.priv) { setStatus(typeof t==='function'?t('errNotInvited')||'Invite-only table':'Invite-only table', 'err'); return; }
        const pp = document.getElementById('password-prompt');
        if (pp) {
          var ppName = document.getElementById('pp-table-name');
          var ppPass = document.getElementById('pp-pass');
          if (ppName) ppName.textContent = '🔒 ' + g.name;
          if (ppPass) ppPass.value = '';
          pp.dataset.gameId = gameId;
          pp.style.display = 'flex';
          setTimeout(function(){ if (ppPass) ppPass.focus(); }, 100);
        }
        return;
      }
      addChat(null, 'Joining "' + esc(g.name) + '"...', 'sys');
      _sendJoin(MSG.buildJoinGame(parseInt(gameId), false));
    },
    setTableFilter(f) {
      var n = parseInt(f, 10); if (isNaN(n) || n < 0 || n > 5) n = 0;
      S._tableFilter = String(n);
      try { localStorage.setItem('pth_table_filter', S._tableFilter); } catch(e) {}
      renderGames();
    },
    dismissWinner() { dismissWinner(); },
    // Un clic MANUEL sur un bouton d'action (ou son raccourci clavier, qui
    // passe par btn.click()) repasse le mode a Manuel, comme le client
    // officiel (QML/Qt-Widgets, bible §5.2 ; demande sp0ck 2026-07-17).
    // Le mode auto (_playAutoMode) et la pre-action appellent le doAction
    // INTERNE et ne repassent donc pas le mode.
    doAction(action, bet) { if (S._playingMode !== 0) this.setPlayingMode(0); doAction(action, bet); },
    confirmCall(action, amount) { if (S._playingMode !== 0) this.setPlayingMode(0); confirmCall(action, amount); },
    doRaise() { if (S._playingMode !== 0) this.setPlayingMode(0); doRaise(); },
    // Pave numerique de mise (ui/bet-keypad.mjs) et arrondi du slider :
    // ponts pour les handlers inline de la barre d'action.
    openBetKeypad() { if (window.openBetKeypad) window.openBetKeypad(); },
    _roundRaise(v, min, max) { return window._roundRaise ? window._roundRaise(v, min, max) : v; },

    // ── Per-login-mode CreateGame defaults ───────────────────────────────
    //
    // The form should feel different depending on who's likely to be on the
    // other side of the table:
    //   • LAN / Private server (unauth) → friends & family. Small table (5
    //     seats), short 15s timeout, "fill with bots" pre-checked so you
    //     can start dealing as soon as 2 humans have joined.
    //   • pokerth.net (guest / registered) → public strangers. Standard 8-
    //     seat full ring, longer 30s timeout to give players time to think,
    //     blinds rise every 10 hands (slower), bots OFF by default and the
    //     minimum-humans-before-bots fallback set higher (5).
    //
    // Returns an object whose keys map 1:1 to the form's element ids (minus
    // the 'cf-' prefix). _applyCreateFormDefaults() walks this object and
    // writes each value into the corresponding input.
    _getCreateDefaults(skipSaved) {
      var mode = S._currentLoginMode || 'unauth';
      var isPublic = (mode === 'guest' || mode === 'auth');
      // Last-used settings (saved by createGame) take priority over the
      // per-mode baseline, so the form re-opens with what the user actually
      // used last time. The table name is never restored — always fresh.
      var saved = null;
      try { saved = JSON.parse(localStorage.getItem('pth_last_create') || 'null'); } catch (e) { saved = null; }
      var withSaved = function (base) {
        if (saved && typeof saved === 'object') {
          for (var k in saved) {
            // Advanced keys (raiseMode, gameType…) aren't in the baseline
            // object, so we must NOT require hasOwnProperty here.
            if (saved[k] == null) continue;
            // Le nom de table est restauré comme le reste. Il en était exclu
            // par crainte du refus « nom déjà pris » quand la table précédente
            // tourne encore ; c'est désormais traité au moment de remplir le
            // champ (_freeGameName), donc plus aucune raison de faire retaper
            // son nom au joueur à chaque partie. Un nom vide ne recouvre rien —
            // et un nom AUTO (défaut du mode, nom admin) enregistré par une
            // session passée n'est pas un choix : il laisse la main aux
            // préférences (rapport forum : « My online game » figé recouvrait
            // pour toujours le nom réglé dans les options).
            if (k === 'name' && (!String(saved[k]).trim() || _isAutoGameName(saved[k]))) continue;
            base[k] = saved[k];
          }
        }
        return base;
      };
      // Admin-set table defaults (from /app-config) override the per-mode baseline,
      // but a player's own last-used settings still win (withSaved runs after this).
      var withAdmin = function (base) {
        var a = window._adminTableDefaults;
        if (a && typeof a === 'object') ['players', 'blind', 'stack', 'timeout'].forEach(function (k) { if (a[k] != null && a[k] !== '') base[k] = a[k]; });
        return base;
      };
      // Préférences de création du mode courant (pth_prefs_internet /
      // pth_prefs_lan / pth_prefs_local, parité QML InternetGameSettings /
      // NetworkGameSettings / LocalGameSettings). Elles existaient déjà —
      // éditables champ par champ dans les Options avancées, exportées dans le
      // .pdb — mais ne s'appliquaient qu'en cliquant la pastille ⭐ Perso. Un
      // panneau de préférences dont les valeurs n'apparaissent nulle part n'en
      // est pas un : elles s'appliquent maintenant à l'ouverture du formulaire.
      //
      // C'est aussi ce que faisait l'ancien client Qt-Widgets, dont la boîte de
      // création s'initialisait depuis NetTimeOutPlayerAction /
      // NetDelayBetweenHands. La réécriture QML a perdu cette liaison (aucune
      // lecture de SettingsManager dans LobbyCreateGamePage.qml) — divergence
      // assumée, dans le sens d'une régression upstream réparée.
      //
      // Elles s'appliquent SOUS le dernier formulaire utilisé (pth_last_create),
      // pas au-dessus. Chaque bouton garde ainsi son rôle et un seul :
      //   · le joueur modifie le formulaire et lance → il retrouve ses choix à
      //     l'ouverture suivante ; rien ne les recouvre dans son dos ;
      //   · 💾 enregistre les réglages courants comme préférences ;
      //   · ⭐ Mes préférences les recharge, sur demande.
      // Les préférences servent donc de socle : elles habillent le formulaire
      // tant qu'aucune partie n'a été créée dans ce mode, et remplissent les
      // champs que le dernier formulaire ne couvre pas.
      //
      // Le nom de table est restauré comme les autres champs — le bouton ⭐ le
      // faisait déjà (applyCreatePrefs), il n'y avait aucune raison que le
      // remplissage automatique s'en écarte.
      var self = this;
      var withPrefs = function (base) {
        var pref = null;
        try { pref = self._readCreatePrefsRaw(); } catch (e) { pref = null; }
        if (pref && typeof pref === 'object') {
          for (var k in pref) {
            if (pref[k] == null) continue;
            // Un nom vide ne doit pas écraser le nom par défaut du mode.
            if (k === 'name' && !String(pref[k]).trim()) continue;
            base[k] = pref[k];
          }
        }
        return base;
      };
      // Mode entraînement : défauts du jeu LOCAL officiel (configfile.cpp
      // qt6-qml : StartCash 5000, GameSpeed 4, hausse toutes les 8 mains,
      // NetTimeOutPlayerAction 20). Aligné QML v0.3.686 (demande Arnaud).
      if (window._offlineMode) {
        var baseOffline = {
          name: _defaultNameForMode(),
          players: 10,
          blind: 10,
          stack: 5000,
          timeout: 20,
          raiseEvery: 8,
          guiSpeed: 4,
          delayHands: 7,
          bots: true,
          minHumans: 2,
          tag: 'offline',
        };
        return skipSaved ? withAdmin(baseOffline) : withSaved(withPrefs(withAdmin(baseOffline)));
      }
      if (isPublic) {
        // Defaults for pokerth.net (guest + registered) — alignés 1:1 sur le
        // client QML (configfile.cpp : NetStartCash 3000, NetFirstSmallBlind
        // 10, NetRaiseSmallBlindEveryHands 8, NetTimeOutPlayerAction 20,
        // NetDelayBetweenHands 7). Les anciens timeouts courts (5 s public /
        // 15 s LAN) sont remplacés par le défaut officiel 20 s (v0.3.686).
        var basePublic = {
          name: _defaultNameForMode(),
          players: 10,
          blind: 10,
          stack: 3000,
          timeout: 20,
          raiseEvery: 8,
          guiSpeed: 4,
          delayHands: 7,
          bots: false,
          minHumans: 5,
          tag: 'public', // for the QuickGame dialog
        };
        return skipSaved ? withAdmin(basePublic) : withSaved(withPrefs(withAdmin(basePublic)));
      }
      // LAN / private-server profile (covers both the 'lan' login mode
      // and the 'unauth' private-server-guest mode). Défauts réseau QML
      // officiels (3000 / SB 10 / hausse 8 mains / 20 s / délai 7).
      // Bots default ON so a small group can start a hand fast.
      var baseLan = {
        name: _defaultNameForMode(),
        players: 10,
        blind: 10,
        stack: 3000,
        timeout: 20,
        raiseEvery: 8,
        guiSpeed: 4,
        delayHands: 7,
        bots: true,
        minHumans: 2,
        tag: 'lan',
      };
      return skipSaved ? withAdmin(baseLan) : withSaved(withPrefs(withAdmin(baseLan)));
    },

    // Apply the per-mode defaults to the create-form inputs. We only
    // overwrite empty fields (or fields still holding the previous mode's
    // default) so a user who already typed a custom value isn't surprised
    // by their input being clobbered.
    // Le nom mémorisé peut être celui d'une table encore ouverte, et le serveur
    // refuse un nom déjà pris (gameNameInUse). Plutôt que de laisser le joueur
    // se prendre le refus, on décale le nom tant qu'il est visible dans le
    // lobby : « Chez Bob » → « Chez Bob 2 ». C'est ce qui permet de mémoriser
    // le nom sans réintroduire l'ennui qu'on cherchait à éviter.
    //
    // Purement local : on ne consulte que la liste déjà reçue. Si elle n'est
    // pas encore chargée, on n'invente rien — le refus reste possible, mais il
    // est visible depuis que setStatus le double d'un toast.
    _freeGameName(name) {
      var base = String(name == null ? '' : name).trim();
      if (!base) return base;
      var taken = {};
      try {
        var g = (window.S && window.S.games) || {};
        for (var k in g) { if (g[k] && g[k].name) taken[String(g[k].name).trim().toLowerCase()] = true; }
      } catch (e) { return base; }
      if (!taken[base.toLowerCase()]) return base;
      // 48 caractères = maximumLength du champ QML ; on garde la place du suffixe.
      var stem = base.slice(0, 44);
      for (var n = 2; n <= 99; n++) {
        var cand = stem + ' ' + n;
        if (!taken[cand.toLowerCase()]) return cand;
      }
      return base;
    },
    _applyCreateFormDefaults(force, skipSaved) {
      var d = this._getCreateDefaults(skipSaved);
      var set = function(id, val, options) {
        var el = document.getElementById(id);
        if (!el) return;
        var isCheckbox = el.type === 'checkbox';
        var current = isCheckbox ? el.checked : el.value;
        var defaultMarker = el.dataset.modeDefault; // last value we wrote ourselves
        // Don't overwrite if the user typed something different from our
        // previous default. Force=true (form just opened) always rewrites.
        if (!force && defaultMarker !== undefined && current !== defaultMarker) return;
        if (isCheckbox) {
          el.checked = !!val;
        } else {
          el.value = val;
          el.dispatchEvent(new Event('input'));
        }
        el.dataset.modeDefault = isCheckbox ? (!!val) : String(val);
      };
      set('cf-name',        this._freeGameName(d.name));
      set('cf-players',     d.players);
      set('cf-blind',       d.blind);
      set('cf-stack',       d.stack);
      set('cf-timeout',     d.timeout);
      set('cf-raise-every', d.raiseEvery);
      set('cf-gui-speed',   d.guiSpeed);
      set('cf-delay',       d.delayHands);
      // Advanced options: only present in `d` when restored from a saved
      // session (withSaved copies them in). Apply them when available so the
      // "More options" panel also reflects the last-used config.
      if (d.raiseMode     != null) set('cf-raise-mode',   d.raiseMode);
      if (d.endRaiseMode  != null) set('cf-end-raise',    d.endRaiseMode);
      if (d.endRaiseValue != null) set('cf-end-raise-val',d.endRaiseValue);
      // Ordre manuel des blindes : restaurer liste + flag, puis resynchroniser
      // toute l'UI (radios auto/manuel, pastilles, radios « Ensuite »).
      if (d.manualBlinds  != null) set('cf-manual-blinds', d.manualBlinds);
      this._syncBlindsOrderUI(d.manualOrder != null ? !!d.manualOrder : null);
      if (d.gameType      != null) set('cf-game-type',    d.gameType);
      if (d.allowSpectators != null) {
        var asEl = document.getElementById('cf-allow-spectators');
        if (asEl) {
          if (asEl.type === 'checkbox') asEl.checked = !!d.allowSpectators;
          else asEl.value = d.allowSpectators ? '1' : '0';
        }
      }
      // Bornes QML : re-clampe les valeurs restaurées depuis une sauvegarde
      // antérieure aux nouvelles bornes (ex. délai 3 < min 5).
      var _dl = document.getElementById('cf-delay'); if (_dl) this.clampNum(_dl);
      // Same for the QuickGame dialog default
      var qc = document.getElementById('qc-players');
      if (qc) {
        var qcCurrent = qc.value;
        var qcMarker = qc.dataset.modeDefault;
        if (force || qcMarker === undefined || qcCurrent === qcMarker) {
          // narmod wants 10 max players by default everywhere, so the
          // quick-game dialog mirrors d.players (the per-mode default).
          qc.value = d.players;
          qc.dataset.modeDefault = qc.value;
        }
      }
      // Bot difficulty is only meaningful in Training (offline) mode — show the
      // pills there and highlight the saved choice.
      var skRow = document.getElementById('cf-skill-row');
      if (skRow) {
        skRow.style.display = window._offlineMode ? '' : 'none';
        if (window._offlineMode && this.setBotSkill) {
          var _sk = 'mixed';
          try { _sk = localStorage.getItem('pth_offline_skill') || 'mixed'; } catch (e) {}
          this.setBotSkill(_sk);
        }
      }
    },

    toggleCreateForm() {
      // Conservé pour compat (intent PWA ?go=create) : ouvre la page dédiée.
      this.openCreatePage();
    },
    // Ouvre l'écran dédié « Créer une partie ». Le formulaire existant
    // (#create-form, tous ses champs/handlers) est déplacé une seule fois dans
    // la page, ce qui préserve toute la logique de createGame().
    openCreatePage(opts) {
      // Parité officielle ShowGameSettingsDialogOnNewGame (startwindowimpl.cpp,
      // callNewGameDialog) : en mode entraînement, si l'option « afficher les
      // réglages à chaque nouvelle partie » est décochée, on saute l'écran de
      // création et on démarre immédiatement avec les derniers réglages
      // sauvegardés (« sonst mit gespeicherten Werten starten »), bots inclus
      // via le hook _offlineAutoReplay → startWithBots() au JoinGameAck.
      if (window._offlineMode && !_advGet('create_dialog', true)) {
        try {
          this._applyCreateFormDefaults(true);   // baseline + derniers réglages utilisés
          window._offlineAutoReplay = true;
          this.createGame();
          return;
        } catch (e) { window._offlineAutoReplay = false; }
      }
      var form = document.getElementById('create-form');
      var body = document.getElementById('create-page-body');
      if (form && body && form.parentNode !== body) body.appendChild(form);
      if (form) { form.style.display = 'block'; form.classList.add('open'); }
      this._rankSnap = null;      // jamais de restauration trans-session
      this._vorlageSnap = null;   // idem pour le modèle communautaire (non persisté, comme le QML)
      try { var _vs = document.getElementById('cf-vorlage'); if (_vs) _vs.value = '0'; } catch (e) {}
      // Précharger les titres communautaires (parité upstream 0640366) : le
      // titre mensuel est alors déjà en cache au choix d'une vorlage Monthly
      // Cup, au lieu d'arriver après un éventuel clic rapide sur « Créer ».
      try {
        if (_advGet('community_content', true) && window._botSuggest && window._botSuggest.prefetchGameTitles)
          window._botSuggest.prefetchGameTitles();
      } catch (e) {}
      try { this._applyCreateFormDefaults(false); } catch (e) {}
      // Pastille « Perso » (charger mes préférences) : visible seulement si
      // des préférences existent pour le MODE COURANT (pastille 💾 ou Options
      // avancées), avec l'ancien pth_create_prefs en repli.
      try { var _pp = document.getElementById('cf-preset-perso'); if (_pp) _pp.style.display = this.hasCreatePrefs() ? '' : 'none'; } catch (e) {}
      // Bloc « Style de partie » (réglages rapides) : développé par défaut en
      // entraînement et en LAN, replié sur Internet (pokerth.net) — demande
      // Arnaud web.288 ; l'état choisi par le joueur est mémorisé PAR MODE.
      try { var _so = localStorage.getItem(this._styleGridKey()); this.toggleStyleGrid(_so == null ? this._styleGridMode() !== 'net' : _so === '1', true); } catch (e) {}
      // Mode entraînement : le style de partie mémorisé (« normal » par
      // défaut) est présélectionné à l'ouverture — valeurs ET surbrillance,
      // comme le niveau de bots (mixte) juste au-dessus.
      try {
        if (window._offlineMode) {
          var _st = 'normal';
          try { _st = localStorage.getItem('pth_create_style') || 'normal'; } catch (e) {}
          if (!/^(tranquille|normal|rapide|ranking|wecup|bbc)$/.test(_st)) _st = 'normal';
          this.applyPreset(_st);
        }
      } catch (e) {}
      // Invité pokerth.net : seule la création de parties « Normal » est
      // permise par le serveur — type forcé à 1, ligne visible mais
      // désactivée (parité QML enabled: !isGuest), nom imposé par
      // _syncGameTypeConstraints. Les verrous classé/mot de passe sont
      // resynchronisés dans la foulée.
      try {
        var _gtr = document.getElementById('cf-gtype-row');
        if (_gtr) _gtr.style.display = '';
        if (S._currentLoginMode === 'guest') { var _gts = document.getElementById('cf-game-type'); if (_gts) _gts.value = '1'; }
        if (window._gtypeDdRefresh) window._gtypeDdRefresh();
        this._syncGameTypeConstraints();
      } catch (e) {}
      // Aide de l'As (modules/guide) : openCreatePage({ ranking: true }) ouvre
      // la création sur une table classée avec le preset Ranking (format 5/5)
      // — jamais pour un invité (le serveur refuse ranking aux invités).
      try {
        if (opts && opts.ranking && S._currentLoginMode !== 'guest') {
          var _gt4 = document.getElementById('cf-game-type');
          if (_gt4) { _gt4.value = '4'; if (window._gtypeDdRefresh) window._gtypeDdRefresh(); this._syncGameTypeConstraints(); }
          this.applyPreset('ranking', document.querySelector('.cf-preset[data-preset="ranking"]'));
        }
      } catch (e) {}
      show('s-create');
    },
    closeCreatePage() {
      // Mode entraînement : la page de création EST l'écran d'accueil après
      // connexion (pas de lobby offline) → Annuler/Retour ramène au login
      // via la déconnexion propre existante (teardown du FakeServer inclus).
      if (window._offlineMode) { this.disconnect(); return; }
      show('s-lobby');
    },
    // Mode du formulaire pour le bloc « Style de partie » : 'local'
    // (entraînement), 'lan' ou 'net' (pokerth.net, compte ou invité).
    _styleGridMode() {
      if (window._offlineMode) return 'local';
      var m = S._currentLoginMode || 'lan';
      return (m === 'guest' || m === 'auth') ? 'net' : 'lan';
    },
    _styleGridKey() { return 'pth_create_style_open_' + this._styleGridMode(); },
    // Développer / réduire les pastilles de style de partie (la barre « Perso »
    // reste toujours visible). État persisté par mode (web.288) ; par défaut
    // développé en entraînement / LAN, replié sur Internet. `auto` : appliqué
    // à l'ouverture de la page, pas un choix du joueur (rien n'est mémorisé).
    toggleStyleGrid(force, auto) {
      var g = document.getElementById('cf-style-grid'), b = document.getElementById('cf-style-toggle');
      if (!g) return;
      var open = (force != null) ? !!force : (g.style.display === 'none');
      g.style.display = open ? '' : 'none';
      if (b) {
        b.setAttribute('aria-expanded', open ? 'true' : 'false');
        var tx = b.querySelector('.cfs-tx');
        if (tx) { tx.setAttribute('data-i18n', open ? 'styleCollapse' : 'styleExpand'); tx.textContent = t(open ? 'styleCollapse' : 'styleExpand'); }
        var ar = b.querySelector('.cfs-arr');
        if (ar) ar.textContent = open ? '\u25b4' : '\u25be';
      }
      if (!auto) { try { localStorage.setItem(this._styleGridKey(), open ? '1' : '0'); } catch (e) {} }
      // Aide de l'As : la visite du formulaire suit (texte « replié » / « développé »)
      try { if (typeof window._guideRefresh === 'function') window._guideRefresh(); } catch (e) {}
    },
    // Stepper +/- (page « Créer une partie ») : incrémente/décrémente un champ
    // numérique selon son step/min/max. Réutilise les IDs existants.
    stepField(id, dir) {
      var el = document.getElementById(id); if (!el) return;
      var step = parseInt(el.step, 10) || 1;
      var min = (el.min !== '' && el.min != null) ? parseInt(el.min, 10) : -Infinity;
      var max = (el.max !== '' && el.max != null) ? parseInt(el.max, 10) :  Infinity;
      var v = (parseInt(el.value, 10) || 0) + dir * step;
      v = Math.max(min, Math.min(max, v));
      el.value = v;
    },
    // Intervalle de hausse des blindes : le radio mains/minutes pilote le champ
    // caché cf-raise-mode (1 = mains, 2 = minutes) lu par createGame().
    setRaiseMode(n) {
      var el = document.getElementById('cf-raise-mode'); if (el) el.value = n;
    },
    // ── Ordre manuel des blindes (parité QML LocalGameSettings/NetworkGameSettings) ──
    // La liste vit dans le champ caché cf-manual-blinds (CSV trié croissant) : c'est
    // la source lue par createGame(), _readCreateForm() et le rendu des pastilles.
    // Sémantique officielle (netpacket.cpp) : mode manuel = liste non vide dans
    // NetGameInfo champ 14 ; « Ensuite » (cf-end-raise 1/2/3) = APRÈS épuisement.
    _getManualBlinds() {
      var el = document.getElementById('cf-manual-blinds');
      if (!el || !el.value) return [];
      return el.value.split(',').map(function(s){ return parseInt(s, 10); })
        .filter(function(n){ return !isNaN(n) && n > 0; });
    },
    _setManualBlinds(arr) {
      arr = (arr || []).filter(function(n){ return Number.isInteger(n) && n > 0; });
      arr.sort(function(a, b){ return a - b; });
      // Dédoublonnage (le QML refuse les doublons dans addBlind)
      arr = arr.filter(function(n, i){ return arr.indexOf(n) === i; });
      var el = document.getElementById('cf-manual-blinds');
      if (el) el.value = arr.join(',');
      this._renderManualBlinds();
      return arr;
    },
    _renderManualBlinds() {
      var box = document.getElementById('cf-mb-list'); if (!box) return;
      var list = this._getManualBlinds();
      var h = '';
      for (var i = 0; i < list.length; i++) {
        h += '<button type="button" class="cf-preset" title="' + (t('blindsRemoveTip') || 'Remove') + '"'
           + ' onclick="App.removeManualBlind(' + list[i] + ')">'
           + '<span class="cfp-n">$' + list[i] + ' \u00d7</span></button>';
      }
      box.innerHTML = h;
      box.style.display = list.length ? '' : 'none';
    },
    setManualBlindsMode(on) {
      var ed = document.getElementById('cf-mb-editor');
      if (ed) ed.style.display = on ? '' : 'none';
      var r = document.getElementById(on ? 'cf-mb1' : 'cf-mb0'); if (r) r.checked = true;
      if (on) this._renderManualBlinds();
    },
    addManualBlind() {
      var inp = document.getElementById('cf-mb-val');
      var v = inp ? parseInt(inp.value, 10) : NaN;
      if (isNaN(v) || v <= 0) return;
      // Bornes du serveur (netpacketvalidator ValidateGameInfo) : 30 niveaux
      // au plus, valeurs ≤ 1 000 000 — au-delà, il ferme la session.
      var L = (window._createPresets && window._createPresets.LIMITS) || {};
      var maxN = (L.manualBlinds && L.manualBlinds.max) || 30, maxV = (L.blindValue && L.blindValue.max) || 1000000;
      if (v > maxV) v = maxV;
      var list = this._getManualBlinds();
      if (list.length >= maxN && list.indexOf(v) < 0) return;
      list.push(v);
      list = this._setManualBlinds(list);
      // Confort : pré-remplir la prochaine valeur (double de la dernière),
      // comme point de départ raisonnable pour une structure de tournoi.
      if (inp && list.length) inp.value = Math.min(maxV, list[list.length - 1] * 2);
    },
    removeManualBlind(v) {
      this._setManualBlinds(this._getManualBlinds().filter(function(n){ return n !== v; }));
    },
    // « Ensuite : » — pilote le champ caché cf-end-raise (endRaiseMode 1/2/3,
    // NetGameInfo champ 7) ; le stepper de valeur n'apparaît qu'en mode 2.
    setAfterMB(mode) {
      var el = document.getElementById('cf-end-raise'); if (el) el.value = String(mode);
      var st = document.getElementById('cf-amb2-step'); if (st) st.style.display = (mode === 2) ? '' : 'none';
      var r = document.getElementById('cf-amb' + mode); if (r) r.checked = true;
    },
    // Resynchronise l'UI « ordre des blindes » depuis les champs cachés
    // (cf-manual-blinds, cf-end-raise) après une écriture programmatique
    // (defaults, préférences, reset). manualOn : true/false = imposé,
    // null = déduit (mode manuel si le radio l'était déjà OU liste non vide).
    _syncBlindsOrderUI(manualOn) {
      if (manualOn == null) {
        var r1 = document.getElementById('cf-mb1');
        manualOn = (r1 && r1.checked) || this._getManualBlinds().length > 0;
      }
      this.setManualBlindsMode(!!manualOn);
      var m = parseInt((document.getElementById('cf-end-raise') || {}).value, 10);
      this.setAfterMB(m >= 1 && m <= 3 ? m : 1);
    },
    // Quick-style presets: fill the create-form numeric fields in one tap.
    // The full form stays fully editable afterwards — presets are just a
    // friendly starting point (kid-friendly: Relaxed / Normal / Fast).
    // Difficulty pills (Training mode): persist the choice and highlight it.
    setBotSkill(v, btn) {
      try { localStorage.setItem('pth_offline_skill', v); } catch (e) {}
      var all = document.querySelectorAll('#cf-skill-pills .cf-preset');
      for (var i = 0; i < all.length; i++) all[i].classList.remove('active');
      var sel = btn || document.querySelector('#cf-skill-pills .cf-preset[data-skill="' + v + '"]');
      if (sel) sel.classList.add('active');
    },

    // ── Vorlagen communautaires ─────────────────────────────────────────
    // Réglages officiels des tournois pokerth.net. Visibles seulement pour
    // « Joueurs invités uniquement » ; remplissent ET verrouillent le
    // formulaire — SAUF le nom : pré-rempli mais éditable (suffixe d'heure
    // possible, ex. « BBC Step 1 23:15 ») ; « Paramètres personnalisés »
    // restaure les valeurs d'avant. Les BBC Steps imposent une liste fixe de 30 paliers
    // de blinds (hausse au temps, toutes les 5 min) ; MC/WEC doublent après
    // N mains. delayBetweenHands = 7 pour toutes (comme le QML).
    //
    // La TABLE elle-même vit dans modules/ui/botsuggest.mjs : depuis l'amont
    // 422f5fe4 elle sert aussi d'empreinte pour reconnaître le type d'un tapis
    // qu'on n'a pas créé, et deux copies divergeraient au premier ajout de
    // vorlage. Elle est lue à l'usage (le module est chargé en <script
    // type="module"> et applyVorlage() ne tourne que sur action de
    // l'utilisateur, donc bien après) ; repli sur liste vide, qui rend
    // simplement le combo inopérant au lieu de jeter.
    get _communityVorlagen() {
      try { return (window._botSuggest && window._botSuggest.presets) || []; }
      catch (e) { return []; }
    },
    // Handler du combo « Modèle communautaire ». idx 0 = Paramètres
    // personnalisés (restauration) ; 1..9 = vorlage (remplit + verrouille).
    applyVorlage() {
      var g = function(id){ return document.getElementById(id); };
      var sel = g('cf-vorlage'); if (!sel) return;
      var idx = parseInt(sel.value, 10) || 0;
      var setv = function(id, v){ var e = g(id); if (e) { e.value = v; e.dispatchEvent(new Event('input')); } };
      if (idx <= 0 || !this._communityVorlagen[idx - 1]) {
        this._restoreVorlage();
        this._syncGameTypeConstraints();
        return;
      }
      // Snapshot des valeurs d'avant la première vorlage (une seule fois,
      // comme le verrou classé) — restauré par « Paramètres personnalisés »
      // ou en quittant le type invitation.
      if (!this._vorlageSnap) {
        this._vorlageSnap = {
          name:       g('cf-name')        ? g('cf-name').value        : '',
          players:    g('cf-players')     ? g('cf-players').value     : 10,
          stack:      g('cf-stack')       ? g('cf-stack').value       : 3000,
          blind:      g('cf-blind')       ? g('cf-blind').value       : 10,
          raiseEvery: g('cf-raise-every') ? g('cf-raise-every').value : 8,
          raiseMode:  (g('cf-rm2') && g('cf-rm2').checked) ? 2 : 1,
          timeout:    g('cf-timeout')     ? g('cf-timeout').value     : 20,
          delay:      g('cf-delay')       ? g('cf-delay').value       : 7,
          manual:     !!(g('cf-mb1') && g('cf-mb1').checked),
          manualStr:  g('cf-manual-blinds') ? g('cf-manual-blinds').value : ''
        };
      }
      var p = this._communityVorlagen[idx - 1];
      this._activeVorlage = p;
      var nm = g('cf-name'); if (nm) nm.value = p.name;
      // Vorlagen au nom mensuel (Monthly Cup) : tirer le préfixe de titre
      // courant de gameslist.txt (« August Cup Final ») et — si l'utilisateur
      // n'a pas édité le nom de repli et que la même vorlage est toujours
      // choisie — le substituer. Asynchrone ; en cas d'échec p.name reste
      // (parité QML LobbyCreateGamePage applyPreset).
      if (p.titleCommand && window._botSuggest && window._botSuggest.gameTitlePrefix) {
        var _fallbackName = p.name, _self = this;
        try {
          window._botSuggest.gameTitlePrefix(p.titleCommand, function (title) {
            var _nm2 = g('cf-name');
            if (title && title.length > 0 && _self._activeVorlage === p
                && _nm2 && _nm2.value === _fallbackName) _nm2.value = title;
          });
        } catch (e) {}
      }
      var ne = g('cf-name-err'); if (ne) ne.style.display = 'none';
      setv('cf-players', 10);
      setv('cf-stack',   p.startCash);
      setv('cf-blind',   p.firstSmallBlind);
      var rmode = p.raiseOnHands ? 1 : 2;
      this.setRaiseMode(rmode);
      var rr = g(rmode === 2 ? 'cf-rm2' : 'cf-rm1'); if (rr) rr.checked = true;
      setv('cf-raise-every', p.raiseOnHands ? p.raiseEveryHands : p.raiseEveryMinutes);
      setv('cf-timeout', p.playerActionTimeout);
      setv('cf-delay',   (window._createPresets && window._createPresets.TEMPLATE_DELAY) || 7);   // toutes les vorlagen : DelayBetweenHands = 7
      if (p.blinds.length) {
        this._setManualBlinds(p.blinds.slice());
        this.setManualBlindsMode(true);
      } else {
        setv('cf-manual-blinds', '');
        this.setManualBlindsMode(false);
        this._renderManualBlinds();
      }
      this._syncGameTypeConstraints();
    },
    // Restauration des valeurs d'avant vorlage (sans resynchroniser — les
    // appelants s'en chargent pour éviter toute récursion).
    _restoreVorlage() {
      this._activeVorlage = null;
      if (!this._vorlageSnap) return;
      var g = function(id){ return document.getElementById(id); };
      var setv = function(id, v){ var e = g(id); if (e) { e.value = v; e.dispatchEvent(new Event('input')); } };
      var snap = this._vorlageSnap; this._vorlageSnap = null;
      var nm = g('cf-name'); if (nm) nm.value = snap.name;
      setv('cf-players', snap.players); setv('cf-stack', snap.stack);
      setv('cf-blind', snap.blind); setv('cf-raise-every', snap.raiseEvery);
      this.setRaiseMode(snap.raiseMode);
      var rr = g(snap.raiseMode === 2 ? 'cf-rm2' : 'cf-rm1'); if (rr) rr.checked = true;
      setv('cf-timeout', snap.timeout); setv('cf-delay', snap.delay);
      setv('cf-manual-blinds', snap.manualStr);
      this.setManualBlindsMode(snap.manual);
      this._renderManualBlinds();
    },
    // ── Parité QML LobbyCreateGamePage (2.1.3) : contraintes selon le type ──
    // passwordAllowed = Normal/Enregistrés seulement ; « Partie classée »
    // verrouille et force les constantes serveur (RANKING_GAME_*) ; invité =
    // nom imposé « Partie de %1 » + type figé (ligne visible mais désactivée,
    // comme le QML). Le mécanisme de sauvegarde (pastilles de style, 💾,
    // réinitialisation) n'est PAS modifié : le verrou n'agit que tant que le
    // type classé est sélectionné, avec restauration des valeurs à la sortie.
    _syncGameTypeConstraints() {
      var g = function(id){ return document.getElementById(id); };
      var sel = g('cf-game-type'); if (!sel) return;
      var isGuest = (S._currentLoginMode === 'guest');
      var type = parseInt(sel.value, 10) || 1;
      var isRanking = (type === 4);
      var isInvite  = (type === 3);
      var pwAllowed = (type === 1 || type === 2);
      // Modèle communautaire : visible seulement en invitation (parité QML) ;
      // quitter le type invitation remet la vorlage à zéro et restaure.
      var vSel = g('cf-vorlage');
      var vRow = g('cf-vorlage-row');
      var communityOn = _advGet('community_content', true);
      if (vRow) vRow.style.display = (isInvite && communityOn) ? '' : 'none';
      if (vSel && (!isInvite || !communityOn) && (parseInt(vSel.value, 10) || 0) > 0) {
        vSel.value = '0';
        this._restoreVorlage();
      }
      var vorlageActive = !!(isInvite && communityOn && vSel && (parseInt(vSel.value, 10) || 0) > 0);
      // fieldsLocked (parité QML) : classé OU vorlage active.
      var fieldsLocked = isRanking || vorlageActive;
      var lockRow = function(id, lock) {
        var el = g(id); if (!el) return;
        var row = el.closest('.cf-row') || el.parentNode;
        if (row) row.classList.toggle('cf-locked', !!lock);
        if ('disabled' in el) el.disabled = !!lock;
      };
      // Mot de passe : interdit en classé (serveur) et en invitation (accès
      // via l'invitation) — décoché automatiquement, comme applyGameType().
      var pwT = g('cf-use-password');
      if (pwT) {
        if (!pwAllowed && pwT.checked) pwT.checked = false;
        lockRow('cf-use-password', !pwAllowed);
        var pwRow = g('cf-password-row');
        if (pwRow) pwRow.style.display = (pwAllowed && pwT.checked) ? 'flex' : 'none';
      }
      // Invité : nom imposé (nom admin du mode s'il existe, sinon la
      // convention QML « %1's game ») + champ nom et choix du type désactivés.
      var nameEl = g('cf-name');
      if (nameEl) {
        // Vorlage : le nom est PRÉ-REMPLI (applyVorlage) mais reste ÉDITABLE —
        // divergence assumée vs QML (qui verrouille) : on veut pouvoir suffixer
        // « BBC Step 1 » en « BBC Step 1 23:15 » (demande narmod 2026-07-17).
        nameEl.disabled = isGuest;
        if (isGuest) {
          var tpl = (typeof t === 'function' && t('guestGameName') !== 'guestGameName')
            ? t('guestGameName') : "{name}'s game";
          nameEl.value = _adminNameForMode() || tpl.replace('{name}', S.myName || 'PokerTH');
        }
      }
      var ddBtn = g('cf-gtype-btn'); if (ddBtn) ddBtn.disabled = isGuest;
      // Classé : snapshot des valeurs courantes puis forçage des constantes
      // serveur ; restauration à la sortie du type classé.
      var setv = function(id, v){ var e = g(id); if (e) { e.value = v; e.dispatchEvent(new Event('input')); } };
      if (isRanking && !this._rankSnap) {
        this._rankSnap = {
          players:    g('cf-players')     ? g('cf-players').value     : 10,
          stack:      g('cf-stack')       ? g('cf-stack').value       : 3000,
          blind:      g('cf-blind')       ? g('cf-blind').value       : 10,
          raiseEvery: g('cf-raise-every') ? g('cf-raise-every').value : 8,
          raiseMode:  (g('cf-rm2') && g('cf-rm2').checked) ? 2 : 1,
          spect:      g('cf-allow-spectators') ? g('cf-allow-spectators').checked : true,
          manual:     !!(g('cf-mb1') && g('cf-mb1').checked)
        };
        setv('cf-players', 10); setv('cf-stack', 10000); setv('cf-blind', 50); setv('cf-raise-every', 11);
        this.setRaiseMode(1); var r1 = g('cf-rm1'); if (r1) r1.checked = true;
        var sp = g('cf-allow-spectators'); if (sp) sp.checked = true;
        var mb0 = g('cf-mb0'); if (mb0) mb0.checked = true;
        this.setManualBlindsMode(false);
      } else if (!isRanking && this._rankSnap) {
        var snap = this._rankSnap; this._rankSnap = null;
        setv('cf-players', snap.players); setv('cf-stack', snap.stack);
        setv('cf-blind', snap.blind); setv('cf-raise-every', snap.raiseEvery);
        this.setRaiseMode(snap.raiseMode);
        var rr = g(snap.raiseMode === 2 ? 'cf-rm2' : 'cf-rm1'); if (rr) rr.checked = true;
        var sp2 = g('cf-allow-spectators'); if (sp2) sp2.checked = snap.spect;
        var mbr = g(snap.manual ? 'cf-mb1' : 'cf-mb0'); if (mbr) mbr.checked = true;
        this.setManualBlindsMode(snap.manual);
      }
      ['cf-players','cf-stack','cf-blind'].forEach(function(id){ lockRow(id, fieldsLocked); });
      // Spectateurs : verrouillés par le classé seulement (QML enabled: !isRanking).
      lockRow('cf-allow-spectators', isRanking);
      var rm1 = g('cf-rm1');
      if (rm1) { var rmRow = rm1.closest('.cf-row-col'); if (rmRow) rmRow.classList.toggle('cf-locked', fieldsLocked); }
      var mb0b = g('cf-mb0');
      if (mb0b) { var mbRow = mb0b.closest('.cf-row-col'); if (mbRow) mbRow.classList.toggle('cf-locked', fieldsLocked); }
      // Timeout et délai entre mains : imposés par la vorlage seulement
      // (QML enabled: !presetActive — le classé les laisse libres).
      lockRow('cf-timeout', vorlageActive);
      lockRow('cf-delay',   vorlageActive);
      // Pastilles de STYLE (data-preset) : inertes tant que le classé ou une
      // vorlage force les valeurs — SAUF « Perso » (⭐), qui reste utilisable :
      // elle charge aussi le nom, le timeout et le délai, libres même en
      // classé, et re-applique le type — les contraintes se resynchronisent
      // derrière. La désactiver en classé enfermait le joueur dont les
      // préférences SONT une partie classée (rapport forum : « the My prefs
      // button doesn't work when Ranking game is selected »).
      var pills = document.querySelectorAll('.cf-preset[data-preset]');
      for (var i = 0; i < pills.length; i++) {
        var lockThis = fieldsLocked && pills[i].getAttribute('data-preset') !== 'perso';
        pills[i].disabled = lockThis;
        pills[i].classList.toggle('cf-locked', lockThis);
      }
    },
    applyPreset(name, btn) {
      // Rythme seulement : les styles ne touchent pas au nombre de joueurs
      // (choix indépendant du tempo, demande d'Arnaud v0.3.515).
      // Structures alignées sur les formats réellement joués (v0.3.516) :
      //   Tranquille = deepstack lent (250 BB, blindes qui montent peu)
      //   Normal     = défauts du client PokerTH desktop (150 BB, hausse/8 mains)
      //   Rapide     = turbo (30 BB, blindes rapides, timer court)
      // raiseEvery est en MAINS : le preset rebascule l'intervalle sur « mains ».
      // Formats pokerth.net alignés sur la source QML 2.1.3 (v0.3.685) —
      // vorlagen communityPresets extraites de LobbyCreateGamePage :
      //   Ranking = constantes serveur des parties classées (10k / SB 50 /
      //             double toutes les 11 mains) + 5 s — hyper-turbo assumé.
      //   WeCup   = format WEC officiel (double/22 mains, 12 s, délai 7 s).
      //   BBC     = BBC Step 3 officiel (5000 / SB 25, hausse AU TEMPS
      //             toutes les 5 min, 10 s, délai 7 s).
      // raiseMode : 1 = mains (défaut), 2 = minutes.
      // Valeurs : modules/create-presets.mjs (STYLES), source partagée avec
      // les réglages de table du directeur de tournoi.
      var v = (window._createPresets && window._createPresets.style(name)) || null;
      if (!v) return;
      var set = function(id, val){ var e = document.getElementById(id); if (e) { e.value = val; e.dispatchEvent(new Event('input')); } };
      set('cf-stack',       v.stack);
      set('cf-blind',       v.blind);
      set('cf-timeout',     v.timeout);
      set('cf-raise-every', v.raiseEvery);
      set('cf-delay',       v.delay);
      // Cohérence : chaque preset fixe aussi l'unité de hausse (mains par
      // défaut, minutes pour BBC) → champ caché + radio.
      var rmode = v.raiseMode || 1;
      this.setRaiseMode(rmode);
      var rmEl = document.getElementById(rmode === 2 ? 'cf-rm2' : 'cf-rm1'); if (rmEl) rmEl.checked = true;
      // Seules les pastilles de STYLE (data-preset) sont concernées — surtout
      // pas celles de difficulté des bots (data-skill), sinon leur
      // présélection disparaît à chaque choix de style.
      var all = document.querySelectorAll('.cf-preset[data-preset]');
      for (var i = 0; i < all.length; i++) all[i].classList.remove('active');
      var sel = btn || document.querySelector('.cf-preset[data-preset="' + name + '"]');
      if (sel) sel.classList.add('active');
      // Mémoriser le dernier style choisi (présélectionné à la prochaine
      // ouverture en mode entraînement ; « normal » par défaut).
      try { localStorage.setItem('pth_create_style', name); } catch (e) {}
    },
    // ── Synchronisation curseur ↔ champ chiffré éditable ──
    // Le champ chiffré (id cf-players / cf-stack) est la valeur lue par
    // createGame ; le curseur (…-range) le pilote et inversement.
    numFromRange(numId, rangeEl) {
      var n = document.getElementById(numId);
      if (n) n.value = rangeEl.value;
    },
    rangeFromNum(rangeId, numEl) {
      var r = document.getElementById(rangeId);
      if (!r) return;
      var v = parseInt(numEl.value, 10);
      if (!isNaN(v)) r.value = v;   // le curseur borne tout seul l'affichage
    },
    clampNum(el) {
      var v = parseInt(el.value, 10);
      var mn = parseInt(el.min, 10), mx = parseInt(el.max, 10);
      if (isNaN(v)) v = isNaN(mn) ? 0 : mn;
      if (!isNaN(mn) && v < mn) v = mn;
      if (!isNaN(mx) && v > mx) v = mx;
      el.value = v;
    },
    toggleMoreOptions() {
      var el = document.getElementById('cf-more-opts');
      var arrow = document.getElementById('cf-more-arrow');
      var lbl = document.getElementById('cf-more-label');
      if (!el) return;
      var open = el.style.display === 'none';
      el.style.display = open ? '' : 'none';
      if (arrow) arrow.textContent = open ? '▼' : '▶';
      if (lbl) lbl.textContent = open ? (t('lessOptions')||'Less options') : (t('moreOptions')||'More options');
    },
    // ── Préférences personnelles de création, PAR MODE depuis la passe G :
    //    trois emplacements pth_prefs_local / pth_prefs_lan / pth_prefs_internet
    //    (parité QML LocalGameSettings / NetworkGameSettings / InternetGameSettings),
    //    également éditables champ par champ dans les Options avancées.
    //    saveCreatePrefs (pastille 💾) fige TOUT le formulaire dans l'emplacement
    //    du mode courant ; applyCreatePrefs (pastille ⭐ Perso) le réinjecte.
    //    L'ancien instantané unique pth_create_prefs reste un repli en lecture. ──
    _createPrefsKey() {
      if (window._offlineMode) return 'pth_prefs_local';
      var m = S._currentLoginMode || 'lan';
      return (m === 'guest' || m === 'auth') ? 'pth_prefs_internet' : 'pth_prefs_lan';
    },
    _readCreatePrefsRaw() {
      var d = null;
      try { d = JSON.parse(localStorage.getItem(this._createPrefsKey()) || 'null'); } catch (e) {}
      if (!d) { try { d = JSON.parse(localStorage.getItem('pth_create_prefs') || 'null'); } catch (e) {} }
      return (d && typeof d === 'object') ? d : null;
    },
    _readCreateForm() {
      var g = function(id){ return document.getElementById(id); };
      var iv = function(id, def){ var e = g(id); var v = e ? parseInt(e.value, 10) : NaN; return isNaN(v) ? def : v; };
      var svv = function(id, def){ var e = g(id); return (e && e.value != null && e.value !== '') ? e.value : def; };
      return {
        name:            (g('cf-name') ? g('cf-name').value : '').trim(),
        players:         iv('cf-players', 10),
        blind:           iv('cf-blind', 10),
        stack:           iv('cf-stack', 3000),
        timeout:         iv('cf-timeout', 15),
        raiseMode:       svv('cf-raise-mode', '1'),
        raiseEvery:      iv('cf-raise-every', 7),
        endRaiseMode:    svv('cf-end-raise', '1'),
        endRaiseValue:   iv('cf-end-raise-val', 200),
        manualOrder:     !!(g('cf-mb1') && g('cf-mb1').checked),
        manualBlinds:    svv('cf-manual-blinds', ''),
        guiSpeed:        iv('cf-gui-speed', 5),
        delayHands:      iv('cf-delay', 7),
        gameType:        svv('cf-game-type', '1'),
        allowSpectators: (function(){ var e = g('cf-allow-spectators'); if (!e) return true; return e.type === 'checkbox' ? e.checked : e.value !== '0'; })(),
        usePassword:     !!(g('cf-use-password') && g('cf-use-password').checked),
        password:        (g('cf-use-password') && g('cf-use-password').checked && g('cf-password')) ? g('cf-password').value : '',
      };
    },
    saveCreatePrefs() {
      try { localStorage.setItem(this._createPrefsKey(), JSON.stringify(this._readCreateForm())); } catch (e) {}
      try { _cfgSyncMark('create_prefs'); } catch (e) {}
      try { var _pp = document.getElementById('cf-preset-perso'); if (_pp) _pp.style.display = ''; } catch (e) {}
      if (typeof showToast === 'function') showToast(t('createPrefsSaved') || 'Preferences saved');
    },
    hasCreatePrefs() {
      try { return !!(localStorage.getItem(this._createPrefsKey()) || localStorage.getItem('pth_create_prefs')); } catch (e) { return false; }
    },
    applyCreatePrefs(btn) {
      var d = this._readCreatePrefsRaw();
      if (!d) {
        if (typeof showToast === 'function') showToast(t('createPrefsNone') || 'No saved preferences yet', { tone: 'error' });
        return;
      }
      var set = function(id, val){ var e = document.getElementById(id); if (e == null || val == null) return; e.value = val; e.dispatchEvent(new Event('input')); };
      if (d.name) set('cf-name', d.name);
      set('cf-players',       d.players);
      set('cf-blind',         d.blind);
      set('cf-stack',         d.stack);
      set('cf-timeout',       d.timeout);
      set('cf-raise-mode',    d.raiseMode);
      set('cf-raise-every',   d.raiseEvery);
      set('cf-end-raise',     d.endRaiseMode);
      set('cf-end-raise-val', d.endRaiseValue);
      set('cf-manual-blinds', d.manualBlinds != null ? d.manualBlinds : '');
      this._syncBlindsOrderUI(d.manualOrder != null ? !!d.manualOrder : null);
      set('cf-gui-speed',     d.guiSpeed);
      set('cf-delay',         d.delayHands);
      set('cf-game-type',     d.gameType);
      var asp = document.getElementById('cf-allow-spectators');
      if (asp && d.allowSpectators != null) {
        if (asp.type === 'checkbox') asp.checked = !!d.allowSpectators;
        else { asp.value = d.allowSpectators ? '1' : '0'; asp.dispatchEvent(new Event('input')); }
      }
      var pw = document.getElementById('cf-use-password');
      if (pw) { pw.checked = !!d.usePassword; try { pw.dispatchEvent(new Event('change')); } catch (e) {} }
      var pwr = document.getElementById('cf-password-row');
      if (pwr) pwr.style.display = d.usePassword ? '' : 'none';
      var pwv = document.getElementById('cf-password');
      if (pwv) pwv.value = d.usePassword ? (d.password || '') : '';
      // Les préférences remplacent tout style prédéfini : seule la pastille
      // « Perso » reste allumée.
      var presets = document.querySelectorAll('.cf-preset[data-preset]');
      for (var i = 0; i < presets.length; i++) presets[i].classList.remove('active');
      var perso = btn || document.getElementById('cf-preset-perso');
      if (perso) perso.classList.add('active');
      if (typeof showToast === 'function') showToast(t('createPrefsLoaded') || 'Preferences loaded');
    },
    // Reset the create-table form to its FACTORY defaults: the per-mode
    // baseline (LAN vs pokerth.net), explicitly IGNORING the last-used
    // settings saved in localStorage (skipSaved=true). Resets every field —
    // visible and hidden — plus the collapsible panels, presets and password
    // section, then confirms with a toast styled like the header ••• menu.
    resetCreateForm() {
      // Le verrou « classé » ne doit pas restaurer son snapshot par-dessus
      // les valeurs réinitialisées (le setVal cf-game-type → '1' plus bas
      // déclenche _syncGameTypeConstraints via l'événement input).
      this._rankSnap = null;
      this._vorlageSnap = null;
      var _vsr = document.getElementById('cf-vorlage'); if (_vsr) _vsr.value = '0';
      // Core + numeric fields (and their linked range sliders, via the
      // 'input' event dispatched inside _applyCreateFormDefaults).
      this._applyCreateFormDefaults(true, true);
      // Advanced options aren't part of the baseline object, so restore their
      // markup defaults explicitly.
      var setVal = function(id, v) {
        var e = document.getElementById(id);
        if (e) { e.value = v; e.dispatchEvent(new Event('input')); }
      };
      setVal('cf-raise-mode',       '1');
      setVal('cf-end-raise',        '1');
      setVal('cf-end-raise-val',    '200');
      setVal('cf-manual-blinds',    '');
      this._syncBlindsOrderUI(false);   // retour à « toujours doubler »
      setVal('cf-game-type',        '1');
      setVal('cf-allow-spectators', '1');
      // Password section back to off / empty / hidden.
      var pw  = document.getElementById('cf-use-password'); if (pw)  pw.checked = false;
      var pwv = document.getElementById('cf-password');     if (pwv) pwv.value = '';
      var pwr = document.getElementById('cf-password-row'); if (pwr) pwr.style.display = 'none';
      // Collapse "More options" back to its default closed state.
      var mo  = document.getElementById('cf-more-opts');   if (mo)  mo.style.display = 'none';
      var moa = document.getElementById('cf-more-arrow');  if (moa) moa.textContent = '\u25B6';
      var mol = document.getElementById('cf-more-label');  if (mol) mol.textContent = (t('moreOptions') || 'More options');
      // Hide the conditional "target blind" row.
      var erv = document.getElementById('cf-end-raise-val-row'); if (erv) erv.style.display = 'none';
      // Clear any highlighted style preset.
      var presets = document.querySelectorAll('.cf-preset');
      for (var i = 0; i < presets.length; i++) presets[i].classList.remove('active');
      // Confirmation toast.
      if (typeof showToast === 'function') showToast(t('fieldsReset') || 'Fields reset');
    },
    startWithBots() {
      if (!S.gId) return;
      send(MSG.buildStartWithBots(S.gId, true));
    },
    // Start the game with the humans currently at the table and NO
    // auto-filling with bots. Same StartEventMessage as startWithBots,
    // just with fillWithComputerPlayers = false.
    //
    // Per the user-validated design (Q1=b): button is only shown when
    // there are at least 2 humans at the table — startWithoutBotsButtonVisible()
    // updates its visibility on every join / leave / player-info event.
    // We re-check the count here defensively because the visibility
    // is just UI gating, not enforcement.
    startNoBots() {
      if (!S.gId) return;
      // Same counting heuristic as refreshStartNoBotsVisibility() AND
      // renderWaitingPanel(): seatData pids with .gone falsy, PLUS myId
      // if missing (the server doesn't always echo GamePlayerJoined for
      // ourselves, especially when we're the admin who just created the
      // table — myId never enters seatData via that path).
      // BUG FIX: previously this counted only seatData and refused with
      // "At least 2 players are needed" even though the visible panel
      // showed "Joueurs: 2/5" (because the renderer DID inject myId).
      var pids = Object.keys(S.seatData)
        .map(function(s){ return parseInt(s,10); })
        .filter(function(p){ return S.seatData[p] && !S.seatData[p].gone; });
      if (S.myId && pids.indexOf(S.myId) === -1) pids.push(S.myId);
      if (pids.length < 2) {
        // Should never reach here because the button is hidden when
        // pids.length < 2, but catch it anyway so a stray click on a
        // stale UI can't send a bad request to the server.
        var fr = (typeof _lang === 'undefined' || _lang !== 'en');
        addGameChat(null, '⚠ ' + t('kickAtLeast2'), 'sys', { prefix: '⚠ ', key: 'kickAtLeast2' });
        return;
      }
      send(MSG.buildStartWithBots(S.gId, false));
    },
    // Bouton unique « Démarrer la partie » de la wait-page (parité QML :
    // Lobby.startGame(fillCpuCheck.checked)). La case « Compléter avec des
    // joueurs ordinateur » décide du remplissage bots.
    startFromWait() {
      if (window._wpFillBots) this.startWithBots();
      else this.startNoBots();
    },
    createGame() {
      const g = id => document.getElementById(id);
      const iv = (id, def) => parseInt(g(id)?.value) || def;
      const sv = (id, def) => parseInt(g(id)?.value) || def;
      // Guard rail: align with the PokerTH game-name length limit. Refuse to
      // create (with a clear, translated message) when the typed name is too
      // long, instead of letting the server reject it.
      const rawName = (g('cf-name')?.value || '').trim();
      if (rawName.length > S.MAX_GAME_NAME) {
        if (typeof showToast === 'function') {
          showToast(t('nameTooLong', { max: S.MAX_GAME_NAME }), { icon: '\u26A0', tone: 'error', duration: 3500 });
        }
        return;
      }
      // Parité QML : nom vide → erreur inline et création bloquée, mais
      // seulement quand le formulaire est ouvert. Les chemins automatiques
      // (entraînement sans dialogue de création) gardent le nom par défaut.
      const _formOpen = !!document.querySelector('#create-form.open');
      if (!rawName && _formOpen) {
        var _ne = g('cf-name-err'); if (_ne) _ne.style.display = '';
        var _nf = g('cf-name'); if (_nf) _nf.focus();
        return;
      }
      // Type effectif (invité : Normal imposé par le serveur) et constantes
      // des parties classées, re-forcées à l'envoi comme le QML même si l'UI
      // a déjà verrouillé les champs (RANKING_GAME_NUMBER_OF_PLAYERS/START_
      // CASH/START_SBLIND/RAISE_EVERY_HAND, spectateurs oui, pas de mdp,
      // blindes toujours doublées).
      const _gtypeSel = (S._currentLoginMode === 'guest') ? 1 : sv('cf-game-type', 1);
      const _isRank   = (_gtypeSel === 4);
      const name    = _safeGameName(rawName || _defaultNameForMode());
      const nplayers= _isRank ? 10    : iv('cf-players', 2);
      const blind   = _isRank ? 50    : iv('cf-blind',   10);
      const stack   = _isRank ? 10000 : iv('cf-stack',   3000);
      const timeout = iv('cf-timeout', 30);
      S.gameTimeout = timeout; // mémoriser le timeout pour le timer
      S.gameStartMoney = stack;  // same idea for the starting stack: the
                               // GameListNew message will eventually echo
                               // this back, but writing it here ensures
                               // it's available immediately for our own
                               // JoinGameAck → GameStartInitial pipeline.
      // Mot de passe : Normal/Enregistrés seulement (QML passwordAllowed) —
      // jamais en classé (interdit serveur) ni en invitation.
      const _pwAllowed = (_gtypeSel === 1 || _gtypeSel === 2);
      const tablePass = (_pwAllowed && document.getElementById('cf-use-password')?.checked) ? (document.getElementById('cf-password')?.value || '') : '';
      // Spectators are allowed by default (true) when the field is missing
      // (older clients, or when the form hasn't been opened) — matches the
      // proto's default. The UI dropdown sends '1' = allowed, '0' = blocked.
      const allowSpecRaw = document.getElementById('cf-allow-spectators');
      const allowSpec = _isRank ? true : (allowSpecRaw
        ? (allowSpecRaw.type === 'checkbox' ? allowSpecRaw.checked : allowSpecRaw.value !== '0')
        : true);
      // Ordre manuel des blindes : liste envoyée SEULEMENT si le radio
      // « liste manuelle » est coché (sémantique officielle : liste non vide
      // = mode manuel côté serveur, netpacket.cpp).
      const manualOn = !_isRank && !!(g('cf-mb1') && g('cf-mb1').checked);
      const manualBlinds = manualOn ? this._getManualBlinds() : [];
      const opts = {
        raiseMode:       _isRank ? 1  : sv('cf-raise-mode',    1),
        raiseEvery:      _isRank ? 11 : iv('cf-raise-every',   7),
        endRaiseMode:    sv('cf-end-raise',     1),
        endRaiseValue:   iv('cf-end-raise-val', 200),
        manualBlinds:    manualBlinds,
        guiSpeed:        iv('cf-gui-speed',     5),
        delayHands:      iv('cf-delay',         7),
        gameType:        _gtypeSel,
        allowSpectators: allowSpec,
        password:        tablePass,
      };
      // Parite QML 2.1.5 : le type de suggestion vient EXPLICITEMENT du preset
      // choisi, jamais du nom de table (librement editable). Sans preset
      // communautaire, pas de suggestion.
      try {
        var _av = App._activeVorlage;
        window._botSuggest.setCreatedSuggestType((_av && _av.suggestType) ? _av.suggestType : '');
      } catch (eSg) {}
      send(MSG.buildCreateGame(name, nplayers, blind, stack, timeout, opts));
      // Entrainement : « Creer une table » lance directement la partie —
      // startWithBots() est declenche par le hook JoinGameAck des que gId
      // est connu (window._offlineAutoReplay, deja utilise par le replay).
      if (window._offlineMode) window._offlineAutoReplay = true;
      // Remember these settings so the next time the create form opens it
      // starts from what the user actually used last (not just the per-mode
      // default). Two things silently broke here (forum report):
      //   1. `bots: bots, minHumans: minHuman` referenced variables that left
      //      with the old fill-with-bots form controls (the choice now lives
      //      on the waiting page, window._wpFillBots). In module strict mode
      //      that's a ReferenceError — thrown INSIDE this try, swallowed by
      //      the catch — so the snapshot was never written at all and nothing
      //      the form remembered survived a reload.
      //   2. The name was left out on purpose, a leftover from before its
      //      guards existed (a blank name is skipped by the reader,
      //      _freeGameName shifts a name still open in the lobby). It is now
      //      saved AS TYPED (rawName).
      try {
        localStorage.setItem('pth_last_create', JSON.stringify({
          // Un nom AUTO (pré-rempli : défaut du mode, nom admin) n'est pas un
          // choix du joueur — on enregistre '' pour laisser les préférences
          // s'appliquer à la prochaine ouverture. Un nom tapé est conservé.
          name: _isAutoGameName(rawName) ? '' : rawName,
          players: nplayers, blind: blind, stack: stack, timeout: timeout,
          raiseEvery: opts.raiseEvery, guiSpeed: opts.guiSpeed,
          delayHands: opts.delayHands,
          raiseMode: opts.raiseMode, endRaiseMode: opts.endRaiseMode,
          endRaiseValue: opts.endRaiseValue, gameType: opts.gameType,
          allowSpectators: opts.allowSpectators,
          manualOrder: manualOn, manualBlinds: manualBlinds.join(','),
        }));
      } catch (e) {}
      var f = document.getElementById('create-form');
      if (f) { f.classList.remove('open'); }
    },
    getLobbyState() {
      // Read-only snapshot of the bits the players-panel renderer
      // needs. Returning a fresh object each time so the consumer
      // can sort/filter freely without affecting our internal state.
      return {
        pids:    Array.from(S._lobbyPids),
        players: S.players,
        myId:    S.myId,
        countries: S._playerCountries,
        rights:    S._playerRights,
        flagOf:  function(pid) { return _ccToFlag(S._playerCountries[pid]); },
      };
    },

    onRememberMe() {
      // Legacy no-op. The 'Remember nickname' checkbox was removed
      // in favour of automatic per-mode persistence. Kept as a stub
      // so any older HTML cached by a Service Worker doesn't 500
      // when its onchange handler fires.
    },
  };
})();

// Bridge: window-scope getters so the players-panel renderer
// (defined outside the IIFE) can read the IIFE-private state.
// Defined right after the IIFE so the closures capture the latest
// references. The renderer falls back to empty data if these
// haven't been set up yet.
window._readLobbyPids = function() {
  // We can't access _lobbyPids directly from out here. Instead we
  // proxy through App.getLobbyState() which the IIFE will expose.
  if (typeof App !== 'undefined' && App.getLobbyState) {
    var s = App.getLobbyState();
    return s.pids || [];
  }
  return [];
};
window._readPlayers = function() {
  if (typeof App !== 'undefined' && App.getLobbyState) {
    var s = App.getLobbyState();
    return s.players || {};
  }
  return {};
};
window._readMyId = function() {
  if (typeof App !== 'undefined' && App.getLobbyState) {
    var s = App.getLobbyState();
    return s.myId || 0;
  }
  return 0;
};


// ── Game chat (mirrors lobby addChat) ──
// Heure locale [HH:MM:SS] préfixée aux messages de chat des joueurs (parité
// officielle). Les messages système (sans expéditeur) restent sans heure.
function _chatTs() {
  var d = new Date();
  function p(n){ return (n < 10 ? '0' : '') + n; }
  return '[' + p(d.getHours()) + ':' + p(d.getMinutes()) + ':' + p(d.getSeconds()) + ']';
}

function addGameChat(sender, text, cls, spec) {
  // Spectators DO read the game chat (sp0ck 31/07/2026 — only SENDING is
  // blocked, see updateSpectatorStrip). Emoji reactions never reach this
  // function (intercepted in onChat / msg-social before routing).
  if (cls === 'sys') return; // messages systeme retires du chat (demande narmod)
  if (sender && cls !== 'mine' && _isIgnored(sender)) return; // joueur ignoré
  var el = document.getElementById('g-chat-msgs');
  if (!el) return;
  var _noEmo = false;
  try { _noEmo = (localStorage.getItem('pth_chat_noemoji') === '1'); } catch (e) {}
  if (sender && _noEmo) { try { text = _advStripEmoji(text); } catch (e) {} }
  var d = document.createElement('div');
  d.className = 'msg ' + (cls || '');
  // Surlignage (parité QML) — miroir de addChat (chat.mjs). Priorité : (chat bot)
  // m'adressant (message commençant par mon pseudo, sensible à la casse) → rouge
  // gras (« botwarn ») ; sinon mon pseudo cité (insensible à la casse) → or gras.
  try {
    var _mn = (window.PthState && window.PthState.myName ? window.PthState.myName : '').trim();
    if (_mn && sender && cls !== 'mine') {
      var _t = String(text);
      if (sender === '(chat bot)' && _t.startsWith(_mn))
        d.className += ' botwarn';
      else if (_t.toLowerCase().indexOf(_mn.toLowerCase()) !== -1)
        d.className += ' mention';
    }
  } catch (_em) {}
  function e(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
  // Corps du message : shortcodes :nom: + émoticônes ASCII (port officiel),
  // sauf en mode « chat sans emoji ». Le nom d'expéditeur n'est jamais converti.
  function emT(s) { var h = e(s); if (!_noEmo && typeof window.applyChatEmoteShortcuts === 'function') { try { h = window.applyChatEmoteShortcuts(h); } catch (_e) {} } if (typeof window._linkifyChatHtml === 'function') { try { h = window._linkifyChatHtml(h); } catch (_e2) {} } if (!_noEmo && typeof window._enlargeChatEmojis === 'function') { try { h = window._enlargeChatEmojis(h); } catch (_e3) {} } return h; }
  if (sender) {
    // Traduction par message (API navigateur, opt-in Options avancees) :
    // bouton visible seulement si body.chat-tr-on (option + support).
    // Libelle traduit ET re-traduisible : data-i18n-title suit un changement
    // de langue, le title initial evite un survol vide avant le premier passage.
    var _trL = 'Translate'; try { _trL = t('chatTranslateBtn'); } catch (_e) {}
    var _tr = (cls !== 'mine' ? '<button class="chat-tr-btn" title="' + e(_trL) + '" data-i18n-title="chatTranslateBtn" onclick="window._chatTranslate(this)" aria-label="' + e(_trL) + '">\u{1F310}</button>' : '');
    // Action « /me … » (parité QML) — miroir de addChat : « *Nom fait qqch* »
    // en italique, sans « Nom: ». Le « /me » part au serveur et est reformaté
    // à l'affichage par chaque client.
    if (String(text).slice(0, 4) === '/me ') {
      d.className += ' action';
      d.innerHTML = '<span class="msg-time">'+_chatTs()+'</span> <span class="txt">*'+e(sender)+' '+emT(text.slice(4))+'*</span>' + _tr;
    } else {
      d.innerHTML = '<span class="msg-time">'+_chatTs()+'</span> <span class="who">'+e(sender)+'</span>: <span class="txt">'+emT(text)+'</span>' + _tr;
    }
    try { d.dataset.orig = text; } catch (_e) {}
  } else {
    // Sans expéditeur = message serveur : broadcast (cls 'bc', ex. annonce
    // « Signup for Monthly Cup … https://… ») → emT (émotes + liens cliquables,
    // URLs protégées par applyChatEmoteShortcuts). Les 'sys' restent en e() :
    // retraduits en textContent brut par _retranslateSysChat.
    d.innerHTML = '<span class="txt">'+(cls === 'sys' ? e(text) : emT(text))+'</span>';
  }
  if (spec && !sender) { try { d.dataset.sys = JSON.stringify(spec); } catch(_e){} }
  var _ls = (typeof window._liveBefore === 'function') ? window._liveBefore(el) : null;
  el.appendChild(d);
  // Plafond d'historique (parité QML kMaxChatBlocks = 400, cf. addChat).
  while (el.childElementCount > 400) el.removeChild(el.firstElementChild);
  if (_ls) window._liveAfter(el, _ls);
  else el.scrollTop = el.scrollHeight;
  var cBtn = document.getElementById('chat-toggle-btn');
  var cPan = document.getElementById('g-chat-panel');
  if (cBtn && cls !== 'mine' && (!cPan || cPan.style.display === 'none')) {
    cBtn.style.color = 'var(--gold)';
    cBtn.style.borderColor = 'var(--gold-dim)';
    if (typeof bumpUnreadChat === 'function') bumpUnreadChat();
    clearTimeout(window._chatFlashTimer);
    window._chatFlashTimer = setTimeout(function(){
      if (!cPan || cPan.style.display === 'none') { cBtn.style.color=''; cBtn.style.borderColor=''; }
    }, 3000);
    // Not in the waiting room: the game panel is not on screen yet and QML
    // plays nothing for the table chat there — a sound with nothing to read.
    var _ps = window.PthState || {};
    var _waitRoom = !!(_ps.gId && !_ps._gameStarted);
    if (!_waitRoom && typeof notifyChat === 'function' && (typeof isGameChatSoundMuted !== 'function' || !isGameChatSoundMuted())) notifyChat();
  }
}

// Re-traduit en direct les messages systeme (cls 'sys') deja affiches dans
// les deux panneaux de chat quand la langue change. Les messages tapes par
// les joueurs (texte libre) ne sont pas touches. Appele depuis setLang().
window._retranslateSysChat = function() {
  ['chat', 'g-chat-msgs'].forEach(function(id) {
    var c = document.getElementById(id); if (!c) return;
    c.querySelectorAll('.msg[data-sys]').forEach(function(d) {
      var s; try { s = JSON.parse(d.dataset.sys); } catch (e) { return; }
      if (!s || !s.key) return;
      var tr = (typeof window.t === 'function') ? window.t(s.key, s.params || {}) : s.key;
      var txt = (s.prefix || '') + tr + (s.suffix || '');
      var span = d.querySelector('.txt');
      if (span) span.textContent = txt;
    });
  });
  // Le journal se re-traduit aussi : ses lignes sont des thunks rejoués ici.
  if (typeof window._retranslateLog === 'function') { try { window._retranslateLog(); } catch (_e) {} }
};

// click handled via inline onclick on game-row

window.addEventListener('resize', function() {
  if (typeof updateBottomLayout === 'function') updateBottomLayout();
  if (typeof window._applySeatOrient === 'function') window._applySeatOrient();
  autoScaleTable();
  // Re-rendu PENDANT le drag de redimensionnement (parité QML : le layout
  // suit la fenêtre en continu, pas d'états intermédiaires faux). renderSeats
  // est déjà throttlé à la frame (garde rAF _seatsRenderPending) — l'appel
  // direct coûte au plus un rendu par frame. Le passage différé (100 ms)
  // reste pour l'état final une fois la fenêtre posée.
  try { if (typeof renderSeats === 'function' && typeof seats !== 'undefined' && seats.length) renderSeats(); } catch (e) {}
  setTimeout(function(){ if(typeof renderSeats==='function' && typeof seats!=='undefined' && seats.length) renderSeats(); }, 100);
});
window.addEventListener('orientationchange', function() {
  setTimeout(function(){ if (typeof window._applySeatOrient === 'function') window._applySeatOrient(); autoScaleTable(); if(typeof renderSeats==='function' && typeof seats!=='undefined' && seats.length) renderSeats();
    // Zoom par orientation : appliquer la valeur mémorisée pour la nouvelle
    // orientation + rafraîchir l'état des boutons +/−/↺.
    try { if (typeof applyTableZoom === 'function') applyTableZoom(); } catch (e) {} }, 300);
});

// ── Zoom de la table (tablette/desktop) ─────────────────────
// Deux boutons +/- en haut a droite reduisent/re-agrandissent #g-table-zone
// (feutre + cartes communes + adversaires) via transform:scale. La barre
// joueur (.player-bar) et la barre d'action (#g-actions) sont DEHORS de
// #g-table-zone -> elles ne bougent pas. Contrainte : max = taille actuelle
// (1.0) ; on ne peut que reduire puis re-agrandir jusqu'a 1.0, donc jamais de
// depassement (ni clip ni pan). transform:scale est purement visuel -> se
// compose avec autoScaleTable (qui agit sur #g-table-scaler) et survit aux
// re-rendus de sieges. Neutralise + masque sur mobile.
var TABLE_ZOOM_MIN = 0.6, TABLE_ZOOM_MAX = 2.0, TABLE_ZOOM_STEP = 0.1, TABLE_ZOOM_DEFAULT = 1;
var _zoomPanX = 0, _zoomPanY = 0; // translation « suivi du siège actif » (px zone)
function _tableZoomGate() {
  // Parite QML tableZoomEnabled : interrupteur des Options avancees (defaut
  // vrai). Desactive -> boutons masques (body.adv-no-tablezoom) et zoom force
  // a 1 via _getTableZoom, sans effacer la valeur memorisee.
  try { return _advGet('table_zoom', true); } catch (e) { return true; }
}
// Zoom mémorisé PAR ORIENTATION (portrait / paysage séparés). Clés NEUVES
// pth_tz2_* : les anciennes valeurs (pth_table_zoom*) ne sont volontairement
// PAS migrées — elles ont été semées par les sémantiques précédentes du zoom
// et faussaient la taille de base. Tout le monde repart à 1.
function _tableZoomKey() {
  try { return (window.innerHeight > window.innerWidth) ? 'pth_tz2_p' : 'pth_tz2_l'; }
  catch (e) { return 'pth_tz2_l'; }
}
function _getTableZoom() {
  // Zoom de table RETIRÉ (demande narmod, 0.3.539) : le rendu variait selon
  // le navigateur/OS. Le placement reste STRICTEMENT celui du client QML sur
  // tous les écrans ; les valeurs mémorisées sont ignorées. Les boutons +/↺/−
  // et la loupe sont masqués côté CSS ; ✎ (édition) et le zoom de cartes
  // restent. Réintroduction éventuelle plus tard = loupe compact-only comme
  // le QML (Bible §3.4).
  return TABLE_ZOOM_DEFAULT;
}
function applyTableZoom() {
  // Le zoom n'est PAS un transform sur #g-table-zone : renderSeats mesure
  // #g-table-zone via getBoundingClientRect (valeurs scalees par un transform),
  // donc scaler ici laissait les sieges ecartes (positions pleine taille). A la
  // place : autoScaleTable multiplie l'echelle du FEUTRE par le zoom (feutre +
  // cartes), et renderSeats replace les sieges autour du feutre reduit ET met
  // chaque siege a l'echelle du zoom (avatars). Resultat : zoom uniforme, les
  // sieges suivent. On purge tout transform residuel sur #g-table-zone.
  var tz = document.getElementById('g-table-zone');
  if (tz && tz.style.transform) tz.style.transform = '';
  try { if (typeof window._renderSeats === 'function') window._renderSeats(); } catch (e) {}
  try { if (typeof autoScaleTable === 'function') autoScaleTable(); } catch (e) {}
  try { if (typeof window._renderSeats === 'function') window._renderSeats(); } catch (e) {}
  _applyZoomTransforms();
  var z = _getTableZoom();
  var maxFit = window._tableZoomMaxFit || TABLE_ZOOM_MAX;
  var bOut = document.getElementById('g-zoom-out');
  var bIn  = document.getElementById('g-zoom-in');
  var bRst = document.getElementById('g-zoom-reset');
  if (bOut) bOut.disabled = (z <= TABLE_ZOOM_MIN + 0.001);
  if (bIn)  bIn.disabled  = (z >= Math.min(TABLE_ZOOM_MAX, maxFit) - 0.001)
                          || (!!window._zoomInLayout && !!window._tableZoomMaxed);
  if (bRst) bRst.disabled = (Math.abs(z - TABLE_ZOOM_DEFAULT) < 0.001);
  var bCz = document.getElementById('g-cardzoom');
  if (bCz) { var _czl=0; try{ _czl=Math.min(5, Math.max(0, parseInt(localStorage.getItem('pth_big_own_cards'),10) || 0)); }catch(e){} bCz.classList.toggle('active', _czl>0); bCz.setAttribute('data-lvl', String(_czl)); }
}
// Agrandissement UNIFORME borne : le feutre (#g-table-scaler) et la couche des
// sieges (#g-seats) sont mis a l'echelle autour du centre du feutre. Le zoom
// effectif est plafonne (mesure des sieges) pour que TOUTE la table reste dans
// la zone -> rien hors-ecran. renderSeats reste neutre (zoom gere ici).
// Zoom +/- (placement classique/custom, PAS la loupe QML) : #g-seats etant
// scale en bloc, on contre-transforme la self : position p' telle que
// pan + c + eff*(p'-c) = position de base. A eff<=1 on restaure les valeurs de base.
function _applySelfZoomCounter() {
  // Loupe QML active -> la self-box vit DANS le calque zoome (parite QML,
  // voir _loupeAnchorSelf) : aucune contre-transformation.
  if ((window._loupeK || 1) > 1.001) return;
  // Zoom "grossir sur place" : ma self-box GROSSIT avec le zoom global, mais
  // sa position de BASE ne change PAS (ancree en bas-centre, jamais masquee
  // par la barre d'action). On contre uniquement la TRANSLATION de #g-seats
  // (position figee a la base) ; l'ECHELLE, elle, suit le zoom.
  try {
    var me = document.querySelector('#g-seats .seat.me');
    if (!me || !me.dataset.baseTop) return;
    var zone = document.getElementById('g-table-zone');
    var oval = document.querySelector('.felt-oval');
    if (!zone || !oval) return;
    var eff = window._tableZoomEff || 1;
    var bs = parseFloat(me.dataset.baseScale) || 1;
    var bt = parseFloat(me.dataset.baseTop) || 0;
    var bl = parseFloat(me.dataset.baseLeft) || 0;
    if (eff <= 1.001) {
      me.style.top = bt.toFixed(1) + 'px'; me.style.left = bl.toFixed(1) + 'px';
      me.style.transform = 'translate(-50%,-50%) scale(' + bs + ')';
      return;
    }
    var zr = zone.getBoundingClientRect(), orr = oval.getBoundingClientRect();
    var oCX = orr.left - zr.left + orr.width / 2 - _zoomPanX;
    var oCY = orr.top - zr.top + orr.height / 2 - _zoomPanY;
    // Position locale telle qu'apres le scale(eff) de #g-seats, le CENTRE de la
    // box retombe exactement sur sa position de base (bt,bl) -> ancrage fixe.
    var lx = oCX + (bl - _zoomPanX - oCX) / eff;
    var ly = oCY + (bt - _zoomPanY - oCY) / eff;
    me.style.left = lx.toFixed(1) + 'px';
    me.style.top = ly.toFixed(1) + 'px';
    // Echelle propre = bs ; #g-seats multiplie par eff -> net eff*bs : la box
    // GROSSIT sur place (avant : bs/eff = figee ; uniforme = base deplacee).
    me.style.transform = 'translate(-50%,-50%) scale(' + bs.toFixed(4) + ')';
  } catch (e) {}
}
window._applySelfZoomCounter = _applySelfZoomCounter;

function _applyZoomTransforms() {
  var sc = document.getElementById('g-table-scaler');
  var seats = document.getElementById('g-seats');
  var oval = document.querySelector('.felt-oval');
  var zone = document.getElementById('g-table-zone');
  if (!sc || !seats || !oval || !zone) return;
  var autofit = window._tableAutofit || 1;
  var zr = zone.getBoundingClientRect();
  var orr = oval.getBoundingClientRect();
  // centre du feutre en coords zone (invariant a l'echelle -> mesure directe ok)
  // Pan compensé : la mesure écran inclut la translation courante — on la
  // retire pour retrouver le centre du feutre en coordonnées LOCALES
  // (pré-transform), qui servent de transform-origin.
  var oCX = orr.left - zr.left + orr.width / 2 - _zoomPanX;
  var oCY = orr.top - zr.top + orr.height / 2 - _zoomPanY;
  // Chevauchement / debordement autorise : on applique le zoom demande tel quel
  // (plus de plafond "toujours visible"). Agrandissement UNIFORME du feutre, des
  // sieges et de mes cartes autour du centre du feutre.
  // Mode « zoom dans le layout » (placement officiel actif) : le +/− est déjà
  // consommé par la bisection de renderSeats — les joueurs grossissent SANS
  // sortir du cadre, se toucher ni recouvrir la rivière. Les couches ne sont
  // alors PAS re-scalées (eff = 1, ni pan ni loupe). La loupe uniforme reste
  // le comportement du placement classique/custom.
  var eff = window._zoomInLayout ? 1
          : Math.max(TABLE_ZOOM_MIN, Math.min(_getTableZoom(), TABLE_ZOOM_MAX));
  window._tableZoomEff = eff;
  window._tableZoomMaxFit = TABLE_ZOOM_MAX;
  // Pan du suivi du siège actif : clampé à l'excédent visible ((eff−1)·½zone,
  // comme le QML), nul dès qu'on repasse à zoom ≤ 1.
  if (eff <= 1.001) { _zoomPanX = 0; _zoomPanY = 0; }
  var _maxPX = Math.max(0, (eff - 1) * zr.width / 2);
  var _maxPY = Math.max(0, (eff - 1) * zr.height / 2);
  _zoomPanX = Math.max(-_maxPX, Math.min(_maxPX, _zoomPanX));
  _zoomPanY = Math.max(-_maxPY, Math.min(_maxPY, _zoomPanY));
  var _pan = (_zoomPanX || _zoomPanY)
    ? 'translate(' + _zoomPanX.toFixed(1) + 'px,' + _zoomPanY.toFixed(1) + 'px) ' : '';
  sc.style.transform = _pan + 'scale(' + (autofit * eff).toFixed(3) + ')';
  sc.style.transformOrigin = 'center center';
  seats.style.transformOrigin = oCX.toFixed(1) + 'px ' + oCY.toFixed(1) + 'px';
  seats.style.transform = _pan + 'scale(' + eff.toFixed(3) + ')';
  // mes cartes (player-bar) grandissent aussi au zoom-avant
  var myc = document.getElementById('g-myseat-cards');
  if (myc) { myc.style.transformOrigin = 'left center'; myc.style.transform = (eff > 1.001 ? 'scale(' + eff.toFixed(3) + ')' : ''); }
  // Cartes communes (#g-comm) : le scaler porte deja autofit*eff -> on neutralise
  // la compensation posee par autoScaleTable (sinon double facteur = eff^2).
  var _ccz = document.getElementById('g-comm');
  if (_ccz) _ccz.style.transform = '';
  _applySelfZoomCounter();
}
// Zoom repliable en mobile : une touche 🔍 qui déploie les boutons de zoom.
// ── Loupe QML (port de tableZone.zoomActive / zoomContent, source 2.1.3) ──
// Facteur fixe ×2.0 sur #g-zoom-layer (transformOrigin 0,0 ; x/y =
// (1−k)·zone/2 + pan) ; clip de la zone quand actif ; pan au pointeur ;
// transition 220 ms OutCubic hors drag. Action bar/fond : hors effet ; la
// self-box est DANS le calque (zoomee et panee avec le reste).
var _loupe = { on:false, k:2.0, panX:0, panY:0, susp:false, drag:false,
               pendSeat:null,     // planned pan seat, timer running (QML _pendingFollowSeat)
               followSeat:null,   // seat already panned to: pid | 'self' | null (QML _followedSeat)
               followTmr:null,
               ringN:null };      // ring count of the previous render
window._loupeK = 1;
function _loupeZone() { return document.getElementById('g-table-zone'); }
function _loupeClamp() {
  var z = _loupeZone(); if (!z) return;
  var k = _loupe.k, mX = (k - 1) / 2 * z.clientWidth, mY = (k - 1) / 2 * z.clientHeight;
  if (_loupe.panX >  mX) _loupe.panX =  mX;
  if (_loupe.panX < -mX) _loupe.panX = -mX;
  if (_loupe.panY >  mY) _loupe.panY =  mY;
  if (_loupe.panY < -mY) _loupe.panY = -mY;
}
// Parite QML (DELTA 2.1.9 §3.5, GamePage.qml : zoomLayer -> zoomContent ->
// selfBox, « selfBox is INSIDE the zoomable layer now », deja vrai en 2.1.4) :
// la self-box est zoomee x2 et panee AVEC le reste ; seuls l'action bar et le
// fond restent hors calque. L'ancienne Bible (§3.5 « self-box fixe ») etait
// fausse : le web contre-transformait la self pour la figer a l'echelle 1, ce
// qui la faisait flotter au milieu d'un anneau x2 (chevauchements en portrait,
// et pan « mon tour » sans self agrandie). Desormais elle garde simplement son
// transform nominal de renderSeats ; ce helper ne fait plus que retirer un
// eventuel reliquat de contre-transformation.
function _loupeAnchorSelf() {
  var me = document.querySelector('#g-seats .seat.me');
  if (!me || !me.dataset.baseTop) return;
  var bs = parseFloat(me.dataset.baseScale) || 1;
  var bl = parseFloat(me.dataset.baseLeft), bt = parseFloat(me.dataset.baseTop);
  if (isNaN(bl) || isNaN(bt)) return;
  me.style.transition = '';
  me.style.left = bl.toFixed(1) + 'px';
  me.style.top  = bt.toFixed(1) + 'px';
  me.style.transform = 'translate(-50%,-50%) scale(' + bs.toFixed(4) + ')';
}
function _loupeApply(anim) {
  var el = document.getElementById('g-zoom-layer'), z = _loupeZone();
  if (!el || !z) return;
  var act = _loupe.on && !_loupe.susp, k = act ? _loupe.k : 1;
  window._loupeK = k;
  el.style.transition = (anim === false || _loupe.drag) ? 'none'
    : 'transform 220ms cubic-bezier(0.215, 0.61, 0.355, 1)';
  el.style.transformOrigin = '0 0';
  el.style.transform = act
    ? 'translate(' + ((1 - k) * z.clientWidth / 2 + _loupe.panX) + 'px,'
                   + ((1 - k) * z.clientHeight / 2 + _loupe.panY) + 'px) scale(' + k + ')'
    : '';
  z.style.overflow = act ? 'hidden' : '';   // clip: tableZone.zoomActive
  var b = document.getElementById('g-zoom-toggle');
  if (b) { b.setAttribute('aria-pressed', _loupe.on ? 'true' : 'false');
           b.classList.toggle('active', _loupe.on); }
  _loupeAnchorSelf();
  // Mini-board (web addition, modules/ui/mini-board.mjs): every pan / toggle
  // can move the real community cards in or out of view.
  try { if (window._miniBoardSync) window._miniBoardSync(); } catch (e) {}
}
function toggleLoupe() {
  _loupe.on = !_loupe.on;
  if (!_loupe.on) { _loupe.panX = _loupe.panY = 0; _loupe.susp = false;
                    if (_loupe.followTmr) { clearTimeout(_loupe.followTmr); _loupe.followTmr = null; }
                    _loupe.pendSeat = null; _loupe.followSeat = null; }
  _loupeClamp(); _loupeApply();
}
window.toggleLoupe = toggleLoupe;
// ── Visibilité STRICTE QML (GamePage 2.1.3:2291) :
//   visible = mobile (pointeur tactile) && Responsive.compact && tableZoomEnabled.
// Position : pastille 36 px en BAS-DROITE — paysage 8 px du bord, portrait
// 8 px AU-DESSUS de la barre d'action. Bouton caché => zoom coupé + pan reset
// (onVisibleChanged QML). Option : localStorage pth_table_zoom ('0' = off,
// défaut activé — parité Config.Parameters.tableZoomEnabled).
function _loupeBtnSync() {
  var b = document.getElementById('g-zoom-toggle'); if (!b) return;
  var coarse = false;
  try { coarse = !!(window.matchMedia && window.matchMedia('(pointer: coarse)').matches); } catch (e) {}
  var w = window.innerWidth, h = window.innerHeight;
  var compact = w < 600 || (w >= h && h < 600);   // Responsive.compact (mobile)
  var enabled = true;
  enabled = _advGet('table_zoom', true);   // the admin kill switch wins over the stored choice
  var vis = coarse && compact && enabled;
  b.classList.toggle('loupe-avail', vis);
  if (!vis && (_loupe.on || _loupe.susp)) {
    _loupe.on = false; _loupe.susp = false; _loupe.panX = _loupe.panY = 0;
    if (_loupe.followTmr) { clearTimeout(_loupe.followTmr); _loupe.followTmr = null; }
    _loupe.pendSeat = null; _loupe.followSeat = null;
    _loupeApply(false);
  }
  if (vis) {
    var portrait = (typeof _tableZonePortrait === 'function') ? _tableZonePortrait() : (h > w);
    var mz = document.querySelector('.my-zone');
    b.style.bottom = (!portrait ? 8 : 8 + (mz ? Math.round(mz.getBoundingClientRect().height) : 0)) + 'px';
  }
}
window._loupeBtnSync = _loupeBtnSync;
setTimeout(_loupeBtnSync, 900);
// Pan au pointeur (souris/tactile). Sièges et boutons restent cliquables :
// le drag ne démarre pas dessus (comme le DragHandler QML sous les items).
(function () {
  var sx = 0, sy = 0, px = 0, py = 0;
  document.addEventListener('pointerdown', function (e) {
    if (!(_loupe.on && !_loupe.susp)) return;
    var z = _loupeZone(); if (!z || !z.contains(e.target)) return;
    if (e.target.closest && (e.target.closest('.seat') || e.target.closest('button') || e.target.closest('select'))) return;
    _loupe.drag = true; sx = e.clientX; sy = e.clientY; px = _loupe.panX; py = _loupe.panY;
  }, true);
  document.addEventListener('pointermove', function (e) {
    if (!_loupe.drag) return;
    _loupe.panX = px + (e.clientX - sx); _loupe.panY = py + (e.clientY - sy);
    _loupeClamp(); _loupeApply(false);
  });
  document.addEventListener('pointerup', function () {
    if (_loupe.drag) { _loupe.drag = false; _loupeApply(); }
  });
})();
// Hook appelé par renderSeats : suivi différé du siège actif + suspension au
// showdown (parité _scheduleFollow/_doFollow + _zoomSuspendedByShowdown).
// ── Follow state machine: straight port of GamePage.qml (2.1.9, tableZone) ──
// _panToPoint / _panToSeat / _scheduleFollow / _doFollow / _reanchorZoom and
// the GameTable connections (myTurn, boardCards, showdown). Not ported:
// onWinningHandTextChanged - on the web that text only ever shows during the
// showdown, where the loupe is suspended (zoomed out), so it could never act.
function _loupeActive() { return _loupe.on && !_loupe.susp; }
// Screen centre on the content point (cx,cy), zone px: pan = k·(size/2 − c).
function _loupePanToPoint(cx, cy) {
  var z = _loupeZone(); if (!z) return;
  _loupe.panX = _loupe.k * (z.clientWidth / 2 - cx);
  _loupe.panY = _loupe.k * (z.clientHeight / 2 - cy);
  _loupeClamp(); _loupeApply();
}
// Ring seats only: the self box is not a ring slot (QML slotForSeat → null).
function _loupeSeatEl(pid) {
  if (pid == null || pid === 'self') return null;
  try { return document.querySelector('#g-seats .seat[data-pid="' + pid + '"]:not(.me)'); } catch (e) { return null; }
}
function _loupePanToSeat(pid) {
  var el = _loupeSeatEl(pid); if (!el) return;
  // Zone coordinates (style left/top set by renderSeats, untransformed).
  _loupePanToPoint(parseFloat(el.style.left) || 0, parseFloat(el.style.top) || 0);
}
// communityCenterY as computed by renderSeats (window._commCenterY, zone px).
function _loupeCommY() {
  var z = _loupeZone(), cy = window._commCenterY;
  return (typeof cy === 'number' && isFinite(cy) && cy > 0) ? cy : (z ? z.clientHeight / 2 : 0);
}
function _loupeStopFollow() {
  if (_loupe.followTmr) { clearTimeout(_loupe.followTmr); _loupe.followTmr = null; }
}
// Deferred follow of the seat to act: the view does NOT jump there at once but
// when that player acts (_loupeDoFollow) or 1/4 of the thinking time is over,
// so the table / community area stays visible longer after a new card.
function _loupeScheduleFollow(pid, sec) {
  if (!_loupeActive() || _loupe.drag) return;
  if (!_loupeSeatEl(pid)) return;                                  // none, or me (the myTurn path)
  pid = String(pid);
  if (pid === _loupe.followSeat) return;                           // already there
  if (pid === _loupe.pendSeat && _loupe.followTmr) return;         // already planned
  _loupe.pendSeat = pid;
  _loupeStopFollow();
  _loupe.followTmr = setTimeout(_loupeDoFollow, Math.max(800, (sec > 0 ? sec : 8) * 250));
}
function _loupeDoFollow() {
  _loupeStopFollow();
  if (!_loupeActive() || _loupe.drag) return;
  if (_loupe.pendSeat == null) return;
  _loupePanToSeat(_loupe.pendSeat);
  _loupe.followSeat = _loupe.pendSeat;
  _loupe.pendSeat = null;
}
// My turn: drop a planned opponent pan and show the self box zone at once
// (bottom of the table, centred) so hand cards and action area are in view.
function _loupeMyTurn() {
  if (!_loupeActive()) return;
  var z = _loupeZone(); if (!z) return;
  _loupeStopFollow();
  _loupe.pendSeat = null;
  _loupe.followSeat = 'self';
  _loupe.panX = 0;
  _loupe.panY = -(_loupe.k - 1) * z.clientHeight / 2;
  _loupeClamp(); _loupeApply();
}
// New street: forget the "already panned to" mark so the first player of the
// round is followed again, and pan to the community cards.
function _loupeBoardCards() {
  if (!_loupeActive()) return;
  _loupeStopFollow();
  _loupe.pendSeat = null; _loupe.followSeat = null;
  if (_loupe.drag) return;
  var z = _loupeZone(); if (!z) return;
  _loupePanToPoint(z.clientWidth / 2, _loupeCommY());
}
// New hand (no board card yet): marks reset only, no pan.
function _loupeHandStart() {
  if (!_loupe.on) return;
  _loupeStopFollow();
  _loupe.pendSeat = null; _loupe.followSeat = null;
}
// Re-anchor (upstream a6d4f05, _reanchorZoom): panX/panY are ABSOLUTE
// coordinates of the ring distribution that was current when the pan was made.
// As soon as the ring is redistributed - "Remove departed players" is on and
// someone leaves, or the option is toggled mid-hand - the excerpt points at a
// place where no box sits any more. Re-anchor it onto the seat it was showing;
// if that seat left the ring (or no seat was followed) go back to the table
// centre, which exists in every distribution. The self box zone hangs on the
// lower zone edge, not on a ring slot: its excerpt stays valid.
function _loupeReanchor() {
  if (!_loupeActive() || _loupe.drag) return;
  if (_loupe.followSeat === 'self') return;
  var z = _loupeZone(); if (!z) return;
  if (_loupeSeatEl(_loupe.followSeat)) { _loupePanToSeat(_loupe.followSeat); return; }
  _loupe.followSeat = null;
  _loupePanToPoint(z.clientWidth / 2, _loupeCommY());
}
// Mini-board tap (web addition): toggle the view between the community cards
// and the self box zone. 'board' is no ring seat: _loupeScheduleFollow never
// matches it and _loupeReanchor falls back to the table centre, as intended.
function _loupeToggleBoard() {
  if (!_loupeActive() || _loupe.drag) return;
  if (_loupe.followSeat === 'board') { _loupeMyTurn(); return; }
  var z = _loupeZone(); if (!z) return;
  _loupeStopFollow();
  _loupe.pendSeat = null;
  _loupePanToPoint(z.clientWidth / 2, _loupeCommY());
  _loupe.followSeat = 'board';
}
window._loupeToggleBoard = _loupeToggleBoard;
window._loupeReanchor = _loupeReanchor;
window._loupeMyTurn = _loupeMyTurn;
window._loupeBoardCards = _loupeBoardCards;
window._loupeOnRender = function (activeEl, showdown, timerTot) {
  _loupeBtnSync();   // visibilité/position réévaluées à chaque rendu de table
  try { if (window._miniBoardSync) window._miniBoardSync(); } catch (e) {}   // turn / action state may have changed
  // The ring count is the one criterion that changes on every redistribution
  // (parity with onRingCountChanged). Tracked even while the loupe is off, so
  // the baseline is right when it gets switched on. Deferred (~ Qt.callLater):
  // the overlap guard of renderSeats may still re-place the seats.
  var _ringNow = window._seatCount || 0;
  var _ringMoved = (_loupe.ringN != null && _ringNow !== _loupe.ringN);
  _loupe.ringN = _ringNow;
  if (_ringMoved && _loupe.on) setTimeout(_loupeReanchor, 0);
  if (!_loupe.on) return;
  var z = _loupeZone(); if (!z) return;
  if (showdown) {   // zoom out for the overview, switched on again next hand
    if (!_loupe.susp) {   // QML onShowdownActiveChanged: planned pan dropped, pan reset
      _loupe.susp = true;
      _loupeStopFollow();
      _loupe.pendSeat = null; _loupe.followSeat = null;
      _loupe.panX = 0; _loupe.panY = 0;
      _loupeApply();
    }
    return;
  }
  if (_loupe.susp) { _loupe.susp = false; _loupeApply(); }
  // Safety net (QML onPlayersChanged): follow the active opponent in a deferred
  // way. _loupeScheduleFollow is idempotent, no timer thrash under re-renders.
  if (activeEl) _loupeScheduleFollow(activeEl.getAttribute('data-pid'), timerTot);
};
window.addEventListener('resize', function () { _loupeClamp(); _loupeApply(false); _loupeBtnSync(); });

function toggleZoomCtrl() {
  var el = document.getElementById('g-zoom-ctrl');
  if (!el) return;
  var open = el.classList.toggle('open');
  var t = document.getElementById('g-zoom-toggle');
  if (t) t.setAttribute('aria-expanded', open ? 'true' : 'false');
}
window.toggleZoomCtrl = toggleZoomCtrl;

function tableZoomStep(dir) {
  var z = _getTableZoom() + (dir > 0 ? TABLE_ZOOM_STEP : -TABLE_ZOOM_STEP);
  z = Math.round(z * 100) / 100;
  z = Math.max(TABLE_ZOOM_MIN, Math.min(TABLE_ZOOM_MAX, z));
  try { localStorage.setItem(_tableZoomKey(), String(z)); } catch (e) {}
  applyTableZoom();
}
function tableZoomReset() {
  try { localStorage.setItem(_tableZoomKey(), String(TABLE_ZOOM_DEFAULT)); } catch (e) {}
  applyTableZoom();
}
window.tableZoomStep = tableZoomStep;
window.tableZoomReset = tableZoomReset;
window.applyTableZoom = applyTableZoom;

// ── Zoom-follow du siège actif + suspension au showdown (parité QML, bible §3.4) ──
// Quand un adversaire est au tour et que la table est zoomée (>1), le cadrage
// NE saute PAS tout de suite : on programme un pan différé
// (max(800 ms, timeout×250 ms ≈ ¼ du temps de réflexion)) et on pane
// immédiatement si le joueur agit (PlayersActionDone). Au showdown, le zoom se
// suspend (dézoom = vue d'ensemble) et se réactive automatiquement à la main
// suivante s'il était actif. Aucun suivi pendant l'édition des sièges.
var _zoomFollowTimer = null;
var _zoomPendingPid = -1, _zoomFollowedPid = -1;
var _zoomPreShowdown = null; // valeur de zoom sauvée pendant la suspension
function _zoomFollowOn() {
  return (window._tableZoomEff || _getTableZoom()) > 1.001 && !window._seatEditMode
    && _advGet('zoom_follow', true);   // actif par défaut (parité QML zoom-follow)
}
function _zoomPanToSeat(pid) {
  var zone = document.getElementById('g-table-zone');
  var oval = document.querySelector('.felt-oval');
  var seatEl = document.querySelector('#g-seats .seat[data-pid="' + pid + '"]');
  if (!zone || !oval || !seatEl) return;
  var eff = window._tableZoomEff || _getTableZoom();
  if (eff <= 1.001) return;
  // Coordonnées LOCALES (pré-transform) : offsetLeft/Top du siège (layout, non
  // transformé) + centre du feutre re-déduit de la mesure écran compensée du
  // pan courant. Cible : centre du siège → centre de la zone ;
  // t = c − o − (p−o)·eff, clampé ensuite par _applyZoomTransforms.
  var zr = zone.getBoundingClientRect();
  var orr = oval.getBoundingClientRect();
  var oX = orr.left - zr.left + orr.width / 2 - _zoomPanX;
  var oY = orr.top - zr.top + orr.height / 2 - _zoomPanY;
  var pX = seatEl.offsetLeft + seatEl.offsetWidth / 2;
  var pY = seatEl.offsetTop + seatEl.offsetHeight / 2;
  _zoomPanX = zr.width / 2 - oX - (pX - oX) * eff;
  _zoomPanY = zr.height / 2 - oY - (pY - oY) * eff;
  // Pan animé (220 ms OutCubic comme le QML) ; transition retirée ensuite pour
  // ne pas animer les resize / re-rendus ultérieurs.
  var sc = document.getElementById('g-table-scaler');
  var seats = document.getElementById('g-seats');
  [sc, seats].forEach(function (el) {
    if (el) el.style.transition = 'transform 220ms cubic-bezier(0.33, 1, 0.68, 1)';
  });
  try { _applyZoomTransforms(); } catch (e) {}
  setTimeout(function () {
    [sc, seats].forEach(function (el) { if (el) el.style.transition = ''; });
  }, 260);
}
function _zoomDoFollow() {
  if (_zoomFollowTimer) { clearTimeout(_zoomFollowTimer); _zoomFollowTimer = null; }
  if (!_zoomFollowOn()) { _zoomPendingPid = -1; return; }
  if (_zoomPendingPid <= 0) return;
  _zoomPanToSeat(_zoomPendingPid);
  _zoomFollowedPid = _zoomPendingPid;
  _zoomPendingPid = -1;
}
// Adversaire au tour → planifier le pan (jamais pour soi : parité QML,
// la self-box reste le point fixe du cadrage).
window._zoomFollowTurn = function (pid, sec) {
  if (!_zoomFollowOn() || !pid) return;
  if (pid === _zoomFollowedPid) return;                       // déjà cadré
  if (pid === _zoomPendingPid && _zoomFollowTimer) return;    // déjà planifié
  _zoomPendingPid = pid;
  if (_zoomFollowTimer) clearTimeout(_zoomFollowTimer);
  _zoomFollowTimer = setTimeout(_zoomDoFollow, Math.max(800, (sec > 0 ? sec : 8) * 250));
};
// Le joueur a agi → exécuter tout pan en attente immédiatement.
window._zoomFollowActed = function () {
  try { _loupeDoFollow(); } catch (e) {}   // loupe: the planned player has acted → pan there at once
  if (_zoomPendingPid > 0) _zoomDoFollow();
};
// Showdown → dézoom d'ensemble (zoom sauvé, restauré à la main suivante).
window._zoomShowdownSuspend = function () {
  if (!_advGet('zoom_follow', true)) return;   // option coupée → zoom intact au showdown
  if (_zoomFollowTimer) { clearTimeout(_zoomFollowTimer); _zoomFollowTimer = null; }
  _zoomPendingPid = -1; _zoomFollowedPid = -1;
  var z = _getTableZoom();
  if (z > 1.001 && _zoomPreShowdown == null) {
    _zoomPreShowdown = z;
    _zoomPanX = 0; _zoomPanY = 0;
    try { localStorage.setItem('pth_table_zoom', '1'); } catch (e) {}
    try { applyTableZoom(); } catch (e) {}
  }
};
// Nouvelle main → reset du suivi + restauration du zoom suspendu.
window._zoomHandStart = function () {
  try { _loupeHandStart(); } catch (e) {}
  if (_zoomFollowTimer) { clearTimeout(_zoomFollowTimer); _zoomFollowTimer = null; }
  _zoomPendingPid = -1; _zoomFollowedPid = -1;
  var need = (_zoomPreShowdown != null) || _zoomPanX || _zoomPanY;
  _zoomPanX = 0; _zoomPanY = 0;
  if (_zoomPreShowdown != null) {
    var z = _zoomPreShowdown; _zoomPreShowdown = null;
    try { localStorage.setItem('pth_table_zoom', String(z)); } catch (e) {}
  }
  if (need) { try { applyTableZoom(); } catch (e) {} }
};

// ════════════════════════════════════════════════════════════════════════
// [Phase 2] Placement custom des sièges (fractions par orientation/nb de
// joueurs, mode édition glisser-déposer, bannière, autoScaleTable) déplacé
// dans public/modules/game/seats.mjs (toujours global via window.*).

// ── Chat redimensionnable au doigt ──────────────────────────────
// Ajoute une poignée en bas du panneau. Le glissement (Pointer Events
// = tactile + souris) ajuste la hauteur de la zone messages, bornée à
// [50px, 75% de l'écran]. Le chat s'ouvre à sa taille par défaut ; pas
// de restauration entre sessions (les styles inline posés au glissement
// persistent tant que la page vit, puis repartent au défaut au reload).
// Idempotent : la poignée n'est créée qu'une fois (guard _resizable).
// Marge entre le bas d'un panneau overlay du lobby (chat / joueurs) et le
// début de la carte « Créer une table ».
var LOBBY_PANEL_GAP = 14;

/* ════════════════════════════════════════════════════════════════════════
   FENETRES FLOTTANTES (deplacables / redimensionnables) — chat, journal,
   reactions. Active UNIQUEMENT par les gates :
     _winGate()  : largeur >= 900 px (tablette + desktop)  -> journal/reactions
     _chatGate() : >= 900 px ET souris (pointer:fine)       -> chat (desktop only)
   Sous le seuil, les panneaux restent en bandeau pleine largeur (inchange) et
   chat/journal y gardent leur resize vertical historique (makeChatResizable).
   Patron pointeur calque sur makeChatResizable (setPointerCapture).
   ════════════════════════════════════════════════════════════════════════ */
function _winGate(){ try{ return window.matchMedia('(min-width:900px) and (min-height:600px)').matches; }catch(e){ return false; } }
function _chatGate(){ try{ return window.matchMedia('(min-width:900px) and (hover:hover) and (pointer:fine)').matches; }catch(e){ return false; } }
function _placeWin(panel, left, top){
  // right/bottom:auto AVANT de mesurer : un panneau encore en base CSS
  // (left:0;right:0) mesurerait une largeur pleine et se collerait au bord.
  panel.style.right='auto';   panel.style.bottom='auto';
  var w=panel.offsetWidth, h=panel.offsetHeight, vw=window.innerWidth, vh=window.innerHeight;
  left=Math.max(4, Math.min(left, vw-w-4));
  top =Math.max(4, Math.min(top,  vh-h-4));
  panel.style.left=left+'px'; panel.style.top=top+'px';
}
function _saveWin(panel, key){
  if(!key) return;
  try{
    var r=panel.getBoundingClientRect(), d={left:Math.round(r.left), top:Math.round(r.top)};
    if(panel._winResizable){ d.width=Math.round(r.width); d.height=Math.round(r.height); }
    localStorage.setItem(key, JSON.stringify(d));
  }catch(e){}
}
function _restoreWin(panel, key){
  if(!key) return false;
  try{
    var raw=localStorage.getItem(key); if(!raw) return false;
    var d=JSON.parse(raw); if(!d || typeof d.left!=='number') return false;
    if(d.width)  panel.style.width =d.width +'px';
    if(d.height) panel.style.height=d.height+'px';
    _placeWin(panel, d.left, d.top);
    return true;
  }catch(e){ return false; }
}
function makeWinDraggable(panel, handle, key){
  if(!panel || !handle) return;
  handle.style.cursor='move'; handle.style.touchAction='none';
  if(panel._winDragWired) return;            // une seule fois par element
  panel._winDragWired=true;
  var sx=0, sy=0, sl=0, st=0, drag=false, pend=false, sup=false;
  handle.addEventListener('pointerdown', function(e){
    if(panel._winDrag===false) return;       // inerte hors mode flottant
    var _b = e.target.closest && e.target.closest('button');
    // Boutons d'en-tete : pas de drag — SAUF les onglets .gip-tab, qui se
    // traînent « au seuil » (bougé > 7px = déplacement, tap simple = clic).
    if(_b && !(_b.classList && _b.classList.contains('gip-tab'))) return;
    var r=panel.getBoundingClientRect();
    sx=e.clientX; sy=e.clientY; sl=r.left; st=r.top; sup=false;
    if(_b){ pend=true; return; }             // pas de preventDefault : le clic d'onglet reste possible
    _ensureFloating(panel, e);
    drag=true;
    handle.classList.add('win-dragging');
    try{ handle.setPointerCapture(e.pointerId); }catch(_){}
    e.preventDefault();
  });
  handle.addEventListener('pointermove', function(e){
    if(pend && !drag){
      if(Math.abs(e.clientX-sx)+Math.abs(e.clientY-sy) <= 7) return;
      _ensureFloating(panel, e);
      var r2=panel.getBoundingClientRect(); sl=r2.left; st=r2.top;
      drag=true; sup=true; pend=false;
      handle.classList.add('win-dragging');
      try{ handle.setPointerCapture(e.pointerId); }catch(_){}
    }
    if(!drag) return;
    _placeWin(panel, sl+(e.clientX-sx), st+(e.clientY-sy));
  });
  // Un drag parti d'un onglet ne doit pas déclencher le changement d'onglet.
  handle.addEventListener('click', function(e){ if(sup){ sup=false; e.stopPropagation(); e.preventDefault(); } }, true);
  function end(e){
    pend=false;
    if(!drag) return; drag=false;
    handle.classList.remove('win-dragging');
    try{ handle.releasePointerCapture(e.pointerId); }catch(_){}
    _saveWin(panel, key);
  }
  handle.addEventListener('pointerup', end);
  handle.addEventListener('pointercancel', end);
}
// ── Zoom de fenêtre (demande narmod 2026-07-18) : le CONTENU (texte,
// contrôles, espacements) suit l'agrandissement/rétrécissement de la fenêtre.
// z = taille courante / taille par défaut (borné), multiplié par un facteur
// global d'app dérivé du viewport — les fenêtres/popups s'adaptent aussi à la
// taille de la fenêtre de l'app. Rendu via la propriété CSS `zoom`
// (standardisée) posée sur les enfants directs : le layout interne se fait en
// coordonnées locales puis est mis à l'échelle (flex/scroll restent corrects).
function _appWinZoom(){
  var z = Math.min(window.innerWidth / 1440, window.innerHeight / 900);
  return Math.max(0.9, Math.min(1.25, z));
}
function _applyWinZoom(panel){
  if (!panel || !panel._winOpt || !panel._winOpt.zoom) return;
  try {
    var o = panel._winOpt;
    var w = panel.offsetWidth  || o.defW || 340;
    var h = panel.offsetHeight || o.defH || 300;
    var z = Math.min(w / (o.defW || 340), h / (o.defH || 300));
    z = Math.max(0.8, Math.min(1.8, z)) * _appWinZoom();
    panel.style.setProperty('--wz', z.toFixed(3));
    panel.classList.add('win-zoom');
  } catch (e) {}
}
function makeWinResizable(panel, key, minW, minH, maxW, maxH){
  if(!panel || panel._winRszWired) return;
  panel._winRszWired=true;
  minW=minW||240; minH=minH||140;
  // maxW/maxH optionnels : bornes hautes de la fenetre (0/undefined = illimite).
  ['n','s','e','w','ne','nw','se','sw'].forEach(function(dir){
    var h=document.createElement('div');
    h.className='win-rsz win-rsz-'+dir;
    panel.appendChild(h);
    var sx=0, sy=0, sw=0, sh=0, sl=0, st=0, on=false;
    h.addEventListener('pointerdown', function(e){
      _ensureFloating(panel);
      on=true;
      var r=panel.getBoundingClientRect();
      sx=e.clientX; sy=e.clientY; sw=r.width; sh=r.height; sl=r.left; st=r.top;
      panel.classList.add('win-resizing');
      try{ h.setPointerCapture(e.pointerId); }catch(_){}
      e.preventDefault(); e.stopPropagation();
    });
    h.addEventListener('pointermove', function(e){
      if(!on) return;
      var dx=e.clientX-sx, dy=e.clientY-sy, nl=sl, nt=st, nw=sw, nh=sh;
      if(dir.indexOf('e')>=0) nw=sw+dx;
      if(dir.indexOf('s')>=0) nh=sh+dy;
      if(dir.indexOf('w')>=0){ nw=sw-dx; nl=sl+dx; }
      if(dir.indexOf('n')>=0){ nh=sh-dy; nt=st+dy; }
      if(nw<minW){ if(dir.indexOf('w')>=0) nl-=(minW-nw); nw=minW; }
      if(nh<minH){ if(dir.indexOf('n')>=0) nt-=(minH-nh); nh=minH; }
      if(maxW && nw>maxW){ if(dir.indexOf('w')>=0) nl+=(nw-maxW); nw=maxW; }
      if(maxH && nh>maxH){ if(dir.indexOf('n')>=0) nt+=(nh-maxH); nh=maxH; }
      var vw=window.innerWidth, vh=window.innerHeight;
      // Borne la TAILLE pour garder le bord opposé au coin tiré dans l'écran,
      // sans repousser le coin ancré (sinon la fenêtre « recule » en s'agrandissant).
      if(dir.indexOf('e')>=0) nw=Math.min(nw, vw-nl-6);
      if(dir.indexOf('s')>=0) nh=Math.min(nh, vh-nt-6);
      if(dir.indexOf('w')>=0 && nl<6){ nw-=(6-nl); nl=6; }
      if(dir.indexOf('n')>=0 && nt<6){ nh-=(6-nt); nt=6; }
      nw=Math.max(minW, Math.min(nw, vw-12)); nh=Math.max(minH, Math.min(nh, vh-12));
      if(maxW) nw=Math.min(nw, maxW); if(maxH) nh=Math.min(nh, maxH);
      panel.style.width=nw+'px'; panel.style.height=nh+'px';
      panel.style.right='auto'; panel.style.bottom='auto';
      panel.style.left=nl+'px'; panel.style.top=nt+'px';
      _applyWinZoom(panel);
    });
    function end(e){
      if(!on) return; on=false;
      panel.classList.remove('win-resizing');
      try{ h.releasePointerCapture(e.pointerId); }catch(_){}
      _saveWin(panel, key);
    }
    h.addEventListener('pointerup', end);
    h.addEventListener('pointercancel', end);
  });
}
function _clampWinToViewport(panel){
  // Borne la taille (si redimensionnable) puis la position d'une fenetre
  // flottante au viewport courant : taille memorisee sur un ecran plus
  // grand, ou navigateur retreci apres coup.
  try{
    var o=panel._winOpt||{};
    if(panel._winResizable){
      var mw=Math.max(o.minW||240, window.innerWidth-8);
      var mh=Math.max(o.minH||140, window.innerHeight-8);
      if(panel.offsetWidth >mw) panel.style.width =mw+'px';
      if(panel.offsetHeight>mh) panel.style.height=mh+'px';
    }
    var r=panel.getBoundingClientRect();
    _placeWin(panel, r.left, r.top);
  }catch(e){}
}
function _enableFloating(panel, opt){
  if(!panel) return; opt=opt||{};
  panel.classList.add('floating-win');
  panel._winDrag=true; panel._winResizable=!!opt.resizable;
  panel.style.setProperty('max-height','none','important');
  var restored=_restoreWin(panel, opt.key);
  if(restored){
    // Taille memorisee avant l'introduction des bornes maxi : on la re-borne.
    if(opt.maxW && panel.offsetWidth >opt.maxW) panel.style.width =opt.maxW+'px';
    if(opt.maxH && panel.offsetHeight>opt.maxH) panel.style.height=opt.maxH+'px';
  }
  if(!restored){
    if(opt.resizable){
      // openW/openH : taille de PREMIERE ouverture, distincte de defW/defH qui
      // restent la base du zoom de contenu (_applyWinZoom). Absents => defW/defH.
      if(!panel.style.width) panel.style.width=(opt.openW||opt.defW||340)+'px';
      panel.style.height=(opt.openH||opt.defH||300)+'px';
    }
    _placeWin(panel, (opt.defLeft!=null?opt.defLeft:16), (opt.defTop!=null?opt.defTop:56));
  }
  if(opt.handle) makeWinDraggable(panel, opt.handle, opt.key);
  if(opt.resizable) makeWinResizable(panel, opt.key, opt.minW, opt.minH, opt.maxW, opt.maxH);
  panel._winOpt = panel._winOpt || opt;
  _clampWinToViewport(panel);
  _applyWinZoom(panel);
}
function _disableFloating(panel){
  if(!panel || !panel.classList.contains('floating-win')) return;
  panel.classList.remove('floating-win');
  panel.classList.remove('win-zoom');
  panel.style.removeProperty('--wz');
  panel._winDrag=false; panel._winResizable=false;
  panel.style.removeProperty('max-height');
  ['left','top','right','bottom','width','height'].forEach(function(p){ panel.style[p]=''; });
  var hs=panel.querySelectorAll('.win-rsz');
  for(var i=0;i<hs.length;i++) hs[i].remove();
  panel._winRszWired=false;   // re-injectable si on repasse en flottant
}
window.addEventListener('resize', function(){
  // TOUTES les fenetres flottantes (chat, log, reactions, musique, mains,
  // journaux, ...) : re-bornees en taille ET en position au viewport.
  var ps=document.querySelectorAll('.floating-win');
  for(var i=0;i<ps.length;i++){
    var p=ps[i];
    if(p.style.display==='none' || !p.offsetWidth) continue;
    _clampWinToViewport(p);
    _applyWinZoom(p);   // le facteur global d'app (viewport) a pu changer
  }
});

function _ensureFloating(panel, dragEv){
  // Promotion bandeau -> fenetre flottante au 1er drag/resize. No-op si deja
  // flottant ou si l'element n'a pas opte (panel._winOpt absent, ex. carte mains).
  if (!panel || panel.classList.contains('floating-win') || !panel._winOpt) return;
  var opt=panel._winOpt, r=panel.getBoundingClientRect();
  panel.classList.add('floating-win');
  panel._winDrag=true; panel._winResizable=!!opt.resizable;
  panel.style.setProperty('max-height','none','important');
  var newW=Math.round(r.width), newH=Math.round(r.height), left=r.left, top=r.top;
  // Detachement en TIRANT la barre de titre (dragEv present) : on retrecit en
  // vraie fenetre compacte, recentree sous le curseur (comme restaurer une
  // fenetre maximisee). Le resize (dragEv absent) garde la taille courante.
  if (dragEv){
    var dw=opt.defW||340, dh=opt.defH||300;
    // On FIXE les deux dimensions (et non "reduire si plus grand") : un bandeau
    // court comme reactions (1 rangee, ~120px) doit s'AGRANDIR a sa taille fenetre
    // pour montrer tous les emojis d'un coup.
    var relX=r.width ? (dragEv.clientX-r.left)/r.width : 0.5;
    left=Math.round(dragEv.clientX - relX*dw);
    newW=dw; newH=dh;
  }
  if(opt.maxW) newW=Math.min(newW, opt.maxW);
  if(opt.maxH) newH=Math.min(newH, opt.maxH);
  panel.style.width=newW+'px';
  panel.style.height=newH+'px';
  _placeWin(panel, left, top);
  if (opt.resizable) makeWinResizable(panel, opt.key, opt.minW, opt.minH, opt.maxW, opt.maxH);
  _applyWinZoom(panel);
  _saveWin(panel, opt.key);
}
function _attachFloatControls(panel, opt){
  // Ouvre "comme avant" (le bandeau garde sa position CSS) mais cable le drag +
  // les poignees de resize ; le panneau se detache en flottant au 1er geste.
  // Si une position a deja ete memorisee, rouvre directement en flottant.
  if (!panel) return;
  opt=opt||{}; panel._winOpt=opt;
  var hasSaved=false;
  try{ hasSaved=!!(opt.key && localStorage.getItem(opt.key)); }catch(e){}
  if (hasSaved){ _enableFloating(panel, opt); return; }
  panel._winDrag=true;
  if (opt.handle) makeWinDraggable(panel, opt.handle, opt.key);
  if (opt.resizable) makeWinResizable(panel, opt.key, opt.minW, opt.minH, opt.maxW, opt.maxH);
}
// Mode « mini » (windowshade) du lecteur de musique. Sur telephone / petite
// fenetre (hors _winGate) le panneau est normalement fige en bottom-sheet. Quand
// l'utilisateur le REPLIE, on le detache en fenetre flottante DEPLACABLE (poignee
// = barre de titre) ; a l'expansion on retablit l'ancrage fixe. Sur desktop /
// tablette le panneau est deja flottant a l'ouverture -> no-op. Appele par
// music.mjs (_applyShade) a chaque bascule ET au montage.
function _musicShadeFloat(shaded){
  var panel=document.getElementById('music-panel');
  if(!panel) return;
  if(_winGate()) return;                 // desktop/tablette : deja gere a l'ouverture
  if(shaded){
    if(!panel.classList.contains('floating-win'))
      _enableFloating(panel, { key:'pth_winpos_music', handle: panel.querySelector('.music-panel-title'), resizable:false, defW:340, zoom:true });
  } else {
    _disableFloating(panel);
  }
}
window.pthMusicShadeFloat = _musicShadeFloat;
function resetWindows(){
  // Bouton reset du header (≥900px) : efface TOUTES les positions/tailles
  // memorisees et remet chaque fenetre a son etat par defaut (bandeau, ou
  // position CSS d'origine pour les fenetres flottantes).
  ['pth_winpos_chat','pth_winpos_lobbychat','pth_winpos_log2','pth_winpos_react','pth_winpos_theme','pth_winpos_hands','pth_winpos_music','pth_odds_pos','pth_odds_w','pth_assist_pos','pth_assist_w','pth_winpos_assist','pth_win_adv','pth_win_help','pth_win_jr','pth_win_range'].forEach(function(k){ try{ localStorage.removeItem(k); }catch(e){} });
  ['g-chat-panel','lobby-chat-panel','g-log-panel','g-reaction-panel','music-panel'].forEach(function(id){ var p=document.getElementById(id); if(p) _disableFloating(p); });
  // Fenetres flottantes odds/assist : retire les styles inline -> retour aux defauts CSS.
  ['odds-monitor','assist-win'].forEach(function(id){ var el=document.getElementById(id); if(el){ ['left','top','right','bottom','width'].forEach(function(pr){ el.style[pr]=''; }); el.style.removeProperty('--ws'); } });
  var card=document.getElementById('hands-card-inner');
  if(card){
    card._winResizable=false;
    var hs=card.querySelectorAll('.win-rsz'); for(var i=0;i<hs.length;i++) hs[i].remove();
    card._winRszWired=false;
    ['position','left','top','right','bottom','width','height'].forEach(function(p){ card.style[p]=''; });
  }
  var rg=document.querySelector('#range-modal .range-card');
  if(rg) _disableFloating(rg);
  try{ if (typeof window.closeThemePanel==='function') window.closeThemePanel(); }catch(e){}
  try{ if (typeof window.pthAceResetWin==='function') window.pthAceResetWin(); }catch(e){}   // « More help » (web.310)
}
function makeChatResizable(panel, msgs, onResize) {
  if (!panel || !msgs) return;
  panel._onResize = onResize || null;   // callback de suivi (mis à jour à chaque appel)
  if (panel._resizable) return;
  panel._resizable = true;
  // Mémorise les valeurs par défaut (styles inline d'origine) pour pouvoir
  // réinitialiser à la taille d'ouverture (cf. resetChatSize).
  panel._origMaxH = panel.style.maxHeight || '';
  msgs._origMaxH  = msgs.style.maxHeight || '';
  msgs._origFlex  = msgs.style.flex || '';

  var handle = document.createElement('div');
  handle.className = 'chat-resize-handle';
  try { handle.title = t('resizeTooltip'); } catch (e) { handle.title = 'Drag to resize'; }
  handle.setAttribute('data-i18n-title', 'resizeTooltip');
  var grip = document.createElement('div');
  grip.className = 'crh-grip';
  handle.appendChild(grip);
  panel.appendChild(handle);

  var dragging = false, startY = 0, startH = 0;
  function maxH() { return Math.round(window.innerHeight * 0.6); } // 60% écran
  function clamp(h) { return Math.max(50, Math.min(maxH(), h)); }

  handle.addEventListener('pointerdown', function(e) {
    dragging = true;
    startY = e.clientY;
    startH = msgs.getBoundingClientRect().height;
    handle.classList.add('dragging');
    // Lève les plafonds (max-height CSS !important du chat en jeu,
    // max-height inline du chat lobby) pour laisser grandir le panneau.
    panel.style.setProperty('max-height', 'none', 'important');
    msgs.style.setProperty('max-height', 'none', 'important');
    msgs.style.flex = 'none';
    try { handle.setPointerCapture(e.pointerId); } catch (_) {}
    e.preventDefault();
  });
  handle.addEventListener('pointermove', function(e) {
    if (!dragging) return;
    msgs.style.height = clamp(startH + (e.clientY - startY)) + 'px';
    if (panel._onResize) panel._onResize();
  });
  function end(e) {
    if (!dragging) return;
    dragging = false;
    handle.classList.remove('dragging');
    try { handle.releasePointerCapture(e.pointerId); } catch (_) {}
    if (panel._onResize) panel._onResize();
  }
  handle.addEventListener('pointerup', end);
  handle.addEventListener('pointercancel', end);
  // Re-borne si l'écran tourne / change de taille.
  window.addEventListener('resize', function() {
    if (msgs.style.height) msgs.style.height = clamp(parseInt(msgs.style.height, 10) || 0) + 'px';
  });
}

// Réinitialise un chat à sa taille d'ouverture par défaut (annule un
// éventuel glissement précédent) en restaurant les styles inline d'origine.
function resetChatSize(panel, msgs) {
  if (!panel || !msgs) return;
  panel.style.removeProperty('max-height');
  if (panel._origMaxH) panel.style.maxHeight = panel._origMaxH;
  msgs.style.height = '';
  msgs.style.removeProperty('max-height');
  if (msgs._origMaxH) msgs.style.maxHeight = msgs._origMaxH;
  msgs.style.flex = msgs._origFlex || '';
}

// Bouton durchsage : réservé aux admins pokerth.net (playerRights === 3),
// comme le bouton kickban du popup joueur et l'icône « campaign » du client
// QML. Le serveur revérifie de toute façon.
function _syncGlobalNoticeBtn() {
  var b = document.getElementById('l-gn-btn');
  if (!b) return;
  // HORS de l'IIFE App : `S` n'existe pas ici (ReferenceError avalée par
  // msg-lobby, le bouton ne s'affichait jamais) — passer par le pont.
  var S = window.PthState || {};
  var mine = (S._playerRights && S.myId) ? (S._playerRights[S.myId] || 0) : 0;
  b.style.display = (mine === 3) ? '' : 'none';
}
window._syncGlobalNoticeBtn = _syncGlobalNoticeBtn;

function toggleLobbyChat() {
  _syncGlobalNoticeBtn();
  try { if (window._syncSuggestBtn) window._syncSuggestBtn(); } catch (e) {}
  // Chat intégré au lobby (colonne en wide, sous les tables en compact)
  // → plus de fenêtre flottante ni d'overlay. No-op dans les deux modes.
  return;
}


function renderHandsHelp() {
  // Icône + couleur de force (vert fort → gris faible) par combinaison
  var ICONS = ['👑','🔥','🎯','🏠','💧','🪜','✦','✌️','👥','⬆️'];
  var RAMP  = ['#2ecc71','#4cc56a','#79c25c','#a6bd4f','#c9b144','#d09a3c','#cf8038','#b86a37','#946035','#6f6353'];
  // c = cartes [valeur, couleur] ; k = 1 si la carte COMPTE (éclairée), 0 si inutile (estompée)
  var hands = [
    { c:[['A','♠'],['K','♠'],['Q','♠'],['J','♠'],['10','♠']], k:[1,1,1,1,1], n:'h1n', d:'h1d' },
    { c:[['9','♣'],['8','♣'],['7','♣'],['6','♣'],['5','♣']],   k:[1,1,1,1,1], n:'h2n', d:'h2d' },
    { c:[['K','♠'],['K','♥'],['K','♦'],['K','♣'],['8','♣']],   k:[1,1,1,1,0], n:'h3n', d:'h3d' },
    { c:[['Q','♣'],['Q','♥'],['Q','♠'],['J','♦'],['J','♣']],   k:[1,1,1,1,1], n:'h4n', d:'h4d' },
    { c:[['A','♦'],['J','♦'],['8','♦'],['5','♦'],['2','♦']],   k:[1,1,1,1,1], n:'h5n', d:'h5d' },
    { c:[['9','♠'],['8','♥'],['7','♣'],['6','♦'],['5','♠']],   k:[1,1,1,1,1], n:'h6n', d:'h6d' },
    { c:[['7','♠'],['7','♦'],['7','♣'],['K','♠'],['4','♥']],   k:[1,1,1,0,0], n:'h7n', d:'h7d' },
    { c:[['J','♣'],['J','♥'],['5','♦'],['5','♠'],['A','♣']],   k:[1,1,1,1,0], n:'h8n', d:'h8d' },
    { c:[['A','♥'],['A','♠'],['9','♦'],['6','♣'],['3','♠']],   k:[1,1,0,0,0], n:'h9n', d:'h9d' },
    { c:[['A','♠'],['K','♦'],['9','♣'],['5','♥'],['2','♠']],   k:[1,0,0,0,0], n:'h10n', d:'h10d' },
  ];
  var inner = document.getElementById('hands-card-inner');
  if (!inner) return;
  function cardHtml(card, isKey) {
    var suit = card[1];
    var red  = (suit === '♥' || suit === '♦');
    var cls  = 'hc' + (red ? ' r' : '') + (isKey ? ' key' : ' kick');
    return '<div class="' + cls + '">' + card[0] + '<br>' + suit + '</div>';
  }
  var rows = hands.map(function(h, i) {
    var cards = h.c.map(function(card, j) { return cardHtml(card, h.k[j]); }).join('');
    // Description : "base||exemple" → l'exemple est mis en valeur (or)
    var parts = String(t(h.d)).split('||');
    var desc  = parts[0] + (parts[1] ? ' <span class="hand-ex">' + parts[1] + '</span>' : '');
    return '<div class="hand-row">'
      + '<div class="hand-rail" style="background:' + RAMP[i] + '"></div>'
      + '<div class="hand-rank" style="color:' + RAMP[i] + '">' + (i + 1) + '</div>'
      + '<div class="hand-cards">' + cards + '</div>'
      + '<div class="hand-info">'
      +   '<div class="hand-name"><span class="hand-ico">' + ICONS[i] + '</span>' + t(h.n) + '</div>'
      +   '<div class="hand-desc">' + desc + '</div>'
      + '</div></div>';
  }).join('');
  var legend = '<div class="hands-legend">'
    + '<span class="hl"><span class="hl-mini bright"></span>' + t('handsLegOk') + '</span>'
    + '<span class="hl"><span class="hl-mini dim"></span>' + t('handsLegNo') + '</span>'
    + '<span class="hl"><span class="hl-grad"></span>' + t('handsLegForce') + '</span>'
    + '</div>';
  inner.innerHTML = '<div class="g-chat-panel-header"><span style="font-size:0.65rem;color:var(--chatlog-muted, var(--gold-dim));letter-spacing:0.15em;text-transform:uppercase">' + t('handsTitle') + '</span>'
    + '<button onclick="toggleHandsHelp()" title="' + t('handsClose') + '" style="background:none;border:none;color:var(--chatlog-text2, var(--chatlog-text, var(--text)));cursor:pointer;font-size:0.85rem;padding:0 4px">\u2715</button></div>'
    + '<div class="hands-scroll">'
    + legend
    + rows
    + '</div>';
}

// Indicateur d'état uniforme pour les bascules du menu •••  : ✓ vert quand
// l'option est active, rien quand elle est inactive (pas de croix). Centralisé
// ici pour que toutes les entrées (assistance, vibration, voix, auto,
// quick-bet…) partagent exactement la même visualisation.
function _menuTick(on) {
  return on ? ' <span class="menu-tick">\u2713</span>' : '';
}
window._menuTick = _menuTick;

function toggleHeaderOverflow(e) {
  if (e) e.stopPropagation();
  var m = document.getElementById('g-overflow-menu');
  if (!m) return;
  // ADMIN section divider: mirror the admin buttons' visibility (use the
  // Close-table item as proxy — it's shown whenever the user is admin).
  try {
    var asep = document.getElementById('admin-sep-mob');
    var aref = document.getElementById('admin-close-mob');
    if (asep && aref) {
      var adminOn = (aref.style.display !== 'none');
      asep.style.display = adminOn ? '' : 'none';
    }
  } catch(e13) {}
  m.classList.toggle('open');
}
function closeHeaderOverflow() {
  var m = document.getElementById('g-overflow-menu');
  if (m) m.classList.remove('open');
}
// Lobby twin: identical behaviour but targets the lobby overflow menu.
// Kept as a separate pair of functions so the inline onclick handlers in
// the lobby HTML stay self-explanatory ('Lobby' in the name), and so we
// don't have to thread a menu id through every callsite.
function toggleLobbyOverflow(e) {
  if (e) e.stopPropagation();
  var m = document.getElementById('l-overflow-menu');
  if (!m) return;
  m.classList.toggle('open');
}
function closeLobbyOverflow() {
  var m = document.getElementById('l-overflow-menu');
  if (m) m.classList.remove('open');
}
function toggleConnectOverflow(e) {
  if (e) e.stopPropagation();
  var m = document.getElementById('connect-overflow-menu');
  if (!m) return;
  m.classList.toggle('open');
}
function closeConnectOverflow() {
  var m = document.getElementById('connect-overflow-menu');
  if (m) m.classList.remove('open');
}
// Jumeau « Créer une partie » : même roue crantée + globe que le lobby
// (demande narmod : header uniforme sur la page de création).
function toggleCreateOverflow(e) {
  if (e) e.stopPropagation();
  var m = document.getElementById('cr-overflow-menu');
  if (!m) return;
  m.classList.toggle('open');
}
function closeCreateOverflow() {
  var m = document.getElementById('cr-overflow-menu');
  if (m) m.classList.remove('open');
}
// Lobby brand: tap the ♠ to slide the POKERTH word in/out. Only matters on
// narrow screens (CSS keeps the word always visible on wide ones). Auto-folds
// again after a few seconds so it doesn't permanently re-crowd the header.
var _brandFoldTimer = null;
function toggleBrandName() {
  var b = document.getElementById('lobby-brand');
  if (!b) return;
  var nowOpen = b.classList.toggle('brand-open');
  clearTimeout(_brandFoldTimer);
  if (nowOpen) {
    _brandFoldTimer = setTimeout(function () {
      b.classList.remove('brand-open');
    }, 4000);
  }
}
// Fermer le menu si on clique ailleurs (game + lobby)
document.addEventListener('click', function(e) {
  var btn = document.getElementById('g-overflow-btn');
  var menu = document.getElementById('g-overflow-menu');
  if (menu && btn && !btn.contains(e.target) && !menu.contains(e.target)) {
    menu.classList.remove('open');
  }
  var lbtn = document.getElementById('l-overflow-btn');
  var lmenu = document.getElementById('l-overflow-menu');
  if (lmenu && lbtn && !lbtn.contains(e.target) && !lmenu.contains(e.target)) {
    lmenu.classList.remove('open');
  }
  var cbtn = document.getElementById('connect-overflow-btn');
  var cmenu = document.getElementById('connect-overflow-menu');
  if (cmenu && cbtn && !cbtn.contains(e.target) && !cmenu.contains(e.target)) {
    cmenu.classList.remove('open');
  }
  var crbtn = document.getElementById('cr-overflow-btn');
  var crmenu = document.getElementById('cr-overflow-menu');
  if (crmenu && crbtn && !crbtn.contains(e.target) && !crmenu.contains(e.target)) {
    crmenu.classList.remove('open');
  }
});

function toggleHandsHelp(invoker) {
  var ov = document.getElementById('hands-overlay');
  var card = document.getElementById('hands-card-inner');
  if (!ov || !card) return;
  var opening = ov.style.display === 'none';
  var fallbackBtn = document.getElementById('hands-toggle-btn');
  var btn = opening && invoker && invoker.getAttribute && invoker.getAttribute('aria-controls') === 'hands-card-inner'
    ? invoker : (card._drawerInvoker || fallbackBtn);
  if (opening) card._drawerInvoker = btn;
  if (opening) {
    renderHandsHelp();
    ov.style.display = 'flex';
    card.setAttribute('aria-hidden', 'false');
    card._winRszWired = false;   // innerHTML reconstruit -> re-injecter les poignees
    // Même système de fenêtre que chat/journal/réactions (déplaçable + redimensionnable partout).
    _configureGameDrawer(card, true, btn);
  } else {
    if (card.classList.contains('floating-win')) _saveWin(card, 'pth_winpos_hands');
    ov.style.display = 'none';
    card.setAttribute('aria-hidden', 'true');
    _configureGameDrawer(card, false, btn);
  }
  document.querySelectorAll('[aria-controls="hands-card-inner"]').forEach(function(trigger) {
    trigger.setAttribute('aria-expanded', opening ? 'true' : 'false');
  });
}

// ── État « fenêtre ouverte » : le bouton déclencheur passe en or ────────
// Convention unique de toute l'application : un bouton qui a ouvert une
// fenêtre, un panneau ou un menu reste en or tant que celle-ci est visible.
// Rendu : .win-open / body.adv-no-winopen (pokerth.css).
// Le registre est DÉCLARATIF et aucun toggle existant n'est modifié : un
// MutationObserver par fenêtre resynchronise les boutons, ce qui couvre
// aussi les fermetures indirectes (clic hors menu, Escape, back-guard).
// Hors périmètre volontaire : 📳 vibration, 🤐 voix, coupure du son et les
// ✕ de fermeture (états propres), onglets internes (.rk-tab/.gip-tab ont
// déjà leur .active). ⛶ plein écran est inclus (demande narmod).
var _WIN_BTN = [
  { win: 'ranking-modal',         mode: 'display', btns: ['ranking-btn-connect', 'ranking-btn-lobby', 'ranking-btn-create', 'ranking-btn-game'] },
  { win: 'tableranking-modal',    mode: 'display', btns: ['tableranking-btn-game'] },
  { win: 'forum-modal',           mode: 'display', btns: ['forum-btn-connect', 'forum-btn-lobby', 'forum-btn-create', 'forum-btn-game'] },
  { win: 'pm-modal',              mode: 'display', btns: ['pm-btn-lobby'] },
  { win: 'adv-modal',             mode: 'display', btns: ['adv-opts-connect-mob', 'adv-opts-lobby-mob', 'adv-opts-create-mob', 'adv-opts-mob'] },
  { win: 'music-panel',           mode: 'display', btns: ['music-toggle-connect-mob', 'music-toggle-lobby-mob', 'music-toggle-create-mob', 'music-toggle-game-mob'] },
  { win: 'g-chat-panel',          mode: 'display', btns: ['chat-toggle-btn', 'adaptive-chat-toggle'] },
  { win: 'g-log-panel',           mode: 'display', btns: ['log-toggle-btn', 'adaptive-info-toggle'] },
  { win: 'g-reaction-panel',      mode: 'display', btns: ['react-toggle-btn', 'adaptive-reactions-toggle'] },
  { win: 'hands-overlay',         mode: 'display', btns: ['hands-toggle-btn', 'adaptive-hands-toggle'] },
  { win: 'players-panel',         mode: 'display', btns: ['h-players'], sel: ['.fbar-players'] },
  { win: 'avatar-popup',          mode: 'display', btns: ['av-trigger'] },
  { win: 'l-chat-emoji-panel',    mode: 'display', btns: ['l-chat-emoji-toggle'] },
  { win: 'g-chat-emoji-panel',    mode: 'display', btns: ['g-chat-emoji-toggle'] },
  { win: 'connect-overflow-menu', mode: 'open',    btns: ['connect-overflow-btn'] },
  { win: 'l-overflow-menu',       mode: 'open',    btns: ['l-overflow-btn'] },
  { win: 'cr-overflow-menu',      mode: 'open',    btns: ['cr-overflow-btn'] },
  { win: 'g-overflow-menu',       mode: 'open',    btns: ['g-overflow-btn'] },
  { win: 'pv-overflow-menu',      mode: 'open',    btns: ['pv-overflow-btn'] },
  { win: 'cl-links-connect',      mode: 'details', sel: ['#cl-links-connect > summary'] }
];
// 🏆 Classement : traite exactement comme les autres boutons d'en-tete
// (.rk-trophy suit currentColor -> neutre au repos, or quand la fenetre est
// ouverte). Plus de variante anneau (demande narmod 23/07).
window._winBtn = function (btn, open) {
  if (!btn || !btn.classList) return;
  btn.classList.toggle('win-open', !!open);
};
function _winBtnEls(e) {
  var out = [], i;
  var ids = e.btns || [];
  for (i = 0; i < ids.length; i++) { var b = document.getElementById(ids[i]); if (b) out.push(b); }
  var sels = e.sel || [];
  for (i = 0; i < sels.length; i++) {
    try { var n = document.querySelectorAll(sels[i]); for (var j = 0; j < n.length; j++) out.push(n[j]); } catch (_e) {}
  }
  return out;
}
function _winIsOpen(e) {
  var w = document.getElementById(e.win);
  if (!w) return false;
  if (e.mode === 'open')    return w.classList.contains('open');
  if (e.mode === 'details') return !!w.open;
  return w.style.display !== 'none' && !w.hidden;
}
function _syncWinBtns() {
  var off = false;
  try { off = document.body.classList.contains('adv-no-winopen'); } catch (e) {}
  var i, j, els;
  for (i = 0; i < _WIN_BTN.length; i++) {
    els = _winBtnEls(_WIN_BTN[i]);
    var on = !off && _winIsOpen(_WIN_BTN[i]);
    for (j = 0; j < els.length; j++) window._winBtn(els[j], on);
  }
  // ⛶ plein écran : bascule sans fenêtre, dorée à la demande (visibilité).
  var fs = !off && !!(document.fullscreenElement || document.webkitFullscreenElement);
  window._winBtn(document.getElementById('fs-btn-lobby'), fs);
  window._winBtn(document.getElementById('fs-btn-game'), fs);
  // 🔊 popover son : créé / détruit dynamiquement dans <body>.
  var sp = false; try { sp = !off && !!document.querySelector('.sound-pop'); } catch (e) {}
  window._winBtn(document.getElementById('sound-toggle-btn'), sp);
  window._winBtn(document.getElementById('adv-sound-btn'), sp);
}
window._syncWinBtns = _syncWinBtns;
var _winSyncQueued = false;
function _winSyncSoon() {
  if (_winSyncQueued) return;
  _winSyncQueued = true;
  var run = function () { _winSyncQueued = false; _syncWinBtns(); };
  if (window.requestAnimationFrame) window.requestAnimationFrame(run); else setTimeout(run, 16);
}
window._winSyncSoon = _winSyncSoon;
function _winBtnWire() {
  var obs = null;
  try { obs = new MutationObserver(_winSyncSoon); } catch (e) { _syncWinBtns(); return; }
  var seen = {};
  for (var i = 0; i < _WIN_BTN.length; i++) {
    var id = _WIN_BTN[i].win;
    if (seen[id]) continue; seen[id] = 1;
    var w = document.getElementById(id);
    if (w) { try { obs.observe(w, { attributes: true, attributeFilter: ['style', 'class', 'open', 'hidden'] }); } catch (e) {} }
  }
  // Popover son : seul cas où l'élément n'existe pas en permanence.
  try { obs.observe(document.body, { childList: true }); } catch (e) {}
  try {
    document.addEventListener('fullscreenchange', _winSyncSoon);
    document.addEventListener('webkitfullscreenchange', _winSyncSoon);
  } catch (e) {}
  _syncWinBtns();
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', _winBtnWire);
else _winBtnWire();

// ── Ordre d'empilement des fenetres (« la derniere ouverte passe dessus ») ──
// Avant : chaque panneau portait un z-index CONSTANT en CSS (chat 100, journal
// et joueurs 99, reactions 101, Combinaisons 200, musique 900). Le classement
// etait donc fige par identite : le chat restait au-dessus du panneau Joueurs
// meme ouvert apres lui, et aucun clic ne pouvait le faire passer devant.
// Desormais tous partent de la meme base CSS (100) et c'est ce compteur partage
// qui les differencie : une fenetre remonte quand elle s'ouvre ET quand on la
// touche (comportement fenetre standard). Bande bornee a _WS_TOP pour rester
// SOUS les dialogues et pages plein ecran (z-index 120+).
var _WS_BASE = 100, _WS_TOP = 118, _wsZ = _WS_BASE;
// cls : tiroirs du lobby, ouverts par une classe sur #s-lobby (pas par display).
var _WIN_STACK = [
  { id: 'g-chat-panel' },
  { id: 'lobby-chat-panel' },
  { id: 'g-log-panel' },
  { id: 'g-reaction-panel' },
  { id: 'g-assist-panel' },
  { id: 'music-panel' },
  { id: 'hands-overlay' },
  { id: 'players-panel',  cls: 'pl-open' },
  { id: 'lobby-gameinfo', cls: 'gi-open' }
];
function _wsOpen(e) {
  var el = document.getElementById(e.id);
  if (!el) return false;
  if (e.cls) {
    // En lobby, le tiroir est toujours display:flex et coulisse par transform :
    // seule la classe dit s'il est ouvert.
    var sl = document.getElementById('s-lobby');
    try { if (sl && getComputedStyle(sl).display !== 'none') return sl.classList.contains(e.cls); } catch (x) {}
  }
  try { return getComputedStyle(el).display !== 'none' && !el.hidden; } catch (x) { return false; }
}
// Renormalise la bande quand le compteur atteint le plafond : on reattribue
// _WS_BASE+1.. en conservant l'ordre relatif courant.
function _wsNormalize() {
  var arr = [], i, el, z;
  for (i = 0; i < _WIN_STACK.length; i++) {
    el = document.getElementById(_WIN_STACK[i].id); if (!el) continue;
    z = parseInt(el.style.zIndex, 10); if (!z) continue;
    arr.push({ el: el, z: z });
  }
  arr.sort(function (a, b) { return a.z - b.z; });
  _wsZ = _WS_BASE;
  for (i = 0; i < arr.length; i++) arr[i].el.style.zIndex = (++_wsZ);
}
function _winRaise(id) {
  var el = document.getElementById(id); if (!el) return;
  if (parseInt(el.style.zIndex, 10) === _wsZ) return;   // deja au sommet
  if (_wsZ >= _WS_TOP) _wsNormalize();
  el.style.zIndex = (++_wsZ);
}
window._winRaise = _winRaise;
var _wsWas = {};
function _wsSync() {
  for (var i = 0; i < _WIN_STACK.length; i++) {
    var e = _WIN_STACK[i], op = _wsOpen(e);
    if (op && !_wsWas[e.id]) _winRaise(e.id);          // transition ferme -> ouvert
    _wsWas[e.id] = op;
  }
}
var _wsQueued = false;
function _wsSyncSoon() {
  if (_wsQueued) return;
  _wsQueued = true;
  var run = function () { _wsQueued = false; _wsSync(); };
  if (window.requestAnimationFrame) window.requestAnimationFrame(run); else setTimeout(run, 16);
}
function _winStackWire() {
  var i, el;
  for (i = 0; i < _WIN_STACK.length; i++) {
    el = document.getElementById(_WIN_STACK[i].id); if (!el) continue;
    // Capture : la fenetre remonte meme si un enfant stoppe la propagation.
    (function (id, node) {
      try { node.addEventListener('pointerdown', function () { _winRaise(id); }, true); } catch (x) {}
    })(_WIN_STACK[i].id, el);
  }
  var obs = null;
  try { obs = new MutationObserver(_wsSyncSoon); } catch (x) { _wsSync(); return; }
  for (i = 0; i < _WIN_STACK.length; i++) {
    el = document.getElementById(_WIN_STACK[i].id);
    if (el) { try { obs.observe(el, { attributes: true, attributeFilter: ['style', 'class', 'hidden'] }); } catch (x) {} }
  }
  var sl = document.getElementById('s-lobby');
  if (sl) { try { obs.observe(sl, { attributes: true, attributeFilter: ['class'] }); } catch (x) {} }
  _wsSync();
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', _winStackWire);
else _winStackWire();

// ── Unread-chat badge ──────────────────────────────────────────────
// A small red counter on the 💬 buttons (game header, lobby header) so a
// closed chat panel never hides incoming messages.
// Incremented from addGameChat/addChat when the relevant panel is closed,
// and cleared when the user opens the chat.
window._unreadChat = 0;
function _chatBadgeHtml(n) {
  return '<span class="chat-badge">' + (n > 99 ? '99+' : n) + '</span>';
}
function _renderChatBadge() {
  var n = window._unreadChat || 0;
  ['chat-toggle-btn', 'lobby-chat-btn'].forEach(function (id) {
    var btn = document.getElementById(id);
    if (!btn) return;
    var old = btn.querySelector('.chat-badge');
    if (old) old.remove();
    if (n > 0) {
      btn.insertAdjacentHTML('beforeend', _chatBadgeHtml(n));
    }
  });
}
function bumpUnreadChat() {
  window._unreadChat = (window._unreadChat || 0) + 1;
  _renderChatBadge();
  refreshAppBadge();
}
function clearUnreadChat() {
  window._unreadChat = 0;
  _renderChatBadge();
  refreshAppBadge();
}

// ── App-icon badge (PWA Badging API) ────────────────────────────────
// Shows a count on the installed app icon = unread chat + (1 if it's your
// turn). Feature-detected: Chrome/Edge desktop+Android and installed
// Safari/iOS support it; Firefox does not, so it silently no-ops there.
window._badgeTurn = false;
function refreshAppBadge() {
  try {
    if (!('setAppBadge' in navigator)) return;
    var n = (window._unreadChat || 0) + (window._badgeTurn ? 1 : 0);
    if (n > 0) navigator.setAppBadge(n);
    else if ('clearAppBadge' in navigator) navigator.clearAppBadge();
  } catch (e) { /* badge unavailable — ignore */ }
}
window.refreshAppBadge = refreshAppBadge;

// ── Selecteur d'emoji pour le chat de jeu (desktop) ──────────────
// Bouton dans la barre de saisie (visible seulement sur appareil a souris) qui
// ouvre une grille d'emojis ; un clic insere l'emoji a la position du curseur
// dans #g-chat-in. sendGameChat envoie le texte tel quel (les emojis sont du
// simple texte unicode -> aucun changement de protocole). Equivalent des
// emoticones du chat du client officiel.
var CHAT_EMOJIS = ['😀','😃','😄','😁','😆','😅','😂','🤣','😊','🙂','😉','😍','😘','😋','😎','🤩','🥳','🤔','😐','😏','😒','😞','😢','😭','😤','😠','😡','🥺','😱','😬','🙄','😴','🤗','🤫','👍','👎','👏','🙌','🙏','💪','🤝','👋','❤️','🔥','⭐','✨','🎉','💯','✅','❌','🃏','♠️','♥️','♦️','♣️'];
function _populateChatEmojis(panel, inputId) {
  if (!panel || panel._filled) return;
  panel._filled = true;
  function row(list) {
    var s = '';
    for (var i = 0; i < list.length; i++) {
      var e = list[i];
      s += '<button type="button" class="chat-emoji-btn" data-emo="' + e + '" title="' + e + '">' + e + '</button>';
    }
    return s;
  }
  var tt = function (k, fb) { return (typeof t === 'function' && t(k) !== k) ? t(k) : fb; };
  var h = '<div class="chat-emoji-sec">' + tt('emoFrequent', 'Frequent') + '</div>' + row(CHAT_EMOJIS)
        + '<div class="chat-emoji-sec">' + tt('emoAll', 'All') + '</div>' + row(CHAT_EMOJIS_ALL);
  panel.innerHTML = h;
  panel.addEventListener('click', function(ev) {
    var b = (ev.target && ev.target.closest) ? ev.target.closest('.chat-emoji-btn') : null;
    if (b && b.getAttribute('data-emo')) insertChatEmoji(b.getAttribute('data-emo'), inputId);
  });
}
function insertChatEmoji(emo, inputId) {
  var inp = document.getElementById(inputId || 'g-chat-in');
  if (!inp) return;
  var s = (inp.selectionStart != null) ? inp.selectionStart : inp.value.length;
  var e = (inp.selectionEnd   != null) ? inp.selectionEnd   : inp.value.length;
  inp.value = inp.value.slice(0, s) + emo + inp.value.slice(e);
  var pos = s + emo.length;
  inp.focus();
  try { inp.setSelectionRange(pos, pos); } catch (err) {}
}
function toggleChatEmojiPicker(btn) {
  // btn porte data-panel (id de la grille) + data-input (id du champ de saisie).
  // Sans argument -> chat de jeu (compat).
  var panelId = (btn && btn.getAttribute && btn.getAttribute('data-panel')) || 'g-chat-emoji-panel';
  var inputId = (btn && btn.getAttribute && btn.getAttribute('data-input')) || 'g-chat-in';
  var panel = document.getElementById(panelId);
  if (!panel) return;
  _populateChatEmojis(panel, inputId);
  var open = (panel.style.display === 'none' || panel.style.display === '');
  panel.style.display = open ? 'grid' : 'none';
  if (btn && btn.classList) btn.classList.toggle('active', open);
  if (open) { var inp = document.getElementById(inputId); if (inp) inp.focus(); }
}
// ── Chat : complétion Tab des pseudos + historique de saisie ↑/↓ ────────────
// (parité ChatBox QML, bible §11). Historique partagé jeu+lobby, en mémoire
// de session, plafonné. Toute frappe réinitialise l'itération Tab ET la
// navigation d'historique, comme le QML.
var _chatHist = [];
var _CHAT_HIST_MAX = 50;
window._chatPushHist = function (txt) {
  if (!txt) return;
  if (_chatHist[_chatHist.length - 1] === txt) return; // pas de doublon consécutif
  _chatHist.push(txt);
  if (_chatHist.length > _CHAT_HIST_MAX) _chatHist.shift();
};
// ── Easter egg : code Konami — effet commun au clavier (chat de partie,
// ci-dessous) et à la manette (modules/ui/gamepad.mjs, ↑↑↓↓←→←→ B A en mode
// Navigation à la table). Confettis (Reactions.playReactionFx) + trophée
// secret « L'œuf » (grantSecret — catégorie cachée, visible seulement une
// fois débloqué). Au plus une fois toutes les 5 s. Renvoie true si joué.
var _konamiLast = 0;
function _konamiEgg() {
  var _nw = Date.now(); if (_nw - _konamiLast < 5000) return false; _konamiLast = _nw;
  try {
    var _fx = window.Reactions && window.Reactions.playReactionFx;
    if (_fx) {
      _fx('\u{1F95A}', window.innerWidth * 0.5, window.innerHeight * 0.45);
      setTimeout(function () { try { _fx('\u{1F389}', window.innerWidth * 0.5, window.innerHeight * 0.45); } catch (e3) {} }, 180);
    }
  } catch (e4) {}
  try {
    import('/modules/achievements/index.mjs').then(function (m) {
      var a = (m && m.grantSecret) ? m.grantSecret('egg') : null;
      if (a) { try { window.dispatchEvent(new CustomEvent('pth-achievement', { detail: a })); } catch (e5) {} }
    }).catch(function () {});
  } catch (e6) {}
  return true;
}
window._konamiEgg = _konamiEgg;
function _attachChatKeys(id, gameScope) {
  var inp = document.getElementById(id);
  if (!inp || inp._keysAttached) return;
  inp._keysAttached = true;
  // ── Easter egg : code Konami (↑↑↓↓←→←→BA) dans le chat de PARTIE, tous
  // modes. Détection passive via addEventListener (n'interfère ni avec
  // l'historique ↑/↓ ni avec la saisie) ; le « ba » final est retiré du champ.
  // Effet : _konamiEgg() ci-dessus.
  if (gameScope) {
    var _kSeq = ['ArrowUp','ArrowUp','ArrowDown','ArrowDown','ArrowLeft','ArrowRight','ArrowLeft','ArrowRight','b','a'];
    var _kPos = 0;
    inp.addEventListener('keydown', function (e) {
      var k = (e.key && e.key.length === 1) ? e.key.toLowerCase() : e.key;
      _kPos = (k === _kSeq[_kPos]) ? _kPos + 1 : (k === _kSeq[0] ? 1 : 0);
      if (_kPos < _kSeq.length) return;
      _kPos = 0;
      if (!_konamiEgg()) return;
      // keydown comes before the « a » is inserted: keep it out, drop the « b ».
      e.preventDefault();
      try { inp.value = inp.value.replace(/b$/i, ''); } catch (e2) {}
    });
  }
  var tabMatches = null, tabIdx = 0, tabStart = 0, tabTail = '';
  var histIdx = -1, draft = '';
  function caretEnd() { try { inp.setSelectionRange(inp.value.length, inp.value.length); } catch (e) {} }
  // L'envoi sur Entrée était câblé en attribut inline (onkeydown) : on le
  // reprend ici pour pouvoir intercepter Entrée quand le popup d'emotes est
  // ouvert (accepter la suggestion au lieu d'envoyer), comme le QML.
  var sendOnEnter = inp.onkeydown;
  inp.onkeydown = null;

  // ── Popup de suggestion d'emotes (":smi…" → 😄) — parité ChatBox QML ──
  // Codes = window.chatEmoteShortcodes() (chat-emotes.js), EXACTEMENT ce que
  // applyChatEmoteShortcuts remplace à l'affichage. Déclencheur : ":" (début
  // ou après espace) + ≥2 caractères [a-z0-9_+-] avant le curseur — le ":"
  // fermant fait disparaître le popup de lui-même. Préfixes d'abord, puis
  // sous-chaînes. Esc masque jusqu'à la prochaine frappe.
  var esMatches = [], esIdx = 0, esTokenStart = -1, esSuppressed = false;
  var esBox = null;
  function esEnsureBox() {
    if (esBox) return esBox;
    esBox = document.createElement('div');
    esBox.className = 'emote-suggest';
    (inp.parentElement || document.body).appendChild(esBox);
    return esBox;
  }
  function esOpen() { return esMatches.length > 0 && !esSuppressed && document.activeElement === inp; }
  function esRender() {
    var box = esEnsureBox();
    if (!esOpen()) { box.classList.remove('open'); return; }
    box.innerHTML = '';
    for (var i = 0; i < esMatches.length; i++) (function (i) {
      var row = document.createElement('div');
      row.className = 'es-row' + (i === esIdx ? ' sel' : '');
      var em = document.createElement('span'); em.className = 'es-emoji'; em.textContent = esMatches[i].emoji;
      var cd = document.createElement('span'); cd.className = 'es-code';  cd.textContent = ':' + esMatches[i].code + ':';
      row.appendChild(em); row.appendChild(cd);
      // mousedown neutralisé : le clic ne vole pas le focus du champ (parité TapHandler QML)
      row.addEventListener('mousedown', function (e) { e.preventDefault(); });
      row.addEventListener('mouseenter', function () { if (esIdx !== i) { esIdx = i; esRender(); } });
      row.addEventListener('click', function () { esIdx = i; esAccept(); inp.focus(); });
      box.appendChild(row);
    })(i);
    box.classList.add('open');
    var sel = box.children[esIdx];
    if (sel && sel.scrollIntoView) sel.scrollIntoView({ block: 'nearest' });
  }
  function esUpdate() {
    var pos = (inp.selectionStart != null) ? inp.selectionStart : inp.value.length;
    var upto = inp.value.slice(0, pos);
    var m = upto.match(/(?:^|\s):([a-z0-9_+-]{2,})$/);
    if (!m || typeof window.chatEmoteShortcodes !== 'function') {
      if (esMatches.length) { esMatches = []; esRender(); }
      return;
    }
    var typed = m[1];
    esTokenStart = upto.length - typed.length - 1;
    var list = window.chatEmoteShortcodes();
    var pre = [], sub = [];
    for (var i = 0; i < list.length; i++) {
      var idx = list[i].code.indexOf(typed);
      if (idx === 0) pre.push(list[i]);
      else if (idx > 0) sub.push(list[i]);
    }
    esMatches = pre.concat(sub);
    esIdx = 0;
    esRender();
  }
  // Remplace le token tapé (":smi") par l'EMOJI du choix — WYSIWYG et moins
  // d'octets dans la limite serveur de 128, exactement comme le QML.
  function esAccept() {
    if (!esMatches.length) return;
    var e = esMatches[Math.min(esIdx, esMatches.length - 1)];
    var pos = (inp.selectionStart != null) ? inp.selectionStart : inp.value.length;
    inp.value = inp.value.slice(0, esTokenStart) + e.emoji + inp.value.slice(pos);
    var np = esTokenStart + e.emoji.length;
    try { inp.setSelectionRange(np, np); } catch (err) {}
    esMatches = [];
    esRender();
  }
  inp.addEventListener('input', function () { esSuppressed = false; esUpdate(); });
  inp.addEventListener('click', esUpdate);
  inp.addEventListener('focus', esUpdate);
  inp.addEventListener('blur', function () { esRender(); });
  inp.addEventListener('keyup', function (e) {
    if (e.key === 'ArrowLeft' || e.key === 'ArrowRight' || e.key === 'Home' || e.key === 'End') esUpdate();
  });

  inp.addEventListener('keydown', function (e) {
    // ── Popup d'emotes ouvert : ↑/↓ = sélection (circulaire), Tab/Enter =
    // accepter, Esc = masquer jusqu'à la prochaine frappe ──
    if (esOpen()) {
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        esIdx = (esIdx + esMatches.length - 1) % esMatches.length;
        esRender();
        return;
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        esIdx = (esIdx + 1) % esMatches.length;
        esRender();
        return;
      } else if ((e.key === 'Tab' && !e.shiftKey && !e.ctrlKey && !e.metaKey && !e.altKey) || e.key === 'Enter') {
        e.preventDefault();
        esAccept();
        return;
      } else if (e.key === 'Escape') {
        e.preventDefault();
        esSuppressed = true;
        esRender();
        return;
      }
    }
    // ── Tab : complète un pseudo, re-Tab itère sur les correspondances ──
    if (e.key === 'Tab' && !e.shiftKey && !e.ctrlKey && !e.metaKey && !e.altKey) {
      if (tabMatches && tabMatches.length) {
        tabIdx = (tabIdx + 1) % tabMatches.length;
      } else {
        var pos = (inp.selectionStart != null) ? inp.selectionStart : inp.value.length;
        var m = inp.value.slice(0, pos).match(/(\S+)$/);
        if (!m) return;                       // rien à compléter → Tab normal
        var prefix = m[1].toLowerCase();
        var nicks = (window._chatNicks ? window._chatNicks(gameScope) : []) || [];
        var seen = {};
        var matches = nicks.filter(function (n) {
          var k = n.toLowerCase();
          if (seen[k] || k.indexOf(prefix) !== 0) return false;
          seen[k] = 1; return true;
        });
        if (!matches.length) return;          // aucun pseudo → Tab normal
        tabMatches = matches; tabIdx = 0;
        tabStart = pos - m[1].length;
        tabTail = inp.value.slice((inp.selectionEnd != null) ? inp.selectionEnd : pos);
      }
      e.preventDefault();
      var nick = tabMatches[tabIdx];
      var suffix = (tabStart === 0) ? ': ' : ' '; // en tête de message : « nick: »
      inp.value = inp.value.slice(0, tabStart) + nick + suffix + tabTail;
      var np = tabStart + nick.length + suffix.length;
      try { inp.setSelectionRange(np, np); } catch (err) {}
      return;
    }
    // ── ↑ / ↓ : historique des messages envoyés ──
    if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
      if (!_chatHist.length) return;
      e.preventDefault();
      tabMatches = null;
      // Un token qui matche par hasard en fin d'entrée d'historique ne doit
      // pas ouvrir le popup d'emotes (parité QML).
      esSuppressed = true; esRender();
      if (e.key === 'ArrowUp') {
        if (histIdx === -1) { draft = inp.value; histIdx = _chatHist.length - 1; }
        else if (histIdx > 0) histIdx--;
        inp.value = _chatHist[histIdx]; caretEnd();
      } else {
        if (histIdx === -1) return;
        histIdx++;
        if (histIdx >= _chatHist.length) { histIdx = -1; inp.value = draft; }
        else inp.value = _chatHist[histIdx];
        caretEnd();
      }
      return;
    }
    // Toute autre frappe réinitialise Tab et la navigation d'historique
    tabMatches = null;
    histIdx = -1;
    // ── Entrée (popup fermé) : envoi — reprise du handler inline d'origine ──
    if (e.key === 'Enter' && typeof sendOnEnter === 'function') {
      sendOnEnter.call(inp, e);
      esMatches = []; esRender();
    }
  });
}
(function () {
  function _initChatKeys() {
    _attachChatKeys('chat-in', false);
    _attachChatKeys('g-chat-in', true);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', _initChatKeys);
  else _initChatKeys();
})();

window.toggleChatEmojiPicker = toggleChatEmojiPicker;
window.insertChatEmoji = insertChatEmoji;

// ── Picker emoji COMPLET (parité EmojiPicker QML, bible §11) ────────────────
// ~1070 émojis générés par plages Unicode stables (≤ 12.0 pour un rendu
// natif fiable iOS/Android/desktop — pas de police embarquée, contrairement
// au NotoColorEmoji du QML). Affichés en 2 sections : « Fréquents »
// (CHAT_EMOJIS, la liste historique) puis « Tous ».
var CHAT_EMOJIS_ALL = ["😀","😁","😂","😃","😄","😅","😆","😇","😈","😉","😊","😋","😌","😍","😎","😏","😐","😑","😒","😓","😔","😕","😖","😗","😘","😙","😚","😛","😜","😝","😞","😟","😠","😡","😢","😣","😤","😥","😦","😧","😨","😩","😪","😫","😬","😭","😮","😯","😰","😱","😲","😳","😴","😵","😶","😷","😸","😹","😺","😻","😼","😽","😾","😿","🙀","🙁","🙂","🙃","🙄","🙅","🙆","🙇","🙈","🙉","🙊","🙋","🙌","🙍","🙎","🙏","🤏","🤐","🤑","🤒","🤓","🤔","🤕","🤖","🤗","🤘","🤙","🤚","🤛","🤜","🤝","🤞","🤟","🤠","🤡","🤢","🤣","🤤","🤥","🤦","🤧","🤨","🤩","🤪","🤫","🤬","🤭","🤮","🤯","🤰","🤱","🤲","🤳","🤴","🤵","🤶","🤷","🤸","🤹","🤺","🤼","🤽","🤾","🤿","🥀","🥁","🥂","🥃","🥄","🥅","🥇","🥈","🥉","🥊","🥋","🥌","🥍","🥎","🥏","🥐","🥑","🥒","🥓","🥔","🥕","🥖","🥗","🥘","🥙","🥚","🥛","🥜","🥝","🥞","🥟","🥠","🥡","🥢","🥣","🥤","🥥","🥦","🥧","🥨","🥩","🥪","🥫","🥬","🥭","🥮","🥯","🥰","🥱","🥳","🥴","🥵","🥶","🥺","🥻","🥼","🥽","🥾","🥿","🦀","🦁","🦂","🦃","🦄","🦅","🦆","🦇","🦈","🦉","🦊","🦋","🦌","🦍","🦎","🦏","🦐","🦑","🦒","🦓","🦔","🦕","🦖","🦗","🦘","🦙","🦚","🦛","🦜","🦝","🦞","🦟","🦠","🦡","🦢","🦣","🦤","🦥","🦦","🦧","🦨","🦩","🦪","🦫","🦬","🦭","🦮","🦯","🦰","🦱","🦲","🦳","🦴","🦵","🦶","🦷","🦸","🦹","🦺","🦻","🦼","🦽","🦾","🦿","🧀","🧁","🧂","🧃","🧄","🧅","🧆","🧇","🧈","🧉","🧊","🧍","🧎","🧏","🧐","🧑","🧒","🧓","🧔","🧕","🧖","🧗","🧘","🧙","🧚","🧛","🧜","🧝","🧞","🧟","🧠","🧡","🧢","🧣","🧤","🧥","🧦","🧧","🧨","🧩","🧪","🧫","🧬","🧭","🧮","🧯","🧰","🧱","🧲","🧳","🧴","🧵","🧶","🧷","🧸","🧹","🧺","🧻","🧼","🧽","🧾","🧿","🌀","🌁","🌂","🌃","🌄","🌅","🌆","🌇","🌈","🌉","🌊","🌋","🌌","🌍","🌎","🌏","🌐","🌑","🌒","🌓","🌔","🌕","🌖","🌗","🌘","🌙","🌚","🌛","🌜","🌝","🌞","🌟","🌠","🌡","🌢","🌣","🌤","🌥","🌦","🌧","🌨","🌩","🌪","🌫","🌬","🌭","🌮","🌯","🌰","🌱","🌲","🌳","🌴","🌵","🌶","🌷","🌸","🌹","🌺","🌻","🌼","🌽","🌾","🌿","🍀","🍁","🍂","🍃","🍄","🍅","🍆","🍇","🍈","🍉","🍊","🍋","🍌","🍍","🍎","🍏","🍐","🍑","🍒","🍓","🍔","🍕","🍖","🍗","🍘","🍙","🍚","🍛","🍜","🍝","🍞","🍟","🍠","🍡","🍢","🍣","🍤","🍥","🍦","🍧","🍨","🍩","🍪","🍫","🍬","🍭","🍮","🍯","🍰","🍱","🍲","🍳","🍴","🍵","🍶","🍷","🍸","🍹","🍺","🍻","🍼","🍽","🍾","🍿","🎀","🎁","🎂","🎃","🎄","🎅","🎆","🎇","🎈","🎉","🎊","🎋","🎌","🎍","🎎","🎏","🎐","🎑","🎒","🎓","🎔","🎕","🎖","🎗","🎘","🎙","🎚","🎛","🎜","🎝","🎞","🎟","🎠","🎡","🎢","🎣","🎤","🎥","🎦","🎧","🎨","🎩","🎪","🎫","🎬","🎭","🎮","🎯","🎰","🎱","🎲","🎳","🎴","🎵","🎶","🎷","🎸","🎹","🎺","🎻","🎼","🎽","🎾","🎿","🏀","🏁","🏂","🏃","🏄","🏅","🏆","🏇","🏈","🏉","🏊","🏋","🏌","🏍","🏎","🏏","🏐","🏑","🏒","🏓","🏔","🏕","🏖","🏗","🏘","🏙","🏚","🏛","🏜","🏝","🏞","🏟","🏠","🏡","🏢","🏣","🏤","🏥","🏦","🏧","🏨","🏩","🏪","🏫","🏬","🏭","🏮","🏯","🏰","🏱","🏲","🏳","🏴","🏵","🏶","🏷","🏸","🏹","🏺","🐀","🐁","🐂","🐃","🐄","🐅","🐆","🐇","🐈","🐉","🐊","🐋","🐌","🐍","🐎","🐏","🐐","🐑","🐒","🐓","🐔","🐕","🐖","🐗","🐘","🐙","🐚","🐛","🐜","🐝","🐞","🐟","🐠","🐡","🐢","🐣","🐤","🐥","🐦","🐧","🐨","🐩","🐪","🐫","🐬","🐭","🐮","🐯","🐰","🐱","🐲","🐳","🐴","🐵","🐶","🐷","🐸","🐹","🐺","🐻","🐼","🐽","🐾","🐿","👀","👁","👂","👃","👄","👅","👆","👇","👈","👉","👊","👋","👌","👍","👎","👏","👐","👑","👒","👓","👔","👕","👖","👗","👘","👙","👚","👛","👜","👝","👞","👟","👠","👡","👢","👣","👤","👥","👦","👧","👨","👩","👪","👫","👬","👭","👮","👯","👰","👱","👲","👳","👴","👵","👶","👷","👸","👹","👺","👻","👼","👽","👾","👿","💀","💁","💂","💃","💄","💅","💆","💇","💈","💉","💊","💋","💌","💍","💎","💏","💐","💑","💒","💓","💔","💕","💖","💗","💘","💙","💚","💛","💜","💝","💞","💟","💠","💡","💢","💣","💤","💥","💦","💧","💨","💩","💪","💫","💬","💭","💮","💯","💰","💱","💲","💳","💴","💵","💶","💷","💸","💹","💺","💻","💼","💽","💾","💿","📀","📁","📂","📃","📄","📅","📆","📇","📈","📉","📊","📋","📌","📍","📎","📏","📐","📑","📒","📓","📔","📕","📖","📗","📘","📙","📚","📛","📜","📝","📞","📟","📠","📡","📢","📣","📤","📥","📦","📧","📨","📩","📪","📫","📬","📭","📮","📯","📰","📱","📲","📳","📴","📵","📶","📷","📸","📹","📺","📻","📼","📽","📾","📿","🔀","🔁","🔂","🔃","🔄","🔅","🔆","🔇","🔈","🔉","🔊","🔋","🔌","🔍","🔎","🔏","🔐","🔑","🔒","🔓","🔔","🔕","🔖","🔗","🔘","🔙","🔚","🔛","🔜","🔝","🔞","🔟","🔠","🔡","🔢","🔣","🔤","🔥","🔦","🔧","🔨","🔩","🔪","🔫","🔬","🔭","🔮","🔯","🔰","🔱","🔲","🔳","🔴","🔵","🔶","🔷","🔸","🔹","🔺","🔻","🔼","🔽","🕐","🕑","🕒","🕓","🕔","🕕","🕖","🕗","🕘","🕙","🕚","🕛","🕜","🕝","🕞","🕟","🕠","🕡","🕢","🕣","🕤","🕥","🕦","🕧","🕺","🖕","🖖","🖤","🗻","🗼","🗽","🗾","🗿","🚀","🚁","🚂","🚃","🚄","🚅","🚆","🚇","🚈","🚉","🚊","🚋","🚌","🚍","🚎","🚏","🚐","🚑","🚒","🚓","🚔","🚕","🚖","🚗","🚘","🚙","🚚","🚛","🚜","🚝","🚞","🚟","🚠","🚡","🚢","🚣","🚤","🚥","🚦","🚧","🚨","🚩","🚪","🚫","🚬","🚭","🚮","🚯","🚰","🚱","🚲","🚳","🚴","🚵","🚶","🚷","🚸","🚹","🚺","🚻","🚼","🚽","🚾","🚿","🛀","🛁","🛂","🛃","🛄","🛅","🛋","🛌","🛍","🛎","🛏","🛐","🛑","🛒","🛴","🛵","🛶","🛷","🛸","🛹","🛺","☀️","☁️","☂️","☃️","☄️","☎️","☔️","☕️","☘️","☠️","☢️","☣️","☦️","☪️","☮️","☯️","☸️","☹️","☺️","♈️","♉️","♊️","♋️","♌️","♍️","♎️","♏️","♐️","♑️","♒️","♓️","♠️","♣️","♥️","♦️","♨️","♻️","⚠️","⚡️","⚪","⚫","⚽","⚾","⛄","⛅","⛎","⛔","⛪","⛲","⛳","⛴","⛵","⛺","⛽","✂️","✈️","✉️","✊","✋","✨","✳️","✴️","❄️","❇️","❌","❗","❤️","⭐"];


// Ouvre un panneau DIRECTEMENT en fenêtre flottante compacte, ancrée près de son
// bouton (sous, aligné à gauche ou à droite) — sur tous les appareils. Si une
// position a déjà été mémorisée, _enableFloating la restaure.
function _openFloatingNearBtn(panel, btn, opt, side) {
  if (!panel) return;
  opt = opt || {};
  var defW = opt.defW || 300;
  var r = btn ? btn.getBoundingClientRect() : null;
  if (r) {
    opt.defTop  = Math.round(r.bottom + 6);
    opt.defLeft = (side === 'right')
      ? Math.max(6, Math.round(r.right - defW))
      : Math.max(6, Math.round(r.left));
  }
  _enableFloating(panel, opt);
}

// ── Parite QML : le chat de table reste « actif » pendant qu'on joue ──
// (demande neuling 2026-08-10). En HTML, cliquer un <button> lui donne le
// focus : le champ de chat le perd et, sur mobile, le clavier se ferme —
// il faut recliquer le chat apres chaque action. En QML les boutons ne
// prennent pas le focus clavier, donc le chat reste saisissable.
//  - souris : preventDefault au mousedown sur un BOUTON de la barre quand
//    le champ de chat a le focus → le clic part, le focus ne bouge pas ;
//  - tactile : re-focus du champ juste apres le tap (preventDefault au
//    touchstart casserait le clic, donc on refocalise a posteriori).
// Seuls les <button> sont concernes : champ de mise et slider gardent leur
// comportement de focus normal (parite « focus bet input »).
function _initChatFocusHold() {
  var wrap = document.querySelector('#s-game .action-wrap') || document.getElementById('g-actions');
  if (!wrap || wrap._chatHold) return;
  wrap._chatHold = true;
  function _chatFocused() {
    var i = document.getElementById('g-chat-in');
    return !!(i && document.activeElement === i);
  }
  wrap.addEventListener('mousedown', function (ev) {
    var b = ev.target && ev.target.closest ? ev.target.closest('button') : null;
    if (b && _chatFocused()) ev.preventDefault();
  });
  wrap.addEventListener('touchstart', function (ev) {
    var b = ev.target && ev.target.closest ? ev.target.closest('button') : null;
    if (b && _chatFocused()) {
      setTimeout(function () {
        var i = document.getElementById('g-chat-in');
        if (!i) return;
        var p = document.getElementById('g-chat-panel');
        if (p && p.style.display !== 'none') {
          try { i.focus({ preventScroll: true }); } catch (e) { try { i.focus(); } catch (e2) {} }
        }
      }, 60);
    }
  }, { passive: true });
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', _initChatFocusHold);
else _initChatFocusHold();

function _gameDrawerConfig(panel) {
  if (!panel) return null;
  if (panel.id === 'g-chat-panel') return {
    normalTrigger: document.getElementById('chat-toggle-btn'),
    adaptiveTrigger: document.getElementById('adaptive-chat-toggle'),
    side: 'left',
    focus: function () { return document.getElementById('g-chat-in'); },
    refreshOutsideAdaptive: true,
    floating: { key:'pth_winpos_chat', handle: panel.querySelector('.g-chat-panel-header'), resizable:true, minW:240, minH:160, defW:300, defH:280, zoom:true }
  };
  if (panel.id === 'g-log-panel') return {
    normalTrigger: document.getElementById('log-toggle-btn'),
    adaptiveTrigger: document.getElementById('adaptive-info-toggle'),
    side: 'right',
    focus: function () { return panel.querySelector('.gip-tab.gip-on'); },
    refreshOutsideAdaptive: false,
    floating: { key:'pth_winpos_log2', handle: panel.querySelector('.g-chat-panel-header'), resizable:true, minW:240, minH:140, defW: window.innerWidth >= 1400 ? 340 : 300, defH:300, zoom:true }
  };
  if (panel.id === 'hands-card-inner') return {
    normalTrigger: document.getElementById('hands-toggle-btn'),
    adaptiveTrigger: document.getElementById('adaptive-hands-toggle'),
    visibilityPanel: document.getElementById('hands-overlay'),
    side: 'right',
    focus: function () { return panel.querySelector('.g-chat-panel-header button'); },
    refreshOutsideAdaptive: false,
    floating: { key:'pth_winpos_hands', handle: panel.querySelector('.g-chat-panel-header'), resizable:true, minW:280, minH:220, defW:380, defH:440, zoom:true }
  };
  if (panel.id === 'g-reaction-panel') return {
    normalTrigger: document.getElementById('react-toggle-btn'),
    adaptiveTrigger: document.getElementById('adaptive-reactions-toggle'),
    side: 'left',
    focus: function () { return panel.querySelector('.react-panel-close'); },
    refreshOutsideAdaptive: false,
    floating: { key:'pth_winpos_react', handle: panel.querySelector('.react-panel-title'), resizable:true, minW:280, minH:230, maxW:760, maxH:520, defW:330, defH:340 }
  };
  return null;
}

function _refreshGameDrawerLayout() {
  setTimeout(function () {
    try { autoScaleTable(); } catch (e) {}
    try { if (typeof updateBottomLayout === 'function') updateBottomLayout(); } catch (e) {}
    try { if (typeof renderSeats === 'function' && typeof seats !== 'undefined' && seats.length) renderSeats(); } catch (e) {}
  }, 50);
}

function reconfigureGameDrawersForAdaptivePlay(adaptive) {
  var panels = [document.getElementById('g-chat-panel'), document.getElementById('g-log-panel'), document.getElementById('hands-card-inner'), document.getElementById('g-reaction-panel')];
  for (var i = 0; i < panels.length; i++) {
    var panel = panels[i], config = _gameDrawerConfig(panel);
    if (!panel || !config) continue;
    if (adaptive) {
      panel.setAttribute('role', 'dialog');
      panel.setAttribute('aria-modal', 'false');
      _disableFloating(panel);
    } else {
      panel.removeAttribute('role');
      panel.removeAttribute('aria-modal');
    }
    var visibilityPanel = config.visibilityPanel || panel;
    var open = visibilityPanel.style.display !== 'none';
    if (!open) continue;
    var btn = adaptive ? config.adaptiveTrigger : config.normalTrigger;
    panel._drawerInvoker = btn;
    if (adaptive) {
      setTimeout(function (targetPanel) {
        var targetConfig = _gameDrawerConfig(targetPanel);
        var target = targetConfig && targetConfig.focus();
        try { if (target) target.focus(); } catch (e) {}
      }, 80, panel);
    } else {
      _openFloatingNearBtn(panel, btn, config.floating, config.side);
    }
  }
  _refreshGameDrawerLayout();
}
window.reconfigureGameDrawersForAdaptivePlay = reconfigureGameDrawersForAdaptivePlay;
try { reconfigureGameDrawersForAdaptivePlay(typeof window.isAdaptivePlay === 'function' && window.isAdaptivePlay()); } catch (e) {}

function _configureGameDrawer(panel, opening, btn) {
  var config = _gameDrawerConfig(panel);
  if (!config) return false;
  var adaptive = typeof window.isAdaptivePlay === 'function' && window.isAdaptivePlay();
  if (opening) {
    if (adaptive) _disableFloating(panel);
    else _openFloatingNearBtn(panel, btn, config.floating, config.side);
  }
  if (adaptive || config.refreshOutsideAdaptive) {
    setTimeout(function () {
      try { autoScaleTable(); } catch (e) {}
      if (adaptive) { try { if (typeof updateBottomLayout === 'function') updateBottomLayout(); } catch (e) {} }
      try { if (typeof renderSeats === 'function' && typeof seats !== 'undefined' && seats.length) renderSeats(); } catch (e) {}
      if (!adaptive) return;
      var target = opening ? config.focus() : btn;
      try { if (target) target.focus(); } catch (e) {}
      if (!opening) panel._drawerInvoker = null;
    }, 50);
  }
  return adaptive;
}

function toggleGameChat(invoker) {
  // Spectators can open the panel read-only (sp0ck 31/07/2026): the input row
  // is hidden by CSS (body.spectator-nosend), only sending is blocked.
  var panel = document.getElementById('g-chat-panel');
  var fallbackBtn = document.getElementById('chat-toggle-btn');
  if (!panel) return;
  var open = panel.style.display === 'none';
  var btn = open && invoker && invoker.getAttribute && invoker.getAttribute('aria-controls') === 'g-chat-panel'
    ? invoker : (panel._drawerInvoker || fallbackBtn);
  if (open) panel._drawerInvoker = btn;
  panel.style.display = open ? 'flex' : 'none';
  panel.setAttribute('aria-hidden', open ? 'false' : 'true');
  document.querySelectorAll('[aria-controls="g-chat-panel"]').forEach(function(trigger) {
    trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  var adaptive = _configureGameDrawer(panel, open, btn);
  if (open) {
    if (typeof clearUnreadChat === 'function') clearUnreadChat();
    var m = document.getElementById('g-chat-msgs');
    if (m) { if (typeof window._liveReset === 'function') window._liveReset(m); else m.scrollTop = m.scrollHeight; }
    var inp = document.getElementById('g-chat-in');
    if (inp) setTimeout(function(){ inp.focus(); }, 80);
  } else if (btn && window.matchMedia('(max-width: 740px) and (orientation: portrait)').matches
      && document.documentElement.getAttribute('data-interface-size') === 'extra-large') {
    setTimeout(function(){ btn.focus(); }, 0);
    panel._drawerInvoker = null;
  }
}
function joinWithPassword() {
  var pp = document.getElementById('password-prompt');
  if (!pp) return;
  var gameId = parseInt(pp.dataset.gameId);
  var pass   = (document.getElementById('pp-pass') || {}).value || '';
  pp.style.display = 'none';
  if (typeof App !== 'undefined' && App.joinGameWithPassword) {
    App.joinGameWithPassword(gameId, pass);
  }
}

function toggleMusicPanel() {
  // Lecteur coupe par l'admin (/app-config.musicEnabled) : no-op defensif, au cas
  // ou un appel externe atteindrait la fonction malgre les entrees de menu masquees.
  if (window._musicOff) return;
  var panel = document.getElementById('music-panel');
  if (!panel) return;
  var open = panel.style.display === 'none' || panel.style.display === '';
  panel.style.display = open ? 'flex' : 'none';
  if (open) {
    // Draggable + resizable on desktop/tablet; fixed bottom-sheet on phones —
    // same window system as the chat / log / reaction panels. Fait AVANT le mount
    // pour que le mode « mini = deplacable » (telephone) que _applyShade peut
    // activer ne soit pas aussitot annule par le _disableFloating ci-dessous.
    if (_winGate()) {
      _attachFloatControls(panel, { key: 'pth_winpos_music', handle: panel.querySelector('.music-panel-title'), resizable: false, defW: 340, zoom: true });
    } else {
      _disableFloating(panel);
    }
    // (Re-)render the player and refresh the auto-updating track list on every
    // open — tracks added later then appear without a reload.
    try { if (window.Music && window.Music.mount) window.Music.mount(document.getElementById('music-body')); } catch (e) {}
  }
  // Reflect open/closed state on the entry buttons (active = gold).
  ['music-btn-connect', 'music-toggle-lobby-mob', 'music-toggle-game-mob', 'music-toggle-connect-mob'].forEach(function (id) {
    var b = document.getElementById(id);
    if (!b) return;
    b.style.background  = open ? 'rgba(var(--gold-rgb),0.2)' : '';
    b.style.borderColor = open ? 'var(--gold-dim)' : '';
    b.style.color       = open ? 'var(--gold)' : '';
  });
}
window.toggleMusicPanel = toggleMusicPanel;

// ── Grille de réactions auto-adaptative (fenêtre flottante) ──
// Les 30 émojis de la PAGE ACTIVE restent tous visibles : à chaque redimensionnement on choisit
// le découpage colonnes × lignes qui maximise la taille de case carrée, puis
// on borne la case entre 32 px (en dessous → la grille défile, très petites
// fenêtres) et 84 px (au-delà → cases plafonnées et grille centrée). La taille
// des émojis suit la case via la variable CSS --react-cell.
function _fitReactGrid(panel){
  panel = panel || document.getElementById('g-reaction-panel');
  if (!panel) return;
  // 3 pages depuis 2026-08-28 : on ne mesure que la grille VISIBLE (page active).
  var grid = panel.querySelector('.react-grid:not([hidden])') || panel.querySelector('.react-grid');
  if (!grid) return;
  if (!panel.classList.contains('floating-win')){
    // Retour bandeau (resetWindows) : rendre la main aux règles CSS — sur
    // TOUTES les pages, pas seulement la page active.
    var _rgs = panel.querySelectorAll('.react-grid');
    for (var _ri = 0; _ri < _rgs.length; _ri++){
      var _rg = _rgs[_ri];
      _rg.style.gridTemplateColumns=''; _rg.style.gridAutoRows='';
      _rg.style.gap=''; _rg.style.justifyContent=''; _rg.style.alignContent='';
      _rg.style.padding='';
      _rg.style.removeProperty('--react-cell');
    }
    return;
  }
  if (panel.style.display === 'none') return;
  var n = grid.querySelectorAll('.react-btn').length;
  if (!n) return;
  var GAP = 4, MIN = 32, MAX = 84;
  var W = grid.clientWidth, H = grid.clientHeight;
  if (W < MIN || H < MIN) return;
  // PAD : marge interne réservée au zoom de survol (scale 1.2 → +10 % de case
  //   de chaque côté). Sans elle, les boutons de bord débordent la zone
  //   overflow:auto au survol et une barre de défilement clignote
  //   (bug constaté 2026-08-28). Intégrée en forme close au calcul :
  //   cell*cols + GAP*(cols-1) + 2*(0.12*cell) = W  ⇔
  //   cell = (W - GAP*(cols-1)) / (cols + 0.24) — idem verticalement.
  //   clientWidth inclut le padding que NOUS posons : la mesure reste stable
  //   d'un appel à l'autre (la taille de la grille est fixée par le flex).
  var PADR = 0.12;
  var bestCols = 1, bestCell = 0;
  for (var cols = 1; cols <= n; cols++){
    var rows = Math.ceil(n / cols);
    var cell = Math.min((W - GAP*(cols-1))/(cols + 2*PADR), (H - GAP*(rows-1))/(rows + 2*PADR));
    if (cell > bestCell){ bestCell = cell; bestCols = cols; }
  }
  var cell = Math.floor(Math.max(MIN, Math.min(MAX, bestCell)));
  var rows = Math.ceil(n / bestCols);
  var pad = Math.ceil(cell * PADR);
  grid.style.gridTemplateColumns = 'repeat(' + bestCols + ', ' + cell + 'px)';
  grid.style.gridAutoRows = cell + 'px';
  grid.style.gap = GAP + 'px';
  grid.style.padding = pad + 'px';
  grid.style.justifyContent = 'center';
  // Centré verticalement quand tout tient ; ancré en haut si ça défile.
  grid.style.alignContent = (rows*(cell+GAP)-GAP > H - 2*pad) ? 'start' : 'center';
  grid.style.setProperty('--react-cell', cell + 'px');
}

// ── Pagination du panneau réactions (3 pages thématiques × 30, 2026-08-28) ──
// Pager compact dans la barre de titre : ‹ [N/3] › ; chaque page est une .react-grid,
// seule la page active est visible ([hidden] sur les autres) et _fitReactGrid
// ne mesure qu'elle. Dernière page mémorisée (pth_react_page).
function setReactionPage(i, dir){
  var panel = document.getElementById('g-reaction-panel');
  if (!panel) return;
  var grids = panel.querySelectorAll('.react-grid');
  if (!grids.length) return;
  var n = grids.length;
  i = ((i % n) + n) % n;                       // les flèches bouclent (page 3 → 1)
  for (var k = 0; k < n; k++){
    if (k === i) grids[k].removeAttribute('hidden');
    else grids[k].setAttribute('hidden', '');
  }
  // Glissement directionnel discret de la page entrante (flèches ET swipe) ;
  // neutralisé par prefers-reduced-motion côté CSS.
  if (dir === 'left' || dir === 'right'){
    var g = grids[i];
    g.classList.remove('rp-in-left', 'rp-in-right');
    void g.offsetWidth;                        // redémarre l'animation
    g.classList.add(dir === 'left' ? 'rp-in-left' : 'rp-in-right');
  }
  var ind = document.getElementById('react-page-ind');
  if (ind) ind.textContent = (i + 1) + '/' + n;
  try { localStorage.setItem('pth_react_page', String(i)); } catch (e) {}
  _fitReactGrid(panel);
}

// ── Swipe horizontal tactile sur les pages de réactions (2026-08-28) ──
// Un balayage franc (≥ 48 px, nettement horizontal, < 600 ms) change de page.
// Écouteurs passifs : le défilement vertical de la grille (petites fenêtres)
// et le tap des boutons restent intacts — un tap qui glisse au-delà du seuil
// n'émet de toute façon plus de click (comportement navigateur standard).
// La barre de titre est exclue : elle sert déjà à déplacer la fenêtre.
function _attachReactSwipe(panel){
  if (panel._reactSwipe) return;
  panel._reactSwipe = true;
  var x0 = 0, y0 = 0, t0 = 0, armed = false;
  panel.addEventListener('touchstart', function(e){
    if (!e.touches || e.touches.length !== 1) { armed = false; return; }
    var tg = e.target;
    if (tg && tg.closest && tg.closest('.react-panel-title')) { armed = false; return; }
    armed = true;
    x0 = e.touches[0].clientX; y0 = e.touches[0].clientY; t0 = Date.now();
  }, { passive: true });
  panel.addEventListener('touchend', function(e){
    if (!armed) return;
    armed = false;
    var t = e.changedTouches && e.changedTouches[0];
    if (!t) return;
    if (Date.now() - t0 > 600) return;                       // geste lent = pas un swipe
    var dx = t.clientX - x0, dy = t.clientY - y0;
    if (Math.abs(dx) < 48 || Math.abs(dx) < Math.abs(dy) * 1.5) return;
    setReactionPage(_reactPageCurrent() + (dx < 0 ? 1 : -1), dx < 0 ? 'left' : 'right');
  }, { passive: true });
}
function _reactPageCurrent(){
  var v = 0;
  try { v = parseInt(localStorage.getItem('pth_react_page') || '0', 10) || 0; } catch (e) {}
  return v;
}

function toggleReactionPanel(invoker) {
  // Réactions actives partout, y compris pokerth.net : sendReaction() relaie
  // via la commande /emoji dans le chat de partie (interop web <-> Qt/QML).
  // L'ancien garde-fou _directWS masquait le bouton sur pokerth.net (régression).
  // Spectators: picker unavailable (send-lock, sp0ck 31/07/2026) — button is
  // hidden by CSS, this guard covers programmatic/keyboard paths.
  try { if (window.PthState && window.PthState._amSpectator) return; } catch (e) {}
  var panel = document.getElementById('g-reaction-panel');
  var fallbackBtn = document.getElementById('react-toggle-btn');
  if (!panel) return;
  var open = panel.style.display === 'none' || panel.style.display === '';
  var btn = open && invoker && invoker.getAttribute && invoker.getAttribute('aria-controls') === 'g-reaction-panel'
    ? invoker : (panel._drawerInvoker || fallbackBtn);
  if (open) panel._drawerInvoker = btn;
  panel.style.display = open ? 'flex' : 'none';
  panel.setAttribute('aria-hidden', open ? 'false' : 'true');
  document.querySelectorAll('[aria-controls="g-reaction-panel"]').forEach(function(trigger) {
    trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  if (open) { _applyReactMuteUI(); try { _applyReactPinUI(); } catch (e) {} }
  if (open) {
    // minW/minH relevés : au minimum de fenêtre, les 30 émojis de la page active tiennent encore
    // à la borne basse de case (32 px) sans défilement.
    _configureGameDrawer(panel, true, btn);
    if (!panel._reactFitRO && typeof ResizeObserver !== 'undefined'){
      panel._reactFitRO = new ResizeObserver(function(){ _fitReactGrid(panel); });
      panel._reactFitRO.observe(panel);
    }
    setReactionPage(_reactPageCurrent());  // restaure la page + _fitReactGrid
    _attachReactSwipe(panel);              // pages au doigt sur tactile
  }
  if (!open) _configureGameDrawer(panel, false, btn);
  setTimeout(function(){
    autoScaleTable();
    if(typeof renderSeats==='function' && typeof seats!=='undefined' && seats.length)
      renderSeats();
  }, 80);
}

// ── Panneau info unifié (parité QML GameInfoPanel) : le journal et le
// moniteur d'odds partagent UNE fenêtre à deux onglets Historique/Chances. ──
function gipShowTab(tab) {
  if (tab !== 'log' && tab !== 'odds' && tab !== 'stats') tab = 'log';
  var lb = document.getElementById('g-log-body'),
      ob = document.getElementById('g-odds-body'),
      sb = document.getElementById('g-stats-body');
  var tl = document.getElementById('gip-tab-log'),
      to = document.getElementById('gip-tab-odds'),
      ts = document.getElementById('gip-tab-stats');
  if (lb) lb.style.display = tab === 'log' ? '' : 'none';
  if (ob) ob.style.display = tab === 'odds' ? '' : 'none';
  if (sb) sb.style.display = tab === 'stats' ? '' : 'none';
  if (tl) tl.classList.toggle('gip-on', tab === 'log');
  if (to) to.classList.toggle('gip-on', tab === 'odds');
  if (ts) ts.classList.toggle('gip-on', tab === 'stats');
  // Le bouton « Exporter le journal » n'a de sens que sur l'onglet
  // Historique — masqué sur Chances et Stats (demande narmod 19/07).
  var xb = document.getElementById('gip-export');
  if (xb) xb.style.display = tab === 'log' ? '' : 'none';
  // L'assistance (hand-strength) n'a de sens que sur l'onglet Historique.
  var asg = document.getElementById('gip-assist');
  try { localStorage.setItem('pth_gip_tab', tab); } catch (e) {}
  if (tab === 'odds') { try { if (typeof window._renderOdds === 'function') window._renderOdds(); } catch (e) {} }
  if (tab === 'stats') { try { var _rs = window._renderStatsNow || window._renderStats; if (typeof _rs === 'function') _rs(); } catch (e) {} }
  try { if (typeof window._gipAssistSync === 'function') window._gipAssistSync(); } catch (e) {}
}
window.gipShowTab = gipShowTab;
// Ouvre le panneau sur un onglet précis (Alt+L → Historique, Alt+I → Chances) :
// fermé → ouvre sur l'onglet ; ouvert sur l'autre onglet → bascule ;
// ouvert sur le même onglet → ferme (comportement toggle du QML).
function gipOpenTab(tab) {
  var panel = document.getElementById('g-log-panel');
  if (!panel) return;
  var cur = 'log';
  try { cur = localStorage.getItem('pth_gip_tab') === 'odds' ? 'odds' : 'log'; } catch (e) {}
  if (panel.style.display === 'none') { toggleLog(); gipShowTab(tab); }
  else if (cur !== tab) gipShowTab(tab);
  else toggleLog();
}
window.gipOpenTab = gipOpenTab;

function toggleLog(invoker) {
  var panel = document.getElementById('g-log-panel');
  var fallbackBtn = document.getElementById('log-toggle-btn');
  if (!panel) return;
  var isHidden = panel.style.display === 'none';
  var btn = isHidden && invoker && invoker.getAttribute && invoker.getAttribute('aria-controls') === 'g-log-panel'
    ? invoker : (panel._drawerInvoker || fallbackBtn);
  if (isHidden) panel._drawerInvoker = btn;
  panel.style.display = isHidden ? '' : 'none';
  panel.setAttribute('aria-hidden', isHidden ? 'false' : 'true');
  document.querySelectorAll('[aria-controls="g-log-panel"]').forEach(function(trigger) {
    trigger.setAttribute('aria-expanded', isHidden ? 'true' : 'false');
  });
  _configureGameDrawer(panel, isHidden, btn);
  if (isHidden) {
    var lb = document.getElementById('g-log-body');
    // Le plus récent est en haut (liste inversée) : rouvrir le panneau
    // remet le suivi automatique en marche, même s'il était en pause.
    if (lb) { if (typeof window._liveReset === 'function') window._liveReset(lb); else lb.scrollTop = 0; }
    // Restaurer le dernier onglet consulté (Historique par défaut).
    try { gipShowTab((function(){try{var _t=localStorage.getItem('pth_gip_tab');return (_t==='odds'||_t==='stats')?_t:'log';}catch(_e){return 'log';}})()); } catch (e) {}
    if (window.matchMedia('(max-width: 740px) and (orientation: portrait)').matches
        && document.documentElement.getAttribute('data-interface-size') === 'extra-large') {
      setTimeout(function(){ var tab = panel.querySelector('.gip-tab.gip-on'); if (tab) tab.focus(); }, 0);
    }
  } else if (btn && window.matchMedia('(max-width: 740px) and (orientation: portrait)').matches
      && document.documentElement.getAttribute('data-interface-size') === 'extra-large') {
    setTimeout(function(){ btn.focus(); }, 0);
    panel._drawerInvoker = null;
  }
}

// Exporte le journal : feuille de partage native si dispo (iOS/Android),
// sinon copie dans le presse-papier (avec repli execCommand). Ordre
// chronologique, dans la langue active, précédé d'un en-tête table + date.
function exportLog() {
  var body = (typeof window._buildLogText === 'function') ? window._buildLogText() : '';
  if (!body || !body.trim()) {
    if (typeof showToast === 'function') showToast(t('logEmpty'), { tone: 'error', icon: '' });
    return;
  }
  var table = (((document.getElementById('g-name') || {}).textContent) || 'PokerTH').trim();
  var title = (typeof t === 'function') ? t('logPanelTitle') : 'Log';
  var full = title + ' — ' + table + ' — ' + new Date().toLocaleString() + '\n' +
             '────────────────────\n' + body + '\n';
  function copied() { if (typeof showToast === 'function') showToast(t('logCopied')); }
  function fallback() {
    try {
      var ta = document.createElement('textarea');
      ta.value = full; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.focus(); ta.select();
      document.execCommand('copy'); ta.remove(); copied();
    } catch (e) {}
  }
  if (navigator.share) {
    navigator.share({ title: 'PokerTH — ' + title, text: full }).catch(function(){});
  } else if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(full).then(copied).catch(fallback);
  } else {
    fallback();
  }
}
window.exportLog = exportLog;

// Vide l'historique visible d'un chat (local uniquement — pas d'effet serveur).
// 'lobby' -> #chat ; 'game' -> #g-chat-msgs. Le chat n'a pas de store séparé
// (_retranslateSysChat relit le DOM), donc vider le conteneur suffit.
function clearChatPanel(which){
  var el = document.getElementById(which === 'lobby' ? 'chat' : 'g-chat-msgs');
  if (el) el.innerHTML = '';
  if (el && typeof window._liveReset === 'function') window._liveReset(el);
}
window.clearChatPanel = clearChatPanel;

// ── Players online panel ──
// Wired to the #h-players pill in the lobby header. Toggles a
// dropdown that lists every pid in _lobbyPids with its name (or
// '#<pid>' if the PlayerInfoReply hasn't arrived yet).
function togglePlayersPanel() {
  // 3-colonnes (≥900) : la liste joueurs est une colonne persistante → pas de toggle.
  if (window._lobby3IsWide && window._lobby3IsWide()) return;
  // Compact (Phase 1b) : slide-in intégré au lobby (plus d'overlay flottant).
  if (window._lobby3TogglePlayers) { window._lobby3TogglePlayers(); return; }
  var panel = document.getElementById('players-panel');
  if (!panel) return;
  var isHidden = panel.style.display === 'none';
  if (isHidden) {
    // Close sibling dropdowns so only one is open at a time.
    ['lobby-chat-panel'].forEach(function(id) {
      var el = document.getElementById(id);
      if (el) el.style.display = 'none';
    });
    // Position the panel right below the header. The CSS rule uses
    // a hard-coded top:36px, but the header padding is clamp()-based
    // and produces 36–52 px depending on viewport. Measure the actual
    // bottom of the lobby header at open time so the panel always
    // starts flush against it, never overlapping or leaving a gap.
    var hdr = document.querySelector('#s-lobby .header');
    if (hdr) {
      var rect = hdr.getBoundingClientRect();
      panel.style.top = Math.round(rect.bottom) + 'px';
    }
    panel.style.display = '';
    renderPlayersList();
    var _list = document.getElementById('players-list-body');
    var _lb = document.querySelector('#s-lobby .lobby-body');
    var _defReserve = 0;
    // Overlay : les tables suivent quand le panneau rétrécit, restent en
    // place (recouvertes) quand il dépasse sa taille d'ouverture.
    makeChatResizable(panel, _list, function(){
      if (_lb) _lb.style.paddingTop = (Math.min(panel.offsetHeight, _defReserve) + LOBBY_PANEL_GAP) + 'px';
    });
    resetChatSize(panel, _list);                 // rouvrir à la taille par défaut
    _defReserve = panel.offsetHeight;
    if (_lb) _lb.style.paddingTop = (_defReserve + LOBBY_PANEL_GAP) + 'px';
    // Focus the search input so the user can type right away.
    var inp = document.getElementById('players-search-in');
    if (inp) setTimeout(function(){ inp.focus(); }, 50);
  } else {
    panel.style.display = 'none';
    var _lb2 = document.querySelector('#s-lobby .lobby-body');
    if (_lb2) _lb2.style.paddingTop = '';         // libère l'espace
  }
}

// ✕ du champ de recherche joueur : vide le filtre, rafraîchit la liste, garde le focus.
window.plSearchClear = function () {
  var inp = document.getElementById('players-search-in');
  if (!inp) return;
  inp.value = '';
  try { renderPlayersList(); } catch (e) {}
  try { inp.focus(); } catch (e) {}
};

// Bascule du tri du panneau Joueurs (A–Z / pays), persistée.
window.setPlSort = function (m) {
  try { localStorage.setItem('pth_pl_sort', m === 'cc' ? 'cc' : 'az'); } catch (e) {}
  try { renderPlayersList(); } catch (e) {}
};
// Déroulant de tri (parité officielle) : 'az' / 'cc' = mode de tri ;
// 'idle' = bascule l'affichage des joueurs inactifs (hors partie), puis le
// select revient sur le tri courant.
window.plSortSelect = function (val) {
  if (['az','cc','idle'].indexOf(val) === -1) val = 'az';
  try { localStorage.setItem('pth_pl_mode', val); } catch (e) {}
  if (val === 'az' || val === 'cc') { try { localStorage.setItem('pth_pl_sort', val); } catch (e) {} } // compat
  try { renderPlayersList(); } catch (e) {}
};
// Icônes d'action par joueur (colonne Joueurs connectés) : ⊘ ignorer + 📊 stats.
// Monochromes (currentColor) pour suivre le thème, comme l'officiel.
var _PL_BAN_SVG = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="9"/><line x1="5.6" y1="5.6" x2="18.4" y2="18.4"/></svg>';
var _PL_BAR_SVG = '<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden="true"><rect x="4" y="12" width="4" height="8" rx="1"/><rect x="10" y="7" width="4" height="13" rx="1"/><rect x="16" y="3" width="4" height="17" rx="1"/></svg>';
// Manette : statut « en partie » (colonne dédiée). Allumée si le joueur joue.
var _PL_PAD_SVG = '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true"><path d="M6.5 7h11a4 4 0 0 1 4 4v3.1A2.9 2.9 0 0 1 16.3 16l-1-1.4H8.7l-1 1.4A2.9 2.9 0 0 1 2.5 14.1V11a4 4 0 0 1 4-4Zm.5 3v1.5H5.5V13H7v1.5h1.5V13H10v-1.5H8.5V10H7Zm8.6.1a1 1 0 1 0 0 2 1 1 0 0 0 0-2Zm1.9-1.9a1 1 0 1 0 0 2 1 1 0 0 0 0-2Z"/></svg>';
// Bascule ignorer depuis la LISTE (léger : toggle + re-render, sans ouvrir le
// popup — contrairement à window._toggleIgnore qui est pour la carte joueur).
window._plToggleIgnore = function(pid){
  try {
    var nm = (window._readPlayers ? window._readPlayers()[pid] : null);
    if (!nm) return;
    _setIgnoredName(nm, !_isIgnored(nm));
    if (typeof renderPlayersList === 'function') renderPlayersList();
  } catch(e){}
};

// ── Colonnes masquables de la liste « Joueurs en ligne » ───────────────
// Le Nom est verrouillé (toujours visible) ; les autres colonnes sont
// activables/désactivables depuis l'en-tête (#pl-colhead). Choix persisté
// dans localStorage 'pth_pl_cols' = liste des colonnes MASQUÉES (une
// nouvelle colonne future est donc visible par défaut).
// acts : largeur VARIABLE, contrairement aux autres pistes. Une pastille fait
// 20px (icone 14 + padding 3), plus les gouttieres. Trois pastilles pour tout
// le monde (message prive, ignorer, stats) ; une quatrieme, le marteau, quand
// je suis admin serveur. La piste doit suivre le nombre reellement affiche :
// l'en-tete utilise le gabarit COMPLET, une piste figee le desalignerait de la
// colonne des lignes (c'etait le cas au passage de deux a trois pastilles).
var _PL_ACTS_W = { 3: '70px', 4: '90px' };
function _plActsTrack() {
  var admin = false;
  try { admin = !!(window._amServerAdmin && window._amServerAdmin()); } catch (e) {}
  return _PL_ACTS_W[admin ? 4 : 3];
}
var _PL_TRACK = { av:'22px', name:'minmax(0,1fr)', status:'22px', flag:'48px', star:'26px', inv:'26px', acts:'70px' };
// Lu a CHAQUE construction de gabarit (en-tete comme lignes) pour que le
// passage admin / non-admin se voie sans rechargement.
function _plTrack(k) { return (k === 'acts') ? _plActsTrack() : _PL_TRACK[k]; }
var _PL_COL_ORDER   = ['av','name','star','status','flag','inv','acts'];
var _PL_TOGGLE_COLS = ['av','status','flag','star','acts']; // 'name' et 'inv' exclus
// Colonne « Inviter à la partie » (parité PlayerListItem QML) : présente
// UNIQUEMENT sur la page d'attente de démarrage (s-lobby.lobby-waiting)
// d'une partie SUR INVITATION (type 3, parité QML canInviteFromCurrentGame :
// jamais en Normal / inscrits seulement / Ranking).
// Réutilise la mécanique du modal d'invitation : App._inviteEligiblePids()
// pour l'éligibilité et App.sendInvite(pid) pour l'envoi.
// Enveloppe : ouvre la conversation privée avec ce joueur (parité QML,
// icône ✉ de la liste des joueurs connectés).
var _PL_MAIL_SVG = '<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M20 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2Zm0 4.24-8 4.76-8-4.76V6l8 4.76L20 6v2.24Z"/></svg>';
// Parite QML canSendPm (PlayerListItem.qml) : pas d'enveloppe sur ma propre
// ligne, pas d'enveloppe si je suis invite (le serveur refuse tout chat des
// invites), et pas d'enveloppe vers un joueur assis a une partie EN COURS
// (isPlayerInRunningGame) -- le serveur ne lui delivrerait rien.
// NB : `S` est prive a l'IIFE App et n'existe PAS ici ; comme tout le reste
// de renderPlayersList, on passe par les ponts window.* (un acces direct
// levait un ReferenceError qui vidait la liste entiere).
function _plCanSendPm(r) {
  if (r.isMe) return false;
  try { if (window._amGuestMode && window._amGuestMode()) return false; } catch (e) {}
  try { return !(window._playerInRunningGame && window._playerInRunningGame(r.pid)); }
  catch (e) { return true; }
}
// Marteau (gavel) : kickban total, parite QML canAdminModerate -- visible
// seulement si JE suis admin serveur, jamais sur ma propre ligne ni sur un bot.
var _PL_GAVEL_SVG = '<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M2.3 19.3 8.6 13l2.4 2.4-6.3 6.3a1.7 1.7 0 0 1-2.4-2.4Zm10.1-6.6-1.4-1.4 6.4-6.4 1.4 1.4-6.4 6.4ZM15.9 2l6.1 6.1-1.8 1.8-6.1-6.1L15.9 2ZM9.8 8.1l6.1 6.1-1.8 1.8-6.1-6.1 1.8-1.8Z"/></svg>';
function _plCanKickban(r) {
  if (r.isMe) return false;
  try { if (window.isBot && window.isBot(r.pid)) return false; } catch (e) {}
  try { return !!(window._amServerAdmin && window._amServerAdmin()); } catch (e) { return false; }
}
window._plOpenPm = function(pid){
  var nm = (typeof window.getPlayerName === 'function') ? window.getPlayerName(pid) : null;
  if (!nm) return;
  try { if (typeof window.openPmModal === 'function') window.openPmModal(nm); } catch (e) {}
};
var _PL_INVITE_SVG = '<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M15 12a4 4 0 1 0-4-4 4 4 0 0 0 4 4Zm0 1.8c-3.5 0-6.3 1.8-6.3 4V19h12.6v-1.2c0-2.2-2.8-4-6.3-4ZM6 9V6.6H4.4V9H2v1.6h2.4V13H6v-2.4h2.4V9H6Z"/></svg>';
function _plWaitingMode() { var s = document.getElementById('s-lobby'); return !!(s && s.classList.contains('lobby-waiting')); }
function _plCanInviteHere() {
  try { return !!(window.InviteLink && window.InviteLink.canInviteFromCurrentGame && window.InviteLink.canInviteFromCurrentGame()); }
  catch (e) { return false; }
}
function _plColOrder() { return (_plWaitingMode() && _plCanInviteHere()) ? _PL_COL_ORDER : _PL_COL_ORDER.filter(function(k){ return k !== 'inv'; }); }
window._plInvite = function(pid){
  try { if (typeof App !== 'undefined' && App.sendInvite) App.sendInvite(pid); } catch(e) {}
  try { renderPlayersList(); } catch(e) {}
};
function _plColsHidden() {
  try { return new Set((localStorage.getItem('pth_pl_cols') || '').split(',').filter(Boolean)); }
  catch (e) { return new Set(); }
}
function _plColVisible(k) { return k === 'name' || !_plColsHidden().has(k); }
function _plVisibleCols() { return _plColOrder().filter(_plColVisible); }
function _plHiddenToggleKeys() { return _plColOrder().filter(function(k){ return _PL_TOGGLE_COLS.indexOf(k) !== -1 && !_plColVisible(k); }); }
window._plToggleCol = function (k) {
  if (_PL_TOGGLE_COLS.indexOf(k) === -1) return;
  try {
    var h = _plColsHidden();
    if (h.has(k)) h.delete(k); else h.add(k);
    localStorage.setItem('pth_pl_cols', Array.from(h).join(','));
  } catch (e) {}
  try { renderPlayersList(); } catch (e) {}
};
// Menu "+" (colonnes masquées) : ouvert/fermé en mémoire (pas de persistance,
// il se referme d'une session à l'autre). Fermé au clic extérieur.
var _plColMenuOpen = false;
window._plColMenuToggle = function (e) {
  if (e) e.stopPropagation();
  _plColMenuOpen = !_plColMenuOpen;
  try { renderPlayersList(); } catch (e2) {}
};
document.addEventListener('click', function (e) {
  if (!_plColMenuOpen) return;
  if (e.target.closest && e.target.closest('.pl-colh-plus-wrap')) return;
  _plColMenuOpen = false;
  try { renderPlayersList(); } catch (e2) {}
});
// Icônes de l'en-tête colonnes (monochromes, suivent le thème via currentColor).
var _PL_PERSON_SVG = '<svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm0 1.6c-4 0-7.2 2-7.2 4.6V20h14.4v-1.8c0-2.6-3.2-4.6-7.2-4.6Z"/></svg>';
var _PL_FLAG_SVG   = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" aria-hidden="true"><path d="M6 21V4h11l-2.2 4L17 12H6"/></svg>';
var _PL_PLUS_SVG   = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>';
// En-tête : une pastille par colonne actuellement VISIBLE (même gabarit que
// les lignes, --pl-cols → alignement 1:1 garanti, quel que soit l'ordre dans
// lequel les colonnes ont été masquées/réaffichées). Le Nom = cellule
// verrouillée, pas de pastille. Les colonnes masquées n'ont plus de pastille
// dans la grille : elles se retrouvent dans le menu "+" (piste fixe à part,
// ajoutée seulement si au moins une colonne est masquée).
function _plColHeadHtml() {
  var _tt = function (k, fb) { return (typeof t === 'function' && t(k) !== k) ? t(k) : fb; };
  var NAME_SVG = '<svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><line x1="5" y1="8" x2="19" y2="8"/><line x1="5" y1="12" x2="15" y2="12"/><line x1="5" y1="16" x2="17" y2="16"/></svg>';
  var ICON  = { av:_PL_PERSON_SVG, name:NAME_SVG, status:_PL_PAD_SVG, flag:_PL_FLAG_SVG, star:'<span class="pl-colh-star">\u2605</span>', inv:_PL_INVITE_SVG, acts:_PL_BAR_SVG };
  var LABEL = { av:_tt('plColAvatar','Avatar'), name:_tt('plColName','Name'), status:_tt('plColStatus','In game'), flag:_tt('plColCountry','Country'), star:_tt('plColMe','Me') + ' \u00b7 ' + _tt('nvRating','Rating'), inv:_tt('inviteBtn','Invite'), acts:_tt('plColActions','Actions') };
  var html = _plVisibleCols().map(function (k) {
    if (k === 'name' || k === 'inv') {
      // Fausse pastille : colonne Nom toujours visible (non togglable),
      // même apparence carrée en état "on" mais non cliquable.
      return '<span class="pl-colh-chip on pl-colh-lock" title="' + LABEL[k] + '" aria-label="' + LABEL[k] + '">' + ICON[k] + '</span>';
    }
    return '<button type="button" class="pl-colh-chip on"'
      + ' title="' + LABEL[k] + '" aria-label="' + LABEL[k] + '" aria-pressed="true"'
      + ' onclick="window._plToggleCol(\'' + k + '\')">' + ICON[k] + '</button>';
  }).join('');
  var _hidden = _plHiddenToggleKeys();
  if (_hidden.length) {
    var _items = _hidden.map(function (k) {
      return '<button type="button" class="pl-colh-menu-item" onclick="window._plToggleCol(\'' + k + '\')">' + ICON[k] + '<span>' + LABEL[k] + '</span></button>';
    }).join('');
    var _moreLbl = _tt('plColMore', 'More columns');
    html += '<span class="pl-colh-plus-wrap">'
      + '<button type="button" class="pl-colh-chip pl-colh-plus" title="' + _moreLbl + '" aria-label="' + _moreLbl + '" aria-expanded="' + _plColMenuOpen + '" onclick="window._plColMenuToggle(event)">' + _PL_PLUS_SVG + '</button>'
      + (_plColMenuOpen ? '<span class="pl-colh-menu">' + _items + '</span>' : '')
      + '</span>';
  }
  return html;
}

function renderPlayersList() {
  var body = document.getElementById('players-list-body');
  var countEl = document.getElementById('players-panel-count');
  var titleEl = document.getElementById('players-panel-title');
  if (!body) return;
  // Rebuild the title from scratch so it stays in sync with the
  // active language and the running count. Structure mirrors the
  // game-chat panel header (single inline span).
  if (titleEl) {
    var lbl = (typeof t === 'function') ? t('playersOnlineTitle') : 'Players online';
    titleEl.innerHTML = '👥 ' + lbl + ' — <span id="players-panel-count">0</span>';
    countEl = document.getElementById('players-panel-count'); // re-resolve after innerHTML
  }
  // ── En-tête colonnes + gabarit de grille ──
  // rowHtml n'émet que les cellules visibles ; --pl-cols (posé sur la liste)
  // donne aux .pl-row le gabarit réduit correspondant → pas de piste vide.
  // L'en-tête (sticky, dans le corps scrollable) utilise EXACTEMENT le même
  // gabarit réduit que les lignes → alignement 1:1 garanti, quel que soit
  // l'ordre dans lequel les colonnes ont été masquées/réaffichées. Une piste
  // fixe supplémentaire (22px) est ajoutée UNIQUEMENT s'il reste au moins une
  // colonne masquée, pour le bouton "+" qui les réaffiche.
  var _visCols = _plVisibleCols();
  var _hiddenKeys = _plHiddenToggleKeys();
  var _headTmpl = _visCols.map(_plTrack).join(' ') + (_hiddenKeys.length ? ' 22px' : '');
  var _headHtml = '<div class="pl-colhead" style="grid-template-columns:' + _headTmpl + '">'
                + _plColHeadHtml() + '</div>';
  try { body.style.setProperty('--pl-cols', _visCols.map(_plTrack).join(' ')); } catch (e) {}
  // Largeur mini de la colonne Joueurs (lobby large >=900) : pistes fixes
  // visibles + gaps + padding/bordure du panneau + 60px pour le pseudo. Sans
  // ce plancher, au défaut 240px les pistes fixes (228px) mangeaient toute la
  // ligne et la colonne Nom tombait à 0px (aucun pseudo visible). Recalculé à
  // chaque rendu : colonnes masquées / admin / Inviter / barre de défilement.
  try {
    var _gap = parseFloat(getComputedStyle(body).getPropertyValue('--sp-3')) || 8;
    var _fixed = _visCols.filter(function (k) { return k !== 'name'; })
      .reduce(function (sum, k) { return sum + (parseFloat(_plTrack(k)) || 0); }, 0);
    var _sb = Math.max(0, body.offsetWidth - body.clientWidth);
    var _lg = document.querySelector('#s-lobby .lobby-grid');
    if (_lg) _lg.style.setProperty('--pl-min', Math.ceil(_fixed + (_visCols.length - 1) * _gap + 26 + _sb + 60) + 'px');
  } catch (e) {}
  // Build the list of {pid, name} from _lobbyPids (defined inside
  // the IIFE; we read it via window-level references).
  var pids = window._readLobbyPids ? window._readLobbyPids() : [];
  var nameMap = window._readPlayers ? window._readPlayers() : {};
  var myId = window._readMyId ? window._readMyId() : 0;
  // Snapshot complet pour accéder aux drapeaux (flagOf) sans multiplier les ponts.
  var _ls = (typeof App !== 'undefined' && App.getLobbyState) ? App.getLobbyState() : {};
  var _flagOf = (_ls && typeof _ls.flagOf === 'function') ? _ls.flagOf : function() { return ''; };
  // Build display rows
  var rows = pids.map(function(pid) {
    return { pid: pid, name: nameMap[pid] || ('#' + pid), isMe: pid === myId };
  });
  // Déduplication de MON pseudo : le serveur peut lister plusieurs pids en
  // ligne portant exactement mon nom (fantôme d'une session précédente pas
  // encore purgée). On ne garde que MA session (marquée isMe / ★) et on retire
  // les homonymes. N'affecte pas les autres joueurs entre eux.
  (function(){
    var _mine = (myId && nameMap[myId] && String(nameMap[myId]).charAt(0) !== '#') ? nameMap[myId] : null;
    if (_mine) rows = rows.filter(function(r){ return r.isMe || r.name !== _mine; });
  })();
  // Same for the other players: a too-quick reconnect leaves the dead session
  // listed under the same nickname (it rejects PMs). Only the latest session
  // is kept (modules/game/presence.mjs).
  (function(){
    var _gh = null;
    try { _gh = window._pthGhostPids ? window._pthGhostPids() : null; } catch (e) {}
    if (_gh && _gh.size) rows = rows.filter(function(r){ return r.isMe || !_gh.has(r.pid); });
  })();
  // Filter by search input
  var _qIn = document.getElementById('players-search-in');
  // Garde anti-autoremplissage : un gestionnaire de mots de passe peut
  // injecter un identifiant enregistré (ex. « admin ») sans action du
  // joueur — la liste se vidait alors toute seule. Valeur autoremplie = ignorée.
  if (_qIn && _qIn.value) {
    var _af = false;
    try { _af = _qIn.matches(':autofill'); } catch (e) {}
    if (!_af) { try { _af = _qIn.matches(':-webkit-autofill'); } catch (e) {} }
    if (_af) _qIn.value = '';
  }
  var q = (_qIn || {}).value || '';
  // ✕ d'effacement visible seulement quand le champ contient du texte.
  var _qClr = document.getElementById('players-search-clr');
  if (_qClr) _qClr.hidden = !q;
  q = q.toLowerCase().trim();
  if (q) rows = rows.filter(function(r) { return r.name.toLowerCase().includes(q); });
  // Tri : A–Z ou par pays (parité tri joueurs QML, bible §16) — je me
  // classe comme tout le monde selon le filtre actif (plus d'épinglage en
  // tête ; ★ suffit à me repérer). Persistant (pth_pl_sort) ; sans-pays en dernier.
  // Mode unique (single-select, parité officielle) : 'az' (alpha, tous) ·
  // 'cc' (par pays, tous) · 'idle' (n'affiche QUE les joueurs inactifs).
  var _plMode = 'az';
  try { _plMode = localStorage.getItem('pth_pl_mode') || localStorage.getItem('pth_pl_sort') || 'az'; } catch (e) {}
  if (['az','cc','idle'].indexOf(_plMode) === -1) _plMode = 'az';
  var _plSort = (_plMode === 'cc') ? 'cc' : 'az';
  rows.sort(function(a, b) {
    if (_plSort === 'cc') {
      // Codes pays via le pont App.getLobbyState().countries (la variable
      // _playerCountries vit dans l'IIFE App, inaccessible d'ici).
      var _ccs = (_ls && _ls.countries) || {};
      var ca = (_ccs[a.pid] || '\uffff');
      var cb = (_ccs[b.pid] || '\uffff');
      if (ca !== cb) return ca < cb ? -1 : 1;
    }
    return a.name.localeCompare(b.name);
  });
  try {
    var _bAz = document.getElementById('pls-az'), _bCc = document.getElementById('pls-cc');
    if (_bAz) _bAz.classList.toggle('active', _plSort !== 'cc');
    if (_bCc) _bCc.classList.toggle('active', _plSort === 'cc');
  } catch (e) {}
  if (countEl) countEl.textContent = pids.length;
  if (rows.length === 0) {
    body.innerHTML = _headHtml + '<div class="pl-empty">' + (q ? '— ' : '—') + '</div>';
    return;
  }
  // ── Variante A : sections « En partie / Au lobby » (choix utilisateur
  // sur maquette). L'activité est calculée UNE fois par joueur, chaque
  // groupe garde le tri (moi d'abord, puis alphabétique) et la recherche
  // filtre les deux sections. Headers affichés seulement si les deux
  // groupes sont non vides (sinon liste plate, rien à séparer). ──
  rows.forEach(function(r) {
    r.act = (typeof window._playerActivity === 'function') ? window._playerActivity(r.pid) : '';
  });
  var _inGame = rows.filter(function(r) { return r.act; });
  var _atLobby = rows.filter(function(r) { return !r.act; });
  // Éligibilité d'invitation (page d'attente uniquement) : même source que le
  // modal (App._inviteEligiblePids) -> exclut moi et les joueurs déjà à ma table.
  var _invMode = _plWaitingMode() && _plCanInviteHere() && (typeof App !== 'undefined') && App._inviteEligiblePids;
  var _invElig = {};
  if (_invMode) { try { App._inviteEligiblePids().forEach(function(p){ _invElig[p] = 1; }); } catch(e) { _invMode = false; } }
  // Admin ? decide le nombre d'emplacements de la colonne d'actions ; lu une
  // fois par rendu et non par ligne, pour que toutes les lignes s'accordent
  // meme si les droits changeaient au milieu d'une boucle.
  var _actsAdmin = false;
  try { _actsAdmin = !!(window._amServerAdmin && window._amServerAdmin()); } catch (e) {}
  var rowHtml = function(r) {
    var esc = function(s) { return String(s).replace(/[<>&"]/g, function(c){return {'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[c];}); };
    // Avatar chip via the unified helper (same priority order as
    // every other compact list in the app: real PokerTH image >
    // placeholder logo > emoji > 🤖 > initial letter).
    var avChip = (typeof window._avatarChipHtml === 'function')
      ? window._avatarChipHtml(r.pid, r.name, 'pl-av')
      : '<span class="pl-av letter">' + esc((r.name[0] || '?').toUpperCase()) + '</span>';
    // Drapeau du pays + code ISO à 2 lettres à sa droite (certains drapeaux
    // se ressemblent). Code lu depuis countries[pid]. Sans pays → rien.
    var flag = _flagOf(r.pid) || '';
    var _ccRaw = (_ls.countries && _ls.countries[r.pid]) ? String(_ls.countries[r.pid]).trim().toUpperCase() : '';
    var cc = /^[A-Z]{2}$/.test(_ccRaw) ? _ccRaw : '';
    // Nom cliquable → ouvre le popup joueur (rôle, drapeau, cups, lien profil).
    // Tous les joueurs (enregistrés ET invités) ; le popup gère le contenu.
    // Pour MOI : appeler openPlayerInfoPopup() SANS argument → exactement la
    // même fenêtre que le bouton joueur du header. Pour les autres : avec pid.
    var _ppArg = r.isMe ? '' : String(r.pid);
    // Parité QML PlayerListItem (stable, 27/08/2026) : phrase complète
    // « %1 is playing in "%2". » / « %1 is not playing at the moment. » en
    // tooltip du NOM — même source (r.act) que la manette de statut, dont le
    // title (nom de table seul) est conservé tel quel. Le pendant tactile —
    // pas de hover au doigt — est la même ligne dans le popup joueur
    // (_otherPlayerInfoHtml, player-popup.mjs).
    var _actTtl = r.act
      ? _tt('plPlayingInFull', '%1 is playing in "%2".').replace('%1', r.name).replace('%2', r.act)
      : _tt('plNotPlayingFull', '%1 is not playing at the moment.').replace('%1', r.name);
    // Pastille d'étiquette APRÈS le pseudo, hors du lien (le pseudo garde
    // l'ellipse pour lui seul, la pastille reste visible derrière un nom trop
    // long) ; la note en étoiles, elle, va dans la colonne ★ (demande narmod
    // 07/09). Jamais sur ma propre ligne — ce qui laisse justement la place à
    // mon étoile dans cette colonne.
    var _nvTag = '', _nvStars = '';
    if (!r.isMe) {
      try {
        if (typeof window._nvSeatDot === 'function') _nvTag = window._nvSeatDot(r.name);
        if (typeof window._nvSeatStars === 'function') _nvStars = window._nvSeatStars(r.name);
      } catch (e) {}
    }
    var nameHtml = '<span class="pl-name-link" role="button" tabindex="0"'
      + ' title="' + esc(_actTtl) + '"'
      + ' onclick="window.openPlayerInfoPopup(' + _ppArg + ')"'
      + ' onkeydown="if(event.key===\'Enter\')window.openPlayerInfoPopup(' + _ppArg + ')">'
      + esc(r.name) + '</span>'
      + (_nvTag ? '<span class="seat-nv">' + _nvTag + '</span>' : '');
    // Statut « en partie » : une seule manette dans sa colonne (allumée si le
    // joueur est dans une partie, éteinte sinon). Plus de nom de partie sous le pseudo.
    var _status = '<span class="pl-status' + (r.act ? ' on' : '') + '" title="' + (r.act ? esc(r.act) : _tt('plNotPlaying','Not playing')) + '"' + (r.act ? '' : ' data-i18n-title="plNotPlaying"') + '>' + _PL_PAD_SVG + '</span>';
    var _ign  = _isIgnored(r.name);
    // Le 🚫 de ma propre ligne est conservé tel quel : le retirer serait un
    // changement visible à part entière (accord narmod 26/08).
    // La cellule porte TOUJOURS le meme nombre d'emplacements que la piste
    // reserve (3, ou 4 en admin) : une pastille absente laisse une cale de
    // meme largeur. Sans elle, .pl-acts etant aligne a droite, une ligne
    // depourvue d'enveloppe ou de marteau glissait d'un cran et ses icones
    // ne tombaient plus sous la bonne pastille d'en-tete.
    var _acts = '<span class="pl-acts">'
      + (_plCanSendPm(r) ? '<button type="button" class="pl-act pl-act-pm" title="' + _tt('pmBtn','Private message') + '" data-i18n-title="pmBtn" aria-label="' + _tt('pmBtn','Private message') + '" onclick="event.stopPropagation();window._plOpenPm(' + r.pid + ')">' + _PL_MAIL_SVG + '</button>' : '<span class="pl-act-gap"></span>')
      + '<button type="button" class="pl-act pl-act-ban' + (_ign ? ' on' : '') + '" title="' + _tt('plIgnore','Ignore') + '" data-i18n-title="plIgnore" aria-label="' + _tt('plIgnore','Ignore') + '" onclick="event.stopPropagation();window._plToggleIgnore(' + r.pid + ')">' + _PL_BAN_SVG + '</button>'
      + '<button type="button" class="pl-act pl-act-stats" title="' + _tt('plStats','Stats') + '" data-i18n-title="plStats" aria-label="' + _tt('plStats','Stats') + '" onclick="event.stopPropagation();window._plOpenStats(' + _ppArg + ')">' + _PL_BAR_SVG + '</button>'
      + (_actsAdmin ? (_plCanKickban(r) ? '<button type="button" class="pl-act pl-act-gavel" title="' + _tt('piKickban','Total kickban') + '" data-i18n-title="piKickban" aria-label="' + _tt('piKickban','Total kickban') + '" onclick="event.stopPropagation();window._adminBanPlayer(' + r.pid + ')">' + _PL_GAVEL_SVG + '</button>' : '<span class="pl-act-gap"></span>') : '')
      + '</span>';
    var _plCell = function (k) {
      switch (k) {
        case 'av':     return avChip;
        case 'name':   return '<span class="pl-name' + (_nvTag ? ' has-nv' : '') + '">' + nameHtml + '</span>';
        case 'status': return _status;
        case 'flag':   return '<span class="pl-flag">' + flag + (cc ? '<span class="pl-cc">' + cc + '</span>' : '') + '</span>';
        // Deux sens, une colonne : mon étoile sur ma ligne, ma note en étoiles
        // sur celle des autres. Ils ne peuvent pas se croiser (_nvStars est
        // vide sur ma propre ligne).
        case 'star':   return '<span class="pl-star">' + (r.isMe ? '★' : _nvStars) + '</span>';
        case 'inv': {
          if (!_invMode || !_invElig[r.pid]) return '<span class="pl-cell-off"></span>';
          var _sent = (typeof App.inviteSentTo === 'function') && App.inviteSentTo(r.pid);
          return _sent
            ? '<span class="pl-act pl-act-inv sent" title="' + _tt('inviteSent','Invited') + '">' + _PL_INVITE_SVG + '</span>'
            : '<button type="button" class="pl-act pl-act-inv" title="' + _tt('inviteBtn','Invite') + '" aria-label="' + _tt('inviteBtn','Invite') + '" onclick="event.stopPropagation();window._plInvite(' + r.pid + ')">' + _PL_INVITE_SVG + '</button>';
        }
        case 'acts':   return _acts;
      }
      return '';
    };
    // Colonnes masquées : piste RETIRÉE (pas de cellule vide) → le nom
    // récupère vraiment la largeur. L'en-tête (_headTmpl, renderPlayersList)
    // utilise désormais le même gabarit réduit → alignement 1:1 garanti.
    return '<div class="pl-row' + (r.isMe ? ' pl-me' : '') + '">'
      + _visCols.map(function (k) { return _plCell(k); }).join('')
      + '</div>';
  };
  var _tt = function(k, fb) { return (typeof t === 'function' && t(k) !== k) ? t(k) : fb; };
  // Synchronise la valeur du déroulant sur le mode courant.
  try {
    var _sortSel = document.getElementById('pl-sort-select');
    if (_sortSel) _sortSel.value = _plMode;
  } catch (e) {}
  // Liste À PLAT (parité officielle). Mode 'idle' → n'affiche QUE les joueurs
  // inactifs (hors partie) ; sinon tous les joueurs, dans l'ordre de tri.
  var _shown = (_plMode === 'idle') ? rows.filter(function(r){ return !r.act; }) : rows;
  body.innerHTML = _headHtml + (_shown.length ? _shown.map(rowHtml).join('') : '<div class="pl-empty">—</div>');
}

/* ── Page Privacy in-app (même entête cp-header que les autres écrans) ── */
;(function(){
  function $(id){ return document.getElementById(id); }
  // The policy as a web page, in the player's language — the same format as
  // /faq and /rules, served translated on every install, indexing on or off.
  // Offline the page cannot load: the in-app window, which follows the UI
  // language too, opens instead.
  function privacyUrl(){
    var l = window._lang || '';
    return '/privacy' + (l && l !== 'en' ? '?lang=' + encodeURIComponent(l) : '');
  }
  function privacyWeb(){ return navigator.onLine !== false; }
  // Keep the footer link's href in step with the language, so a long press or
  // "open in a new tab" reaches the same page as a plain click.
  function syncPrivacyHref(){
    var a = document.querySelector('a[onclick*="openPrivacyPage"]');
    if (a) a.setAttribute('href', privacyUrl());
  }
  // i18n.mjs is a module and may not be loaded yet when this runs: subscribe
  // once the DOM is ready (onLangChange ignores a second subscription).
  function initPrivacyHref(){ if (window._onLangChange) window._onLangChange(syncPrivacyHref); syncPrivacyHref(); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initPrivacyHref); else initPrivacyHref();
  window.openPrivacyPage = function(){
    if (privacyWeb()) { location.href = privacyUrl(); return; }
    var p = $('privacy-page'); if (!p) return;
    p.style.display = 'flex';
  };
  window.closePrivacyPage = function(){
    window.closePrivacyOverflow();
    var p = $('privacy-page'); if (p) p.style.display = 'none';
  };
  window.togglePrivacyOverflow = function(e){
    if (e) e.stopPropagation();
    var m = $('pv-overflow-menu'); if (m) m.classList.toggle('open');
  };
  window.closePrivacyOverflow = function(){
    var m = $('pv-overflow-menu'); if (m) m.classList.remove('open');
  };
  document.addEventListener('click', function(e){
    var m = $('pv-overflow-menu'), b = $('pv-overflow-btn');
    if (m && m.classList.contains('open') && !m.contains(e.target) && e.target !== b && !(b && b.contains(e.target))) m.classList.remove('open');
  });
  document.addEventListener('keydown', function(e){
    if (e.key === 'Escape') { var p = $('privacy-page'); if (p && p.style.display === 'flex') window.closePrivacyPage(); }
  });
})();

/* ── Page « À propos de PokerTH » (parité AboutPage QML) ── */
;(function(){
  function $(id){ return document.getElementById(id); }
  // Onglets trop larges pour la fenêtre (téléphone, langues longues) : au lieu
  // de libellés coupés sur deux lignes (« Journa / l des… »), une barre qui
  // défile horizontalement avec les noms entiers (demande narmod 22/10/2026).
  // Mesuré en mode défilement : s'ils tiennent tous, la barre redevient la
  // rangée d'onglets égaux habituelle.
  function abFitTabs(){
    var bar = document.querySelector('#about-page .ab-tabs'), p = $('about-page');
    if (!bar || !p || p.style.display === 'none') return;
    bar.classList.add('ab-scroll');
    if (bar.scrollWidth <= bar.clientWidth + 1) bar.classList.remove('ab-scroll');
    abShowActiveTab();
  }
  function abShowActiveTab(){
    var bar = document.querySelector('#about-page .ab-tabs');
    var a = bar && bar.classList.contains('ab-scroll') && bar.querySelector('.ab-tab.active');
    if (a) {
      var bl = bar.getBoundingClientRect(), al = a.getBoundingClientRect();
      if (al.left < bl.left) bar.scrollLeft -= (bl.left - al.left) + 12;
      else if (al.right > bl.right) bar.scrollLeft += (al.right - bl.right) + 28;
    }
    abTabsEdge();
  }
  // Un fondu sur chaque bord derrière lequel il reste des onglets (mesuré sur
  // les positions réelles : vaut aussi de droite à gauche).
  function abTabsEdge(){
    var bar = document.querySelector('#about-page .ab-tabs');
    if (!bar) return;
    var on = bar.classList.contains('ab-scroll'), b = bar.getBoundingClientRect(), l = false, r = false;
    if (on) Array.prototype.forEach.call(bar.children, function (t) { var x = t.getBoundingClientRect(); if (x.left < b.left - 1) l = true; if (x.right > b.right + 1) r = true; });
    bar.classList.toggle('ab-fl', l); bar.classList.toggle('ab-fr', r);
  }
  (function(){ var bar = document.querySelector('#about-page .ab-tabs'); if (bar) bar.addEventListener('scroll', abTabsEdge, { passive: true }); })();
  window.addEventListener('resize', abFitTabs);
  if (window._onLangChange) window._onLangChange(abFitTabs);
  else document.addEventListener('DOMContentLoaded', function(){ if (window._onLangChange) window._onLangChange(abFitTabs); });
  window.openAboutPage = function(){
    var p = $('about-page'); if (!p) return;
    p.style.display = 'flex';
    var v = $('ab-version');
    if (v) v.textContent = 'PokerTH Web Client ' + (window.BUILD_VERSION || '');
    window.abShowTab(0);
    abFitTabs();
  };
  window.closeAboutPage = function(){ var p = $('about-page'); if (p) p.style.display = 'none'; };
  window.abShowTab = function(i){
    for (var k = 0; k < 7; k++) {
      var tb = $('ab-tab-' + k), pn = $('ab-pane-' + k);
      if (tb) tb.classList.toggle('active', k === i);
      if (pn) pn.style.display = (k === i) ? 'block' : 'none';
    }
    if (i === 5) _abLoadChangelog(); else _abClLoaded = false; // relecture en ligne au retour
    // Onglet Guides du poker : liste servie dans la langue de la page,
    // relue dans la langue de l'interface si elle diffère (web.243).
    if (i === 6) import('/modules/seo/about-guides.mjs').then(function (m) { m.refreshAboutGuides(window._lang); }).catch(function () {});
    abShowActiveTab();
  };
  // Onglet Changelog (demande sp0ck 12/08/2026, parité widget/QML) : le
  // fichier ChangeLog upstream, embarqué dans /ChangeLog (épinglé à la
  // release livrée — à rafraîchir à chaque bump de release). Chargé une
  // seule fois, rendu texte échappé avec les entêtes de version en évidence.
  var _abClLoaded = false;
  function _abClRender(txt){
    var esc = function(s){ return String(s).replace(/[&<>]/g, function(c){ return { '&':'&amp;', '<':'&lt;', '>':'&gt;' }[c]; }); };
    // Regroupement par type (demande narmod 03/09/2026) : dans chaque bloc de
    // version, les lignes « - new: / - improvement: / - bugfix: » (convention
    // de ChangeLog-web) sont rangées sous des sous-titres traduits. Les lignes
    // sans préfixe reconnu restent telles quelles, dans l'ordre du fichier —
    // le ChangeLog upstream (sans préfixes) est donc rendu comme avant.
    var t2 = function(k, fb){ var v = (typeof window.t === 'function') ? window.t(k) : k; return (v && v !== k) ? v : fb; };
    var GRP = [
      { re: /^-\s*new:\s*/i,         key: 'abClNew',          fb: 'New' },
      { re: /^-\s*improvement:\s*/i, key: 'abClImprovements', fb: 'Improvements' },
      { re: /^-\s*bugfix:\s*/i,      key: 'abClBugfixes',     fb: 'Bug fixes' }
    ];
    // Fusion par version (narmod 09/09/2026, étendue 13/09/2026) : ChangeLog-web
    // tient une entrée par DÉPLOIEMENT (« <date> version 2.1.8-web: » ou, depuis
    // web.121, « <date> version 2.1.9-web.N: »). Pour un rendu propre — un seul
    // bloc par version upstream, comme le ChangeLog des clients installables —
    // le compteur de déploiement « .N » est ignoré dans la clé de fusion : tous
    // les builds d'une même version « X.Y.Z-web » se regroupent sous une seule
    // entête, quel que soit leur .N (ou son absence, cas des anciennes entrées
    // sans compteur). L'entête affichée est reconstruite (date du bloc le plus
    // récent + version sans .N + « (current series) » si présent) plutôt que
    // recopiée telle quelle, pour ne pas figer un numéro de build particulier
    // sur un bloc qui en contient plusieurs. Items dans l'ordre du fichier
    // (antichronologique). Le ChangeLog upstream n'a pas de suffixe « -web »
    // donc n'est pas affecté par ce repli — rendu inchangé.
    var VER = /^(\d{4}-\d{2}-\d{2})\s+version\s+(.*)$/i;
    var head = [], blocks = [], byKey = {}, block = null;
    String(txt).split('\n').forEach(function(line){
      var m = VER.exec(line);
      if (m || /^Before\s+\d{4}-\d{2}-\d{2}/i.test(line)) {
        var rawDate = m ? m[1] : null;
        var rawVer  = m ? m[2] : line.trim();
        var isCurrent = /\(current series\)/i.test(rawVer);
        var key = rawVer.replace(/\(current series\)/i, '').replace(/:/g, '').trim()
          .replace(/(-web)\.\d+\b/i, '$1'); // ignore le compteur de déploiement pour la fusion
        block = byKey['k:' + key];
        if (!block) {
          var dispVer = m ? (rawDate + ' version ' + key + (isCurrent ? ' (current series)' : '') + ':') : line;
          block = byKey['k:' + key] = { ver: dispVer, plain: [], groups: [[], [], []] };
          blocks.push(block);
        }
        return;
      }
      if (line.trim() === '') return; // séparateur de blocs : l'espacement est posé au rendu
      if (!block) { head.push(line); return; }
      for (var i = 0; i < GRP.length; i++)
        if (GRP[i].re.test(line)) { block.groups[i].push(line.replace(GRP[i].re, '')); return; }
      block.plain.push(line);
    });
    var out = [];
    head.forEach(function(l){ out.push('<div class="ab-cl-line">' + esc(l) + '</div>'); });
    blocks.forEach(function(b, bi){
      if (bi || head.length) out.push('<div class="ab-cl-gap"></div>');
      out.push('<div class="ab-cl-ver">' + esc(b.ver) + '</div>');
      b.plain.forEach(function(l){ out.push('<div class="ab-cl-line">' + esc(l) + '</div>'); });
      GRP.forEach(function(g, i){
        if (!b.groups[i].length) return;
        out.push('<div class="ab-cl-grp">' + esc(t2(g.key, g.fb)) + '</div>');
        b.groups[i].forEach(function(item){ out.push('<div class="ab-cl-line ab-cl-item">' + esc(item) + '</div>'); });
      });
    });
    return out.join('');
  }

  // Sous-onglets du changelog : « Client web » | « Autres clients »
  window.abClShowSub = function(which){
    var tw = document.getElementById('ab-cl-tab-web'), tu = document.getElementById('ab-cl-tab-up');
    var cw = document.getElementById('ab-cl-web'),    cu = document.getElementById('ab-cl-up');
    var web = (which !== 'up');
    if (tw) tw.classList.toggle('active', web);
    if (tu) tu.classList.toggle('active', !web);
    if (cw) cw.style.display = web ? '' : 'none';
    if (cu) cu.style.display = web ? 'none' : '';
  };
  function _abLoadChangelog(){
    if (_abClLoaded) return;
    var cw = document.getElementById('ab-cl-web'), cu = document.getElementById('ab-cl-up');
    if (!cw || !cu) return;
    _abClLoaded = true;
    // Deux journaux, un par sous-onglet. Chaque source est lue EN LIGNE
    // d'abord (GitHub raw — un push chez narmod ou sp0ck est visible
    // immédiatement, ~5 min de cache CDN au pire, 6 s de délai maxi),
    // puis en repli la copie embarquée précachée (hors-ligne / GitHub
    // inaccessible). Un journal manquant n'empêche pas l'autre.
    var errTxt = function(){ var t = (window.I18N && window.I18N.t) ? window.I18N.t('abClError') : null; return (t && t !== 'abClError') ? t : 'Changelog unavailable.'; };
    var fetchTxt = function(u, ms){
      var ctl = null, tm = null;
      try { ctl = new AbortController(); tm = setTimeout(function(){ try { ctl.abort(); } catch (e) {} }, ms || 6000); } catch (e) {}
      return fetch(u, ctl ? { cache: 'no-cache', signal: ctl.signal } : { cache: 'no-cache' })
        .then(function(r){ return r.ok ? r.text() : null; })
        .catch(function(){ return null; })
        .finally(function(){ if (tm) clearTimeout(tm); });
    };
    var one = function(liveUrl, localUrl){
      return fetchTxt(liveUrl).then(function(t){ return t != null ? t : fetchTxt(localUrl); });
    };
    // Client web : CHANGELOG.md du dépôt (narmod 07/10/2026 — la liste build par build de
    // ChangeLog-web était trop longue), rendu markdown par modules/ui/changelog-md.mjs ;
    // repli local /CHANGELOG.md (lien symbolique public/ → racine, précaché).
    var tr = function(k, fb){ var v = (typeof window.t === 'function') ? window.t(k) : k; return (v && v !== k) ? v : fb; };
    Promise.all([
      one('https://raw.githubusercontent.com/narmod/pokerth-web-client/main/CHANGELOG.md', '/CHANGELOG.md'),
      one('https://raw.githubusercontent.com/pokerth/pokerth/stable/ChangeLog', '/ChangeLog')
    ]).then(function(res){
      var web = res[0], up = res[1];
      if (web == null && up == null) throw new Error('none');
      if (up != null)  cu.innerHTML = _abClRender(up);  else cu.textContent = errTxt();
      if (web == null) { cw.textContent = errTxt(); return; }
      return import('/modules/ui/changelog-md.mjs').then(function(m){
        cw.innerHTML = m.renderChangelogMd(web, tr);
      }, function(){ cw.textContent = web; });
    }).catch(function(){
      _abClLoaded = false; // réessai possible au prochain clic
      var t = errTxt();
      cw.textContent = t; cu.textContent = t;
    });
  }
  document.addEventListener('keydown', function(e){
    if (e.key === 'Escape') { var p = $('about-page'); if (p && p.style.display !== 'none' && p.style.display !== '') window.closeAboutPage(); }
  });
})();

// ── Dropdown custom « Type de partie » (parité QML StyledCombo) ──────────────
// Le <select id="cf-game-type"> natif reste la source de vérité (caché) : tous
// les lecteurs/écrivains existants (sv/svv/set/setVal) continuent de marcher.
// Ce bloc ne fait que refléter sa valeur dans une UI à icônes (champ + liste).
;(function(){
  var sel  = document.getElementById('cf-game-type');
  var btn  = document.getElementById('cf-gtype-btn');
  var ico  = document.getElementById('cf-gtype-ico');
  var lbl  = document.getElementById('cf-gtype-lbl');
  var list = document.getElementById('cf-gtype-list');
  if (!sel || !btn || !ico || !lbl || !list) return;
  var KEY = { '1':'gameNormal', '2':'gameRegistered', '3':'gameInvite', '4':'gameRanking' };
  function refresh() {
    var v = String(sel.value || '1');
    if (!KEY[v]) v = '1';
    ico.className = 'gt-dd-ico gt-ico-' + v;
    lbl.setAttribute('data-i18n', KEY[v]);
    // Libellé : t() si dispo, sinon le texte de l'option native (déjà
    // traduite par la passe data-i18n-opt, ou l'anglais par défaut).
    var opt = sel.querySelector('option[value="' + v + '"]');
    lbl.textContent = (typeof window.t === 'function' && window.t(KEY[v]) !== KEY[v])
      ? window.t(KEY[v])
      : (opt ? opt.textContent : v);
    var items = list.children;
    for (var i = 0; i < items.length; i++)
      items[i].classList.toggle('sel', items[i].getAttribute('data-val') === v);
  }
  function close() { list.hidden = true; btn.setAttribute('aria-expanded', 'false'); }
  btn.addEventListener('click', function(e) {
    e.stopPropagation();
    var open = list.hidden;
    list.hidden = !open;
    btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    if (open) refresh();
  });
  list.addEventListener('click', function(e) {
    var it = e.target.closest('.gt-dd-item');
    if (!it) return;
    sel.value = it.getAttribute('data-val');
    sel.dispatchEvent(new Event('input'));
    sel.dispatchEvent(new Event('change'));
    refresh(); close();
  });
  document.addEventListener('click', function(e) {
    if (!list.hidden && !e.target.closest('#cf-gtype-dd')) close();
  });
  document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape' && !list.hidden) close();
  });
  // set()/setVal() dispatchent 'input' sur le select → on suit, et on
  // resynchronise les contraintes QML (verrous classé, mot de passe…).
  function syncConstraints() {
    try { if (typeof App !== 'undefined' && App._syncGameTypeConstraints) App._syncGameTypeConstraints(); } catch (e) {}
  }
  sel.addEventListener('input',  function() { refresh(); syncConstraints(); });
  sel.addEventListener('change', function() { refresh(); syncConstraints(); });
  window._gtypeDdRefresh = refresh;
  refresh();
  // Erreur « nom requis » (parité QML nameError) : effacée dès la saisie.
  var nameEl = document.getElementById('cf-name');
  var nameErr = document.getElementById('cf-name-err');
  if (nameEl && nameErr) nameEl.addEventListener('input', function() {
    if (nameEl.value.trim().length > 0) nameErr.style.display = 'none';
  });
})();

;(function(){ 
// ═══ [9g-A1] Exposition explicite pour le passage en type=module ═══
// En module, les fonctions/vars top-level ne créent PLUS de propriétés
// window : tout ce que le HTML (handlers inline), chat-emotes.js ou les
// modules consomment via le global doit être ponté explicitement.
// Inventaire automatisé du 2026-07-19 (31 fonctions + App ; les 8 vars
// mutables partagées sont devenues des propriétés window à la source).
window._advGet = _advGet;
window._cfgSyncMark = _cfgSyncMark;   // pont pour modules/ui/forumnews.mjs (etat lu → sync compte)
window._advStripEmoji = _advStripEmoji;
window._chatTs = _chatTs;
// Recentrage explicite d'une fenetre : _enableFloating ne place la fenetre
// que lors de la PREMIERE ouverture (ensuite _restoreWin reapplique la
// position memorisee). Les cartes de stats veulent s'ouvrir centrees a chaque
// fois tout en conservant la TAILLE choisie par le joueur.
window._placeWin = _placeWin;
window._disableFloating = _disableFloating;
window._enableFloating = _enableFloating;
window._winGate = _winGate;   // fix: rkWinGate/trWinGate testent window._winGate (sinon classement jamais flottant -> non redimensionnable)
window._getTableZoom = _getTableZoom;
window._hideBanner = _hideBanner;
window._isIgnored = _isIgnored;
window._seatTraitsNow = _seatTraitsNow;
window._setIgnoredName = _setIgnoredName;   // fix: player-popup.mjs (_toggleIgnore) called it bare -> ReferenceError
window._showBanner = _showBanner;
window._startIpBlockCountdown = _startIpBlockCountdown;
window._tableZoomGate = _tableZoomGate;
window.addGameChat = addGameChat;
window.closeConnectOverflow = closeConnectOverflow;
window.closeCreateOverflow = closeCreateOverflow;
window.closeHeaderOverflow = closeHeaderOverflow;
window.closeLobbyOverflow = closeLobbyOverflow;
window.getAvatarColor = getAvatarColor;
window.joinWithPassword = joinWithPassword;
window.renderPlayersList = renderPlayersList;
window.toggleConnectOverflow = toggleConnectOverflow;
window.toggleCreateOverflow = toggleCreateOverflow;
window.toggleFullscreen = toggleFullscreen;
window.toggleGameChat = toggleGameChat;
window.toggleHandsHelp = toggleHandsHelp;

// ── Relocalisation à chaud du monolithe (registre i18n) ────────────────────
// setLang() ne balaie que le DOM déclaratif (data-i18n*). Tout ce que ce
// fichier peint impérativement en JS reste sinon figé dans la langue
// précédente jusqu'à réouverture du panneau concerné. Un seul abonné pour
// tout le monolithe : chaque bloc est gardé et ne repeint que si sa surface
// est réellement visible.
//
// renderHandsHelp() est appelée ici et non depuis i18n.mjs : c'est une
// fonction de la portée de ce module (pokerth.js est un `type="module"`),
// donc invisible depuis un autre module. L'appel nu qui vivait dans setLang
// levait une ReferenceError dès que la fenêtre des combinaisons était
// ouverte, ce qui interrompait tout le reste de setLang.
try {
  window._onLangChange(function () {
    // Hint de statut de l'écran de connexion (posé par setStatus).
    try { if (typeof window._refreshConnectStatus === 'function') window._refreshConnectStatus(); } catch (e) {}
    // Fenêtre « combinaisons du poker », si ouverte.
    try {
      var ho = document.getElementById('hands-overlay');
      if (ho && ho.style.display !== 'none') renderHandsHelp();
    } catch (e) {}
    // Pastille « N joueur(s) » du header lobby (posée par les messages serveur).
    try { if (typeof window._refreshPlayersPill === 'function') window._refreshPlayersPill(); } catch (e) {}
    // Panneaux/popups ouverts rendus en JS (stats, joueurs, infos partie, profil).
    try { if (typeof window._refreshOpenPanels === 'function') window._refreshOpenPanels(); } catch (e) {}
    // Messages système déjà affichés dans le chat.
    try { if (typeof window._retranslateSysChat === 'function') window._retranslateSysChat(); } catch (e) {}
    // Nom de table par défaut, s'il n'a pas été personnalisé.
    try { if (typeof window._localizeCreateNameField === 'function') window._localizeCreateNameField(); } catch (e) {}
  });
} catch (e) {}
window.toggleHeaderOverflow = toggleHeaderOverflow;
window.toggleLobbyChat = toggleLobbyChat;
window.toggleLobbyOverflow = toggleLobbyOverflow;
window.toggleLog = toggleLog;
window.togglePlayersPanel = togglePlayersPanel;
window.toggleReactionPanel = toggleReactionPanel;
window.App = App;

/* ── Anti-défilement tactile de la PAGE (téléphone / tablette) ─────────────
   html/body sont déjà overflow:hidden + overscroll-behavior:none, mais les
   vieux Safari iOS (< 16) les ignorent et laissent la page entière panner /
   rebondir au doigt (rubber-band constaté sur iPad, login inclus). Garde JS :
   un touchmove sans ancêtre réellement défilant est annulé. Restent intacts :
   pinch multi-doigts (loupe), contrôles natifs (sliders/champs), et toute
   zone avec overflow auto/scroll qui déborde (listes, chat, réglages). */
(function(){
  // Pinch-zoom du navigateur : Safari iOS ignore user-scalable=no du meta
  // viewport → on annule les gestes de zoom. Sans perte : la loupe de table
  // est un bouton +/- dédié (parité QML zoomLayer), jamais un pinch.
  // Option « browser_zoom » (Options avancées, DÉSACTIVÉE par défaut) : la
  // cocher rend le zoom natif au navigateur — recours d'accessibilité.
  window._applyBrowserZoomOpt = function(){
    try{
      var on = _advGet('browser_zoom', false);
      window._browserZoomOn = !!on;
      var m = document.querySelector('meta[name="viewport"]');
      if (!m) return;
      // On repart du content courant : la largeur peut avoir été réécrite au
      // boot (téléphones larges → width=393), il ne faut pas l'écraser.
      var c = (m.getAttribute('content') || '')
        .replace(/,?\s*(maximum-scale|user-scalable)\s*=\s*[^,]*/g, '')
        .replace(/^\s*,\s*/, '').trim();
      if (!on) c += ', maximum-scale=1, user-scalable=no';
      m.setAttribute('content', c);
    }catch(e){}
  };
  window._applyBrowserZoomOpt();
  ['gesturestart','gesturechange','gestureend'].forEach(function(ev){
    document.addEventListener(ev, function(e){
      if (window._browserZoomOn) return;
      if (e.cancelable) e.preventDefault();
    }, { passive:false });
  });
  document.addEventListener('touchmove', function(e){
    // Multi-doigts = tentative de pinch : bloquée sauf si l'option est cochée.
    if (e.touches && e.touches.length > 1){
      if (!window._browserZoomOn && e.cancelable) e.preventDefault();
      return;
    }
    var el = e.target;
    if (el && el.closest && el.closest('input,textarea,select')) return;
    while (el && el !== document.documentElement){
      if (el.scrollHeight > el.clientHeight + 1 || el.scrollWidth > el.clientWidth + 1){
        var cs; try{ cs = getComputedStyle(el); }catch(_){ break; }
        if (/(auto|scroll)/.test(cs.overflowY + ' ' + cs.overflowX)) return;
      }
      el = el.parentElement;
    }
    if (e.cancelable) e.preventDefault();
  }, { passive:false });
})();

window.BUILD_VERSION='2.1.10-web.332'; try{ var b=document.getElementById('cf-build'); if(b) b.textContent='\u00b7 build '+window.BUILD_VERSION; }catch(e){} })();

/* theme-color du navigateur : suit le thème actif ou la palette High contrast
   (Android, Safari, iOS standalone récent). Lit --theme-color et met
   à jour le meta au chargement + à chaque changement de présentation. rAF pour
   lire après recalcul de style (fiabilité iOS). */
;(function(){
  var meta = document.querySelector('meta[name="theme-color"]');
  if (!meta) return;
  function upd(){
    requestAnimationFrame(function(){
      try{
        var c = getComputedStyle(document.documentElement).getPropertyValue('--theme-color').trim();
        if (c) meta.setAttribute('content', c);
      }catch(e){}
    });
  }
  upd();
  try{ new MutationObserver(upd).observe(document.documentElement, { attributes:true, attributeFilter:['data-theme','data-high-contrast'] }); }catch(e){}
})();

/* ── Overlay dropdowns (chat / réactions / journal + lobby) ────────────────
   Les panneaux déroulants sont position:fixed et doivent s'ouvrir JUSTE sous
   le header. Le header n'a pas de hauteur fixe (clamp + paddings + variations
   portrait/paysage + breakpoints) : on mesure sa hauteur réelle et on la
   publie dans --ovl-top, consommée par le CSS (top:var(--ovl-top)). On lit le
   header de l'écran ACTIF (lobby ou jeu). Mesure via getBoundingClientRect
   (fiable iOS, contrairement à getComputedStyle sur les custom properties).
   Mis à jour : resize, orientationchange, changement d'écran (show()), et
   ResizeObserver pour tout changement de contenu du header. */
;(function(){
  function syncOverlayTop(){
    try{
      var scr = document.querySelector('.screen.active');
      var h = scr && scr.querySelector('.header');
      if(!h) return;
      var px = Math.round(h.getBoundingClientRect().height);
      if(px > 0) document.documentElement.style.setProperty('--ovl-top', px + 'px');
    }catch(e){}
  }
  window._syncOverlayTop = syncOverlayTop;
  try{
    if(typeof ResizeObserver !== 'undefined'){
      var ro = new ResizeObserver(function(){ syncOverlayTop(); });
      var hs = document.querySelectorAll('.screen > .header');
      for(var i=0;i<hs.length;i++) ro.observe(hs[i]);
    }
  }catch(e){}
  window.addEventListener('resize', syncOverlayTop, { passive:true });
  window.addEventListener('orientationchange', function(){ setTimeout(syncOverlayTop, 80); });
  requestAnimationFrame(syncOverlayTop);
})();



// Fuseau horaire IANA du navigateur, pour la carte du monde de l'admin
// (pings /__visit). Chaîne vide si le navigateur ne le dit pas.
// navigator.webdriver : vrai quand le navigateur est pilote par un programme
// (Playwright, Puppeteer, Selenium…). Envoye sous `wd` avec les pings anonymes
// pour que l'admin puisse mettre ces visites de cote (proxy.js visitIsBot).
window._pthAutomated = function () {
  try { return navigator.webdriver === true; } catch (e) { return false; }
};
// Opened from the installed app (home screen / desktop PWA) rather than a tab.
window._pthIsApp = function () {
  try { return !!(window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true; } catch (e) { return false; }
};
window._pthTimeZone = function () {
  try { var z = Intl.DateTimeFormat().resolvedOptions().timeZone; return (typeof z === 'string' && z.length <= 64) ? z : ''; }
  catch (e) { return ''; }
};
;(function(){
  // ── Anonymous visit ping (traffic counter) ──
  // Fires once per browser session: total visits = sessions, unique visitors =
  // distinct persistent random ids. No IP, no PII. Aggregated server-side.
  try { if (sessionStorage.getItem('pth_visit_sent')) return; } catch (e) { return; }
  // Owner self-exclusion (set from the admin panel): skip the counter entirely.
  try { if (localStorage.getItem('pth_no_count') === '1') return; } catch (e) {}
  var fire = function () {
    try {
      try { sessionStorage.setItem('pth_visit_sent', '1'); } catch (e) {}
      var vid = '';
      try { vid = localStorage.getItem('pth_vid') || ''; } catch (e) {}
      if (!vid) {
        vid = (window.crypto && crypto.randomUUID) ? crypto.randomUUID()
            : (Date.now().toString(36) + Math.random().toString(36).slice(2, 10));
        try { localStorage.setItem('pth_vid', vid); } catch (e) {}
      }
      // pwa : seul champ que le serveur ne peut pas déduire de l'en-tête (l'UA
      // est identique en onglet et en app installée). OS, navigateur et langue
      // sont dérivés côté serveur (langue : repli sur nl, ci-dessous). tz : le fuseau du navigateur (« Europe/Paris »),
      // que le proxy ramène à un pays pour la carte de l'admin (server/geo-stats.js)
      // — aucune IP n'est lue pour cela.
      var pwa = false;
      try { pwa = !!(window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true; } catch (e) {}
      // live: /live visits are counted apart from the web client's (proxy.js
      // recordLiveVisit), so the embedded view never inflates its footfall.
      // Landing source (read early by pokerth-client.html, see
      // server/ref-stats.js): referring host, own page, utm_source, invite
      // and ?lang= flags. Only fields that are set are sent.
      var msg = window.LIVE_MODE ? { vid: vid, live: true } : { vid: vid, pwa: pwa };
      try { if (window._pthAutomated()) msg.wd = true; } catch (e) {}
      if (!window.LIVE_MODE) {
        try { var tz = window._pthTimeZone(); if (tz) msg.tz = tz; } catch (e) {}
        // nl : navigator.languages (3 premières), lu par le proxy seulement
        // quand l'en-tête Accept-Language ne porte aucune langue (WebView,
        // en-tête absent) — même donnée, même comptage en totaux.
        try {
          var nl = (navigator.languages && navigator.languages.length) ? navigator.languages.slice(0, 3).join(',') : (navigator.language || '');
          if (typeof nl === 'string' && nl && nl.length <= 128) msg.nl = nl;
        } catch (e) {}
        try {
          var L = window.__pthLanding || {};
          if (L.ref) msg.ref = String(L.ref);
          else if (L.self) msg.self = String(L.self);
          if (L.src) msg.src = String(L.src);
          if (L.inv) msg.inv = true;
          if (L.lang) msg.lang = true;
        } catch (e) {}
      }
      var body = JSON.stringify(msg);
      if (navigator.sendBeacon) {
        navigator.sendBeacon('/__visit', new Blob([body], { type: 'application/json' }));
      } else {
        fetch('/__visit', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: body, keepalive: true }).catch(function () {});
      }
    } catch (e) { /* never let the counter break the app */ }
  };
  try {
    if (document.readyState === 'complete' || document.readyState === 'interactive') fire();
    else window.addEventListener('load', fire, { once: true });
  } catch (e) { fire(); }
})();

;(function(){
  // ── Per-mode connection counter ──
  // Fires once per session per mode when a connection opens. Reports to OUR
  // proxy (/__visit) even when the game socket is a direct WSS to pokerth.net —
  // the count-ping is independent of the game transport. No IP, no PII.
  // Alias public du mode d'entrée (repris de e3edf9a5) : même règle que
  // _cntMode() côté connexion — on lit le mode CHOISI (#server-mode), jamais le
  // transport. Exposé pour les appelants externes / la console de diagnostic.
  window._pthConnMode = function () {
    var v = '';
    try { var el = document.getElementById('server-mode'); v = el ? el.value : ''; } catch (e) {}
    if (v === 'offline' || window._offlineMode) return 'offline';
    if (v === 'pokerthnet') return 'pokerthnet';
    if (v === 'lan-dedi') return 'lan';
    return window.directWS ? 'pokerthnet' : 'lan';
  };
  // `srv` (host:port) is sent for a LAN game only: the proxy counts it under
  // the LAN directory entry it belongs to (« other » when not listed) and
  // never keeps the address. Counted once per server and browser session.
  window._pthCountConnect = function (mode, srv) {
    // /live is counted apart from the web client: a spectator session is not a
    // player opening pokerth.net.
    if (window.LIVE_MODE) mode = 'live';
    try {
      if (['pokerthnet', 'lan', 'offline', 'live'].indexOf(mode) < 0) return;
      try { if (localStorage.getItem('pth_no_count') === '1') return; } catch (e) {}
      if (mode !== 'lan' || typeof srv !== 'string' || !srv || srv.length > 260) srv = '';
      var k = 'pth_conn_' + mode + (srv ? '@' + srv : '');
      if (sessionStorage.getItem(k)) return;
      sessionStorage.setItem(k, '1');
    } catch (e) { /* sessionStorage blocked — fall through and send once */ }
    try {
      var vid = '';
      try { vid = localStorage.getItem('pth_vid') || ''; } catch (e) {}
      var cm = { mode: mode, vid: vid };
      if (srv) cm.srv = srv;
      if (window._pthIsApp && window._pthIsApp()) cm.pwa = true;
      try { var tz = window._pthTimeZone(); if (tz) cm.tz = tz; } catch (e) {}
      try { if (window._pthAutomated()) cm.wd = true; } catch (e) {}
      var body = JSON.stringify(cm);
      if (navigator.sendBeacon) navigator.sendBeacon('/__visit', new Blob([body], { type: 'application/json' }));
      else fetch('/__visit', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: body, keepalive: true }).catch(function () {});
    } catch (e) {}
  };
  // Logged in on pokerth.net: as a guest or with an account. A total per day,
  // nothing else (no name, no id beyond the anonymous visit id already sent).
  // Once per kind and browser session; /live spectators are not players.
  window._pthCountLogin = function (kind) {
    if (window.LIVE_MODE || (kind !== 'guest' && kind !== 'auth')) return;
    try {
      try { if (localStorage.getItem('pth_no_count') === '1') return; } catch (e) {}
      var k = 'pth_login_' + kind;
      if (sessionStorage.getItem(k)) return;
      sessionStorage.setItem(k, '1');
    } catch (e) {}
    try {
      var vid = '';
      try { vid = localStorage.getItem('pth_vid') || ''; } catch (e) {}
      var lg = { login: kind, vid: vid };
      try { var tz = window._pthTimeZone(); if (tz) lg.tz = tz; } catch (e) {}
      if (window._pthIsApp && window._pthIsApp()) lg.pwa = true;
      try { if (window._pthAutomated()) lg.wd = true; } catch (e) {}
      var body = JSON.stringify(lg);
      if (navigator.sendBeacon) navigator.sendBeacon('/__visit', new Blob([body], { type: 'application/json' }));
      else fetch('/__visit', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: body, keepalive: true }).catch(function () {});
    } catch (e) {}
  };
})();

/* ═══ Lobby responsive v2 — parité QML LobbyPage (Phase 1b) ═══
   Reparente les panneaux dans la grille, gère les poignées de resize (wide,
   voisins qui suivent), le chat intégré + slide-in Joueurs/Infos (compact),
   et la barre du bas. Purement additif. */
;(function lobby3col(){
  function W(){ try { return window.matchMedia('(min-width:900px)').matches; } catch(e){ return false; } }
  function grid(){ return document.querySelector('#s-lobby .lobby-grid'); }
  function sLobby(){ return document.getElementById('s-lobby'); }

  function reparent(){
    var g=grid(); if(!g) return;
    var pp=document.getElementById('players-panel');
    var cp=document.getElementById('lobby-chat-panel');
    if(pp && pp.parentNode!==g) g.appendChild(pp);
    if(cp && cp.parentNode!==g) g.appendChild(cp);
  }

  /* ── Barre du haut : recherche joueur (gauche) + filtre parties (droite),
        pleine largeur au-dessus des 3 colonnes — parité LobbyPage officielle. ── */
  function ensureTopbar(){
    var lb=document.querySelector('#s-lobby .lobby-body'), g=grid();
    if(!lb || !g) return;
    var tb=lb.querySelector('.lobby-topbar');
    if(!tb){ tb=document.createElement('div'); tb.className='lobby-topbar'; lb.insertBefore(tb, g); }
    var filt=document.getElementById('g-filter-bar');
    if(filt && filt.parentNode!==tb) tb.appendChild(filt);
  }
  // Recherche joueur : dans la barre du haut en wide (à gauche du filtre),
  // dans le panneau Joueurs en compact (parité officielle).
  function placeSearch(){
    var srch=document.querySelector('.players-search');
    var tb=document.querySelector('#s-lobby .lobby-topbar');
    var pp=document.getElementById('players-panel');
    var list=document.getElementById('players-list-body');
    if(!srch) return;
    if(W()){ if(tb && srch.parentNode!==tb) tb.insertBefore(srch, tb.firstChild); }
    else { if(pp && list && srch.parentNode!==pp) pp.insertBefore(srch, list); }
  }
  // Barre du bas (Joueur + Créer) : sous la colonne Parties en wide (largeur =
  // colonne centrale), tout en bas pleine largeur en compact.
  function placeFootbar(){
    var fb=document.querySelector('#s-lobby .lobby-footbar');
    var lb=document.querySelector('#s-lobby .lobby-body');
    var games=document.querySelector('#s-lobby .lobby-grid > .games-col');
    var stats=document.getElementById('lobby-statsbar');
    if(!fb) return;
    if(W()){
      var grid=document.querySelector('#s-lobby .lobby-grid');
      if(grid && fb.parentNode!==grid) grid.appendChild(fb);
    } else {
      if(lb && fb.parentNode!==lb){
        if(stats && stats.parentNode===lb) lb.insertBefore(fb, stats);
        else lb.appendChild(fb);
      }
    }
  }

  /* ── Poignées de redimensionnement (wide) ── */
  var MINC=334, MINL=160, MINR=200, MININFO=120, HW=12;
  function ensureHandles(){
    var g=grid(); if(!g) return;
    ['l','r','v'].forEach(function(k){
      if(g.querySelector('.lob-h-'+k)) return;
      var h=document.createElement('div');
      h.className='lob-h lob-h-'+k; h.dataset.lobh=k;
      h.addEventListener('pointerdown', startDrag);
      g.appendChild(h);
    });
    if(!g.querySelector('.lob-hm')){
      var hm=document.createElement('div');
      hm.className='lob-hm'; hm.dataset.lobh='m';
      hm.addEventListener('pointerdown', startDrag);
      g.appendChild(hm);
    }
    try{
      var L=localStorage.getItem('pth_lob_l'), R=localStorage.getItem('pth_lob_r'), I=localStorage.getItem('pth_lob_info'), M=localStorage.getItem('pth_lob_mgames');
      if(L) g.style.setProperty('--lc-l', parseInt(L,10)+'px');
      if(R) g.style.setProperty('--lc-r', parseInt(R,10)+'px');
      if(I) g.style.setProperty('--lc-info', parseInt(I,10)+'px');
      if(M) g.style.setProperty('--m-games-h', parseInt(M,10)+'px');
    }catch(e){}
  }
  function startDrag(e){
    var k=e.currentTarget.dataset.lobh;
    // Poignées l/r/v = wide uniquement ; poignée m = compact uniquement.
    if(k==='m'){ if(W()) return; } else { if(!W()) return; }
    var g=grid(); if(!g) return;
    var gr=g.getBoundingClientRect(), self=e.currentTarget;
    self.classList.add('drag');
    try{ self.setPointerCapture(e.pointerId); }catch(_){}
    function move(ev){
      if(k==='l'){
        var maxL=gr.width - MINC - MINR - 2*HW;
        g.style.setProperty('--lc-l', Math.round(Math.max(MINL, Math.min(ev.clientX-gr.left, maxL)))+'px');
      } else if(k==='r'){
        var maxR=gr.width - MINC - MINL - 2*HW;
        g.style.setProperty('--lc-r', Math.round(Math.max(MINR, Math.min(gr.right-ev.clientX, maxR)))+'px');
      } else if(k==='v'){
        var maxI=gr.height - MININFO - HW;
        g.style.setProperty('--lc-info', Math.round(Math.max(MININFO, Math.min(ev.clientY-gr.top, maxI)))+'px');
      } else { // 'm' : hauteur des Tables en compact (le Chat remplit le reste)
        var maxM=gr.height - 130 - 16;
        g.style.setProperty('--m-games-h', Math.round(Math.max(120, Math.min(ev.clientY-gr.top, maxM)))+'px');
      }
    }
    function up(){
      self.classList.remove('drag');
      document.removeEventListener('pointermove',move,true);
      document.removeEventListener('pointerup',up,true);
      try{
        var cs=getComputedStyle(g);
        if(k==='m'){
          localStorage.setItem('pth_lob_mgames', parseInt(cs.getPropertyValue('--m-games-h'))||0);
        } else {
          localStorage.setItem('pth_lob_l', parseInt(cs.getPropertyValue('--lc-l'))||240);
          localStorage.setItem('pth_lob_r', parseInt(cs.getPropertyValue('--lc-r'))||300);
          localStorage.setItem('pth_lob_info', parseInt(cs.getPropertyValue('--lc-info'))||220);
        }
      }catch(_){}
    }
    document.addEventListener('pointermove',move,true);
    document.addEventListener('pointerup',up,true);
    e.preventDefault();
  }

  /* ── Slide-in mobile (Joueurs / Infos) + scrim ── */
  function ensureScrim(){
    var s=sLobby(); if(!s) return null;
    var sc=s.querySelector('.lob-scrim');
    if(!sc){ sc=document.createElement('div'); sc.className='lob-scrim';
      sc.addEventListener('click', closeSlide); s.appendChild(sc); }
    return sc;
  }
  function setScrim(on){ var sc=ensureScrim(); if(sc) sc.classList.toggle('on', !!on && !W()); }
  function closeSlide(){ var s=sLobby(); if(s) s.classList.remove('pl-open','gi-open'); setScrim(false); }
  function togglePlayers(){
    if(W()) return;
    var s=sLobby(); if(!s) return;
    var open=!s.classList.contains('pl-open');
    s.classList.toggle('pl-open', open); s.classList.remove('gi-open');
    setScrim(open);
    if(open){ try{renderPlayersList();}catch(e){} var inp=document.getElementById('players-search-in'); if(inp) setTimeout(function(){inp.focus();},60); }
  }
  function openInfo(){
    if(W()) return;
    var s=sLobby(); if(!s) return;
    s.classList.add('gi-open'); s.classList.remove('pl-open'); setScrim(true);
  }

  function sync(){
    reparent();   // auto-reparation : le chat/joueurs DOIVENT etre dans la grille (mode docke QML)
    var pp=document.getElementById('players-panel');
    var cp=document.getElementById('lobby-chat-panel');
    var lb=document.querySelector('#s-lobby .lobby-body');
    if(pp) pp.style.display='flex';   // placement géré par le CSS (grille wide / slide-in compact)
    if(cp) cp.style.display='flex';
    if(lb) lb.style.paddingTop='';
    placeSearch();
    placeFootbar();
    if(W()) closeSlide();             // pas de slide-in résiduel en wide
    try{ renderPlayersList(); }catch(e){}
  }
  function foot(){
    var nm=(typeof myName!=='undefined' && myName)?myName:'';
    var el=document.getElementById('lobby-foot-name');
    if(el) el.textContent=nm||'—';
    var av=document.getElementById('lobby-foot-av');
    if(av){
      if(nm && typeof window._avatarChipHtml==='function'){
        var mid=(typeof window._readMyId==='function')?window._readMyId():0;
        av.innerHTML=window._avatarChipHtml(mid, nm, 'pl-av');
      } else av.innerHTML='';
    }
  }
  function boot(){ reparent(); ensureTopbar(); ensureHandles(); ensureScrim(); sync(); foot(); }
  if(document.readyState!=='loading') boot();
  else document.addEventListener('DOMContentLoaded', boot);
  var _rt;
  window.addEventListener('resize', function(){ clearTimeout(_rt); _rt=setTimeout(sync,120); });

  window._lobby3Foot         = foot;
  window._lobby3IsWide       = W;
  window._lobby3Sync         = sync;
  window._lobby3TogglePlayers= togglePlayers;
  window._lobby3OpenInfo     = openInfo;
  window._lobby3CloseSlide   = closeSlide;
})();


