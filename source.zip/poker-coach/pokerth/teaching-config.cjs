// Shared configuration for local and public static teaching tables.
module.exports = {
  modes: {offline:true,lan:false,pokerthnet:false},
  loginDefaults: {mode:'offline'},
  serverName:'PokerTH · 中文教学桌',
  serverTagline:'先打一手，再看懂每个决定。由你决定何时继续。',
  tableDefaults: {players:9,blind:10,stack:2000,timeout:120},
  defaults: {voice:'0',sound:'0',assist:'1'},
  musicEnabled:false,
  featureOff:['voice','forum','chat_translate'],
};
