﻿$ErrorActionPreference = 'Stop'
$gameDir = $PSScriptRoot
$phonePort = 8788
$healthUrl = "http://127.0.0.1:$phonePort/health"
function Test-PhoneServer {
  try {
    $health = Invoke-RestMethod $healthUrl -TimeoutSec 1
    return ($health.app -eq 'pokerth-chinese-teaching' -and $health.host -eq '0.0.0.0' -and $health.port -eq $phonePort)
  } catch { return $false }
}
$ready = Test-PhoneServer
if (-not $ready) {
  $nodeCmd = Get-Command node -ErrorAction SilentlyContinue
  $nodeExe = if ($nodeCmd) { $nodeCmd.Source } elseif (Test-Path -LiteralPath 'D:\node.exe') { 'D:\node.exe' } else { $null }
  if (-not $nodeExe) { throw '需要安装 Node.js 22 或更新版本。' }
  $runtimeDir = Join-Path $gameDir '.runtime'
  New-Item -ItemType Directory -Force -Path $runtimeDir | Out-Null
  $previousHost = $env:POKER_HOST
  $previousPort = $env:POKER_PORT
  try {
    $env:POKER_HOST = '0.0.0.0'
    $env:POKER_PORT = [string]$phonePort
    $serverFile = Join-Path $gameDir 'local-server.cjs'
    $serverProcess = Start-Process -FilePath $nodeExe -ArgumentList ('"' + $serverFile + '"') -WorkingDirectory $gameDir -WindowStyle Hidden -RedirectStandardOutput (Join-Path $runtimeDir 'phone-server.log') -RedirectStandardError (Join-Path $runtimeDir 'phone-server-error.log') -PassThru
  } finally {
    $env:POKER_HOST = $previousHost
    $env:POKER_PORT = $previousPort
  }
  for ($attempt=0; $attempt -lt 30; $attempt++) {
    Start-Sleep -Milliseconds 200
    if ($serverProcess.HasExited) { break }
    $ready = Test-PhoneServer
    if ($ready) { break }
  }
  if (-not $ready) { throw '手机服务启动失败，8788 端口可能被占用；请查看 pokerth/.runtime/phone-server-error.log。' }
}
Write-Host ''
Write-Host '请保持电脑开机，并让手机和电脑连接同一个 Wi-Fi。'
Write-Host '在手机浏览器打开以下链接（优先尝试 Wi-Fi 网卡地址）：'
$addresses = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | Where-Object { $_.IPAddress -ne '127.0.0.1' -and $_.IPAddress -notlike '169.254.*' -and $_.AddressState -eq 'Preferred' } | Select-Object -ExpandProperty IPAddress -Unique)
foreach ($address in $addresses) { Write-Host "http://${address}:$phonePort/?lang=zh" }
if ($addresses.Count -eq 0) { Write-Host '未找到局域网 IPv4 地址，请连接 Wi-Fi 后重新启动。' }
Write-Host ''
Write-Host '如果手机打不开，请检查同一 Wi-Fi 与设备隔离；若被 Windows 防火墙拦截，仅在你信任的专用网络允许 Node.js。'
Write-Host '关闭此窗口后，手机服务仍会在后台运行。'
$phoneListener = Get-NetTCPConnection -LocalPort $phonePort -State Listen -ErrorAction SilentlyContinue | Select-Object -First 1
if ($phoneListener) { Write-Host "如需停止手机服务，在 PowerShell 执行：Stop-Process -Id $($phoneListener.OwningProcess)" }
Start-Process "http://127.0.0.1:$phonePort/?lang=zh"
