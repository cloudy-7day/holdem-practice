(function (root, factory) {
  'use strict';
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.PokerEngine = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const NAMES = ['你', '林舟', '阿宁', '老陈', '小夏', '阿杰', '七喜', '木木', '星河'];
  const HAND_NAMES = ['高牌', '一对', '两对', '三条', '顺子', '同花', '葫芦', '四条', '同花顺'];

  function evaluate(cards) {
    if (!Array.isArray(cards) || cards.length < 5 || cards.length > 7 ||
        cards.some(c => !Number.isInteger(c) || c < 0 || c > 51) || new Set(cards).size !== cards.length) {
      throw new Error('评估需要 5 至 7 张不重复的有效牌');
    }
    const counts = Array(15).fill(0), suits = [[], [], [], []];
    for (const c of cards) { const r = c % 13 + 2; counts[r]++; suits[Math.floor(c / 13)].push(r); }
    const ranks = [];
    for (let r = 14; r >= 2; r--) if (counts[r]) ranks.push(r);
    const byCount = n => ranks.filter(r => counts[r] >= n);
    function straight(rs) {
      const set = new Set(rs); if (set.has(14)) set.add(1);
      for (let top = 14; top >= 5; top--) {
        if ([0, 1, 2, 3, 4].every(d => set.has(top - d))) return top;
      }
      return 0;
    }
    const flush = suits.find(s => s.length >= 5);
    const sf = flush ? straight(flush) : 0;
    const four = byCount(4), trips = byCount(3), pairs = byCount(2);
    let category, kickers;
    if (sf) { category = 8; kickers = [sf]; }
    else if (four.length) { category = 7; kickers = [four[0], ranks.find(r => r !== four[0])]; }
    else if (trips.length && pairs.some(r => r !== trips[0])) { category = 6; kickers = [trips[0], pairs.find(r => r !== trips[0])]; }
    else if (flush) { category = 5; kickers = flush.slice().sort((a, b) => b - a).slice(0, 5); }
    else if (straight(ranks)) { category = 4; kickers = [straight(ranks)]; }
    else if (trips.length) { category = 3; kickers = [trips[0], ...ranks.filter(r => r !== trips[0]).slice(0, 2)]; }
    else if (pairs.length >= 2) { category = 2; kickers = [pairs[0], pairs[1], ranks.find(r => r !== pairs[0] && r !== pairs[1])]; }
    else if (pairs.length) { category = 1; kickers = [pairs[0], ...ranks.filter(r => r !== pairs[0]).slice(0, 3)]; }
    else { category = 0; kickers = ranks.slice(0, 5); }
    let score = category;
    for (let i = 0; i < 5; i++) score = score * 15 + (kickers[i] || 0);
    return { score, category, name: HAND_NAMES[category], kickers };
  }

  function createGame(options) {
    const { count = 9, dealer = 0, smallBlind = 5, bigBlind = 10, rng = Math.random } = options || {};
    const stacks = options && options.stacks !== undefined ? options.stacks.slice() : Array(count).fill(1000);
    if (!Number.isInteger(count) || count < 2 || count > 9 || stacks.length !== count ||
        stacks.some(n => !Number.isSafeInteger(n) || n < 0) || stacks.filter(n => n > 0).length < 2 ||
        !Number.isInteger(dealer) || dealer < 0 || dealer >= count ||
        !Number.isSafeInteger(smallBlind) || smallBlind <= 0 || !Number.isSafeInteger(bigBlind) || bigBlind < smallBlind ||
        !Number.isSafeInteger(stacks.reduce((a, b) => a + b, 0)) || typeof rng !== 'function') {
      throw new Error('座位、筹码或盲注设置无效');
    }
    // The shuffled deck and betting-round bookkeeping never enter a player view.
    const deck = Array.from({ length: 52 }, (_, i) => i);
    for (let i = 51; i > 0; i--) {
      const random = rng();
      if (!Number.isFinite(random) || random < 0 || random >= 1) throw new Error('随机源须返回 [0,1)');
      const j = Math.floor(random * (i + 1)); [deck[i], deck[j]] = [deck[j], deck[i]];
    }
    const players = stacks.map((stack, id) => ({ id, name: NAMES[id], stack, hole: [], folded: stack === 0,
      allIn: false, streetBet: 0, totalBet: 0, startStack: stack }));
    const state = { players, board: [], street: 'preflop', dealer, smallBlindSeat: null, bigBlindSeat: null,
      currentBet: bigBlind, minRaise: bigBlind, actor: null, done: false, pot: 0, log: [], result: null };
    let pending = new Set(), actedAt = new Map();
    const live = () => players.filter(p => !p.folded);
    const able = () => players.filter(p => !p.folded && !p.allIn);
    function next(from, predicate) {
      for (let i = 1; i <= count; i++) { const seat = (from + i) % count; if (predicate(players[seat])) return seat; }
      return null;
    }
    function log(seat, type, amount, text) { state.log.push({ seat, street: state.street, type, amount, text }); }
    function pay(p, amount) {
      p.stack -= amount; p.streetBet += amount; p.totalBet += amount; state.pot += amount;
      if (p.stack === 0) p.allIn = true;
    }
    function refund() {
      const ordered = players.slice().sort((a, b) => b.totalBet - a.totalBet);
      const excess = ordered[0].totalBet - ordered[1].totalBet;
      if (excess <= 0) return;
      const p = ordered[0];
      p.stack += excess; p.totalBet -= excess; p.streetBet = Math.max(0, p.streetBet - excess);
      p.allIn = p.stack === 0; state.pot -= excess;
      log(p.id, 'refund', excess, `${p.name}收回未被跟注的 ${excess} 筹码`);
    }
    function settle(reason) {
      refund();
      const hands = players.map(p => ({ seat: p.id,
        rank: !p.folded && state.board.length === 5 ? evaluate(p.hole.concat(state.board)) : null }));
      const pots = [], winnings = Array(count).fill(0);
      const levels = [...new Set(players.map(p => p.totalBet).filter(n => n > 0))].sort((a, b) => a - b);
      let previous = 0;
      for (const level of levels) {
        const contributors = players.filter(p => p.totalBet >= level);
        const amount = (level - previous) * contributors.length;
        previous = level;
        let eligible = contributors.filter(p => !p.folded);
        // A fold victory claims all committed chips, regardless of contribution level.
        if (reason === 'fold') eligible = live();
        if (!eligible.length) throw new Error('底池无有效竞争者');
        const best = reason === 'fold' ? null : Math.max(...eligible.map(p => hands[p.id].rank.score));
        const winners = eligible.filter(p => reason === 'fold' || hands[p.id].rank.score === best).map(p => p.id);
        const order = winners.slice().sort((a, b) => ((a - state.dealer + count - 1) % count) - ((b - state.dealer + count - 1) % count));
        const each = Math.floor(amount / winners.length), odd = amount % winners.length;
        order.forEach((seat, i) => { winnings[seat] += each + (i < odd ? 1 : 0); });
        pots.push({ amount, winners });
      }
      const payouts = [];
      winnings.forEach((amount, seat) => {
        if (!amount) return;
        players[seat].stack += amount;
        payouts.push({ seat, amount }); log(seat, 'award', amount, `${players[seat].name}赢得 ${amount} 筹码`);
      });
      state.pot = 0; state.actor = null; state.done = true;
      if (reason === 'showdown') state.street = 'showdown';
      state.result = { reason, payouts, pots, hands,
        summary: reason === 'fold' ? `${live()[0].name}因其他玩家弃牌获胜；未继续发公共牌。` : `摊牌结束：${payouts.map(p => `${players[p.seat].name}获得 ${p.amount}`).join('，')}。` };
    }
    function dealStreet() {
      if (state.street === 'river') { settle('showdown'); return; }
      const street = state.street === 'preflop' ? 'flop' : state.street === 'flop' ? 'turn' : 'river';
      state.street = street;
      deck.pop(); // Burn before each street, as at a physical table.
      const number = street === 'flop' ? 3 : 1;
      for (let i = 0; i < number; i++) state.board.push(deck.pop());
      players.forEach(p => { p.streetBet = 0; });
      state.currentBet = 0; state.minRaise = bigBlind;
      pending = new Set(able().map(p => p.id)); actedAt = new Map();
      log(null, 'deal', 0, `发出${street === 'flop' ? '翻牌' : street === 'turn' ? '转牌' : '河牌'}`);
    }
    function advance(from) {
      if (live().length === 1) { settle('fold'); return; }
      for (let guard = 0; guard < 5; guard++) {
        const actors = able();
        // A lone stack may only answer an outstanding bet. No empty side-pot betting.
        if (actors.length <= 1) {
          // A nominal full big blind matters with multiple betting players only.
          // Against all-ins the lone stack answers the chips actually posted.
          state.currentBet = Math.max(...live().map(p => p.streetBet));
          if (actors.length === 1 && actors[0].streetBet < state.currentBet) {
            pending = new Set([actors[0].id]); state.actor = actors[0].id; return;
          }
          pending.clear();
        }
        for (const seat of pending) if (players[seat].folded || players[seat].allIn) pending.delete(seat);
        if (pending.size) { state.actor = next(from, p => pending.has(p.id)); return; }
        dealStreet(); if (state.done) return;
        from = state.dealer;
      }
      throw new Error('下注轮推进异常');
    }
    function legalActions() {
      if (state.done || state.actor === null) return { fold: false, check: false, call: 0, canRaise: false, minRaiseTo: 0, maxRaiseTo: 0 };
      const p = players[state.actor], need = Math.max(0, state.currentBet - p.streetBet);
      const maxRaiseTo = p.streetBet + p.stack, minRaiseTo = state.currentBet + state.minRaise;
      const faced = actedAt.get(p.id);
      const reopened = faced === undefined || (faced === 0 && state.currentBet > 0) || state.currentBet - faced >= state.minRaise;
      return { fold: true, check: need === 0, call: Math.min(need, p.stack),
        canRaise: reopened && maxRaiseTo > state.currentBet && able().some(other => other.id !== p.id), minRaiseTo, maxRaiseTo };
    }
    function act(action) {
      if (state.done || state.actor === null || !action || typeof action !== 'object') throw new Error('当前不能行动');
      const legal = legalActions(), p = players[state.actor];
      const { type, amount } = action;
      if (!['fold', 'check', 'call', 'raise'].includes(type) ||
          (type === 'check' && !legal.check) || (type === 'call' && legal.call <= 0) ||
          (type === 'raise' && (!legal.canRaise || !Number.isSafeInteger(amount) || amount <= state.currentBet || amount > legal.maxRaiseTo ||
           (amount < legal.minRaiseTo && amount !== legal.maxRaiseTo)))) throw new Error('非法行动或加注额度');
      const actor = p.id;
      pending.delete(actor);
      if (type === 'fold') { p.folded = true; log(actor, type, 0, `${p.name}弃牌`); }
      else if (type === 'check') { actedAt.set(actor, state.currentBet); log(actor, type, 0, `${p.name}过牌`); }
      else if (type === 'call') {
        const chips = legal.call; pay(p, chips); actedAt.set(actor, state.currentBet);
        log(actor, type, chips, `${p.name}跟注 ${chips}${p.allIn ? '（全下）' : ''}`);
      } else {
        const increment = amount - state.currentBet, chips = amount - p.streetBet;
        pay(p, chips); state.currentBet = amount;
        if (increment >= state.minRaise) state.minRaise = increment;
        actedAt.set(actor, state.currentBet);
        for (const other of able()) if (other.id !== actor && other.streetBet < state.currentBet) pending.add(other.id);
        log(actor, type, chips, `${p.name}加注至 ${amount}${p.allIn ? '（全下）' : ''}`);
      }
      advance(actor); return state;
    }
    function view(seat) {
      if (!Number.isInteger(seat) || seat < 0 || seat >= count) throw new Error('座位不存在');
      return { seat, hole: players[seat].hole.slice(), board: state.board.slice(), street: state.street, pot: state.pot,
        currentBet: state.currentBet, minRaise: state.minRaise, dealer: state.dealer,
        players: players.map(({ id, name, stack, folded, allIn, streetBet, totalBet }) => ({ id, name, stack, folded, allIn, streetBet, totalBet })),
        legal: seat === state.actor ? legalActions() : null, activeCount: live().length };
    }
    if (players[state.dealer].folded) state.dealer = next(state.dealer, p => !p.folded);
    state.smallBlindSeat = live().length === 2 ? state.dealer : next(state.dealer, p => !p.folded);
    state.bigBlindSeat = next(state.smallBlindSeat, p => !p.folded);
    for (let round = 0; round < 2; round++) {
      let seat = state.dealer;
      for (let i = 0; i < live().length; i++) { seat = next(seat, p => !p.folded); players[seat].hole.push(deck.pop()); }
    }
    log(null, 'deal', 0, '发放两张底牌，开始翻前下注');
    for (const [seat, blind, type] of [[state.smallBlindSeat, smallBlind, 'smallBlind'], [state.bigBlindSeat, bigBlind, 'bigBlind']]) {
      const p = players[seat], amount = Math.min(p.stack, blind); pay(p, amount);
      log(seat, type, amount, `${p.name}投入${type === 'smallBlind' ? '小' : '大'}盲 ${amount}${p.allIn ? '（全下）' : ''}`);
    }
    pending = new Set(able().map(p => p.id));
    advance(state.bigBlindSeat);
    return { state, legalActions, act, view };
  }
  return { createGame, evaluate };
});
