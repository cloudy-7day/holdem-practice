(function (root, factory) {
  'use strict';
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./engine.js'));
  else root.PokerCoach = factory(root.PokerEngine);
}(typeof globalThis !== 'undefined' ? globalThis : this, function (Engine) {
  'use strict';

  const styles = Object.freeze([
    {id: 'balanced', name: '均衡练习', description: '结合牌力与跟注成本行动，托管时保持适度进攻。'},
    {id: 'tight-aggressive', name: '紧手进攻', description: '入池较谨慎，拿到较强牌时更愿意主动加注。'},
    {id: 'loose-aggressive', name: '宽范围进攻', description: '参与范围较宽，更多使用主动下注和少量试探。'},
    {id: 'patient', name: '耐心等待', description: '偏好控制底池，对昂贵跟注保持更高要求。'},
    {id: 'curious', name: '好奇跟注', description: '更愿意支付小成本看下一张牌，主动加注较少。'},
    {id: 'pressure', name: '主动施压', description: '较常主动加注，偶尔用弱牌尝试施加压力。'},
    {id: 'steady', name: '稳健观察', description: '重视底池赔率，通常以稳定节奏控制风险。'},
    {id: 'social', name: '宽松看牌', description: '喜欢参与小底池，面对高成本行动时仍会收缩。'},
    {id: 'selective', name: '精选进攻', description: '选择较强机会入池，入池后偏好明确的主动行动。'}
  ].map(Object.freeze));
  const tendencies = {
    balanced: {margin: .025, aggression: .54, bluff: .025, size: .57},
    'tight-aggressive': {margin: .055, aggression: .72, bluff: .015, size: .65},
    'loose-aggressive': {margin: -.015, aggression: .77, bluff: .07, size: .62},
    patient: {margin: .065, aggression: .28, bluff: .005, size: .43},
    curious: {margin: -.035, aggression: .22, bluff: .01, size: .42},
    pressure: {margin: .005, aggression: .87, bluff: .09, size: .75},
    steady: {margin: .035, aggression: .42, bluff: .015, size: .52},
    social: {margin: -.025, aggression: .33, bluff: .035, size: .46},
    selective: {margin: .05, aggression: .78, bluff: .02, size: .7}
  };
  const streetNames = {preflop: '翻牌前', flop: '翻牌圈', turn: '转牌圈', river: '河牌圈', showdown: '摊牌'};
  const actionNames = {fold: '弃牌', check: '过牌', call: '跟注', raise: '加注'};
  const percent = n => (Math.max(0, Math.min(1, n)) * 100).toFixed(1) + '%';
  const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));

  function opponents(view) {
    return view.players.filter(p => p.id !== view.seat && !p.folded).length;
  }

  function priceCall(view) {
    const call = view.legal ? view.legal.call : 0;
    const hero = view.players.find(p => p.id === view.seat);
    const accounted = view.players.every(p => Number.isFinite(p.totalBet) && p.totalBet >= 0) &&
      view.players.reduce((sum, p) => sum + p.totalBet, 0) === view.pot;
    let contestablePot = view.pot;
    if (hero && accounted && call > 0) {
      const ceiling = hero.totalBet + call;
      contestablePot = view.players.reduce((sum, p) => sum + Math.min(p.totalBet, ceiling), 0);
    }
    return {call, contestablePot, potOdds: call > 0 ? call / (contestablePot + call) : 0, capped: contestablePot < view.pot};
  }

  // At most C(45,2)=990 evaluations. This is a proof about known cards,
  // separate from sampled equity. Hero must also play the public five cards.
  function guaranteedRiverSplit(view) {
    if (view.street !== 'river' || view.board.length !== 5 || opponents(view) !== 1) return false;
    const boardRank = Engine.evaluate(view.board);
    if (Engine.evaluate(view.hole.concat(view.board)).score !== boardRank.score) return false;
    if (boardRank.category === 8 && boardRank.kickers[0] === 14) return true;
    const known = new Set(view.board.concat(view.hole));
    const remaining = [];
    for (let card = 0; card < 52; card++) if (!known.has(card)) remaining.push(card);
    for (let i = 0; i < remaining.length; i++) for (let j = i + 1; j < remaining.length; j++) {
      if (Engine.evaluate(view.board.concat([remaining[i], remaining[j]])).score !== boardRank.score) return false;
    }
    return true;
  }

  // Each trial deals a fresh random possible board and opponent hands. No game
  // state, private opponent cards, or future deck is accepted by this module.
  function estimateEquity(view, samples, rng) {
    const count = opponents(view);
    if (!count) return 1;
    const known = new Set(view.hole.concat(view.board));
    const available = [];
    for (let c = 0; c < 52; c++) if (!known.has(c)) available.push(c);
    const missing = 5 - view.board.length;
    const needed = missing + 2 * count;
    if (view.hole.length !== 2 || missing < 0 || needed > available.length) throw new Error('无法估算：公开牌面数据不完整。');
    let share = 0;
    for (let sample = 0; sample < samples; sample++) {
      const deck = available.slice();
      for (let i = 0; i < needed; i++) {
        const j = i + Math.floor(clamp(rng(), 0, .9999999999999999) * (deck.length - i));
        const temp = deck[i]; deck[i] = deck[j]; deck[j] = temp;
      }
      const board = view.board.concat(deck.slice(0, missing));
      const hero = Engine.evaluate(view.hole.concat(board)).score;
      let ties = 1;
      let beaten = false;
      for (let p = 0; p < count; p++) {
        const offset = missing + p * 2;
        const rank = Engine.evaluate([deck[offset], deck[offset + 1]].concat(board)).score;
        if (rank > hero) { beaten = true; break; }
        if (rank === hero) ties++;
      }
      if (!beaten) share += 1 / ties;
    }
    return share / samples;
  }

  function raiseAmount(view, size) {
    const l = view.legal;
    if (!l || !l.canRaise) return null;
    if (l.maxRaiseTo < l.minRaiseTo) return l.maxRaiseTo;
    const increment = Math.max(view.minRaise || 1, (view.pot + l.call) * size);
    return clamp(Math.round((view.currentBet || 0) + increment), l.minRaiseTo, l.maxRaiseTo);
  }

  function recommend(view, equity) {
    const l = view.legal;
    if (!l) return 'check';
    const odds = priceCall(view).potOdds;
    const fairShare = 1 / (opponents(view) + 1);
    const strong = equity > Math.max(.29, fairShare * 1.65) && equity > odds + .14;
    if (l.canRaise && strong) return 'raise';
    if (l.check) return 'check';
    if (l.call > 0 && (equity >= odds + .025 || !l.fold)) return 'call';
    if (l.fold) return 'fold';
    return l.call > 0 ? 'call' : 'check';
  }

  function analyze(view, options) {
    options = options || {};
    const samples = clamp(Math.floor(Number(options.samples) || 100), 1, 200);
    const exactSplit = guaranteedRiverSplit(view);
    const equity = exactSplit ? .5 : estimateEquity(view, samples, options.rng || Math.random);
    const l = view.legal;
    const price = priceCall(view);
    const {call, potOdds, contestablePot, capped} = price;
    const recommendation = exactSplit && l ? (l.check ? 'check' : call > 0 ? 'call' : recommend(view, equity)) : recommend(view, equity);
    const raiseTo = recommendation === 'raise' ? raiseAmount(view, .6) : null;
    const stage = streetNames[view.street] || '当前阶段';
    const titles = {fold: '成本偏高，可以考虑弃牌', check: '可以免费过牌，继续观察', call: '成本可接受，可以考虑跟注', raise: '牌力相对突出，可以考虑加注'};
    const choice = recommendation === 'raise' ? '加注至 ' + raiseTo : actionNames[recommendation];
    let explanation = stage + '，底池 ' + view.pot + '，需跟注 ' + call + '。';
    if (capped) explanation += '你当前可争取的底池为 ' + contestablePot + '；已排除无法赢取的超额筹码。';
    explanation += call ? '底池赔率约为 ' + percent(potOdds) + '（跟注额 ÷ 跟注后可争取底池）。' : '本次无需支付跟注成本。';
    if (exactSplit) explanation += '公共牌已构成双方必然平分的最佳五张牌，任何合法对手底牌都无法改变这一点，确定权益为 50%；可考虑' + choice + '。';
    else explanation += '对 ' + opponents(view) + ' 位对手的随机手牌进行 ' + samples + ' 次模拟，粗略底池权益约 ' + percent(equity) + '，已计入平分底池；可考虑' + choice + '。';
    const cautions = [
      '这是对随机手牌的粗略模拟，不是求解器或对手真实范围胜率；少量样本会波动。',
      '底池赔率只比较当前跟注成本；后续下注、位置、弃牌率及对手范围会改变决策。'
    ];
    if (exactSplit) cautions[0] = '这里的平分由已知公共牌确定，并非随机手牌模拟；跟注会取回应得的平分份额，弃牌会失去该份额。';
    if (view.street === 'preflop' || view.street === 'flop') cautions.push('尚有公共牌未发出，当前权益不等于最终结果或可保证的收益。');
    if (l && l.canRaise && l.maxRaiseTo < l.minRaiseTo) cautions.push('当前只能短码全下加注；未达到完整加注幅度可能不会重新开放他人的加注权。');
    if (l && !l.canRaise && l.call > 0) cautions.push('当前加注权受限或筹码不足，可按合法选项跟注或弃牌。');
    if (opponents(view) > 1) cautions.push('多人底池可能存在边池；这里未逐个模拟边池，短码时权益不能直接当作回报率。');
    if (view.players.some(p => p.id !== view.seat && !p.folded && !p.allIn)) {
      if (view.seat === view.dealer && view.street === 'preflop' && view.players.length > 2) {
        cautions.push('位置提醒：你在庄位，但翻牌前盲注位仍排在你之后，可能跟注或加注；不要只按眼前的跟注成本决定。');
      } else if (view.seat === view.dealer && view.street !== 'preflop') {
        cautions.push('位置提醒：你在庄位，翻牌后通常较晚行动，可以先观察对手；若有人加注，行动仍可能再次回到你。');
      } else {
        cautions.push('位置提醒：较早行动时，身后玩家仍可能跟注或加注；先想好遭到加注后愿意投入多少，后面轮次较晚行动通常能获得更多信息。');
      }
    }
    return {equity, potOdds, contestablePot, capped, exactSplit, recommendation, raiseTo, title: titles[recommendation], explanation, cautions};
  }

  function chooseAction(view, style, rng) {
    const l = view.legal;
    if (!l) throw new Error('当前没有可执行行动。');
    if (guaranteedRiverSplit(view)) {
      if (l.check) return {type: 'check'};
      if (l.call > 0) return {type: 'call'};
    }
    rng = rng || Math.random;
    style = style || styles[view.seat] || styles[0];
    const t = tendencies[style.id] || tendencies.balanced;
    const equity = estimateEquity(view, 40, rng);
    const odds = priceCall(view).potOdds;
    const fairShare = 1 / (opponents(view) + 1);
    const strong = equity > Math.max(.27, fairShare * 1.55) && equity > odds + .10 + t.margin;
    const affordable = equity >= odds + t.margin;
    const roll = rng();
    const smallPrice = !l.call || l.call / Math.max(1, view.pot) < .2;
    const bluff = smallPrice && roll < t.bluff;
    if (l.canRaise && ((strong && roll < t.aggression) || bluff)) {
      return {type: 'raise', amount: raiseAmount(view, t.size)};
    }
    if (l.check) return {type: 'check'};
    if (l.call > 0 && (affordable || !l.fold)) return {type: 'call'};
    if (l.fold) return {type: 'fold'};
    return {type: 'check'};
  }

  function reviewDecision(input) {
    const view = input.view;
    const action = input.action;
    const a = input.analysis || analyze(view);
    const label = actionNames[action.type] || '行动';
    const cost = action.type === 'raise' ? '至 ' + action.amount : action.type === 'call' && view.legal ? ' ' + view.legal.call : '';
    let verdict = action.type === a.recommendation ? 'good' : 'consider';
    if (action.type === 'fold' && view.legal && view.legal.check) verdict = 'caution';
    if (action.type === 'call' && a.equity + .10 < a.potOdds) verdict = 'caution';
    if (action.type === 'raise' && a.equity + .06 < a.potOdds) verdict = 'caution';
    const exactSplit = a.exactSplit === true || guaranteedRiverSplit(view);
    if (exactSplit && action.type === 'fold') verdict = 'caution';
    const titles = {good: '这次行动有合理依据', consider: '这里有另一种可讨论的选择', caution: '这次决策值得重点回看'};
    let explanation = (streetNames[view.street] || '行动时') + '，你实际选择了' + label + cost + '。';
    explanation += exactSplit ? '当时公共牌已经确定双方平分底池，权益为 50%；跟注所需权益约 ' + percent(a.potOdds) + '。' :
      '按当时可见信息，随机手牌粗略权益约 ' + percent(a.equity) + '，跟注所需权益约 ' + percent(a.potOdds) + '。';
    if (exactSplit) explanation += action.type === 'fold' ? '当时可通过跟注或免费过牌保留确定的平分份额，弃牌会放弃这部分筹码。' :
      '公共牌已决定平分，保留摊牌资格即可取得应得份额；这个判断可由当时的牌面直接确认。';
    else if (action.type === 'fold' && view.legal && view.legal.check) explanation += '当时可以免费过牌，保留继续参与的机会通常更有价值。';
    else if (action.type === a.recommendation) explanation += '这与当前粗略估算的建议一致，但仍需结合对手范围和后续成本。';
    else explanation += '可比较' + actionNames[a.recommendation] + '的理由；模拟未涵盖真实范围、后续下注和所有策略因素。';
    explanation += '只评价决策当时的依据，不用后来发出的牌或本局输赢倒推对错。';
    return {verdict, title: titles[verdict], explanation};
  }

  function summarizePlayer(player, actions, style) {
    style = style || styles[player.id] || styles[0];
    const counts = {fold: 0, check: 0, call: 0, raise: 0};
    const actual = (actions || []).filter(a => a.seat === player.id && Object.prototype.hasOwnProperty.call(counts, a.type));
    for (const action of actual) counts[action.type]++;
    const summary = ['raise', 'call', 'check', 'fold'].filter(k => counts[k]).map(k => actionNames[k] + ' ' + counts[k] + ' 次').join('、');
    const net = Number.isFinite(player.startStack) && Number.isFinite(player.stack) ? player.stack - player.startStack : null;
    let text = player.id === 0 ? '以下按你的本局实际行动回看；启用托管时使用「' + style.name + '」预设。' :
      player.name + '的风格设定为「' + style.name + '」：' + style.description;
    text += actual.length ? '本局实际记录：' + summary + '。' : '本局尚无自主行动记录，盲注与派奖不用于推断打法。';
    const folded = actual.find(a => a.type === 'fold');
    if (folded) text += (streetNames[folded.street] || '本局') + '弃牌，之后未再参与底池竞争。';
    const raises = actual.filter(a => a.type === 'raise');
    if (raises.length) {
      const largest = raises.reduce((best, a) => a.amount > best.amount ? a : best);
      text += '本局最大一次加注发生在' + (streetNames[largest.street] || '记录阶段') + '，单次实际投入 ' + largest.amount + ' 筹码；这里是本次付出的筹码数，并非加注后的下注总额。';
    }
    if (counts.call) {
      const callCost = actual.filter(a => a.type === 'call').reduce((total, a) => total + (Number.isFinite(a.amount) ? a.amount : 0), 0);
      text += '这 ' + counts.call + ' 次跟注合计支付 ' + callCost + ' 筹码，可逐次对照当时的底池赔率。';
    }
    if (net !== null) text += '本局虚拟筹码净变化 ' + (net > 0 ? '+' : '') + net + '。';
    let takeaway = player.id === 0 ? '单局行动样本有限；回看每次决定时已知的信息，比只看最终输赢更有帮助。' :
      '风格是预设倾向；单局行动样本有限，不能据此认定对手持牌或长期打法。';
    if (counts.raise && counts.fold) takeaway += '这局既有主动加注，也有后续弃牌，主动投入后仍可根据新信息退出。';
    else if (counts.call && !counts.raise) takeaway += '可回看每次跟注的成本，以及对下一轮下注的准备。';
    else if (counts.raise) takeaway += '可对照加注时的牌面和底池大小，思考价值下注与试探的区别。';
    return {title: player.id === 0 ? '你的本局行动' : player.name + ' · ' + style.name, text, takeaway};
  }

  return {styles, priceCall, analyze, chooseAction, reviewDecision, summarizePlayer};
}));
