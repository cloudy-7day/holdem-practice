# Friend rooms implementation plan

> **For agentic workers:** Use subagent-driven-development, with separate core and UI owners and integration review.

**Goal:** Friends join the same teaching table by room code or invitation URL, on separate networks, with private live cards and personal reviews.

**Architecture:** Reuse OfflineTable on an authoritative server. A portable, serializable Room core runs in Node for LAN and in Cloudflare Durable Objects for Internet rooms. Clients fetch personalized snapshots every second and submit authenticated commands. Turn-based poker does not require a continuous WebSocket; request snapshots also restore iPhone sessions after backgrounding. Keep the existing solo game intact and add a matching mobile friend-table page.

**Tech Stack:** Existing JS engine and review Worker; native fetch/HTTP; Cloudflare Workers + SQLite Durable Objects; Node local server.

## Global constraints

- Plain Chinese, virtual chips only; 2–9 seats, optional bots; manual next hand.
- No AI API, live opponent cards, deck, reconnect tokens, or private decision contexts in public snapshots.
- Reveal all cards only after the hand, explicitly disclosed on room entry as a teaching rule.
- Server validates identity, turn nonce, actions, legal amounts, and host commands; do not trust engine clamping.
- Phone reconnect retains the seat; 60-second action deadline, automatic check/fold; server persists room state.
- Same room code on Node/LAN or public Cloudflare service; GitHub Pages is the frontend only.

## Shared contract

`pokerth/multiplayer/room.mjs` exports `Room`, `RoomError` (status/message), with:

```js
new Room({code, name, token, config, now, rng})
Room.restore(saved, {now, rng})
room.join({name, token}) // returns numeric playerId
room.command(token, {type, turnId, action, amountTo, requestId})
room.snapshot(token) // personalized JSON; calls tick/heartbeat
room.tick() // at most one due bot/timeout action
room.exportState() // private JSON-safe state for persistence
```

`now` and `rng` are injectable functions (defaults Date.now / cryptographic RNG). Tokens are generated in the transport; constructor adds host; config is `{maxPlayers:9, startMoney:2000, smallBlind:10, fillBots:true, turnSeconds:60}`. Commands: `start`, `next`, `action`, `leave`. Turn IDs change for every action request. No join after game starts except authenticated reconnection. Room state phases: `waiting`, `playing`, `review`, `finished`.

Snapshot:
```js
({code, revision, phase, hostId, heroId, config,
 players:[{id,name,isBot,connected,stack,in,folded,allin,streetCommitted,hole}],
 board:[], handNumber:0, dealerId:null, sbId:null, bbId:null, pot:0,
 turn:null /* or {playerId,turnId,deadline,legal (only acting hero),currentBet,streetCommitted} */,
 events:[{id,playerId,text}], report:null /* personalized report on review/finished */})
```

Live `hole` only for hero, empty arrays for opponents. Report reuses teaching analysis schema with recipient heroId; opponent decision contexts are public-only (no hole). Report includes settlement, players' net, own decision contexts, board. `legal` uses engine fields canCheck/canCall/canRaise/callAmt/minRaiseTo/maxRaiseTo/pot.

HTTP API (backend URL optional; same-origin locally):
```text
POST /api/rooms {name,config} -> {token,snapshot}
POST /api/rooms/CODE/join {name} -> {token,snapshot}
GET /api/rooms/CODE Authorization: Bearer TOKEN -> {snapshot}
POST /api/rooms/CODE/command Authorization: Bearer TOKEN JSON command -> {snapshot}
GET /api/rooms/config -> {enabled:true}
```
Errors `{error:ChineseText}`, appropriate HTTP status. Invitation `multiplayer.html?room=CODE`; published backend in `multiplayer-config.json` `{apiBase:"https://...workers.dev"}`. No token in URLs. JSON responses no-store. CORS exact allowed frontend origins.

## Task 1 — portable authoritative room (core owner)

Files: `pokerth/multiplayer/room.mjs`, `pokerth/tests/multiplayer-room.test.mjs`.

- [x] Write failing tests for two humans joining/playing, private cards, forged and stale actions, host-only start/next, invalid amounts, reconnect, all-in/settlement, bots, JSON persistence restore.
- [x] Wrap OfflineTable and capture TeachingSession per-hand context without modifying solo behavior. Persist engine Sets and player references explicitly; restore callback closures safely.
- [x] Run `node --test pokerth/tests/multiplayer-room.test.mjs` and inspect results.

## Task 2 — mobile rooms UI (UI owner)

Files: `pokerth/public/multiplayer.html`, `modules/multiplayer/client.mjs`, `modules/multiplayer/style.css`.

- [x] Build entry nickname/create/join form, invitation copy, 9-seat felt table, visible connection status and action controls.
- [x] Persist own credential per room, reconnect via authenticated snapshot, prevent overlapping poll responses and duplicate command submits.
- [x] Render live private cards, public bets, speech events; host-only next; review via existing analyzeHandAsync with concrete advice and settlement.
- [x] Narrow phone layout, readable cards/buttons; use textContent for names and speech.

## Task 3 — transports and deployment (root)

Files: Node HTTP handler, local-server.cjs, Cloudflare worker + wrangler config, multiplayer-config.json, solo entry link, scripts/package/docs.

- [x] Add bounded JSON parsing, cryptographic codes/tokens, exact CORS, rate and room caps, per-room persistence and lifecycle expiry.
- [x] Run API integration and cross-client browser tests including restore and mobile WebKit.
- [x] Validate Cloudflare dry-run before login; deploy authenticated worker, configure Pages endpoint, publish source and frontend.
- [x] Check live two-browser game (different sessions), forbidden card access, manual next, and mobile layout; report actual limits.

## References

- https://www.pokernow.com/ — create table and invite friends by link, manual pace.
- https://docs.colyseus.io/ — authoritative room architecture and state synchronization.
- https://developers.cloudflare.com/durable-objects/ — room coordination and persistent state.
- https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages — static hosting limitations.

Validation: Chrome and WebKit real2-client games and9-seat320px layout passed; Cloudflare local and deployed API complete showdown, privacy, own reviews, stale command rejection and timeout passed. Final publishing verification recorded in VERIFICATION.md.
