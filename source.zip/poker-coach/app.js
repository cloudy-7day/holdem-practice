(function () {
  'use strict';

  const SUITS = ['♠', '♥', '♣', '♦'];
  const STREETS = { preflop: '翻牌前', flop: '翻牌', turn: '转牌', river: '河牌', showdown: '摊牌' };
  const STAGES = {
    preflop: ['01 / 04', '翻牌前 · 选择起手牌', '每人两张底牌。位置越靠后，能先看到的行动越多；不用每手牌都入池。'],
    flop: ['02 / 04', '翻牌 · 重新认识你的牌', '三张公共牌出现了。先看是否成对、是否有顺子或同花听牌，再考虑对手的行动。'],
    turn: ['03 / 04', '转牌 · 留意变化', '第四张公共牌可能改变领先者。底池变大时，先想好你愿意投入多少，再选择行动。'],
    river: ['04 / 04', '河牌 · 做最后的判断', '五张公共牌已齐，没有下一张可追。考虑哪些更差的牌会跟注，哪些更好的牌会弃牌。'],
    showdown: ['HAND COMPLETE', '本手结束 · 看过程，也看选择', '一次结果不能证明一次决策好坏。回到当时可见的信息，看看每一步是否有清楚的理由。']
  };
  const DESKTOP_POSITIONS = [[50, 83], [17, 76], [9, 48], [20, 22], [40, 16], [62, 16], [81, 22], [91, 48], [83, 76]];
  const MOBILE_POSITIONS = [[50, 83], [14, 10], [38, 10], [62, 10], [86, 10], [14, 28], [38, 28], [62, 28], [86, 28]];
  const format = value => Number(value || 0).toLocaleString('zh-CN');
  const signed = value => (value > 0 ? '+' : '') + format(value);
  const pct = value => Math.round(Math.max(0, Math.min(1, Number(value) || 0)) * 100) + '%';
  const escapeHtml = value => String(value == null ? '' : value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
  const copy = value => JSON.parse(JSON.stringify(value));

  function cardHtml(card, size) {
    const small = size === 'small' ? ' small' : '';
    if (card == null) return '<span class="card back' + small + '" aria-label="未公开的底牌"></span>';
    const rank = card % 13 + 2;
    const suit = Math.floor(card / 13);
    const name = ({ 11: 'J', 12: 'Q', 13: 'K', 14: 'A' })[rank] || rank;
    return '<span class="card' + small + (suit === 1 || suit === 3 ? ' red' : '') + '" aria-label="' + SUITS[suit] + name + '"><span class="rank">' + name + '</span><span class="suit" aria-hidden="true">' + SUITS[suit] + '</span></span>';
  }

  if (typeof module !== 'undefined' && module.exports) module.exports = { cardHtml, format, signed, pct, escapeHtml };
  if (typeof document === 'undefined') return;

  const $ = id => document.getElementById(id);
  let game = null;
  let generation = 0;
  let timer = null;
  let toastTimer = null;
  let busy = false;
  let autopilot = false;
  let fast = false;
  let completed = false;
  let handNumber = 0;
  let decisions = [];
  let analysisCache = null;
  let lastAnnounced = '';
  const session = { hands: 0, net: 0, decisions: 0 };
  const mobile = window.matchMedia('(max-width: 620px)');

  function notify(message) {
    $('toast').textContent = message;
    $('toast').hidden = false;
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => { $('toast').hidden = true; }, 3400);
  }

  function error(message) {
    $('errorMessage').textContent = message;
    $('errorMessage').hidden = false;
  }

  function cancelWork() {
    generation++;
    clearTimeout(timer);
    timer = null;
    fast = false;
    busy = false;
  }

  function createHand(mode) {
    if (mode === 'redeal' && game && game.state.done) return;
    cancelWork();
    const previous = game ? game.state : null;
    const count = Number($('seatCount').value);
    let stacks = Array(count).fill(1000);
    let dealer = previous ? (previous.dealer + (mode === 'redeal' ? 0 : 1)) % count : 0;
    let refilled = 0;
    if (previous && mode !== 'reset') {
      stacks = stacks.map((_, i) => {
        const p = previous.players[i];
        const value = p ? (mode === 'redeal' ? p.startStack : p.stack) : 1000;
        if (value <= 0) { refilled++; return 1000; }
        return value;
      });
    }
    if (mode === 'reset') {
      session.hands = 0; session.net = 0; session.decisions = 0;
      handNumber = 0; dealer = 0;
    }
    try {
      game = PokerEngine.createGame({ count, stacks, dealer, smallBlind: 5, bigBlind: 10 });
    } catch (e) { error('发牌失败：' + e.message); return; }
    handNumber++;
    decisions = [];
    completed = false;
    autopilot = false;
    analysisCache = null;
    lastAnnounced = '';
    $('reviewSection').hidden = true;
    $('errorMessage').hidden = true;
    document.querySelector('.intro-copy').textContent = '先想清楚，再做选择。和 ' + (count - 1) + ' 位不同风格的牌友一起练习。';
    $('pokerTable').setAttribute('aria-label', count + ' 人德州扑克牌桌');
    render();
    scheduleBot();
    if (refilled) notify(refilled + ' 位筹码用尽的玩家已补至 1,000，继续练习。');
    else if (mode === 'redeal') notify('已恢复本手开始时的筹码，重新发牌。人数设置已生效。');
    else if (mode === 'reset') notify('练习记录与筹码已重置。');
  }

  function styleFor(seat) {
    return PokerCoach.styles[seat] || PokerCoach.styles[0];
  }

  function currentAnalysis() {
    if (!game || game.state.done || game.state.actor !== 0) return null;
    const key = generation + ':' + game.state.log.length + ':' + game.state.street;
    if (analysisCache && analysisCache.key === key) return analysisCache;
    const view = copy(game.view(0));
    const analysis = PokerCoach.analyze(view, { samples: 80 });
    analysisCache = { key, view, analysis };
    return analysisCache;
  }

  function renderSeats() {
    const state = game.state;
    const winners = state.done && state.result ? new Set(state.result.payouts.filter(p => p.amount > 0).map(p => p.seat)) : new Set();
    const positions = mobile.matches ? MOBILE_POSITIONS : DESKTOP_POSITIONS;
    $('seats').innerHTML = state.players.map((p, i) => {
      let pos = positions[i];
      if (state.players.length === 8 && !mobile.matches && i > 0) {
        const eight = [[17, 76], [9, 44], [27, 19], [50, 16], [73, 19], [91, 44], [83, 76]];
        pos = eight[i - 1];
      }
      const reveal = i === 0 || state.done;
      const hole = (p.hole || []).map(c => cardHtml(reveal ? c : null, 'small')).join('');
      const recent = state.log.slice().reverse().find(l => l.seat === i && ['fold', 'check', 'call', 'raise'].includes(l.type));
      const status = p.folded ? '已弃牌' : p.allIn ? '全下' : state.done ? (winners.has(i) ? '赢得底池' : '本手结束') : state.actor === i ? (i === 0 && !autopilot ? '轮到你了' : '正在思考…') : recent ? recent.text : '等待行动';
      let markers = '';
      if (state.dealer === i) markers += '<span class="position-marker" title="庄家按钮">D</span>';
      if (state.smallBlindSeat === i) markers += '<span class="position-marker blind" title="小盲注">SB</span>';
      if (state.bigBlindSeat === i) markers += '<span class="position-marker blind" title="大盲注">BB</span>';
      return '<div class="seat' + (i === 0 ? ' is-human' : '') + (state.actor === i && !state.done ? ' is-actor' : '') + (p.folded && !state.done ? ' is-folded' : '') + (winners.has(i) ? ' is-winner' : '') + '" style="left:' + pos[0] + '%;top:' + pos[1] + '%" aria-label="' + escapeHtml(p.name) + '，筹码 ' + format(p.stack) + (p.folded ? '，已弃牌' : '') + '"><div class="hole-cards">' + hole + '</div><div class="seat-info">' + markers + '<div class="seat-name">' + escapeHtml(p.name) + (i === 0 ? '<span class="seat-style">' + (autopilot ? '托管中' : '你的位置') + '</span>' : '') + '</div><span class="seat-stack">' + format(p.stack) + '</span></div><div class="seat-action">' + escapeHtml(status) + '</div>' + (p.streetBet > 0 && !state.done ? '<span class="seat-bet">投入 ' + format(p.streetBet) + '</span>' : '') + '</div>';
    }).join('');
  }

  function renderBoard() {
    const state = game.state;
    $('board').innerHTML = Array.from({ length: 5 }, (_, i) => state.board[i] == null ? '<span class="card empty" aria-label="尚未发出的公共牌"></span>' : cardHtml(state.board[i])).join('');
    $('streetLabel').textContent = state.done ? '本 手 结 束' : STREETS[state.street];
    const total = state.done && state.result ? state.result.payouts.reduce((sum, p) => sum + p.amount, 0) : state.pot;
    $('potCaption').textContent = state.done ? '已分配底池' : '底池';
    $('potValue').textContent = format(total);
    $('tableMessage').textContent = state.done ? (state.result.reason === 'fold' ? '其余玩家弃牌，本手直接结束' : '底牌已公开 · 向下查看复盘') : state.actor === 0 ? (autopilot ? '托管正在替你行动' : '轮到你了 · 慢慢想，不限时') : state.players[state.actor] ? state.players[state.actor].name + ' 正在行动' : '正在发牌';
  }

  function legalRaiseBounds(legal) {
    return { min: Math.min(legal.minRaiseTo, legal.maxRaiseTo), max: legal.maxRaiseTo };
  }

  function renderControls() {
    const state = game.state;
    const human = state.actor === 0 && !state.done && !autopilot && !fast && !busy;
    const legal = human ? game.legalActions() : null;
    $('foldButton').disabled = !human || !legal.fold;
    $('callButton').disabled = !human || (!legal.check && !legal.call);
    $('raiseButton').disabled = !human || !legal.canRaise;
    $('callButton').innerHTML = (legal && legal.call > 0 ? '跟注 ' + format(legal.call) : '过牌') + ' <kbd>C</kbd>';
    $('nextHand').disabled = !state.done;
    $('newHand').disabled = state.done;
    $('autopilot').disabled = state.done || fast;
    $('autopilot').setAttribute('aria-pressed', String(autopilot));
    $('autopilot').textContent = autopilot ? '取消托管' : '本局托管';
    $('fastForward').disabled = state.done || fast;
    $('fastForward').innerHTML = fast ? '正在完成…' : '快速看结果 <span aria-hidden="true">↗</span>';
    $('actionEyebrow').textContent = state.done ? 'HAND COMPLETE' : human ? 'YOUR MOVE' : autopilot || fast ? 'AUTOPILOT' : 'TAKE A BREATH';
    $('actionTitle').textContent = state.done ? '这一手已结束' : human ? '轮到你，怎么打？' : autopilot || fast ? '放轻松，观察牌局' : state.players[0].folded ? '你已弃牌，牌局继续' : '等待牌友行动';
    $('actionContext').textContent = state.done ? '所有底牌和复盘已在下方展开。下一手会保留筹码，并轮换庄家按钮。' : human ? (legal.call > 0 ? '当前需跟注 ' + format(legal.call) + '，你还有 ' + format(state.players[0].stack) + '。先想想对手会拿什么牌。' : '目前无需补筹码，可以免费过牌，也可以主动下注。') : state.players[0].folded ? '牌友会自动打完。你可以继续观察，或快速看到结果。' : autopilot || fast ? '教练使用同样的公开信息替你行动；本局结束后仍可查看全部底牌。' : '观察谁在主动加注、谁愿意跟注，以及你的行动位置。';
    const raiseEnabled = human && legal.canRaise;
    [$('raiseRange'), $('raiseAmount'), ...document.querySelectorAll('[data-preset]')].forEach(el => { el.disabled = !raiseEnabled; });
    if (raiseEnabled) {
      const bounds = legalRaiseBounds(legal);
      const signature = generation + ':' + state.log.length;
      if ($('raiseAmount').dataset.turn !== signature) {
        $('raiseAmount').dataset.turn = signature;
        $('raiseAmount').value = bounds.min;
      }
      $('raiseRange').min = $('raiseAmount').min = bounds.min;
      $('raiseRange').max = $('raiseAmount').max = bounds.max;
      syncRaise($('raiseAmount').value, false);
    }
    $('handNumber').textContent = '第 ' + handNumber + ' 手 · 按钮位置每手轮换';
    $('handsCount').textContent = format(session.hands);
    $('netTotal').textContent = signed(session.net);
    $('decisionsCount').textContent = format(session.decisions);
    const recent = state.log[state.log.length - 1];
    if (recent) {
      const announcement = recent.text;
      if (announcement !== lastAnnounced) {
        $('liveStatus').textContent = announcement;
        lastAnnounced = announcement;
      }
    }
  }

  function renderCoach() {
    const state = game.state;
    const stage = STAGES[state.done ? 'showdown' : state.street] || STAGES.preflop;
    $('stageNumber').textContent = stage[0]; $('stageTitle').textContent = stage[1]; $('stageExplanation').textContent = stage[2];
    const enabled = $('hintsToggle').checked;
    $('hintContent').hidden = !enabled; $('estimateNote').hidden = !enabled; $('hintOff').hidden = enabled;
    let data = null;
    if (state.actor === 0 && !state.done && !autopilot && !fast) data = currentAnalysis();
    const legal = state.actor === 0 && !state.done ? game.legalActions() : null;
    $('toCall').textContent = legal ? format(legal.call) : '—';
    const callPrice = legal ? PokerCoach.priceCall(game.view(0)) : null;
    const odds = callPrice ? callPrice.potOdds : 0;
    $('potOdds').textContent = legal ? pct(odds) : '—';
    if (data) {
      $('equityValue').textContent = data.analysis.exactSplit ? '确定平分权益 = ' + pct(data.analysis.equity) : '随机手牌权益 ≈ ' + pct(data.analysis.equity);
      $('hintTitle').textContent = data.analysis.title;
      $('hintExplanation').textContent = data.analysis.explanation;
      $('hintCautions').innerHTML = (data.analysis.cautions || []).map(text => '<li>' + escapeHtml(text) + '</li>').join('');
    } else {
      $('equityValue').textContent = '仅依据可见信息';
      $('hintTitle').textContent = state.done ? '好决策，也可能输掉一手' : state.players[0].folded ? '弃牌后，也能继续学习' : '先看看桌上的行动';
      $('hintExplanation').textContent = state.done ? '结果已经确定，下面的决策复盘会保留当时的公共牌与建议，帮助你区分过程和运气。' : state.players[0].folded ? '注意后续下注与公开底牌。无需因为后来本可成牌，就否定当时合理的弃牌。' : '轮到你时，这里会根据底牌、公共牌与下注信息给出参考。先观察对手的节奏与位置。';
      $('hintCautions').innerHTML = '';
    }
  }

  function render() {
    if (!game) return;
    if (game.state.done && !completed) completeHand();
    renderSeats(); renderBoard(); renderControls(); renderCoach();
  }

  function syncRaise(value, fromNumber) {
    if (!game || game.state.done || game.state.actor !== 0) return;
    const legal = game.legalActions();
    if (!legal.canRaise) return;
    const bounds = legalRaiseBounds(legal);
    const parsed = Math.round(Number(value));
    const amount = Math.max(bounds.min, Math.min(bounds.max, Number.isFinite(parsed) ? parsed : bounds.min));
    $('raiseRange').value = amount;
    if (!fromNumber) $('raiseAmount').value = amount;
    $('raiseValue').textContent = format(amount);
    $('raiseButton').innerHTML = (amount === legal.maxRaiseTo ? '全下至 ' : '加注至 ') + format(amount) + ' <kbd>R</kbd>';
  }

  function takeHumanAction(type) {
    if (busy || fast || autopilot || !game || game.state.done || game.state.actor !== 0) return;
    const legal = game.legalActions();
    let action;
    if (type === 'fold') { if (!legal.fold) return; action = { type: 'fold' }; }
    else if (type === 'call') { if (!legal.check && !legal.call) return; action = { type: legal.check ? 'check' : 'call' }; }
    else {
      if (!legal.canRaise) return;
      const bounds = legalRaiseBounds(legal);
      const amount = Number($('raiseAmount').value);
      if (!Number.isInteger(amount) || amount < bounds.min || amount > bounds.max) { error('请输入 ' + format(bounds.min) + ' 至 ' + format(bounds.max) + ' 之间的整数。'); $('raiseAmount').focus(); return; }
      action = { type: 'raise', amount };
    }
    busy = true;
    $('errorMessage').hidden = true;
    try {
      const data = currentAnalysis();
      const snapshot = { view: copy(data.view), action: copy(action), analysis: copy(data.analysis) };
      game.act(action);
      decisions.push(snapshot);
      session.decisions++;
      analysisCache = null;
    } catch (e) { error('这次行动未执行：' + e.message); }
    busy = false;
    render(); scheduleBot();
  }

  function actBot() {
    const seat = game.state.actor;
    if (seat == null || game.state.done) return;
    const view = game.view(seat);
    const action = PokerCoach.chooseAction(view, styleFor(seat));
    game.act(action);
    analysisCache = null;
  }

  function scheduleBot() {
    if (fast) return;
    clearTimeout(timer);
    if (!game || game.state.done || (game.state.actor === 0 && !autopilot)) return;
    const token = generation;
    timer = setTimeout(() => {
      if (token !== generation || game.state.done || fast) return;
      try { actBot(); } catch (e) { error('牌友行动遇到问题：' + e.message + '。可重新发牌继续。'); return; }
      render(); scheduleBot();
    }, Number($('speed').value));
  }

  function finishFast() {
    if (!game || game.state.done || fast) return;
    clearTimeout(timer);
    fast = true;
    autopilot = true;
    const token = generation;
    let steps = 0;
    renderControls();
    function batch() {
      if (token !== generation) return;
      try {
        for (let i = 0; i < 25 && !game.state.done; i++) {
          if (++steps > 1600) throw new Error('本手行动超过保护上限');
          actBot();
        }
      } catch (e) { fast = false; autopilot = false; error('快速播放已停止：' + e.message); render(); return; }
      if (game.state.done) { fast = false; render(); }
      else { renderSeats(); renderBoard(); timer = setTimeout(batch, 0); }
    }
    timer = setTimeout(batch, 15);
  }

  function actionDescription(action, view) {
    if (action.type === 'fold') return '弃牌';
    if (action.type === 'check') return '过牌';
    if (action.type === 'call') return '跟注 ' + format(view.legal ? view.legal.call : 0);
    return '加注至 ' + format(action.amount);
  }

  function completeHand() {
    completed = true;
    clearTimeout(timer);
    const state = game.state;
    const net = state.players[0].stack - state.players[0].startStack;
    session.hands++;
    session.net += net;
    $('reviewSection').hidden = false;
    $('resultSummary').textContent = state.result.summary;
    $('resultNet').textContent = signed(net);
    $('resultNet').classList.toggle('negative', net < 0);
    $('revealNote').textContent = '练习模式：公开所有玩家底牌，包括已弃牌者。' + (state.result.reason === 'fold' ? '其余玩家均已弃牌，因此没有继续发公共牌；不虚构后续牌面。' : '牌型取底牌与公共牌中最好的五张；已弃牌者没有争夺底池的资格。');
    const payouts = {};
    state.result.payouts.forEach(p => { payouts[p.seat] = (payouts[p.seat] || 0) + p.amount; });
    $('revealGrid').innerHTML = state.players.map(p => {
      const net = p.stack - p.startStack;
      const hand = state.result.hands.find(h => h.seat === p.id);
      let detail = p.folded ? '已弃牌' : hand && hand.rank ? hand.rank.name : '无需摊牌';
      if (payouts[p.id]) detail += ' · 获得 ' + format(payouts[p.id]);
      return '<article class="reveal-item' + (payouts[p.id] ? ' winner' : '') + '"><div class="reveal-name">' + escapeHtml(p.name) + (payouts[p.id] ? '<span>获胜</span>' : '') + '</div><div class="hole-cards">' + p.hole.map(c => cardHtml(c, 'small')).join('') + '</div><p class="reveal-detail">' + escapeHtml(detail) + '</p><span class="reveal-net' + (net < 0 ? ' negative' : '') + '">' + signed(net) + '</span></article>';
    }).join('');
    $('decisionBadge').textContent = decisions.length;
    $('panelDecisions').innerHTML = decisions.length ? decisions.map((d, i) => {
      const review = PokerCoach.reviewDecision(d);
      const verdictName = { good: '思路合理', consider: '值得推敲', caution: '留意风险' }[review.verdict] || '回看思路';
      const equityLabel = d.analysis.exactSplit ? '当时确定平分权益 = ' : '当时随机手牌权益约 ';
      return '<article class="decision-card"><div class="decision-context"><span>第 ' + (i + 1) + ' 次 · ' + STREETS[d.view.street] + '</span><strong>' + actionDescription(d.action, d.view) + '</strong><span>当时底池 ' + format(d.view.pot) + '</span>' + (d.view.board.length ? '<div class="mini-board" aria-label="决策时的公共牌">' + d.view.board.map(c => cardHtml(c, 'small')).join('') + '</div>' : '') + '</div><div class="decision-text"><span class="decision-verdict ' + escapeHtml(review.verdict) + '">' + verdictName + '</span><h3>' + escapeHtml(review.title) + '</h3><p>' + escapeHtml(review.explanation) + '</p><p class="decision-estimate">' + equityLabel + pct(d.analysis.equity) + ' · 底池赔率 ' + pct(d.analysis.potOdds) + '。仅评估决策时的信息，不用最终结果倒推。</p></div></article>';
    }).join('') : '<p class="empty-review">本手没有自主决策记录。托管与快速播放的行动不会计入你的决策；下一手亲自做几个选择，再来看看思路。</p>';
    $('panelPlayers').innerHTML = '<div class="strategy-grid">' + state.players.map(p => {
      const style = styleFor(p.id);
      const summary = PokerCoach.summarizePlayer(p, state.log.filter(l => l.seat === p.id), style);
      return '<article class="strategy-card"><p class="eyebrow">' + escapeHtml(p.name) + ' · ' + escapeHtml(style.name) + (p.id === 0 ? '（仅托管参考）' : '') + '</p><h3>' + escapeHtml(summary.title) + '</h3><p>' + escapeHtml(summary.text) + '</p><p class="takeaway">' + escapeHtml(summary.takeaway) + '</p></article>';
    }).join('') + '</div>';
    const orderedStreets = ['preflop', 'flop', 'turn', 'river', 'showdown'];
    const allStreets = [...orderedStreets, ...new Set(state.log.map(l => l.street).filter(s => !orderedStreets.includes(s)))];
    let index = 0;
    $('panelHistory').innerHTML = allStreets.map(street => {
      const logs = state.log.filter(l => l.street === street);
      if (!logs.length) return '';
      return '<section class="history-street"><h3>' + escapeHtml(STREETS[street] || street || '结算') + '</h3><ol>' + logs.map(l => '<li' + (l.seat === 0 ? ' class="human-log"' : '') + '><span>' + String(++index).padStart(2, '0') + '</span><span>' + escapeHtml(l.text) + '</span></li>').join('') + '</ol></section>';
    }).join('');
  }

  function selectTab(name, focus) {
    document.querySelectorAll('[data-tab]').forEach(button => {
      const active = button.dataset.tab === name;
      button.setAttribute('aria-selected', String(active));
      button.tabIndex = active ? 0 : -1;
      $('panel' + button.dataset.tab).hidden = !active;
      if (active && focus) button.focus();
    });
  }

  function initialize() {
    if (!window.PokerEngine || !window.PokerCoach) { error('无法加载练习模块。请确保 index.html、engine.js、coach.js、app.js 和 styles.css 在同一文件夹。'); return; }
    $('foldButton').addEventListener('click', () => takeHumanAction('fold'));
    $('callButton').addEventListener('click', () => takeHumanAction('call'));
    $('raiseButton').addEventListener('click', () => takeHumanAction('raise'));
    $('raiseRange').addEventListener('input', event => syncRaise(event.target.value, false));
    $('raiseAmount').addEventListener('input', event => syncRaise(event.target.value, true));
    $('raiseAmount').addEventListener('change', event => syncRaise(event.target.value, false));
    document.querySelectorAll('[data-preset]').forEach(button => button.addEventListener('click', () => {
      if (!game || game.state.done || game.state.actor !== 0) return;
      const legal = game.legalActions();
      const call = legal.call;
      const amount = button.dataset.preset === 'min' ? Math.min(legal.minRaiseTo, legal.maxRaiseTo) : button.dataset.preset === 'all' ? legal.maxRaiseTo : game.state.currentBet + Math.max(game.state.minRaise, Math.round((game.state.pot + call) * (button.dataset.preset === 'half' ? 0.5 : 1)));
      syncRaise(amount, false);
    }));
    $('autopilot').addEventListener('click', () => { if (!game || game.state.done || fast) return; autopilot = !autopilot; render(); scheduleBot(); });
    $('fastForward').addEventListener('click', finishFast);
    $('newHand').addEventListener('click', () => createHand('redeal'));
    $('nextHand').addEventListener('click', () => { if (game && game.state.done) { createHand('next'); $('pokerTable').scrollIntoView({ behavior: window.matchMedia('(prefers-reduced-motion: reduce)').matches ? 'auto' : 'smooth', block: 'start' }); } });
    $('resetSession').addEventListener('click', () => createHand('reset'));
    $('seatCount').addEventListener('change', () => notify('已选 ' + $('seatCount').value + ' 人桌，下次发牌生效。'));
    $('speed').addEventListener('change', scheduleBot);
    $('hintsToggle').addEventListener('change', renderCoach);
    $('oddsInfo').addEventListener('click', () => { $('oddsExplanation').hidden = !$('oddsExplanation').hidden; $('oddsInfo').setAttribute('aria-expanded', String(!$('oddsExplanation').hidden)); });
    document.querySelectorAll('[data-tab]').forEach(button => {
      button.addEventListener('click', () => selectTab(button.dataset.tab, false));
      button.addEventListener('keydown', event => {
        const tabs = [...document.querySelectorAll('[data-tab]')];
        const index = tabs.indexOf(button);
        let next;
        if (event.key === 'ArrowRight') next = (index + 1) % tabs.length;
        if (event.key === 'ArrowLeft') next = (index + tabs.length - 1) % tabs.length;
        if (event.key === 'Home') next = 0;
        if (event.key === 'End') next = tabs.length - 1;
        if (next != null) { event.preventDefault(); selectTab(tabs[next].dataset.tab, true); }
      });
    });
    document.addEventListener('keydown', event => {
      if (event.repeat || event.ctrlKey || event.altKey || event.metaKey || event.shiftKey || /INPUT|SELECT|TEXTAREA/.test(event.target.tagName) || event.target.isContentEditable) return;
      const action = { f: 'fold', c: 'call', r: 'raise' }[event.key.toLowerCase()];
      if (action) { event.preventDefault(); takeHumanAction(action); }
    });
    const resize = () => { if (game) renderSeats(); };
    if (mobile.addEventListener) mobile.addEventListener('change', resize); else mobile.addListener(resize);
    createHand('initial');
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initialize); else initialize();
}());
